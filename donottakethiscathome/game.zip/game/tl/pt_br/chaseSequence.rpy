﻿# TODO: Translation updated at 2024-11-02 03:15

# game/chaseSequence.rpy:134
translate pt_br finalShowdownChase_8dabefc6:

    # ".."
    ".."

# game/chaseSequence.rpy:135
translate pt_br finalShowdownChase_a20cefa7:

    # "..."
    "..."

# game/chaseSequence.rpy:138
translate pt_br finalShowdownChase_28b3ac41:

    # you "!!"
    you "!!"

# game/chaseSequence.rpy:139
translate pt_br finalShowdownChase_d780f384:

    # you "{i}I'm back in the alley...{/i}"
    you "{i}Voltei pro beco...{/i}"

# game/chaseSequence.rpy:142
translate pt_br finalShowdownChase_f7ab12f7:

    # you "{i}It's not here... Good...{/i}"
    you "{i}Não tá aqui... Ainda bem...{/i}"

# game/chaseSequence.rpy:143
translate pt_br finalShowdownChase_06674a63:

    # you "{i}I think... {w}I think I need to get home...{/i}"
    you "{i}Acho... {w}Acho que preciso ir pra casa...{/i}"

# game/chaseSequence.rpy:146
translate pt_br finalShowdownChase_8dabefc6_1:

    # ".."
    ".."

# game/chaseSequence.rpy:147
translate pt_br finalShowdownChase_a20cefa7_1:

    # "..."
    "..."

# game/chaseSequence.rpy:148
translate pt_br finalShowdownChase_d545054f:

    # "I uh..."
    "Eu, hã..."

# game/chaseSequence.rpy:149
translate pt_br finalShowdownChase_0c089aed:

    # "...I step forward? {w}Out of... {w}the alley?"
    "...dou um passo à frente? {w}Saindo... {w}do beco?"

# game/chaseSequence.rpy:150
translate pt_br finalShowdownChase_dae0ec55:

    # you "..."
    you "..."

# game/chaseSequence.rpy:151
translate pt_br finalShowdownChase_edaac27f:

    # you "{i}This is gonna take some getting used to...{/i}"
    you "{i}Vou demorar um tempo pra me acostumar com isso...{/i}"

# game/chaseSequence.rpy:152
translate pt_br finalShowdownChase_c6ca505e:

    # "I-I step forward towards the entrance of the thankfully empty alley."
    "E-eu dou um passo à frente em direção à entrada do beco, que felizmente está vazio."

# game/chaseSequence.rpy:153
translate pt_br finalShowdownChase_a762f582:

    # "I'm almost out of this place..."
    "Tô quase fora daqui..."

# game/chaseSequence.rpy:154
translate pt_br finalShowdownChase_c23d8f1d:

    # "Almost home-{w=0.5}{nw}"
    "Quase em casa-{w=0.5}{nw}"

# game/chaseSequence.rpy:156
translate pt_br finalShowdownChase_f29a87f6:

    # "{b}{color=#FF0000}when \ s u d d e n l y y y y y . . . {/color}{/b}" with hpunch
    "{b}{color=#FF0000}quando \ d e \ r e p e n t e e e e . . . {/color}{/b}" with hpunch

# game/chaseSequence.rpy:157
translate pt_br finalShowdownChase_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/chaseSequence.rpy:161
translate pt_br finalShowdownChase_ba5843f8:

    # cat "{size=+15}YOUUUU!!{/size}" with vpunch
    cat "{size=+15}VOCÊEEE!!{/size}" with vpunch

# game/chaseSequence.rpy:162
translate pt_br finalShowdownChase_56ebb028:

    # you "!!!"
    you "!!!"

# game/chaseSequence.rpy:164
translate pt_br finalShowdownChase_d9cfa56f:

    # cat "{size=+20}YOU'RE{/size}{w=0.5}{nw}" with vpunch
    cat "{size=+20}VOCÊ{/size}{w=0.5}{nw}" with vpunch

# game/chaseSequence.rpy:168
translate pt_br finalShowdownChase_c62afa20:

    # cat "{size=+25}NOT{/size}{w=0.5}{nw}" with vpunch
    cat "{size=+25}NÃO VAI{/size}{w=0.5}{nw}" with vpunch

# game/chaseSequence.rpy:172
translate pt_br finalShowdownChase_66fe51fb:

    # cat "{size=+30}{b}GOING{/b}{/size}{w=0.5}{nw}" with vpunch
    cat "{size=+30}{b}A LUGAR{/b}{/size}{w=0.5}{nw}" with vpunch

# game/chaseSequence.rpy:176
translate pt_br finalShowdownChase_f73f59ae:

    # cat "{size=+35}{b}{i}ANYWHERE!!{/i}{/b}{/size}" with vpunch
    cat "{size=+35}{b}{i}NENHUM!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:224
translate pt_br gotYou_9ea2f78c:

    # " "
    "\ "

# game/chaseSequence.rpy:232
translate pt_br gotYou_9ea2f78c_1:

    # " "
    "\ "

# game/chaseSequence.rpy:240
translate pt_br gotYou_9ea2f78c_2:

    # " "
    "\ "

# game/chaseSequence.rpy:248
translate pt_br gotYou_9ea2f78c_3:

    # " "
    "\ "

# game/chaseSequence.rpy:256
translate pt_br gotYou_9ea2f78c_4:

    # " "
    "\ "

# game/chaseSequence.rpy:263
translate pt_br gotYou_9ea2f78c_5:

    # " "
    "\ "

# game/chaseSequence.rpy:270
translate pt_br gotYou_9ea2f78c_6:

    # " "
    "\ "

# game/chaseSequence.rpy:277
translate pt_br gotYou_9ea2f78c_7:

    # " "
    "\ "

# game/chaseSequence.rpy:341
translate pt_br forcedMenu_11e8f724:

    # "Dammit..! It overrode my choice!"
    "Merda..! Me leu como um livro!"

# game/chaseSequence.rpy:342
translate pt_br forcedMenu_11da515d:

    # "Where the hell do I go?!"
    "Pra onde eu vou?!"

# game/chaseSequence.rpy:350
translate pt_br forcedMenu_80dcf355:

    # "Anywhere but here!"
    "Qualquer lugar, menos aqui!"

# game/chaseSequence.rpy:355
translate pt_br forcedMenu_80dcf355_1:

    # "Anywhere but here!"
    "Qualquer lugar, menos aqui!"

# game/chaseSequence.rpy:360
translate pt_br forcedMenu_80dcf355_2:

    # "Anywhere but here!"
    "Qualquer lugar, menos aqui!"

# game/chaseSequence.rpy:370
translate pt_br forcedMenu_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/chaseSequence.rpy:371
translate pt_br forcedMenu_bd221748:

    # you "Did I... do it..?"
    you "Eu... consegui..?"

# game/chaseSequence.rpy:372
translate pt_br forcedMenu_7f923745:

    # who "thread unraveling... {w}many us escape... {w}many free now..."
    who "fio se desenrolando... {w}muitos nós escapam... {w}muitos livres agora..."

# game/chaseSequence.rpy:373
translate pt_br forcedMenu_3c5590a3:

    # who "{b}{color=#FF0000}I T{/color}{/b} losing us... {w}losing strength..."
    who "{b}{color=#FF0000}I S S O{/color}{/b} nos perdendo... {w}perdendo força..."

# game/chaseSequence.rpy:374
translate pt_br forcedMenu_1c5a04cd:

    # who "your escape... {w}possible now..."
    who "sua fuga... {w}possível agora..."

# game/chaseSequence.rpy:376
translate pt_br forcedMenu_0f670756:

    # cat "{size=+25}{b}{i}NOOO!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}NÃOOO!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:378
translate pt_br forcedMenu_2dadc39a:

    # cat "{size=+25}{b}{i}YOU!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}VOCÊ!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:380
translate pt_br forcedMenu_7e3cb0cc:

    # cat "{size=+25}{b}{i}ARE!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}É!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:382
translate pt_br forcedMenu_3291da01:

    # cat "{size=+25}{b}{i}{color=#FF0000}MINE!!{/color}{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}{color=#FF0000}MEU!!{/color}{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:383
translate pt_br forcedMenu_32f51c80:

    # who "{alpha=0.8}we go ahead... {w}we go free...{/alpha}"
    who "{alpha=0.8}nós seguimos em frente... {w}nós nos libertamos...{/alpha}"

# game/chaseSequence.rpy:384
translate pt_br forcedMenu_c54506c0:

    # who "{alpha=0.5}thank you...{/alpha}"
    who "{alpha=0.5}obrigado...{/alpha}"

# game/chaseSequence.rpy:385
translate pt_br forcedMenu_63e75705:

    # who "{i}{alpha=0.3}thank you...{/alpha}{/i}"
    who "{i}{alpha=0.3}obrigado...{/alpha}{/i}"

# game/chaseSequence.rpy:386
translate pt_br forcedMenu_6f50b679:

    # who "..."
    who "..."

# game/chaseSequence.rpy:394
translate pt_br forcedMenu_dae0ec55:

    # you "..."
    you "..."

# game/chaseSequence.rpy:395
translate pt_br forcedMenu_62914fe0:

    # you "Thank you too... all of you..."
    you "Obrigado também... a todos vocês..."

# game/chaseSequence.rpy:398
translate pt_br forcedMenu_dae0ec55_1:

    # you "..."
    you "..."

# game/chaseSequence.rpy:399
translate pt_br forcedMenu_0ac72f08:

    # you "I won't forget you..."
    you "Eu não vou esquecer vocês..."

# game/chaseSequence.rpy:499
translate pt_br oldTheater5a_b3a0900b:

    # you "Crap! A dead end..!"
    you "Droga! Sem saída..!"

# game/chaseSequence.rpy:501
translate pt_br oldTheater5a_0b089920:

    # cat "{size=+25}{b}{i}STOP RUNNING!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}PARA DE CORRER!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:502
translate pt_br oldTheater5a_28b3ac41:

    # you "!!"
    you "!!"

# game/chaseSequence.rpy:557
translate pt_br oldTheater5c_c52bbb18:

    # cat "{size=+15}{b}{i}GET BACK HERE!!{/i}{/b}{/size}" with vpunch
    cat "{size=+15}{b}{i}VOLTA AQUI!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:558
translate pt_br oldTheater5c_dae0ec55:

    # you "..."
    you "..."

# game/chaseSequence.rpy:649
translate pt_br newCinema5a_7e60013d:

    # you "Dead end..? Where do I-"
    you "Sem saída..? Pra onde eu-"

# game/chaseSequence.rpy:651
translate pt_br newCinema5a_2dea9288:

    # cat "{size=+25}{b}{i}FOUND YOU~!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}TE ACHEI~!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:652
translate pt_br newCinema5a_28b3ac41:

    # you "!!"
    you "!!"

# game/chaseSequence.rpy:709
translate pt_br newCinema5c_c52bbb18:

    # cat "{size=+15}{b}{i}GET BACK HERE!!{/i}{/b}{/size}" with vpunch
    cat "{size=+15}{b}{i}VOLTA AQUI!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:710
translate pt_br newCinema5c_dae0ec55:

    # you "..."
    you "..."

# game/chaseSequence.rpy:798
translate pt_br carnival5a_af46df21:

    # you "How do I get out?!"
    you "Como eu saio daqui?!"

# game/chaseSequence.rpy:800
translate pt_br carnival5a_9290bf8e:

    # cat "{size=+25}{b}{i}NO ESCAPE!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}NÃO HÁ FUGA!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:801
translate pt_br carnival5a_28b3ac41:

    # you "!!"
    you "!!"

# game/chaseSequence.rpy:854
translate pt_br carnival5c_c52bbb18:

    # cat "{size=+15}{b}{i}GET BACK HERE!!{/i}{/b}{/size}" with vpunch
    cat "{size=+15}{b}{i}VOLTA AQUI!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:855
translate pt_br carnival5c_dae0ec55:

    # you "..."
    you "..."

# game/chaseSequence.rpy:967
translate pt_br dogPark5a_5d305961:

    # you "Damn! Gotta escape..!"
    you "Porra! Tenho que escapar..!"

# game/chaseSequence.rpy:969
translate pt_br dogPark5a_cf455219:

    # cat "{size=+25}{b}GOT YOU {i}NOW!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}TE PEGUEI {i}AGORA!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:970
translate pt_br dogPark5a_28b3ac41:

    # you "!!"
    you "!!"

# game/chaseSequence.rpy:1025
translate pt_br dogPark5c_c52bbb18:

    # cat "{size=+15}{b}{i}GET BACK HERE!!{/i}{/b}{/size}" with vpunch
    cat "{size=+15}{b}{i}VOLTA AQUI!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1026
translate pt_br dogPark5c_dae0ec55:

    # you "..."
    you "..."

# game/chaseSequence.rpy:1037
translate pt_br street1_0f670756:

    # cat "{size=+25}{b}{i}NOOO!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}NÃOOO!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1084
translate pt_br street3_85039274:

    # cat "{size=+25}{b}{i}COME BACK!!{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}VOLTA!!{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1131
translate pt_br street5_3ef5df1c:

    # cat "{size=+25}{b}{i}{color=#FF0000}COME BACK!!{/color}{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}{color=#FF0000}VOLTA!!{/color}{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1159
translate pt_br apt1_cad1cfa2:

    # cat "{size=+25}{b}{i}{color=#FF0000}PLEASE!!{/color}{/i}{/b}{/size}" with vpunch
    cat "{size=+25}{b}{i}{color=#FF0000}POR FAVOR!!{/color}{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1186
translate pt_br apt2_8805a939:

    # cat "{size=+20}{b}{i}{color=#FF0000}DON'T LEAVE ME!!{/color}{/i}{/b}{/size}" with vpunch
    cat "{size=+20}{b}{i}{color=#FF0000}NÃO ME DEIXA!!{/color}{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1213
translate pt_br apt3_3088931f:

    # cat "{size=+15}{b}{i}{color=#FF0000}I'LL DIE WITHOUT YOU!!{/color}{/i}{/b}{/size}" with vpunch
    cat "{size=+15}{b}{i}{color=#FF0000}VOU MORRER SEM VOCÊ!!{/color}{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1240
translate pt_br apt4_d1378a7d:

    # cat "{size=+10}{b}{i}{color=#FF0000}I'LL DIE!!{/color}{/i}{/b}{/size}" with vpunch
    cat "{size=+10}{b}{i}{color=#FF0000}VOU MORRER!!{/color}{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1268
translate pt_br apt5_9f2b0199:

    # cat "{size=+5}{b}{i}{color=#FF0000}I'LL DIE!!{/color}{/i}{/b}{/size}" with vpunch
    cat "{size=+5}{b}{i}{color=#FF0000}VOU MORRER!!{/color}{/i}{/b}{/size}" with vpunch

# game/chaseSequence.rpy:1288
translate pt_br apt5_b75195fe:

    # cat "WAIT..!"
    cat "ESPERA..!"

# game/chaseSequence.rpy:1294
translate pt_br apt5_3e0cf073:

    # cat "{size=-5}Wait...{/size}"
    cat "{size=-5}Espera...{/size}"

# game/chaseSequence.rpy:1309
translate pt_br chaseFail_436e4a4f:

    # "I need to dodge AWAY from it!"
    "Preciso fugir PARA LONGE disso!"

translate pt_br strings:

    # game/chaseSequence.rpy:290
    old "GO LEFT!"
    new "IR PRA ESQUERDA!"

    # game/chaseSequence.rpy:290
    old "GO BACK!"
    new "IR PRA TRÁS!"

    # game/chaseSequence.rpy:290
    old "GO RIGHT!"
    new "IR PRA DIREITA!"

    # game/chaseSequence.rpy:326
    old "Go home!!"
    new "Ir pra casa!!"

    # game/chaseSequence.rpy:346
    old "I've got to escape!"
    new "Tenho que fugir!"

    # game/chaseSequence.rpy:346
    old "go WATCH a {b}movie{/b}"
    new "ir ASSISTIR um {b}filme{/b}"

    # game/chaseSequence.rpy:346
    old "go {b}to{/b} the CARNIVAL"
    new "ir {b}ao{/b} FESTIVAL"

    # game/chaseSequence.rpy:346
    old "GO to {b}dog{/b} park"
    new "IR ao parque para {b}cachorros{/b}"

    # game/chaseSequence.rpy:401
    old "They were right... My choice is back!"
    new "Eles estavam certos... Minha escolha voltou!"

    # game/chaseSequence.rpy:408
    old "go to old theater."
    new "ir ao cinema antigo."

    # game/chaseSequence.rpy:408
    old "go to new cinema."
    new "ir ao cinema novo."

    # game/chaseSequence.rpy:1277
    old "PUSH FORWARD!"
    new "VÁ EM FRENTE!"

    # game/chaseSequence.rpy:1304
    old "Persist?"
    new "Persistir?"

    # game/chaseSequence.rpy:1304
    old "Give up?"
    new "Desistir?"

    old "{alpha=1}Don't give in to it...{/alpha}"
    new "{alpha=1}Não deixe isso te vencer...{/alpha}"

    old "{alpha=0.75}Keep going...{/alpha}"
    new "{alpha=0.75}Continue...{/alpha}"

    old "{alpha=0.5}{color=#FF0000}IT's{/color} power is fading...{/alpha}"
    new "{alpha=0.5}O poder {color=#FF0000}DISSO{/color} está enfraquecendo...{/alpha}"

    old "{alpha=0.25}You're almost there...{/alpha}"
    new "{alpha=0.25}Você está quase lá...{/alpha}"

    old "{alpha=0.2}You have the strength to escape...{/alpha}"
    new "{alpha=0.2}Você tem a força para fugir...{/alpha}"

    old "{alpha=0.2}At the end of this chaos...{/alpha}"
    new "{alpha=0.2}Quando esse caos acabar...{/alpha}"

    old "{alpha=0.2}You will be okay...{/alpha}"
    new "{alpha=0.2}Você estará bem...{/alpha}"

    old "{alpha=0.2}We are with you...{/alpha}"
    new "{alpha=0.2}Estamos com você...{/alpha}"
