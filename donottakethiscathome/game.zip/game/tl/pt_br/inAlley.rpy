﻿# TODO: Translation updated at 2024-11-02 03:15

# game/inAlley.rpy:743
translate pt_br inAlley_start_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:746
translate pt_br inAlley_start_28a9f6c1:

    # "{b}{size=-10}You are not ready.{/size}{/b}"
    "{b}{size=-10}Você não está pronto.{/size}{/b}"

# game/inAlley.rpy:754
translate pt_br inAlley_start_e3e320e6:

    # "Only one thing left..."
    "Só mais uma coisa..."

# game/inAlley.rpy:755
translate pt_br inAlley_start_42b896f8:

    # "So..."
    "Então..."

# game/inAlley.rpy:756
translate pt_br inAlley_start_71219ec6:

    # "What should you do with a cat that has been {i}very...{/i}"
    "O que você deveria fazer com um gato que tem sido {i}muito...{/i}"

# game/inAlley.rpy:757
translate pt_br inAlley_start_8794b742:

    # "{i}very...{/i}"
    "{i}muito...{/i}"

# game/inAlley.rpy:758
translate pt_br inAlley_start_ba6b8484:

    # "{i}{size=+10}very...{/size}{/i}"
    "{i}{size=+10}muito...{/size}{/i}"

# game/inAlley.rpy:759
translate pt_br inAlley_start_7cf748e5:

    # "{color=#FF0000}{b}n a u g h t y . . ?{/b}{/color}"
    "{color=#FF0000}{b}l e v a d o . . ?{/b}{/color}"

# game/inAlley.rpy:766
translate pt_br leaveCat_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:767
translate pt_br leaveCat_569a4a54:

    # "You don't think it's a good idea to get the cat's hopes up of having someone look after it if you're not willing to commit."
    "Você não acha uma boa ideia dar esperanças para o gato de que alguém vai cuidar dele se você não está disposto a se comprometer."

# game/inAlley.rpy:768
translate pt_br leaveCat_0035fbdc:

    # "What if it gets attached and somehow tracks you down back to your home?"
    "E se ele se apegar, e de alguma forma, te seguir até sua casa?"

# game/inAlley.rpy:769
translate pt_br leaveCat_5330941f:

    # "{size=-10}You'd never get away from it, then.{/size}{w=0.4}{nw}"
    "{size=-10}Aí sim, você nunca conseguiria se livrar dele.{/size}{w=0.4}{nw}"

# game/inAlley.rpy:770
translate pt_br leaveCat_a85b90f1:

    # you "Sorry... See you around, I guess."
    you "Foi mal... Te vejo por aí, eu acho."

# game/inAlley.rpy:771
translate pt_br leaveCat_21aa06c6:

    # "You stand up, the cat watching your every move."
    "Você se levanta, com o gato observando cada movimento seu."

# game/inAlley.rpy:775
translate pt_br leaveCat_bcd29f0b:

    # "You make it halfway out of the alley when the cat meows almost pitifully at you."
    "Você chega à metade do caminho pra sair do beco quando o gato mia quase como se quisesse te fazer sentir pena."

# game/inAlley.rpy:782
translate pt_br leaveCat_708ef71a:

    # cat "Meoww... Meoww... Meowwww..."
    cat "Miaau... Miaau... Miaaaau..."

# game/inAlley.rpy:784
translate pt_br leaveCat_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:793
translate pt_br leaveCat_9590def2:

    # "No. Nope. You need to nip this in the bud and get on with your day."
    "Não. De jeito nenhum. Você precisa cortar isso pela raiz e seguir com o seu dia."

# game/inAlley.rpy:794
translate pt_br leaveCat_c45c05a0:

    # "It's what's best for the both of you."
    "É o melhor para vocês dois."

# game/inAlley.rpy:798
translate pt_br leaveCat_57513084:

    # "You leave the alley and continue on your way."
    "Você sai do beco e segue seu caminho."

# game/inAlley.rpy:799
translate pt_br leaveCat_b844458f:

    # you "Wait, what was I doing..?"
    you "Espera, o que eu estava fazendo..?"

# game/inAlley.rpy:800
translate pt_br leaveCat_8b6a5b93:

    # "In all the excitement of dealing with your furry dilemma..."
    "Na correria de lidar com seu problema peludo..."

# game/inAlley.rpy:801
translate pt_br leaveCat_5dec36ba:

    # "...you'd forgotten that you still hadn't decided on what you were going to do for your day off."
    "...Você havia se esquecido de que ainda não tinha decidido o que faria no seu dia de folga."

# game/inAlley.rpy:805
translate pt_br leaveCat_cda3a886:

    # "Awwww~"
    "Owwwnt~"

# game/inAlley.rpy:806
translate pt_br leaveCat_f75bff4c:

    # "How are you supposed to walk away from {i}that?{/i}"
    "Como você poderia deixar essa {i}coisinha{/i} para trás?"

# game/inAlley.rpy:807
translate pt_br leaveCat_f3abd822:

    # "What kind of {b}monster{/b} would you be if you could?"
    "Que tipo de {b}monstro{/b} você seria se deixasse?"

# game/inAlley.rpy:827
translate pt_br goToMovies_74698f4f:

    # "It's been a while since a film came out that looked interesting enough for you to drag yourself to a movie theater..."
    "Já faz um tempo que lançou um filme que parecesse interessante o suficiente para você ir ao cinema..."

# game/inAlley.rpy:828
translate pt_br goToMovies_16041c5e:

    # "...but there's a showing of one such film at the old theater."
    "...mas um desses filmes está passando no cinema antigo."

# game/inAlley.rpy:829
translate pt_br goToMovies_08ebae1d:

    # "The movie was a little too niche to be picked up by the new cinema that opened right across the street."
    "O filme era nichado demais para ser exibido no cinema novo que abriu bem do outro lado da rua."

# game/inAlley.rpy:830
translate pt_br goToMovies_b01bac60:

    # "That's okay though. You're not exactly a fan of the crowds."
    "Mas tudo bem. Você não é exatamente fã de multidões."

# game/inAlley.rpy:831
translate pt_br goToMovies_6430cdc2:

    # "And nothing ruins the experience of watching a new movie for you more than a noisy audience."
    "E nada estraga mais a experiência de assistir a um filme novo para você do que um público barulhento."

# game/inAlley.rpy:841
translate pt_br moviesMenu_927147c9:

    # "You don’t know why...{w} but you don’t really feel great about the idea of being alone right now."
    "Você não sabe porque...{w} mas você não se sente muito bem com a idea de estar sozinho agora."

# game/inAlley.rpy:853
translate pt_br oldTheater_1be5a36c:

    # "You eagerly buy your ticket from the kind old man in the booth and head inside."
    "Você compra ansiosamente seu ingresso com o gentil senhor na bilheteira e entra."

# game/inAlley.rpy:857
translate pt_br oldTheater_db3599c5:

    # "It’s barren of any trace of other people and the décor looks like it hasn’t changed since the eighties..."
    "Não tem nenhum sinal de vida, e a decoração parece que não mudou desde os anos oitenta..."

# game/inAlley.rpy:858
translate pt_br oldTheater_77b6ae49:

    # "...maybe even the seventies."
    "...talvez até setenta."

# game/inAlley.rpy:859
translate pt_br oldTheater_599278f5:

    # "But it’s what you were counting on."
    "Mas é exatamente o que você esperava."

# game/inAlley.rpy:860
translate pt_br oldTheater_7ad62eb8:

    # "You consider buying some popcorn..."
    "Você pensa em comprar um pouco de pipoca..."

# game/inAlley.rpy:861
translate pt_br oldTheater_025c7a51:

    # "...but can’t help but be concerned that everything at the concession stand might be expired."
    "...mas não consegue não se preocupar de que tudo no quiosque possa estar vencido."

# game/inAlley.rpy:864
translate pt_br oldTheater_52bad82a:

    # "You move on and walk through the halls, finally locating the theater designated on your ticket stub."
    "Você continua e percorre os corredores, finalmente encontrando a sala indicada no seu bilhete."

# game/inAlley.rpy:867
translate pt_br oldTheater_2bf14d35:

    # "As expected, the theater your movie will be playing in is completely empty."
    "Como esperado, a sala que seu filme está sendo exibido está completamente vazia."

# game/inAlley.rpy:868
translate pt_br oldTheater_5a0a5807:

    # "Perfect."
    "Perfeito."

# game/inAlley.rpy:869
translate pt_br oldTheater_d0351c7d:

    # "You pick a spot right in the middle, even counting the seats and taking into consideration the gap of the staircase."
    "Você escolhe um lugar bem no meio, contando os assentos e levando em consideração até o espaço das escadas."

# game/inAlley.rpy:873
translate pt_br oldTheater_408d2f47:

    # "As you settle in, the dim lights fade away leaving the room pitch black for a few seconds..."
    "Enquanto você se acomoda, as luzes fracas se apagam, deixando a sala completamente escura por alguns segundos..."

# game/inAlley.rpy:874
translate pt_br oldTheater_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:875
translate pt_br oldTheater_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:878
translate pt_br oldTheater_a4fb4a3e:

    # "...before the screen flickers on."
    "...antes que a tela se acenda."

# game/inAlley.rpy:879
translate pt_br oldTheater_dd520a72:

    # "No commercials or trailers pop up – the movie just begins."
    "Nenhum comercial ou trailer aparece – o filme simplesmente começa."

# game/inAlley.rpy:880
translate pt_br oldTheater_a5c79df4:

    # "Pleased, you shrug and let yourself get immersed in the opening scene."
    "Contente, você se deixa envolver pela cena inicial."

# game/inAlley.rpy:881
translate pt_br oldTheater_1b0c5dc9:

    # "But just as you’re getting into the premise..."
    "Mas, justo quando você começa a se envolver pela trama..."

# game/inAlley.rpy:884
translate pt_br oldTheater_b6693490:

    # "...the doors open behind you, momentarily casting light into the room and ruining the atmosphere."
    "...as portas se abrem atrás de você, iluminando momentaneamente a sala e estragando o clima."

# game/inAlley.rpy:885
translate pt_br oldTheater_e56dc443:

    # "You hold in a frustrated sigh."
    "Você segura o suspiro de frustração."

# game/inAlley.rpy:886
translate pt_br oldTheater_c6d5d2d2:

    # "It’s a public establishment after all."
    "É um estabelecimento público, afinal."

# game/inAlley.rpy:887
translate pt_br oldTheater_4fa1403a:

    # "The place can’t exactly afford to stay open if {i}you’re{/i} the only customer."
    "O lugar não pode se manter de pé se {i}você{/i} for o único cliente."

# game/inAlley.rpy:888
translate pt_br oldTheater_93c887ef:

    # "You try to refocus on the movie but you sense the new presence slowly shifting around the theater..."
    "Você tenta se concentrar novamente no filme, mas percebe a nova presença se movendo lentamente pelo cinema..."

# game/inAlley.rpy:889
translate pt_br oldTheater_b4c5e205:

    # "...before heading in your general direction."
    "...antes de se dirigir na sua direção.."

# game/inAlley.rpy:890
translate pt_br oldTheater_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:891
translate pt_br oldTheater_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:893
translate pt_br oldTheater_4d11e7f3:

    # you "..?! Wha-"
    you "..?! O qu-"

# game/inAlley.rpy:906
translate pt_br oldTheater_b0959e10:

    # "You gape in utter disbelief as the stranger shuffles down the aisle only to sit {b}RIGHT{/b} in front of you."
    "Você fica boquiaberto em descrença total enquanto o estranho caminha pelo corredor e se senta {b}BEM{/b} na sua frente."

# game/inAlley.rpy:907
translate pt_br oldTheater_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:908
translate pt_br oldTheater_8ff13d0b:

    # "There’s no one else here and plenty of places to sit."
    "Não há ninguém aqui e muitos lugares para se sentar."

# game/inAlley.rpy:909
translate pt_br oldTheater_67b56825:

    # "The stranger is also..."
    "O estranho também é..."

# game/inAlley.rpy:910
translate pt_br oldTheater_2264fca6:

    # "...{i}unusually{/i} tall."
    "...{i}excepcionalmente{/i} alto."

# game/inAlley.rpy:911
translate pt_br oldTheater_d21b2508:

    # "Even with the stadium-like arrangement of the seats being on a somewhat steep incline, they’re completely blocking your view."
    "Mesmo com a disposição das cadeiras no formato de estádio, bem inclinadas, ele bloqueia completamente sua visão."

# game/inAlley.rpy:919
translate pt_br oldTheater_452114d6:

    # "This is too weird."
    "Isso é estranho demais."

# game/inAlley.rpy:920
translate pt_br oldTheater_f9c856d9:

    # "Feeling uncomfortable, you decide to leave the theater. There's still enough time left in the day to do something else."
    "Se sentindo desconfortável, você decide sair do cinema. Ainda sobrou tempo do seu dia pra fazer outra coisa."

# game/inAlley.rpy:926
translate pt_br oldTheater_16617c12:

    # "Now what?"
    "E agora?"

# game/inAlley.rpy:930
translate pt_br moveTheater1_40036af7:

    # "You don’t want to risk escalating the situation further. This whole thing is already making you uneasy."
    "Você não quer arriscar escalar mais ainda a situação. Isso tudo já tá te deixando desconfortável."

# game/inAlley.rpy:931
translate pt_br moveTheater1_30d6713a:

    # "Why would they choose to sit right in front of you? Surely they know you wouldn’t be able to see past them?"
    "Por que ele escolheria sentar bem na sua frente? Certamente ele sabe que você não pode ver através dele?"

# game/inAlley.rpy:934
translate pt_br moveTheater1_badbf0f2:

    # "Shaking your head with a passive aggressive scoff in the stranger's direction... {w}you reluctantly pick another, less perfect, seat in the theater..."
    "Balançando a cabeça com um resmungo passivo-agressivo na direção do estranho... você, relutantemente, escolhe outro assento, menos perfeito..."

# game/inAlley.rpy:935
translate pt_br moveTheater1_bf0874e3:

    # "But..."
    "Mas..."

# game/inAlley.rpy:936
translate pt_br moveTheater1_cc8c4a97:

    # "As you settle down..."
    "Enquanto você se acomoda..."

# game/inAlley.rpy:937
translate pt_br moveTheater1_62c67dd0:

    # "...you see the strange person get up..."
    "...você vê o estranho se levantar..."

# game/inAlley.rpy:940
translate pt_br moveTheater1_89af2519:

    # "...only to once again sit down in the seat {i}directly{/i} in front of you."
    "...só para, mais uma vez, sentar-se {i}exatamente{/i} na sua frente."

# game/inAlley.rpy:941
translate pt_br moveTheater1_56ebb028:

    # you "!!!"
    you "!!!"

# game/inAlley.rpy:942
translate pt_br moveTheater1_51a47b38:

    # "You look around somewhat helplessly as if waiting for someone to silently agree with you about how odd all of this is."
    "Você olha em volta, um tanto desamparado, esperando que alguém concorde silenciosamente com você sobre o quão estranho é tudo isso."

# game/inAlley.rpy:943
translate pt_br moveTheater1_e5a8d006:

    # "Or to at least inform you that it's all an elaborate prank."
    "Ou para, pelo menos, lhe informar que foi tudo uma pegadinha."

# game/inAlley.rpy:944
translate pt_br moveTheater1_4bc7f00e:

    # "But there’s no one else here with you. That's how you’ve always liked it but..."
    "Mas não há mais ninguém aqui com você. É como você sempre preferiu, mas..."

# game/inAlley.rpy:945
translate pt_br moveTheater1_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:946
translate pt_br moveTheater1_b0de34e0:

    # "You can’t help but think that maybe it would be nice to have {i}someone{/i} else here if it meant not being alone with this weird jerk..."
    "Você não consegue evitar de pensar que seria legal ter mais {i}alguém{/i} aqui, se isso significar não estar sozinho com esse idiota bizarro..."

# game/inAlley.rpy:954
translate pt_br moveTheater1_452114d6:

    # "This is too weird."
    "Isso é estranho demais."

# game/inAlley.rpy:955
translate pt_br moveTheater1_f9c856d9:

    # "Feeling uncomfortable, you decide to leave the theater. There's still enough time left in the day to do something else."
    "Se sentindo desconfortável, você decide sair do cinema. Ainda sobrou tempo do seu dia pra fazer outra coisa."

# game/inAlley.rpy:961
translate pt_br moveTheater1_16617c12:

    # "Now what?"
    "E agora?"

# game/inAlley.rpy:967
translate pt_br moveTheater2_287d233d:

    # "You move again..."
    "Você muda de novo..."

# game/inAlley.rpy:968
translate pt_br moveTheater2_cc9a5909:

    # "!!!"
    "!!!"

# game/inAlley.rpy:971
translate pt_br moveTheater2_198c5f02:

    # "...and {i}again,{/i} they sit right in front of you."
    "...e {i}de novo,{/i} ele senta bem na sua frente."

# game/inAlley.rpy:972
translate pt_br moveTheater2_1cea2bd2:

    # "You bristle, annoyed and a little humiliated."
    "Você se irrita, incomodado e um tanto humilhado."

# game/inAlley.rpy:973
translate pt_br moveTheater2_663c60ce:

    # "Are they just getting a kick out of this or something?"
    "Será que ele está se divertindo com isso ou algo assim?"

# game/inAlley.rpy:974
translate pt_br moveTheater2_22dd2b12:

    # "You’ve wasted enough time with this jerk that you don’t even know what’s going on in the movie anymore."
    "Você já perdeu tanto tempo com esse idiota que nem sabe mais o que está acontecendo no filme."

# game/inAlley.rpy:975
translate pt_br moveTheater2_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:981
translate pt_br moveTheater2_452114d6:

    # "This is too weird."
    "Isso é estranho demais."

# game/inAlley.rpy:982
translate pt_br moveTheater2_f9c856d9:

    # "Feeling uncomfortable, you decide to leave the theater. There's still enough time left in the day to do something else."
    "Se sentindo desconfortável, você decide sair do cinema. Ainda sobrou tempo do seu dia pra fazer outra coisa."

# game/inAlley.rpy:988
translate pt_br moveTheater2_16617c12:

    # "Now what?"
    "E agora?"

# game/inAlley.rpy:993
translate pt_br confrontTheater_d20e8806:

    # "You hate confrontation. You can already feel your palms starting to sweat at the idea of it."
    "Você odeia confrontos. Só de pensar, você já pode sentir a palma das suas mãos começando a suar."

# game/inAlley.rpy:995
translate pt_br confrontTheater_a9c192bd:

    # "Your throat’s closing up and your body's starting to shake."
    "Sua garganta fechando e seu corpo começando a tremer."

# game/inAlley.rpy:996
translate pt_br confrontTheater_2938ac47:

    # "You’ve always been more of a ‘Flight-er’ than a ‘Fighter’..."
    "Você sempre foi mais um ‘fujento’ do que um ‘briguento’..."

# game/inAlley.rpy:997
translate pt_br confrontTheater_ba742fb9:

    # "...but you paid for this ticket. {w}You’ve wanted to watch this movie for ages..."
    "...mas você pagou pelo ingresso. {w}Você quer ver esse filme há tempos..."

# game/inAlley.rpy:998
translate pt_br confrontTheater_4133c851:

    # "...and now this total stranger has ruined the entire experience for you."
    "...e agora esse total estranho arruinou completamente a sua experiência."

# game/inAlley.rpy:999
translate pt_br confrontTheater_31224555:

    # "You’re all alone in this theater. There’s no one who’ll help you if something goes wrong..."
    "Você está sozinho nesse cinema. Não há ninguém para te ajudar caso as coisas deem errado..."

# game/inAlley.rpy:1000
translate pt_br confrontTheater_56f5734b:

    # "But you’re angry enough that you ignore the signs of your body begging you to put as much distance as you can between yourself and this stranger."
    "Mas você está com tanta raiva que ignora os sinais do seu corpo, que implora para que se distancie o máximo possivel desse estranho."

# game/inAlley.rpy:1001
translate pt_br confrontTheater_4d121ecf:

    # "You stand up. Even standing and higher up on the incline, the stranger is still {i}at least{/i} a head taller than you."
    "Você se levanta. Mesmo de pé e em uma parte mais alta do cinema, o estranho ainda é {i}pelo menos{/i} uma cabeça mais alto que você."

# game/inAlley.rpy:1004
translate pt_br confrontTheater_7ecc8825:

    # "The movie continues to play in the background, but you feel as if a hush immediately falls heavily over the theater at your movement..."
    "O filme continua passando no fundo, mas você sente como se um silêncio pesado caísse imediatamente sobre o cinema com o seu movimento..."

# game/inAlley.rpy:1005
translate pt_br confrontTheater_61ee470d:

    # "...as if you can the sense the stranger anticipating what you plan to do next."
    "...como se você pudesse sentir o estranho antecipando o que você planeja fazer a seguir."

# game/inAlley.rpy:1006
translate pt_br confrontTheater_36eaf556:

    # "You square your shoulders and force a little bass into your voice."
    "Você endireita os ombros e engrossa um pouco a voz."

# game/inAlley.rpy:1008
translate pt_br confrontTheater_635cbfd8:

    # you "{size=+10}{b}HEY!{/b}{/size}" with hpunch
    you "{size=+10}{b}EI!{/b}{/size}" with hpunch

# game/inAlley.rpy:1009
translate pt_br confrontTheater_c6fd0e1b:

    # "The effort makes your words come out more harshly than you intended, like a sudden and vicious bark..."
    "Suas palavras saem mais duras do que você pretendia, como um latido repentino e agressivo..."

# game/inAlley.rpy:1010
translate pt_br confrontTheater_77452538:

    # "...but you figure they deserve it anyway."
    "...mas você lembra que ele merece mesmo."

# game/inAlley.rpy:1011
translate pt_br confrontTheater_72a25472:

    # you "You’re being a real jerk, you know that? Just what are you playing at, huh? Are you trying to piss me off?"
    you "Você tá sendo um otário, sabia? O que você quer, hein? Tá querendo me deixar puto?"

# game/inAlley.rpy:1012
translate pt_br confrontTheater_6f50b679:

    # who "..."
    who "..."

# game/inAlley.rpy:1013
translate pt_br confrontTheater_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:1014
translate pt_br confrontTheater_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1015
translate pt_br confrontTheater_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1016
translate pt_br confrontTheater_f6344799:

    # "The silence that follows your words is {b}deafening{/b}..."
    "O silêncio que se segue às suas palavras é {b}ensurdecedor{/b}..."

# game/inAlley.rpy:1017
translate pt_br confrontTheater_93861255:

    # "...so much so that you glance at the screen only to find that the movie has..."
    "...tanto que você olha para a tela e percebe que o filme foi..."

# game/inAlley.rpy:1018
translate pt_br confrontTheater_fee70e3c:

    # "...paused?"
    "...pausado?"

# game/inAlley.rpy:1019
translate pt_br confrontTheater_90b68c87:

    # you "..?"
    you "..?"

# game/inAlley.rpy:1020
translate pt_br confrontTheater_28b3ac41:

    # you "!!"
    you "!!"

# game/inAlley.rpy:1022
translate pt_br confrontTheater_169210d3:

    # "Your attention is ripped back to the stranger in front of you as they shift slightly."
    "Sua atenção é imediatamente puxada de volta para o estranho à sua frente enquanto ele se mexe ligeiramente."

# game/inAlley.rpy:1023
translate pt_br confrontTheater_dbc8ab64:

    # "Like a small animal trying desperately to anticipate the moves of a predator... {w}{b}you don’t move an inch.{/b}"
    "Como um animalzinho tentando desesperadamente antecipar os movimentos de um predador... {w}{b}você não move um centímetro.{/b}"

# game/inAlley.rpy:1024
translate pt_br confrontTheater_74dfd95b:

    # "You don’t look away. {w}You don’t dare to {i}blink.{/i}"
    "Você não desvia o olhar. {w}Você não ousa sequer {i}piscar.{/i}"

# game/inAlley.rpy:1027
translate pt_br confrontTheater_0dd1ea0a:

    # "Instead, your eyes widen as the person’s head turns..."
    "Pelo contrário, seus olhos se arregalam à medida que a cabeça da pessoa gira..."

# game/inAlley.rpy:1030
translate pt_br confrontTheater_5654bfb2:

    # "Then turns some more..."
    "Então gira mais um pouco..."

# game/inAlley.rpy:1031
translate pt_br confrontTheater_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1034
translate pt_br confrontTheater_b88269b6:

    # "Then turns more... {i}beyond{/i} what should be possible... neck bones {i}cracking{/i}..."
    "E gira mais... {i}além{/i} do que poderia ser possível... com os ossos do pescoço {i}estalando{/i}..."

# game/inAlley.rpy:1035
translate pt_br confrontTheater_61ab54e3:

    # "...to face you directly."
    "...para te encarar diretamente."

# game/inAlley.rpy:1038
translate pt_br confrontTheater_17cf9e73:

    # you "...ah..."
    you "...ah..."

# game/inAlley.rpy:1039
translate pt_br confrontTheater_c6ce8445:

    # "You can’t move."
    "Você não consegue se mexer."

# game/inAlley.rpy:1040
translate pt_br confrontTheater_d758f471:

    # "Wide glowing eyes resting above a wider grinning mouth gaze down at you."
    "Olhos brilhantes e arregalados acima de uma boca sorridente ainda mais larga, olhando para você."

# game/inAlley.rpy:1041
translate pt_br confrontTheater_6b167f7f:

    # "The stranger opens their mouth and what comes out..."
    "O estranho abre sua boca, e o que sai dela..."

# game/inAlley.rpy:1042
translate pt_br confrontTheater_2177217c:

    # "...is something impossible to comprehend."
    "...é algo incompreensível."

# game/inAlley.rpy:1044
translate pt_br confrontTheater_742b5efd:

    # who "Nyaaaa-a-a-a-a-a-ahh~{w=2.75}{nw}"
    who "Nyaaaa-a-a-a-a-a-ahh~{w=2.75}{nw}"

# game/inAlley.rpy:1045
translate pt_br confrontTheater_24840d69:

    # you "?!{w=0.3}{nw}"
    you "?!{w=0.3}{nw}"

# game/inAlley.rpy:1046
translate pt_br confrontTheater_65a6a073:

    # who "Nyaaaa-a-a-a-a-a-ahh~{w=2.5}{nw}"
    who "Nyaaaa-a-a-a-a-a-ahh~{w=2.5}{nw}"

# game/inAlley.rpy:1047
translate pt_br confrontTheater_d46cc080:

    # who "Nyaaaa{w=0.75}-a{w=0.75}-a{w=0.75}-a{w=0.75}-aaahhh~"
    who "Nyaaaa{w=0.75}-a{w=0.75}-a{w=0.75}-a{w=0.75}-aaahhh~"

# game/inAlley.rpy:1048
translate pt_br confrontTheater_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:1049
translate pt_br confrontTheater_8d5e95ad:

    # "The voice is endlessly deep and creaks like a weighty door, foreboding and oddly melodic..."
    "A voz é infinitamente profunda e range como uma porta pesada, ameaçadora e estranhamente melódica..."

# game/inAlley.rpy:1050
translate pt_br confrontTheater_98a755c6:

    # "Alluring..."
    "Sedutora..."

# game/inAlley.rpy:1051
translate pt_br confrontTheater_2ff3b202:

    # "But it also snaps you out of your terrified trance and before you know it, you’re already out the door."
    "Mas que também te tira do seu transe aterrorizado e, antes que perceba, você já está saindo da porta."

# game/inAlley.rpy:1057
translate pt_br confrontTheater_0051e82f:

    # "You run through the halls of the empty theater, heading for the exit."
    "Você corre pelos corredores do cinema vazio, procurando a saída."

# game/inAlley.rpy:1060
translate pt_br confrontTheater_3a3a66e0:

    # "You feel something watching you from behind..."
    "Você sente algo nas suas costas, te vigiando..."

# game/inAlley.rpy:1061
translate pt_br confrontTheater_10fd18e4:

    # "{size=-5}...but you're too afraid to look.{/size}"
    "{size=-5}...mas você está com medo demais para olhar.{/size}"

# game/inAlley.rpy:1064
translate pt_br confrontTheater_a376e0ce:

    # "The exit now in sight, you sprint forward and burst through the doors."
    "Com a saída agora à vista, você corre em direção às portas e as arromba."

# game/inAlley.rpy:1067
translate pt_br confrontTheater_c6a8f088:

    # "You look around frantically and spot the crowded cinema across the street."
    "Você olha ao redor freneticamente e avista o cinema lotado do outro lado da rua."

# game/inAlley.rpy:1068
translate pt_br confrontTheater_1b77491a:

    # "People! That’s what you need. Safety in numbers and all that..."
    "Pessoas! É isso que você precisa. Segurança na multidão e tudo mais..."

# game/inAlley.rpy:1069
translate pt_br confrontTheater_e6eacea8:

    # "Without thinking, you rush into the street when a sinking sensation crawls down your spine, compelling you to look behind you."
    "Sem pensar, você corre para a rua, quando um arrepio percorre sua espinha de cima a baixo, fazendo você olhar para trás."

# game/inAlley.rpy:1079
translate pt_br lookBehindYou_movie_d5f8a487:

    # "Refusing to even risk a peek over your shoulder, you rush across the street to the new cinema theater."
    "Se recusando a sequer arriscar uma olhada por cima do ombro, você atravessa a rua correndo em direção ao cinema novo."

# game/inAlley.rpy:1080
translate pt_br lookBehindYou_movie_a724453f:

    # "You didn't realize that it felt like you've been surrounded by some kind of dreadful pressure..."
    "Você não percebeu que estava se sentindo envolto por uma espécie de pressão aterrorizante..."

# game/inAlley.rpy:1084
translate pt_br lookBehindYou_movie_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1085
translate pt_br lookBehindYou_movie_1812debc:

    # "...until it very suddenly vanishes. Leaving you feeling more than a little shaken."
    "...até que ela desaparece de repente. Deixando você um tanto abalado."

# game/inAlley.rpy:1086
translate pt_br lookBehindYou_movie_4036cbd4:

    # "But at least breathing comes easier."
    "Mas pelo menos ficou mais fácil de respirar."

# game/inAlley.rpy:1087
translate pt_br lookBehindYou_movie_e1da1ba0:

    # "{size=-7}You think it's within your best interests to repress {b}everything{/b} that just happened.{/size}"
    "{size=-7}Você pensa que é melhor ignorar {b}tudo{/b} que acabou de acontecer.{/size}"

# game/inAlley.rpy:1088
translate pt_br lookBehindYou_movie_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1089
translate pt_br lookBehindYou_movie_4914da37:

    # "Yeah..."
    "É..."

# game/inAlley.rpy:1099
translate pt_br endOldMovie_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1100
translate pt_br endOldMovie_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1101
translate pt_br endOldMovie_5583c4ca:

    # "Despite your resistance..."
    "Apesar de sua resistência..."

# game/inAlley.rpy:1102
translate pt_br endOldMovie_0fcf7c3b:

    # "...you feel your head turning to look back of its own accord."
    "...você sente sua cabeça se virando para olhar para trás por conta própria."

# game/inAlley.rpy:1103
translate pt_br endOldMovie_7f250539:

    # "While in the middle of the street..."
    "Enquanto está no meio da rua..."

# game/inAlley.rpy:1106
translate pt_br endOldMovie_dfc24e13:

    # "...you catch a glimpse of a grotesque looking person standing behind the glass doors of the old theater..."
    "...você vislumbra uma figura grotesca atrás das portas de vidro do antigo cinema..."

# game/inAlley.rpy:1107
translate pt_br endOldMovie_67373714:

    # "Watching you intensely..."
    "Te observando intensamente..."

# game/inAlley.rpy:1108
translate pt_br endOldMovie_747a081d:

    # "Cradling something their arms..."
    "Segurando alguma coisa em seus braços..."

# game/inAlley.rpy:1109
translate pt_br endOldMovie_973413d4:

    # "Something..."
    "Algo..."

# game/inAlley.rpy:1110
translate pt_br endOldMovie_8ae0fc15:

    # "{size=-10}...familiar.{/size}"
    "{size=-10}...familiar.{/size}"

# game/inAlley.rpy:1111
translate pt_br endOldMovie_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1112
translate pt_br endOldMovie_bf0874e3:

    # "But..."
    "Mas..."

# game/inAlley.rpy:1115
translate pt_br endOldMovie_a9494a86:

    # "{size=+30}{b}{i}BEEP!{/i}{/b}{/size}" with hpunch
    "{size=+30}{b}{i}BIIII!{/i}{/b}{/size}" with hpunch

# game/inAlley.rpy:1116
translate pt_br endOldMovie_90b68c87:

    # you "..?"
    you "..?"

# game/inAlley.rpy:1138
translate pt_br endOldMovie_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:1139
translate pt_br endOldMovie_f5377255:

    # "A glimpse is all you get..."
    "Um vislumbre é tudo que você consegue..."

# game/inAlley.rpy:1140
translate pt_br endOldMovie_e22cae7b:

    # "...as a truck speeds forward and {b}crashes{/b} into your body."
    "...antes que um caminhão se aproxime em alta velocidade e {b}passe por cima{/b} de você."

# game/inAlley.rpy:1146
translate pt_br endOldMovie_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:1147
translate pt_br endOldMovie_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:1148
translate pt_br endOldMovie_0b13bd09:

    # "You’re killed on impact, your body splattered across the road and crushed further under the heavy tires."
    "Você morre no impacto, seu corpo espalhado pela estrada e esmagado sob os pneus pesados."

# game/inAlley.rpy:1149
translate pt_br endOldMovie_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:1150
translate pt_br endOldMovie_7444e453:

    # "Ending 16: Poor Screening Arrangements"
    "Final 16: Péssima Administração"

# game/inAlley.rpy:1163
translate pt_br newCinema_fb646a70:

    # "Deciding to wait for the movie you’ve been anticipating to be available on DVD or streaming..."
    "Decidindo esperar o filme que você tanto aguardava ficar disponível em DVD ou em streaming..."

# game/inAlley.rpy:1164
translate pt_br newCinema_e6448215:

    # "...you join the long line outside the new cinema."
    "...você entra na longa fila do lado de fora do cinema novo."

# game/inAlley.rpy:1165
translate pt_br newCinema_0f82186d:

    # "By the time you’ve reached the ticket booth, you just want to get inside..."
    "Quando você finalmente chega à bilheteria, só quer entrar logo..."

# game/inAlley.rpy:1166
translate pt_br newCinema_2e8f7eeb:

    # "...so you pick a movie at random and take your ticket from the tired looking teenager manning the booth."
    "...então você escolhe um filme qualquer e pega o ingresso com o adolescente aparentemente cansado que cuida da bilheteria."

# game/inAlley.rpy:1170
translate pt_br newCinema_6fcdd2f1:

    # "The décor is chic and sleek and the inside is bustling with people."
    "A decoração é chique e elegante, e o interior está movimentado."

# game/inAlley.rpy:1171
translate pt_br newCinema_df337005:

    # "It’s not what you’re usually into..."
    "Não é bem o que você costuma curtir..."

# game/inAlley.rpy:1172
translate pt_br newCinema_ebfd36e0:

    # "...but it’s kind of nice not being alone..."
    "...mas até que é legal não estar sozinho..."

# game/inAlley.rpy:1173
translate pt_br newCinema_16ea2ab5:

    # "...even if you feel a little lonely watching families and groups of friends laughing among themselves."
    "...mesmo que você se sinta um pouco solitário ao ver famílias e grupos de amigos rindo entre si."

# game/inAlley.rpy:1174
translate pt_br newCinema_8a84e9c7:

    # "You’d get some popcorn, but the lines at the concession stands are long and the prices are criminal anyway."
    "Você até compraria pipoca, mas as filas do quiosque são enormes e os preços são uma facada."

# game/inAlley.rpy:1177
translate pt_br newCinema_f8963506:

    # "You go through the halls..."
    "Você atravessa os corredores..."

# game/inAlley.rpy:1180
translate pt_br newCinema_6a610267:

    # "...and follow the signs to the theater designated on your ticket before heading inside."
    "...e segue as placas até a sala indicada no seu ingresso antes de entrar."

# game/inAlley.rpy:1183
translate pt_br newCinema_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1184
translate pt_br newCinema_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1185
translate pt_br newCinema_cfd045e6:

    # you "*Sigh*..."
    you "*Suspiro*..."

# game/inAlley.rpy:1188
translate pt_br newCinema_a0c7900b:

    # "You sigh at the sight of the absolutely crowded theater."
    "Você suspira ao se deparar com uma sala completamente lotada."

# game/inAlley.rpy:1189
translate pt_br newCinema_2aeb5f16:

    # "You head towards a seat only to be told by the person next to it that it’s being saved for someone."
    "Você se dirige para um assento, só para ouvir pela pessoa ao lado de que ele está reservado para alguém."

# game/inAlley.rpy:1190
translate pt_br newCinema_2c48e4bd:

    # "This happens a few more times before you finally manage to get yourself settled into a seat annoyingly off center to the screen."
    "Isso acontece mais algumas vezes antes de você finalmente conseguir se acomodar em um assento que está irritantemente fora de ângulo em relação à tela."

# game/inAlley.rpy:1191
translate pt_br newCinema_66e2f315:

    # "But the screen is at least visible, if not a little too close. So you grit your teeth and bear it."
    "Mas pelo menos a tela está visível, só um pouco próxima demais. Então, você range os dentes e suporta."

# game/inAlley.rpy:1194
translate pt_br newCinema_84b297cd:

    # "The lights fade out..."
    "As luzes se apagam..."

# game/inAlley.rpy:1195
translate pt_br newCinema_76f1cc33:

    # "...but the chatter doesn’t."
    "...mas a conversa continua."

# game/inAlley.rpy:1198
translate pt_br newCinema_ccf5589e:

    # "The rest of the audience seems content to talk through the commercials and even through the trailers."
    "O resto do público parece contente em conversar durante os comerciais e até mesmo durante os trailers."

# game/inAlley.rpy:1199
translate pt_br newCinema_e5244e34:

    # "You figure the chatter will stop when the movie actually begins..."
    "Você imagina que o converseiro vá parar quando o filme começar de verdade..."

# game/inAlley.rpy:1200
translate pt_br newCinema_42922d85:

    # "...but it doesn’t get even {i}slightly{/i} quieter as the opening scene starts to play out."
    "...mas não fica nem mesmo {i}um pouco{/i} mais quieto assim que a cena de abertura começa a passar."

# game/inAlley.rpy:1201
translate pt_br newCinema_056cb5d7:

    # "You sigh out loud not thinking anyone would hear you anyway."
    "Você suspira alto, imaginando que ninguém te ouviria, de qualquer forma."

# game/inAlley.rpy:1202
translate pt_br newCinema_fe9b2aa2:

    # "This is why you avoid movie theaters like the plague."
    "É por isso que você evita tanto cinemas."

# game/inAlley.rpy:1210
translate pt_br newCinema_c70c22ac:

    # "Suddenly, the screen changes, showing the face of a black cat..."
    "De repente, a tela muda, mostrando a face de um gato preto..."

# game/inAlley.rpy:1211
translate pt_br newCinema_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1212
translate pt_br newCinema_5bd888eb:

    # "{size=-8}A {b}familiar{/b} black cat.{/size}"
    "{size=-8}Um gato preto {b}familiar{/b}.{/size}"

# game/inAlley.rpy:1213
translate pt_br newCinema_bf2cad6b:

    # "Confused murmurs fill the room... but then... {w}the cat on the screen..."
    "Sussurros confusos enchem a sala... até que... {w}o gato na tela..."

# game/inAlley.rpy:1214
translate pt_br newCinema_7f5ff8a8:

    # "{b}...meows.{/b}"
    "{b}...mia.{/b}"

# game/inAlley.rpy:1216
translate pt_br newCinema_d752482c:

    # catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1217
translate pt_br newCinema_28b3ac41:

    # you "!!"
    you "!!"

# game/inAlley.rpy:1218
translate pt_br newCinema_2e7e53ad:

    # "The sound is... {i}strange{/i} and not at all like any cat {i}should{/i} sound."
    "O som é... {i}estranho{/i} e de forma alguma como um gato {i}deveria{/i} soar."

# game/inAlley.rpy:1219
translate pt_br newCinema_4a94d4f7:

    # "Haunting... Almost melodic..."
    "Fantasmagórico... Quase melódico..."

# game/inAlley.rpy:1220
translate pt_br newCinema_d7d1f702:

    # "And layered as if made of multiple voices of different creatures."
    "E sobreposto, como se fosse feito de várias vozes de criaturas diferentes."

# game/inAlley.rpy:1221
translate pt_br newCinema_96a32759:

    # "Creatures that would probably never say-"
    "Criaturas que provavelmente nunca falariam-"

# game/inAlley.rpy:1223
translate pt_br newCinema_d752482c_1:

    # catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1224
translate pt_br newCinema_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:1228
translate pt_br newCinema_7865d364:

    # "You sit in confusion wondering why you haven’t already gotten up and left to complain to the cinema staff..."
    "Você se senta, confuso, se perguntando por que ainda não se levantou e foi reclamar com os funcionários do cinema..."

# game/inAlley.rpy:1229
translate pt_br newCinema_04be082d:

    # "But then you {b}hear{/b} it..."
    "Mas então você {b}ouve{/b}..."

# game/inAlley.rpy:1230
translate pt_br newCinema_b5b4f2e8:

    # "It's scattered and dissonant at first... but among the crowd... people start to chant along with the cat on the screen."
    "Está picotado e dissonante no início... mas entre a multidão... pessoas começam a entoar junto com o gato na tela."

# game/inAlley.rpy:1232
translate pt_br newCinema_b67f4dca:

    # audience "{size=-10}Nyaa... Nyaa... Nyaaa-a-a-a-ah...{/size}"
    audience "{size=-10}Nyaa... Nyaa... Nyaaa-a-a-a-ah...{/size}"

# game/inAlley.rpy:1234
translate pt_br newCinema_45f08096:

    # audience "{size=-5}Nyaa... Nyaa... Nyaaa-a-a-a-ah...{/size}"
    audience "{size=-5}Nyaa... Nyaa... Nyaaa-a-a-a-ah...{/size}"

# game/inAlley.rpy:1236
translate pt_br newCinema_764e589b:

    # audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1237
translate pt_br newCinema_b95dc8fe:

    # "Soon... the entire room is chanting in perfect unison, everyone staring intently at the cat on the screen."
    "Logo... toda a sala está entoando em perfeito uníssono, todos encarando diretamente o gato na tela."

# game/inAlley.rpy:1238
translate pt_br newCinema_9eb4296f:

    # "You’re feeling strangely drawn to the screen yourself..."
    "Você se sente estranhamente atraído pela tela também..."

# game/inAlley.rpy:1239
translate pt_br newCinema_59b62632:

    # "...but the compulsion to stare blankly like the others isn’t that strong..."
    "...mas a compulsão de olhar fixamente como os outros não é tão forte..."

# game/inAlley.rpy:1240
translate pt_br newCinema_53224b1d:

    # "...for {b}now.{/b}"
    "...por {b}enquanto.{/b}"

# game/inAlley.rpy:1241
translate pt_br newCinema_3595f06e:

    # "Also... {w}you start to notice out of the corner of your eye..."
    "Além disso... {w}você começa a notar de canto de olho..."

# game/inAlley.rpy:1242
translate pt_br newCinema_fc9293fc:

    # "...that some of the people in your immediate vicinity are... {w}{i}looking{/i} at you..."
    "...que algumas pessoas próximas estão... {w}{i}olhando{/i} para você..."

# game/inAlley.rpy:1243
translate pt_br newCinema_7072f3b4:

    # "No..."
    "Não..."

# game/inAlley.rpy:1246
translate pt_br newCinema_8adc7d4f:

    # "They’re outright staring {b}holes{/b} into you, even as they continue chanting."
    "Elas estão simplesmente te {b}comendo{/b} com os olhos, enquanto continuam entoando."

# game/inAlley.rpy:1249
translate pt_br newCinema_46abeb33:

    # "They don’t miss a beat as they slowly begin to frown at you in blatant disapproval..."
    "Elas não perdem o ritmo, ao mesmo tempo que começam a lentamente franzir a testa em clara desaprovação..."

# game/inAlley.rpy:1252
translate pt_br newCinema_c4ad1bed:

    # "Their scowls deepen as time goes on as if they’re getting...{w} {i}impatient...{/i}"
    "Suas carrancas pioram conforme o tempo passa, como se elas estivessem ficando...{w} {i}impacientes...{/i}"

# game/inAlley.rpy:1265
translate pt_br leaveCinema_b24b4053:

    # you "{i}This is too weird... I need to get out of here...{/i}"
    you "{i}Isso é estranho demais... tenho que dar o fora daqui...{/i}"

# game/inAlley.rpy:1268
translate pt_br leaveCinema_14daa181:

    # "Gathering your courage...{w} or perhaps putting your fear to use, you stand up,{w} fully intending to leave the theater..."
    "Juntando sua coragem...{w} ou talvez aproveitando seu medo, você se levanta,{w} com a plena intenção de sair do cinema..."

# game/inAlley.rpy:1270
translate pt_br leaveCinema_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1271
translate pt_br leaveCinema_ad7223b1:

    # "...when everything comes to an abrupt {b}STOP.{/b}"
    "...quando tudo chega a um abrupto {b}PAREM.{/b}"

# game/inAlley.rpy:1272
translate pt_br leaveCinema_dff334e8:

    # "All of the chanting stops, even the cat's chanting on the screen."
    "Todo o cântico para, até mesmo o entoar do gato na tela."

# game/inAlley.rpy:1273
translate pt_br leaveCinema_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:1274
translate pt_br leaveCinema_2f1c4fb2:

    # "You tense and risk a glance around the theater."
    "Você arrisca um olhar tenso ao redor do cinema."

# game/inAlley.rpy:1275
translate pt_br leaveCinema_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:1279
translate pt_br leaveCinema_fe50f822:

    # "They’re all staring at you."
    "Todos estão te encarando."

# game/inAlley.rpy:1281
translate pt_br leaveCinema_50e5017d:

    # "Every. {w}Single. {w}One of them."
    "Cada. {w}Um. {w}Deles."

# game/inAlley.rpy:1282
translate pt_br leaveCinema_352295ee:

    # "They’re not moving. They’re not even {i}blinking.{/i}"
    "Eles não se movem. Eles não estão nem mesmo {i}piscando.{/i}"

# game/inAlley.rpy:1283
translate pt_br leaveCinema_99a1a0e1:

    # "You swallow, throat suddenly dry even though a nervous sweat completely soaks through your clothes."
    "Sua garganta repentinamente fica seca, embora o suor de nervoso tenha encharcado completamente suas roupas."

# game/inAlley.rpy:1284
translate pt_br leaveCinema_661663c4:

    # "You highly doubt that sitting back down will fix the situation."
    "Você engole seco. Você duvida muito que se sentar de volta resolva a situação."

# game/inAlley.rpy:1285
translate pt_br leaveCinema_213963ee:

    # "Your legs are shaking under the audience’s unnaturally intense scrutiny..."
    "Suas pernas tremem sob a observação anormalmente intensa do público..."

# game/inAlley.rpy:1286
translate pt_br leaveCinema_f71571f9:

    # "...but you force yourself to step forward and forward and {i}forward{/i} until you finally reach the end of the aisle."
    "...mas você se força a avançar e avançar e {i}avançar{/i} até finalmente alcançar o final do corredor."

# game/inAlley.rpy:1287
translate pt_br leaveCinema_dba70b8c:

    # "You feel their collective gaze even worse on the staircase."
    "Você sente o olhar coletivo deles piorar nas escadas."

# game/inAlley.rpy:1288
translate pt_br leaveCinema_87d1ef1d:

    # "All their heads have turned uncomfortably to the left to look directly at you."
    "Todas as cabeças se viraram desconfortavelmente para a esquerda para te encarar diretamente."

# game/inAlley.rpy:1289
translate pt_br leaveCinema_f70351ce:

    # "The screen illuminates their faces... making clear their blank scowls."
    "A tela ilumina seus rostos... evidenciando claramente suas expressões vazias e carrancudas."

# game/inAlley.rpy:1290
translate pt_br leaveCinema_004b0a78:

    # "They seem even {i}more{/i} upset than they had been minutes ago, identical frown lines digging between their brows."
    "Eles parecem ainda {i}mais{/i} irritados do que estavam minutos atrás, com as mesmas rugas de expressão se aprofundando entre suas sobrancelhas."

# game/inAlley.rpy:1291
translate pt_br leaveCinema_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:1295
translate pt_br leaveCinema_3252a987:

    # "You keep going, the heavy atmosphere becoming more and more oppressive with every step."
    "Você continua, e a atmosfera pesada se torna cada vez mais opressiva a cada passo."

# game/inAlley.rpy:1296
translate pt_br leaveCinema_fb8531cb:

    # "You’re so tense with anticipation that you fully expect someone to grab at you from behind..."
    "Você está tão tenso e ansioso que tem certeza de que alguém vá te agarrar por trás..."

# game/inAlley.rpy:1297
translate pt_br leaveCinema_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1298
translate pt_br leaveCinema_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1299
translate pt_br leaveCinema_0a4bb949:

    # "...but no one does."
    "...mas ninguém faz nada."

# game/inAlley.rpy:1300
translate pt_br leaveCinema_40a5c55d:

    # "You don’t hear any of them even get up."
    "Você não ouve nenhum deles sequer se levantar."

# game/inAlley.rpy:1301
translate pt_br leaveCinema_6bc983be:

    # "You exit the theater, holding your breath as the doors close behind you."
    "Você sai do cinema, prendendo a respiração enquanto as portas se fecham atrás de você."

# game/inAlley.rpy:1308
translate pt_br leaveCinema_ffbf4484:

    # "You briskly walk through the halls, putting as much distance as possible between you and that theater full of people."
    "Você anda rapidamente pelos corredores, tentando se distanciar o máximo possível daquela sala cheia de pessoas."

# game/inAlley.rpy:1311
translate pt_br leaveCinema_26c08f03:

    # "Finally reaching the lobby, you just barely manage to catch yourself from falling to the floor as you gulp in huge gasps of air."
    "Finalmente chegando à entrada, você mal consegue se sustentar e evita cair no chão enquanto inspira profunda e repetidamente."

# game/inAlley.rpy:1312
translate pt_br leaveCinema_83668abb:

    # you "*pant*... *pant*... *pant*..."
    you "*ofegante*... *ofegante*... *ofegante*..."

# game/inAlley.rpy:1313
translate pt_br leaveCinema_52ec6324:

    # "You expect to feel relief as your breathing calms..."
    "Você espera sentir alívio à medida que sua respiração se acalma..."

# game/inAlley.rpy:1314
translate pt_br leaveCinema_a1d9994b:

    # "...but you feel a lingering sense of dread that only spikes once you finally notice it..."
    "...mas sente uma sensação persistente de terror que só aumenta quando você finalmente a percebe..."

# game/inAlley.rpy:1315
translate pt_br leaveCinema_9a5f33b8:

    # "...as well as its source."
    "...assim como sua origem."

# game/inAlley.rpy:1316
translate pt_br leaveCinema_1aa73f86:

    # "You look up...{w} and your stomach {b}sinks.{/b}"
    "Você olha para cima...{w} e seu estômago {b}se revira.{/b}"

# game/inAlley.rpy:1317
translate pt_br leaveCinema_8ca8510a_1:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:1346
translate pt_br leaveCinema_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:1347
translate pt_br leaveCinema_af1c2015:

    # "All the people in the lobby area of the movie theater..."
    "Todas as pessoas na entrada do cinema..."

# game/inAlley.rpy:1348
translate pt_br leaveCinema_a38e0614:

    # "...everyone in line at the concession stand..."
    "...todos na fila do quiosque..."

# game/inAlley.rpy:1349
translate pt_br leaveCinema_0e53b020:

    # "...{i}all{/i} of them..."
    "...{i}todos{/i} eles..."

# game/inAlley.rpy:1350
translate pt_br leaveCinema_b615e9cc:

    # "...are staring at you."
    "...estão te encarando."

# game/inAlley.rpy:1351
translate pt_br leaveCinema_b88c436c:

    # "And they..."
    "E eles..."

# game/inAlley.rpy:1352
translate pt_br leaveCinema_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:1355
translate pt_br leaveCinema_fc56246f:

    # "{size=-8}They look even angrier than the people in the theater.{/size}"
    "{size=-8}Eles parecem ainda mais irritados do que as pessoas na sala do cinema.{/size}"

# game/inAlley.rpy:1358
translate pt_br leaveCinema_87f864e9:

    # "You don’t hesitate this time."
    "Dessa vez você não hesita."

# game/inAlley.rpy:1359
translate pt_br leaveCinema_3d21a06a:

    # "You duck your head, avoiding eye contact, and leave the cinema."
    "Você baixa a cabeça, evitando contato visual, e deixa o cinema."

# game/inAlley.rpy:1368
translate pt_br leaveCinema_f685e7ad:

    # "You ignore the glares of everyone in the ticket booths and the lines leading to them."
    "Você ignora os olhares de todos na bilheteria e na fila que leva até ela."

# game/inAlley.rpy:1375
translate pt_br leaveCinema_80db9421:

    # "You make your way home."
    "Você segue seu caminho para casa."

# game/inAlley.rpy:1382
translate pt_br leaveCinema_f0a2809d:

    # "Whenever you dare to look up at a someone on the way..."
    "Sempre que se atreve a olhar para alguém pelo caminho..."

# game/inAlley.rpy:1383
translate pt_br leaveCinema_bda94720:

    # "...you flinch at the blatant anger, fury, and {i}disgust{/i} on their face."
    "...você se estremece com a raiva, fúria e {i}desgosto{/i} explícitos no rosto deles."

# game/inAlley.rpy:1390
translate pt_br leaveCinema_964bc827:

    # "You think you start to hear the faint sound of a cat’s meowing behind you... or maybe a kitten’s?"
    "Você começa a achar estar ouvindo o som fraco de um gato miando atrás de você... talvez de um filhote?"

# game/inAlley.rpy:1397
translate pt_br leaveCinema_57e876a1:

    # "Doesn’t matter. You just want to go home."
    "Não importa. Você só quer ir para casa."

# game/inAlley.rpy:1404
translate pt_br leaveCinema_b807a344:

    # "You reach your front door and fumble with the keys..."
    "Você alcança porta de casa e se atrapalha com as chaves..."

# game/inAlley.rpy:1405
translate pt_br leaveCinema_f4f2f1d2:

    # "...cowering from the look of pure hatred on your neighbor’s face as he stares at you from his door."
    "...temendo o olhar de puro ódio no rosto do seu vizinho enquanto ele te encara da porta dele."

# game/inAlley.rpy:1409
translate pt_br leaveCinema_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:1410
translate pt_br leaveCinema_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:1414
translate pt_br leaveCinema_cddd7eac:

    # "Finally, you get inside your apartment..."
    "Finalmente, você entra no seu apartamento..."

# game/inAlley.rpy:1415
translate pt_br leaveCinema_4632e734:

    # "...lock all the locks on the door..."
    "...tranca todas as fechaduras da porta..."

# game/inAlley.rpy:1416
translate pt_br leaveCinema_490b851e:

    # "...and slide down with your back against it till you're sitting on the floor."
    "...e desliza com as costas contra ela até se sentar no chão."

# game/inAlley.rpy:1417
translate pt_br leaveCinema_157a374f:

    # you "*pant*... *pant*... *gulp*... *pant*..."
    you "*ofegante*... *ofegante*... *gulp*... *ofegante*..."

# game/inAlley.rpy:1418
translate pt_br leaveCinema_57aaf835:

    # "You allow yourself a moment to breathe."
    "Você se permite respirar por um momento."

# game/inAlley.rpy:1419
translate pt_br leaveCinema_f125ce05:

    # "Now home, your heartbeat calms and your fear slowly bleeds from you, leaving you feeling strangely..."
    "Agora em casa, seu coração se acalma e seu medo lentamente se esvai, fazendo você se sentir estranhamente..."

# game/inAlley.rpy:1420
translate pt_br leaveCinema_0f7ae6ad:

    # "...empty."
    "...vazio."

# game/inAlley.rpy:1421
translate pt_br leaveCinema_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:1427
translate pt_br leaveCinema_bf467465:

    # "You pass the kitchen, head to your room, and slip under the covers of your bed, trying to fall asleep."
    "Você passa pela cozinha, segue para seu quarto, e se cobre nas cobertas na sua cama, tentando se pôr a dormir."

# game/inAlley.rpy:1430
translate pt_br leaveCinema_dbaf51d5:

    # "Maybe it’s all just a bad dream."
    "Talvez tudo tenha sido só um sonho ruim."

# game/inAlley.rpy:1431
translate pt_br leaveCinema_f54febea:

    # "As you fall into a fitful sleep, sure to be full of nightmares of glaring eyes..."
    "Enquanto você cai em um sono agitado, certamente cheio de pesadelos com olhos te encarando..."

# game/inAlley.rpy:1432
translate pt_br leaveCinema_83eadebb:

    # "...you try to ignore the ever-increasing sounds of cats meowing and yowling in the distance outside your apartment."
    "...você tenta ignorar os sons cada vez mais altos de gatos miando e berrando ao longe, do lado de fora do seu apartamento."

# game/inAlley.rpy:1433
translate pt_br leaveCinema_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:1434
translate pt_br leaveCinema_d23cedee:

    # "Ending 17: Black Sheep"
    "Final 17: Ovelha Negra"

# game/inAlley.rpy:1448
translate pt_br blendInCinema_6757b12e:

    # audience "..."
    audience "..."

# game/inAlley.rpy:1449
translate pt_br blendInCinema_af2b87f0:

    # "Thinking fast, you look to the screen and begin to chant in tandem with the crowd."
    "Pensando rápido, você olha para a tela e começa a entoar o cântico junto com a multidão."

# game/inAlley.rpy:1450
translate pt_br blendInCinema_baf609ba:

    # you "N-Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    you "N-Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1451
translate pt_br blendInCinema_6757b12e_1:

    # audience "..."
    audience "..."

# game/inAlley.rpy:1454
translate pt_br blendInCinema_3f83d36c:

    # you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1455
translate pt_br blendInCinema_6757b12e_2:

    # audience "..."
    audience "..."

# game/inAlley.rpy:1458
translate pt_br blendInCinema_6757b12e_3:

    # audience "..."
    audience "..."

# game/inAlley.rpy:1461
translate pt_br blendInCinema_d090b91d:

    # "You feel the harshness of their collective gaze start to ebb away..."
    "Você sente a pressão do olhar coletivo deles começando a se dissipar..."

# game/inAlley.rpy:1462
translate pt_br blendInCinema_5580b6b9:

    # "...the air in the theater becoming lighter once again."
    "...o clima na sala de cinema ficando mais leve de novo."

# game/inAlley.rpy:1464
translate pt_br blendInCinema_764e589b:

    # audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1465
translate pt_br blendInCinema_0b4d7107:

    # "You release air shakily, just realizing that you’d been holding your breath earlier."
    "Você expira de forma trêmula, só agora percebendo que estava prendendo a respiração."

# game/inAlley.rpy:1466
translate pt_br blendInCinema_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1467
translate pt_br blendInCinema_b2294dd7:

    # "You feel stuck."
    "Você se sente preso."

# game/inAlley.rpy:1468
translate pt_br blendInCinema_042d621e:

    # "Surely you can’t just up and leave {i}now...{/i}"
    "Certamente você não pode só se levantar e sair {i}agora...{/i}"

# game/inAlley.rpy:1469
translate pt_br blendInCinema_cf356d17:

    # "Not after... {i}whatever{/i} all that was..."
    "Não depois de... {i}seja lá{/i} o que foi tudo aquilo..."

# game/inAlley.rpy:1470
translate pt_br blendInCinema_ed742197:

    # "The people around you all seem fine now..."
    "As pessoas ao seu redor parecem tranquilas agora..."

# game/inAlley.rpy:1471
translate pt_br blendInCinema_15fcd1a9:

    # "...but there’s no telling if they’d get aggressive at you for even moving too much..."
    "...mas não há como saber se elas ficariam agressivas com você até mesmo por se mexer demais..."

# game/inAlley.rpy:1472
translate pt_br blendInCinema_b896225e:

    # "...never mind outright getting up and leaving."
    "...quanto mais se levantar e ir embora."

# game/inAlley.rpy:1473
translate pt_br blendInCinema_68b1d26e:

    # "You decide to let this run its course. Hopefully someone will come along..."
    "Você decide deixar as coisas acontecerem. Com sorte, alguém aparece..."

# game/inAlley.rpy:1474
translate pt_br blendInCinema_9979a58c:

    # "Right?"
    "Né?"

# game/inAlley.rpy:1475
translate pt_br blendInCinema_4cc0ec01:

    # "{size=-5}Or at least turn the film off?{/size}"
    "{size=-5}Ou, pelo menos, desliga o filme?{/size}"

# game/inAlley.rpy:1476
translate pt_br blendInCinema_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1478
translate pt_br blendInCinema_0de27b67:

    # "You continue to chant along with everyone..."
    "Você continua entoando com todo mundo..."

# game/inAlley.rpy:1482
translate pt_br blendInCinema_3f83d36c_1:

    # you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1485
translate pt_br blendInCinema_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1486
translate pt_br blendInCinema_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:1487
translate pt_br blendInCinema_397110ce:

    # "You start to feel lightheaded..."
    "Você começa a se sentir tonto..."

# game/inAlley.rpy:1488
translate pt_br blendInCinema_8b1e92a6:

    # "You feel as if you could fall asleep, but your eyes don’t feel heavy in the slightest."
    "Você sente como se fosse adormecer, mas seus olhos não estão nem um pouco pesados."

# game/inAlley.rpy:1489
translate pt_br blendInCinema_7ff2d155:

    # "You try to look around and gauge the others' emotional state..."
    "Você tenta olhar ao redor e avaliar o estado emocional dos outros..."

# game/inAlley.rpy:1490
translate pt_br blendInCinema_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:1491
translate pt_br blendInCinema_40d9ca73:

    # "..?"
    "..?"

# game/inAlley.rpy:1492
translate pt_br blendInCinema_a90dd9a4:

    # "But you can’t seem to look away from the screen."
    "Mas você não consegue desviar o olhar da tela."

# game/inAlley.rpy:1493
translate pt_br blendInCinema_2a365272:

    # "You try again, but you’re still locked into eye contact with the cat onscreen."
    "Você tenta de novo, mas ainda está fixado no olhar do gato na tela."

# game/inAlley.rpy:1495
translate pt_br blendInCinema_d752482c:

    # catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1497
translate pt_br blendInCinema_764e589b_1:

    # audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1498
translate pt_br blendInCinema_3f83d36c_2:

    # you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1501
translate pt_br blendInCinema_496d9edf:

    # "You attempt to physically force your line of vision away."
    "You tenta forçar fisicamente seu campo de visão para longe."

# game/inAlley.rpy:1502
translate pt_br blendInCinema_d9f4b72f:

    # "You steel your nerves, ready to throw yourself to the ground if you need to..."
    "Você se prepara mentalmente, pronto para se jogar no chão se for necessário..."

# game/inAlley.rpy:1503
translate pt_br blendInCinema_3e3a5b69:

    # "But your body only gets as far as tensing up for a moment before completely loosening itself again..."
    "Mas seu corpo só consegue tensionar por um momento antes de relaxar por completo novamente..."

# game/inAlley.rpy:1504
translate pt_br blendInCinema_2fb3a1df:

    # "...making you lay back limply into your seat."
    "...fazendo você se recostar frouxamente no assento."

# game/inAlley.rpy:1505
translate pt_br blendInCinema_2a71630f:

    # "You think you should be panicking right about now..."
    "Você acha que deveria estar em pânico agora..."

# game/inAlley.rpy:1506
translate pt_br blendInCinema_a6dd5ae6:

    # "But even your brain feels limp..."
    "Mas até mesmo seu cérebro parece frouxo..."

# game/inAlley.rpy:1510
translate pt_br blendInCinema_8cf039a1:

    # "...your thoughts a vaguely muted pastel pink..."
    "...seus pensamentos têm uma cor rosa pastel meio desbotada..."

# game/inAlley.rpy:1511
translate pt_br blendInCinema_1beaa2de:

    # "...airy..."
    "...delicado..."

# game/inAlley.rpy:1512
translate pt_br blendInCinema_ced05056:

    # "...sickeningly sweet and loosely spun..."
    "...enjoativamente doce e com uma textura leve..."

# game/inAlley.rpy:1513
translate pt_br blendInCinema_57ea3fbe:

    # "...like cotton candy."
    "...como algodão doce."

# game/inAlley.rpy:1514
translate pt_br blendInCinema_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:1515
translate pt_br blendInCinema_0f5de544:

    # "You..."
    "Você..."

# game/inAlley.rpy:1516
translate pt_br blendInCinema_54c46a6d:

    # "You like cotton candy..."
    "Você gosta de algodão doce..."

# game/inAlley.rpy:1517
translate pt_br blendInCinema_cb63a8d9:

    # "You think you shouldn’t mind your thoughts and body being like cotton candy either..."
    "Você pensa que não se importaria que seus pensamentos e corpo sejam como algodão doce..."

# game/inAlley.rpy:1518
translate pt_br blendInCinema_7c477b17:

    # "So... {w}why get up and {i}ruin{/i} that?"
    "Então... {w}por que levantar e {i}arruinar{/i} isso?"

# game/inAlley.rpy:1522
translate pt_br blendInCinema_ba89262e:

    # "It’s nice here."
    "Tá ótimo aqui."

# game/inAlley.rpy:1523
translate pt_br blendInCinema_e24de160:

    # "You’re more at peace than you’ve ever felt before in such a crowded room."
    "Você está mais em paz do que jamais se sentiu em uma sala tão cheia."

# game/inAlley.rpy:1524
translate pt_br blendInCinema_c24bdd0d:

    # "Still chanting, you’ve never felt so aligned and in tune with another person..."
    "Ainda entoando, você nunca se sentiu tão alinhado e em sintonia com outra pessoa..."

# game/inAlley.rpy:1525
translate pt_br blendInCinema_31f93be4:

    # "...let {i}alone{/i} with an entire room full of complete strangers."
    "...{i}quanto mais{/i} com uma sala inteira cheia de completos estranhos."

# game/inAlley.rpy:1526
translate pt_br blendInCinema_04d14b81:

    # "You’re not..."
    "Você não está..."

# game/inAlley.rpy:1527
translate pt_br blendInCinema_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:1528
translate pt_br blendInCinema_9d11f320:

    # "You're not alone..."
    "Você não está sozinho..."

# game/inAlley.rpy:1532
translate pt_br blendInCinema_ae0146e0:

    # "Out of the corner of your eye, the person next to you starts to sink back even further into their chair..."
    "Vendo de canto do olho, a pessoa ao seu lado começa a afundar ainda mais na cadeira..."

# game/inAlley.rpy:1535
translate pt_br blendInCinema_5f0ca8c0:

    # "Then they sink more."
    "Então afunda mais."

# game/inAlley.rpy:1538
translate pt_br blendInCinema_5929012b:

    # "Then {i}more.{/i}"
    "E então {i}mais.{/i}"

# game/inAlley.rpy:1539
translate pt_br blendInCinema_ab0534b1:

    # "Not like they’re slouching or reclining, but more like they’re..."
    "Não é como se estivesse se encurvando ou se deitando, é mais como se estivesse..."

# game/inAlley.rpy:1540
translate pt_br blendInCinema_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:1541
translate pt_br blendInCinema_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:1555
translate pt_br blendInCinema_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:1556
translate pt_br blendInCinema_38fb2682:

    # "{size=-5}...{b}deflating.{/b}{/size}"
    "{size=-5}...{b}esvaziando.{/b}{/size}"

# game/inAlley.rpy:1557
translate pt_br blendInCinema_e38a1999:

    # "Their skin bunches up and wrinkles like fabric as if their muscles... their {i}bones...{/i} have started to disintegrate."
    "Sua pele se amassa e enruga como tecido, como se seus músculos... seus {i}ossos...{/i} estivessem começando a se desintegrar."

# game/inAlley.rpy:1558
translate pt_br blendInCinema_debf73aa:

    # "Their eyes dim before sinking into their sockets."
    "Seus olhos escurecem antes de afundarem nas órbitas."

# game/inAlley.rpy:1559
translate pt_br blendInCinema_35c42551:

    # "Their mouth, still attempting to chant, falls open over a cut off \"Nya-\"..."
    "Sua boca, ainda tentando entoar, se abre com um 'Nya-' interrompido..."

# game/inAlley.rpy:1561
translate pt_br blendInCinema_a9055c48:

    # "...gaping as the word ends in an awful {i}{b}hiss{/b}{/i}... a final, weak release of air."
    "...a palavra termina em um terrível {i}{b}sibilo{/b}{/i}... uma última e fraca liberação de ar."

# game/inAlley.rpy:1563
translate pt_br blendInCinema_a20cefa7_8:

    # "..."
    "..."

# game/inAlley.rpy:1564
translate pt_br blendInCinema_16800af4:

    # "You muse thoughtfully about whether or not you should be distressed at the sight..."
    "Você reflete pensativamente se deveria ou não se angustiar com a cena..."

# game/inAlley.rpy:1569
translate pt_br blendInCinema_b9788577:

    # "...but even {i}then,{/i} the blanket of peace doesn’t leave you."
    "...mas mesmo {i}assim,{/i} o manto de paz não se desfaz."

# game/inAlley.rpy:1570
translate pt_br blendInCinema_214e33b0:

    # "Suddenly, from the pile of skin and clothes next to you... {w}you see a lump moving around..."
    "De repente, do monte de pele e roupas ao seu lado... {w}você vê um volume se movendo..."

# game/inAlley.rpy:1571
translate pt_br blendInCinema_594564ce:

    # "You watch in dazed fascination as the lump makes its way to the part of the skin where the head used to be..."
    "Você observa, fascinado e atordoado, enquanto o volume se move em direção à parte da pele onde costumava ser a cabeça..."

# game/inAlley.rpy:1572
translate pt_br blendInCinema_67dceeae:

    # "And out from the mouth..."
    "E de dentro da boca..."

# game/inAlley.rpy:1575
translate pt_br blendInCinema_7c9b7fd7:

    # "...crawls a tiny black kitten."
    "...sai um pequeno gatinho preto."

# game/inAlley.rpy:1576
translate pt_br blendInCinema_a20cefa7_9:

    # "..."
    "..."

# game/inAlley.rpy:1577
translate pt_br blendInCinema_3f83d36c_3:

    # you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
    you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."

# game/inAlley.rpy:1584
translate pt_br blendInCinema_193a0367:

    # "You can hear the familiar hissing sound all around you now as the unified chants start to fade..."
    "Você agora pode ouvir o familiar som de sibilo ao seu redor, enquanto os cânticos começam a desaparecer..."

# game/inAlley.rpy:1588
translate pt_br blendInCinema_83fb5231:

    # "...only to be replaced with the faint mewling of kittens."
    "...sendo substituídos pelo fraco miado dos gatinhos."

# game/inAlley.rpy:1591
translate pt_br blendInCinema_51f8946e:

    # "Finally, your voice is the only one still chanting... still human..."
    "Finalmente, sua voz é a única ainda entoando... ainda humano..."

# game/inAlley.rpy:1592
translate pt_br blendInCinema_31826a8b:

    # "And alone... {w}again."
    "E sozinho... {w}de novo."

# game/inAlley.rpy:1593
translate pt_br blendInCinema_5d0ac8cd:

    # "{size=-8}You don’t want that. {w}You can’t go back to that. {w}Not again. {w}Not again... {w}{b}Please...{/b}{/size}"
    "{size=-8}Você não quer isso. {w}Não pode voltar a isso. {w}De novo não. {w}De novo não... {w}{b}Por favor...{/b}{/size}"

# game/inAlley.rpy:1594
translate pt_br blendInCinema_a927f418:

    # "Just then, you go completely limp."
    "Então, você fica completamente mole."

# game/inAlley.rpy:1595
translate pt_br blendInCinema_84c8a0dd:

    # "Your body feels light, but it might as well weigh several tons..."
    "Você sente seu corpo leve, mas poderia estar pesando várias toneladas..."

# game/inAlley.rpy:1596
translate pt_br blendInCinema_92382baf:

    # "...because you realize quite suddenly that you can’t move..."
    "...porque você percebe de repente que não consegue se mover..."

# game/inAlley.rpy:1597
translate pt_br blendInCinema_c3f227f7:

    # "Not an {b}inch.{/b}"
    "Nem um {b}centímetro.{/b}"

# game/inAlley.rpy:1598
translate pt_br blendInCinema_e963d3dd:

    # "You can’t shift your eyes to look around..."
    "Você não consegue mexer os olhos para olhar em volta..."

# game/inAlley.rpy:1599
translate pt_br blendInCinema_c72a7267:

    # "You can’t even {i}breathe...{/i}"
    "Você não consegue nem {i}respirar...{/i}"

# game/inAlley.rpy:1600
translate pt_br blendInCinema_0c96f132:

    # "But somehow..."
    "Mas de alguma forma..."

# game/inAlley.rpy:1601
translate pt_br blendInCinema_9096c895:

    # "...the chant continues to creak weakly from your mouth."
    "...o cântico continua a sair timidamente da sua boca."

# game/inAlley.rpy:1602
translate pt_br blendInCinema_af288514:

    # you "{size=-5}N-Nyaa... Nyaa... N-Nyaaa-a-a-a-ah...{/size}"
    you "{size=-5}N-Nyaa... Nyaa... N-Nyaaa-a-a-a-ah...{/size}"

# game/inAlley.rpy:1612
translate pt_br blendInCinema_635a2b3f:

    # "A few kittens come forward and perch themselves on the chairs around you..."
    "Alguns gatinhos se aproximam e se acomodam nas cadeiras ao seu redor..."

# game/inAlley.rpy:1613
translate pt_br blendInCinema_a149e153:

    # "...watching your sinking body..."
    "...observando seu corpo afundar..."

# game/inAlley.rpy:1614
translate pt_br blendInCinema_d292541d:

    # "...mewling as they wait for their youngest sibling to emerge..."
    "...miando enquanto esperam o irmão mais novo deles emergir..."

# game/inAlley.rpy:1615
translate pt_br blendInCinema_5d4fa878:

    # "...from {i}you.{/i}"
    "...de {i}você.{/i}"

# game/inAlley.rpy:1616
translate pt_br blendInCinema_7a472b2f:

    # "Dozens of glowing eyes peer down at you..."
    "Dezenas de olhos brilhantes observam você..."

# game/inAlley.rpy:1619
translate pt_br blendInCinema_d4e4181d:

    # "...and as {i}your{/i} eyes start to cave into the sockets of your softening skull..."
    "...e enquanto {i}seus{/i} olhos começam a afundar nas órbitas do seu crânio amolecido..."

# game/inAlley.rpy:1622
translate pt_br blendInCinema_24c93db0:

    # "...you manage to make out the silhouette of a {b}familiar{/b} cat, perching on the seat right in front of you..."
    "...você consegue distinguir a silhueta de um gato {b}familiar{/b}, sentado no assento bem à sua frente..."

# game/inAlley.rpy:1625
translate pt_br blendInCinema_cb38fcb2:

    # "Your vision finally fades..."
    "Sua visão finalmente se apaga..."

# game/inAlley.rpy:1627
translate pt_br blendInCinema_0af14a4f:

    # "And as that same hiss of air expels itself from your mouth..."
    "E enquanto aquele mesmo sibilo de ar sai da sua boca..."

# game/inAlley.rpy:1628
translate pt_br blendInCinema_cc2adb18:

    # "...the last thing you sense is something small and {b}{i}alive{/i}{/b} shifting eagerly under your skin."
    "...a última coisa que você sente é algo pequeno e {b}{i}vivo{/i}{/b} se movendo entusiasmado sob sua pele."

# game/inAlley.rpy:1629
translate pt_br blendInCinema_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:1630
translate pt_br blendInCinema_a20cefa7_10:

    # "..."
    "..."

# game/inAlley.rpy:1631
translate pt_br blendInCinema_d2ce5919:

    # "Ending 18: Happy Birthday."
    "Final 18: Feliz Aniversário."

# game/inAlley.rpy:1651
translate pt_br goToCarnival_54663883:

    # "You spend the day at the carnival."
    "Você passa o dia no festival."

# game/inAlley.rpy:1652
translate pt_br goToCarnival_295775c9:

    # "Ferris wheel, roller coaster, pharaoh boat... {w}Rides you’ve been on before."
    "Roda-gigante, montanha-russa, barco viking... {w}Brinquedos nos quais você já esteve antes."

# game/inAlley.rpy:1653
translate pt_br goToCarnival_0d9e8fc3:

    # "Hoops, coin toss, balloon darts... {w}Games you’ve played before."
    "Basquete de arcade, arremesso de moedas, dardos... {w}Jogos que você já jogou antes."

# game/inAlley.rpy:1654
translate pt_br goToCarnival_32a40a6e:

    # "Funnel cake, popcorn, cotton candy... {w}Food you’ve eaten before."
    "Bolo de funil, pipoca, algodão doce... {w}Comidas que você já comeu antes."

# game/inAlley.rpy:1655
translate pt_br goToCarnival_d6de1944:

    # "All things you’ve enjoyed {i}before.{/i}"
    "Você já fez tudo isso {i}antes.{/i}"

# game/inAlley.rpy:1656
translate pt_br goToCarnival_c3c9efe7:

    # "You’re surrounded by groups of people all having fun together..."
    "Você está rodeado de grupos de pessoas se divertindo entre si..."

# game/inAlley.rpy:1657
translate pt_br goToCarnival_7598c0f4:

    # "Laughing, playing, eating, taking pictures... Making memories..."
    "Rindo, brincando, comendo, tirando fotos... Criando memórias..."

# game/inAlley.rpy:1658
translate pt_br goToCarnival_b0255334:

    # "And then there’s you."
    "E aí está você."

# game/inAlley.rpy:1659
translate pt_br goToCarnival_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1660
translate pt_br goToCarnival_a7421486:

    # "The sun hasn’t started to set yet, still high in the sky, but it will soon."
    "O sol ainda não começou a se pôr, está ainda bem alto no céu, mas logo vai."

# game/inAlley.rpy:1661
translate pt_br goToCarnival_527d7f2b:

    # "You start to wonder if maybe you should just go home for the day...{w} when you stop in your tracks."
    "Você começa a se perguntar se talvez não seria melhor ir para casa por hoje...{w} quando para abruptamente."

# game/inAlley.rpy:1664
translate pt_br goToCarnival_2f469756:

    # "You see something...{w} {i}new.{/i} {w}An attraction you’ve never seen before."
    "Você vê algo...{w} {i}novo.{/i} {w}Uma atração que nunca tinha visto antes."

# game/inAlley.rpy:1665
translate pt_br goToCarnival_ee0a18bc:

    # "A maze of... funhouse mirrors?"
    "Um labirinto... de espelhos?"

# game/inAlley.rpy:1666
translate pt_br goToCarnival_c0de53a5:

    # "It sounds..."
    "Parece..."

# game/inAlley.rpy:1667
translate pt_br goToCarnival_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1668
translate pt_br goToCarnival_3a26a699:

    # "...kind of lame, honestly."
    "...meio sem graça, honestamente."

# game/inAlley.rpy:1669
translate pt_br goToCarnival_4686437f:

    # "There isn’t even a line to get in."
    "Nem tem fila para entrar."

# game/inAlley.rpy:1670
translate pt_br goToCarnival_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:1671
translate pt_br goToCarnival_cbb84cc7:

    # "But then... {w}what else is there to do..?"
    "Mas então... {w}o que mais há para fazer..?"

# game/inAlley.rpy:1679
translate pt_br goToCarnival_ba0e6a77:

    # "There's got to be a better way to spend your day off than wandering around staring at weird mirrors..."
    "Tem que haver um jeito melhor de passar seu dia de folga do que vagar por aí olhando para espelhos estranhos..."

# game/inAlley.rpy:1686
translate pt_br goToCarnival_16617c12:

    # "Now what?"
    "E agora?"

# game/inAlley.rpy:1694
translate pt_br enteringMaze_1d094261:

    # "You enter the maze."
    "Você entra no labirinto."

# game/inAlley.rpy:1698
translate pt_br enteringMaze_8f41cd1a:

    # "A few rooms in and you notice that the mirrors aren’t {i}all{/i} weird."
    "Após entrar em algumas salas, você percebe que nem {i}todos{/i} os espelhos são estranhos."

# game/inAlley.rpy:1699
translate pt_br enteringMaze_f78b0a7d:

    # "Some just show {i}you{/i} looking back at yourself."
    "Alguns apenas mostram {i}você{/i} se olhando de volta."

# game/inAlley.rpy:1700
translate pt_br enteringMaze_8d2086a8:

    # "A little bored... A lot tired... And so very, very..."
    "Um pouco entediado... Bastante cansado... E tão, tão..."

# game/inAlley.rpy:1701
translate pt_br enteringMaze_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1705
translate pt_br enteringMaze_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1706
translate pt_br enteringMaze_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1708
translate pt_br enteringMaze_95cd8199:

    # "...Maybe this was a mistake."
    "...Talvez tenha sido um erro."

# game/inAlley.rpy:1710
translate pt_br enteringMaze_9712bff9:

    # "Why did you think going into a maze of {b}mirrors{/b} was a good idea? Even if it was something new to experience?"
    "Por que você pensou que ir num labirinto de {b}espelhos{/b} seria uma boa ideia? Mesmo que seja uma coisa nova para experienciar?"

# game/inAlley.rpy:1711
translate pt_br enteringMaze_14d0b867:

    # you "{i}I... I can't do this today...{/i}"
    you "{i}Eu... eu não consigo fazer isso hoje...{/i}"

# game/inAlley.rpy:1712
translate pt_br enteringMaze_316b5d4c:

    # "You turn around to head back the way you came..."
    "Você se vira para sair por onde você entrou..."

# game/inAlley.rpy:1718
translate pt_br enteringMaze_7515fb32:

    # "...only to bump into a mirror."
    "...e dá de cara com um espelho."

# game/inAlley.rpy:1719
translate pt_br enteringMaze_97c66c9f:

    # you "Ow! What the..? Where's the exit?"
    you "Ai! Mas que..? Cadê a saída?"

# game/inAlley.rpy:1720
translate pt_br enteringMaze_b06acef3:

    # "You try again only to find another mirror blocking your way."
    "Você tenta de novo e encontra outro espelho bloqueando seu caminho."

# game/inAlley.rpy:1721
translate pt_br enteringMaze_fbd47643:

    # "By the time you're all turned around, you've realized that the way you came in is completely gone."
    "Quando você já está desorientado, percebe que o caminho por onde entrou desapareceu completamente."

# game/inAlley.rpy:1722
translate pt_br enteringMaze_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:1723
translate pt_br enteringMaze_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:1724
translate pt_br enteringMaze_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:1725
translate pt_br enteringMaze_7d0d986d:

    # you "O-Okay, don't panic. I just have to... keep going forward... right?"
    you "T-Tá, não entra em pânico. Eu só tenho que... continuar seguindo em frente... né?"

# game/inAlley.rpy:1726
translate pt_br enteringMaze_c0fd94ff:

    # "You step through the only opening you can find and nearly trip over something on the ground."
    "Você passa pela única abertura que consegue encontrar e quase tropeça em algo no chão."

# game/inAlley.rpy:1727
translate pt_br enteringMaze_d113f422:

    # "You bend down and pick it up."
    "Você se abaixa e pega o objeto."

# game/inAlley.rpy:1728
translate pt_br enteringMaze_90b68c87:

    # you "..?"
    you "..?"

# game/inAlley.rpy:1729
translate pt_br enteringMaze_1ec82967:

    # you "What's {i}this{/i} doing here?"
    you "O que {i}isso{/i} tá fazendo aqui?"

# game/inAlley.rpy:1730
translate pt_br enteringMaze_c5a1d33c:

    # "In your hand rests a worn looking flashlight."
    "Na sua mão está uma lanterna com aparência desgastada."

# game/inAlley.rpy:1731
translate pt_br enteringMaze_cab20fdf:

    # "Curious, you flick it on."
    "Curioso, você a liga."

# game/inAlley.rpy:1733
translate pt_br enteringMaze_09d06ab8:

    # "*Click*"
    "*Clique*"

# game/inAlley.rpy:1734
translate pt_br enteringMaze_dfb9ab96:

    # "... {w}Huh... {w}The light doesn't look very-{w=1.0}{nw}"
    "... {w}Hã... {w}A luz não parece muito-{w=1.0}{nw}"

# game/inAlley.rpy:1738
translate pt_br enteringMaze_28b3ac41:

    # you "!!"
    you "!!"

# game/inAlley.rpy:1740
translate pt_br enteringMaze_ed7cc831:

    # you "Crap! The lights!"
    you "Droga! As luzes!"

# game/inAlley.rpy:1741
translate pt_br enteringMaze_8f63ef28:

    # "Did the power go out or did the attraction operator forget you were in here?"
    "A energia caiu ou o operador da atração esqueceu que você estava aqui?"

# game/inAlley.rpy:1742
translate pt_br enteringMaze_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:1743
translate pt_br enteringMaze_2babdbaa:

    # "How long {i}have{/i} you been in here, actually?"
    "Há quanto tempo você {i}está{/i} aqui, aliás?"

# game/inAlley.rpy:1744
translate pt_br enteringMaze_10b8c8d1:

    # "You pull out your phone to check the time or maybe call the police..."
    "Você pega seu celular pra ver as horas ou quem sabe ligar para a polícia..."

# game/inAlley.rpy:1745
translate pt_br enteringMaze_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:1746
translate pt_br enteringMaze_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:1747
translate pt_br enteringMaze_fe084e57:

    # "{size=-6}Your phone is dead.{/size}"
    "{size=-6}Seu celular está descarregado.{/size}"

# game/inAlley.rpy:1748
translate pt_br enteringMaze_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:1749
translate pt_br enteringMaze_f293e828:

    # "You grip the flashlight in your hand."
    "Você segura a lanterna com firmeza."

# game/inAlley.rpy:1750
translate pt_br enteringMaze_776c58c3:

    # "The light it emitted earlier was dim enough for you to know there's probably not that much juice left."
    "A luz que ela emitiu mais cedo era fraca o suficiente para você saber que provavelmente não deve ter muita carga restante."

# game/inAlley.rpy:1751
translate pt_br enteringMaze_e64595f9:

    # "Best to reserve it for a worst case scenario and feel your way out."
    "Best to reserve it for a worst case scenario and feel your way out."

# game/inAlley.rpy:1752
translate pt_br enteringMaze_60f2d28e:

    # "Yeah. Yeah, you can do this."
    "É. É, você consegue."

# game/inAlley.rpy:1753
translate pt_br enteringMaze_ddbe6ff4:

    # "You take a calming breath."
    "Você dá uma respirada para se acalmar."

# game/inAlley.rpy:1754
translate pt_br enteringMaze_fb40dccf:

    # you "{i}Well. {w}Forward we go...{/i}"
    you "{i}Bom. {w}Vamos em frente...{/i}"

# game/inAlley.rpy:1755
translate pt_br enteringMaze_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:1763
translate pt_br goToDogPark_5c14c202:

    # "You decide to take a stroll in a park or something."
    "Você decide dar uma volta em um parque ou algo assim."

# game/inAlley.rpy:1764
translate pt_br goToDogPark_e1880432:

    # "The only one within walking distance is the nearby dog park."
    "O único que dá para ir a pé é o parque para cachorros ali perto."

# game/inAlley.rpy:1765
translate pt_br goToDogPark_31ab9223:

    # "You think it’ll make you feel better."
    "Você acha que vai te fazer se sentir melhor."

# game/inAlley.rpy:1766
translate pt_br goToDogPark_b35402c8:

    # "First you get to see a cute cat today, now you’ll get to see a cute dog!"
    "Primeiro você viu um gato fofo hoje, agora vai poder ver um cachorro fofo!"

# game/inAlley.rpy:1767
translate pt_br goToDogPark_a749d8ba:

    # "{i}Several{/i} of them, in fact."
    "{i}Vários{/i} deles, na verdade."

# game/inAlley.rpy:1771
translate pt_br goToDogPark_3d36b825:

    # "The park is bustling with owners and their canine companions."
    "O parque está movimentado com os donos e seus companheiros caninos."

# game/inAlley.rpy:1772
translate pt_br goToDogPark_615bff09:

    # "Playing Frisbee, fetch, running, jumping, even napping~!"
    "Brincando de frisbee, de ir buscar, correndo, pulando, e até tirando uma soneca~!"

# game/inAlley.rpy:1773
translate pt_br goToDogPark_9df30f1c:

    # "Such cuties-{w=0.5}{nw}"
    "Que fofuras-{w=0.5}{nw}"

# game/inAlley.rpy:1776
translate pt_br goToDogPark_40780276:

    # "{size=-8}{b}Whatever. {w}Like you’d want anything to do with these mangy mutts.{/b}{/size}"
    "{size=-8}{b}Tanto faz. {w}Como se você quisesse saber desses vira-latas sarnentos.{/b}{/size}"

# game/inAlley.rpy:1779
translate pt_br goToDogPark_a2a49044:

    # you "{i}..?!{/i}"
    you "{i}..?!{/i}"

# game/inAlley.rpy:1780
translate pt_br goToDogPark_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1781
translate pt_br goToDogPark_0b798a8a:

    # "...What's wrong?"
    "...O que foi?"

# game/inAlley.rpy:1782
translate pt_br goToDogPark_58b82d2c:

    # "You didn’t think that?"
    "Você não pensou isso?"

# game/inAlley.rpy:1783
translate pt_br goToDogPark_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1784
translate pt_br goToDogPark_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1785
translate pt_br goToDogPark_50754116:

    # "You decide to move on."
    "Você decide seguir em frente."

# game/inAlley.rpy:1788
translate pt_br goToDogPark_c5900d2a:

    # "The dogs are all so adorable. You want to pet every single one you come across..."
    "Os cachorros são todos tão adoráveis. Você quer fazer carinho em cada um que encontra..."

# game/inAlley.rpy:1789
translate pt_br goToDogPark_e4211dcf:

    # "...but you know not all owners are cool with strangers just walking up and manhandling their pets."
    "...mas você sabe que nem todos os donos gostam de estranhos se aproximando e pegando nos seus animais."

# game/inAlley.rpy:1790
translate pt_br goToDogPark_4f5fba4a:

    # "Not all dogs appreciate it either."
    "Nem todos os cachorros gostam disso também."

# game/inAlley.rpy:1791
translate pt_br goToDogPark_4f7be349:

    # "So you stroll around the path, trying to exude a welcoming aura that will beckon one of these cute doggies to you."
    "Então você dá uma volta, tentando exalar uma aura acolhedora que atraia um desses cachorrinhos fofos até você."

# game/inAlley.rpy:1794
translate pt_br goToDogPark_3dd44abb:

    # "You don’t have to wait very long."
    "Você não precisa esperar muito."

# game/inAlley.rpy:1796
translate pt_br goToDogPark_1176e05a:

    # who "Bark!"
    who "Au!"

# game/inAlley.rpy:1799
translate pt_br goToDogPark_08c12ebd:

    # "You stop as the smallest, cutest puppy you’ve ever seen scampers up to you, blocking your path~"
    "Você para quando o menor e mais fofo filhote que você já viu corre até você, bloqueando seu caminho~"

# game/inAlley.rpy:1807
translate pt_br puppyMenu_11e3ab75:

    # who "{b}yes leave leave leave dogs are stupid and they all deserve to-{/b}{w=1.5}{nw}"
    who "{b}sim saia saia saia cachorros são estúpidos e todos eles merecem m-{/b}{w=1.5}{nw}"

# game/inAlley.rpy:1809
translate pt_br puppyMenu_16617c12:

    # "Now what?"
    "E agora?"

# game/inAlley.rpy:1814
translate pt_br puppyMenu_4289f415:

    # you "{i}...What?! It's just a puppy!{/i}"
    you "{i}...O quê?! É só um filhotinho!{/i}"

# game/inAlley.rpy:1820
translate pt_br puppyMenu_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:1821
translate pt_br puppyMenu_c19f215c:

    # you "{i}{b}NO!{/b} That's horrible!!{/i}"
    you "{i}{b}NÃO!{/b} Que horrível!!{/i}"

# game/inAlley.rpy:1827
translate pt_br puppyMenu_8ca8510a_1:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:1828
translate pt_br puppyMenu_90c2904a:

    # you "{i}That's disgusting! I think I'm going to be sick...{/i}"
    you "{i}Isso é nojento! Acho que vou vomitar...{/i}"

# game/inAlley.rpy:1835
translate pt_br dontHurtPuppy_592a1c9d:

    # you "{i}There's no way I would {b}ever{/b} do that!{/i}"
    you "{i}Eu não faria isso de jeito {b}nenhum{/b}!{/i}"

# game/inAlley.rpy:1841
translate pt_br pickUpPup_eef93c07:

    # "You pick up the puppy and-{w=0.75}{nw}"
    "Você segura o cachorrinho e-{w=0.75}{nw}"

# game/inAlley.rpy:1858
translate pt_br time_outPup_cc83c025:

    # you "AAAHH!" with hpunch
    you "AAAHH!" with hpunch

# game/inAlley.rpy:1861
translate pt_br time_outPup_2458cb0a:

    # "Terrified, you drop the puppy to the ground... {w}practically throwing it from you."
    "Aterrorizado, você solta o filhotinho no chão... {w}praticamente o jogando para longe."

# game/inAlley.rpy:1862
translate pt_br time_outPup_20de8723:

    # "You immediately feel horrible, wincing in guilt at the tiny yelp it releases upon hitting the ground."
    "Você se tente horrível imediatamente, se encolhendo de culpa com o ganidinho que o filhote solta ao cair no chão."

# game/inAlley.rpy:1863
translate pt_br time_outPup_23e2545d:

    # "The owner shoves you aside with a cutting glare and storms away with their puppy."
    "O dono te empurra com um olhar cortante e sai furioso com o filhote."

# game/inAlley.rpy:1864
translate pt_br time_outPup_529cf39a:

    # you "I-I'm sorry!"
    you "D-Desculpa!"

# game/inAlley.rpy:1865
translate pt_br time_outPup_4eef1ef7:

    # "You call out, but they don't turn back or respond."
    "Você chama, mas ele não se vira nem responde."

# game/inAlley.rpy:1866
translate pt_br time_outPup_7d44f3d1:

    # "Not that you expected them to."
    "Você nem esperava que ele fizesse isso."

# game/inAlley.rpy:1867
translate pt_br time_outPup_30fdc351:

    # "You {i}deserved{/i} it."
    "Você {i}mereceu{/i}."

# game/inAlley.rpy:1872
translate pt_br heldPup_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:1873
translate pt_br heldPup_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1874
translate pt_br heldPup_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1875
translate pt_br heldPup_209b2328:

    # "You just barely manage to rein in the reflex to throw the puppy as far away from you as possible."
    "Você mal consegue conter o reflexo de jogar o filhote o mais longe possível de você."

# game/inAlley.rpy:1876
translate pt_br heldPup_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:1877
translate pt_br heldPup_54632163:

    # "With shaking hands you quickly place the puppy on the grass and take several jerky steps back."
    "Com as mãos tremendo, você rapidamente coloca o filhote na grama e dá vários passos bruscos para trás."

# game/inAlley.rpy:1878
translate pt_br heldPup_3b0e2416:

    # "The owner seems confused by your reaction to their puppy, {w}but you just wave at them in a daze before hastily stumbling away."
    "O dono parece confuso com sua reação com o filhote, {w}mas você apenas acena para ele atordoado antes de sair com pressa."

# game/inAlley.rpy:1885
translate pt_br leavePark1_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:1886
translate pt_br leavePark1_6b46ce4b:

    # "You're not feeling so great about being at the park at the moment. Maybe you should {b}leave{/b}?"
    "Você não está se sentindo muito bem em estar no parque no momento. Talvez seja melhor ir embora?"

# game/inAlley.rpy:1895
translate pt_br leavePark1_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1896
translate pt_br leavePark1_c5fa6fdf:

    # "Good."
    "Bom."

# game/inAlley.rpy:1899
translate pt_br leavePark1_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1900
translate pt_br leavePark1_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1906
translate pt_br stayAtPark_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:1907
translate pt_br stayAtPark_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:1908
translate pt_br stayAtPark_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:1909
translate pt_br stayAtPark_7af3e563:

    # "{size=+32}{b}YOU STAY AT THE PARK.{/b}{/size}"
    "{size=+32}{b}VOCÊ FICA NO PARQUE.{/b}{/size}"

# game/inAlley.rpy:1910
translate pt_br stayAtPark_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:1911
translate pt_br stayAtPark_2ae435aa:

    # "You try to calm down by watching all the dogs from afar as you walk along the path..."
    "Você tenta se acalmar observando os cachorros de longe enquanto caminha..."

# game/inAlley.rpy:1912
translate pt_br stayAtPark_e94f558f:

    # "...but every so often, one will run up to you..."
    "...mas de vez em quando, um deles corre até você..."

# game/inAlley.rpy:1915
translate pt_br stayAtPark_f578fbad:

    # "And when they do, they look..."
    "E vendo de perto, eles parecem..."

# game/inAlley.rpy:1916
translate pt_br stayAtPark_26921232:

    # "...wrong."
    "...errados."

# game/inAlley.rpy:1917
translate pt_br stayAtPark_659594cd:

    # "Their owners don't seem to notice."
    "Seus donos não parecem perceber."

# game/inAlley.rpy:1920
translate pt_br stayAtPark_f9b5bdd2:

    # "You find a bench and sit down for a quick break, closing your eyes."
    "Você acha um banco e se senta para um descanso rápido, fechando os olhos."

# game/inAlley.rpy:1921
translate pt_br stayAtPark_7cc99210:

    # "Maybe... {w}this wasn’t the best idea after all."
    "Talvez... {w}essa não tenha sido a melhor ideia, afinal."

# game/inAlley.rpy:1924
translate pt_br stayAtPark_5917d0bd:

    # "Maybe..."
    "Talvez..."

# game/inAlley.rpy:1925
translate pt_br stayAtPark_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:1930
translate pt_br stayAtPark_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:1931
translate pt_br stayAtPark_8442ca13:

    # "y o u \ s h o u l d \ h a v e \ s t a y e d \ w i t h \ m e \ i n s t e a d"
    "v o c ê \ d e v e r i a \ t e r \ f i c a d o \ c o m i g o"

# game/inAlley.rpy:1934
translate pt_br stayAtPark_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:1935
translate pt_br stayAtPark_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:1939
translate pt_br stayAtPark_90b68c87:

    # you "..?"
    you "..?"

# game/inAlley.rpy:1943
translate pt_br stayAtPark_895c5168:

    # "You’re broken out of your thoughts when something lands gently on your lap."
    "Você é puxado de volta de seus pensamentos quando algo pousa suavemente em seu colo."

# game/inAlley.rpy:1944
translate pt_br stayAtPark_0a7e463f:

    # "You look down and see a frisbee on your thighs."
    "Você olha para baixo e vê um frisbee no seu colo."

# game/inAlley.rpy:1945
translate pt_br stayAtPark_1221e21a:

    # who "Hey! Sorry about that! Can you throw that back?"
    who "E aí! Foi mal por isso! Pode jogar de volta?"

# game/inAlley.rpy:1946
translate pt_br stayAtPark_bbb377a7:

    # "You look up to see an owner waving at you in the distance..."
    "Você olha para cima e vê um dono acenando para você de longe..."

# game/inAlley.rpy:1947
translate pt_br stayAtPark_200e4ba1:

    # "But more importantly..."
    "Mas mais importante..."

# game/inAlley.rpy:1949
translate pt_br stayAtPark_60fece2b:

    # dog "Bark! Bark! {b}Bark!!{/b}" with hpunch
    dog "Au! Au! {b}Au!!{/b}" with hpunch

# game/inAlley.rpy:1950
translate pt_br stayAtPark_90b68c87_1:

    # you "..?"
    you "..?"

# game/inAlley.rpy:1954
translate pt_br stayAtPark_594ff454:

    # dog "Bark!{w=0.5}{nw}" with hpunch
    dog "Au!{w=0.5}{nw}" with hpunch

# game/inAlley.rpy:1958
translate pt_br stayAtPark_594ff454_1:

    # dog "Bark!{w=0.5}{nw}" with hpunch
    dog "Au!{w=0.5}{nw}" with hpunch

# game/inAlley.rpy:1962
translate pt_br stayAtPark_594ff454_2:

    # dog "Bark!{w=0.5}{nw}" with hpunch
    dog "Au!{w=0.5}{nw}" with hpunch

# game/inAlley.rpy:1963
translate pt_br stayAtPark_467ad46e:

    # "A series of excited barks jerks your gaze forward and you see a large dog sprinting towards you."
    "Uma série de latidos animados atrai seu olhar para frente e você vê um cachorro grande correndo em sua direção."

# game/inAlley.rpy:1967
translate pt_br stayAtPark_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:1969
translate pt_br stayAtPark_264ae177:

    # dog "bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark"
    dog "au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au au "

# game/inAlley.rpy:1971
translate pt_br stayAtPark_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:1972
translate pt_br stayAtPark_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:1973
translate pt_br stayAtPark_b6c8c1b0:

    # "A series of excited barks jerks your gaze forward and you see a large \ {b}d o g{/b} \ sprinting towards you."
    "Uma série de latidos animados atrai seu olhar para frente e você vê um \ {b}c a c h o r r o{/b} \ grande correndo em sua direção."

# game/inAlley.rpy:1974
translate pt_br stayAtPark_85913fb3:

    # who "H-Hey! Hurry and throw it back!"
    who "E-Ei! Joga logo de volta!"

# game/inAlley.rpy:1975
translate pt_br stayAtPark_af2033bb:

    # you "Oh! Uhh..!"
    you "Ah! Ãhn..!"

# game/inAlley.rpy:1987
translate pt_br stayAtPark_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:1988
translate pt_br stayAtPark_5aa3617c:

    # "Good. And don't come back."
    "Bom. E não volte mais."

# game/inAlley.rpy:1991
translate pt_br stayAtPark_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:1992
translate pt_br stayAtPark_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:2024
translate pt_br didntThrowFrisbee_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:2028
translate pt_br didntThrowFrisbee_519d8628:

    # "The dog suddenly bounds at you, angry... {b}ferocious{/b}..."
    "O cachorro de repente se lança em você, com raiva... {b}feroz{/b}..."

# game/inAlley.rpy:2029
translate pt_br didntThrowFrisbee_ea9a7b78:

    # "It tears your limbs from your {color=#FF0000}body-{/color}{w=0.6}{nw}"
    "Ele arranca seus membros do seu {color=#FF0000}corpo-{/color}{w=0.6}{nw}"

# game/inAlley.rpy:2031
translate pt_br didntThrowFrisbee_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:2032
translate pt_br didntThrowFrisbee_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2033
translate pt_br didntThrowFrisbee_38dcb322:

    # you "{i}Was... {w}Was that real..?{/i}"
    you "{i}Isso... {w}Isso foi real..?{/i}"

# game/inAlley.rpy:2040
translate pt_br threwFrisbee_0420908d:

    # "You throw the frisbee and the dog runs in the opposite direction..."
    "Você joga o frisbee e o cachorro corre na direção oposta..."

# game/inAlley.rpy:2041
translate pt_br threwFrisbee_5d168864:

    # "...jumping and catching it right out of the air."
    "...saltando e o pegando no ar."

# game/inAlley.rpy:2042
translate pt_br threwFrisbee_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2043
translate pt_br threwFrisbee_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2045
translate pt_br threwFrisbee_25aa3339:

    # "Impressive."
    "Impressionante."

# game/inAlley.rpy:2046
translate pt_br threwFrisbee_b51ea75d:

    # "The dog and the owner walk up to you."
    "O cachorro e o dono andam até você."

# game/inAlley.rpy:2047
translate pt_br threwFrisbee_d0cab412:

    # who "Thanks for that. You can pet him if you want!"
    who "Opa, valeu. Pode fazer carinho nele se quiser!"

# game/inAlley.rpy:2053
translate pt_br threwFrisbee_8b661a0a:

    # "The dog looks up at you, eager for its reward of pets and pats for catching the frisbee."
    "O cachorro olha para você, ansioso pela sua recompensa de muito carinho por pegar o frisbee."

# game/inAlley.rpy:2054
translate pt_br threwFrisbee_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:2055
translate pt_br threwFrisbee_0cee522d:

    # you "{i}Should I..?{/i}"
    you "{i}Será que eu devo..?{/i}"

# game/inAlley.rpy:2065
translate pt_br threwFrisbee_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2066
translate pt_br threwFrisbee_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2067
translate pt_br threwFrisbee_f5df0148:

    # "A wise decision."
    "Sábia decisão."

# game/inAlley.rpy:2070
translate pt_br threwFrisbee_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:2071
translate pt_br threwFrisbee_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2079
translate pt_br threwFrisbee_8dabefc6_3:

    # ".."
    ".."

# game/inAlley.rpy:2080
translate pt_br threwFrisbee_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:2081
translate pt_br threwFrisbee_f5df0148_1:

    # "A wise decision."
    "Sábia decisão."

# game/inAlley.rpy:2084
translate pt_br threwFrisbee_8dabefc6_4:

    # ".."
    ".."

# game/inAlley.rpy:2085
translate pt_br threwFrisbee_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:2093
translate pt_br threwFrisbee_8dabefc6_5:

    # ".."
    ".."

# game/inAlley.rpy:2094
translate pt_br threwFrisbee_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:2095
translate pt_br threwFrisbee_f5df0148_2:

    # "A wise decision."
    "Sábia decisão."

# game/inAlley.rpy:2098
translate pt_br threwFrisbee_8dabefc6_6:

    # ".."
    ".."

# game/inAlley.rpy:2099
translate pt_br threwFrisbee_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:2109
translate pt_br threwFrisbee_8dabefc6_7:

    # ".."
    ".."

# game/inAlley.rpy:2110
translate pt_br threwFrisbee_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:2111
translate pt_br threwFrisbee_f5df0148_3:

    # "A wise decision."
    "Sábia decisão."

# game/inAlley.rpy:2114
translate pt_br threwFrisbee_8dabefc6_8:

    # ".."
    ".."

# game/inAlley.rpy:2115
translate pt_br threwFrisbee_a20cefa7_8:

    # "..."
    "..."

# game/inAlley.rpy:2123
translate pt_br threwFrisbee_8dabefc6_9:

    # ".."
    ".."

# game/inAlley.rpy:2124
translate pt_br threwFrisbee_a20cefa7_9:

    # "..."
    "..."

# game/inAlley.rpy:2125
translate pt_br threwFrisbee_f5df0148_4:

    # "A wise decision."
    "Sábia decisão."

# game/inAlley.rpy:2128
translate pt_br threwFrisbee_8dabefc6_10:

    # ".."
    ".."

# game/inAlley.rpy:2129
translate pt_br threwFrisbee_a20cefa7_10:

    # "..."
    "..."

# game/inAlley.rpy:2137
translate pt_br threwFrisbee_8dabefc6_11:

    # ".."
    ".."

# game/inAlley.rpy:2138
translate pt_br threwFrisbee_a20cefa7_11:

    # "..."
    "..."

# game/inAlley.rpy:2139
translate pt_br threwFrisbee_f5df0148_5:

    # "A wise decision."
    "Sábia decisão."

# game/inAlley.rpy:2142
translate pt_br threwFrisbee_8dabefc6_12:

    # ".."
    ".."

# game/inAlley.rpy:2143
translate pt_br threwFrisbee_a20cefa7_12:

    # "..."
    "..."

# game/inAlley.rpy:2151
translate pt_br threwFrisbee_8dabefc6_13:

    # ".."
    ".."

# game/inAlley.rpy:2152
translate pt_br threwFrisbee_a20cefa7_13:

    # "..."
    "..."

# game/inAlley.rpy:2153
translate pt_br threwFrisbee_f5df0148_6:

    # "A wise decision."
    "Sábia decisão."

# game/inAlley.rpy:2156
translate pt_br threwFrisbee_8dabefc6_14:

    # ".."
    ".."

# game/inAlley.rpy:2157
translate pt_br threwFrisbee_a20cefa7_14:

    # "..."
    "..."

# game/inAlley.rpy:2163
translate pt_br lastChance_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2164
translate pt_br lastChance_be011780:

    # "Really?"
    "Sério?"

# game/inAlley.rpy:2165
translate pt_br lastChance_12c3bc88:

    # "Are you sure?"
    "Tem certeza?"

# game/inAlley.rpy:2166
translate pt_br lastChance_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2167
translate pt_br lastChance_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2168
translate pt_br lastChance_e5bcb204:

    # "I'm warning you."
    "Estou te avisando."

# game/inAlley.rpy:2172
translate pt_br lastChance_7a59abb9:

    # "Do {b}not{/b} touch that mutt..."
    "{b}Não{/b} toque esse vira-lata..."

# game/inAlley.rpy:2173
translate pt_br lastChance_3f44ff49:

    # "{size=-10}...or you {b}will{/b} regret it.{/size}"
    "{size=-10}...ou você {b}vai{/b} se arrepender.{/size}"

# game/inAlley.rpy:2189
translate pt_br lastChance_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2190
translate pt_br lastChance_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2191
translate pt_br lastChance_6f0c5ba2:

    # "{size=+5}{b}G o o d.{/b}{/size}"
    "{size=+5}{b}B o m.{/b}{/size}"

# game/inAlley.rpy:2194
translate pt_br lastChance_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:2195
translate pt_br lastChance_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:2206
translate pt_br petTheDog_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2207
translate pt_br petTheDog_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2210
translate pt_br petTheDog_b546b376:

    # "You reach out your hand..."
    "Você estende a mão..."

# game/inAlley.rpy:2211
translate pt_br petTheDog_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2212
translate pt_br petTheDog_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2215
translate pt_br petTheDog_e3a5738f:

    # "...and you pet the \ {b}d o g.{/b}"
    "...e você faz carinho no  {b}c a c h o r r o.{/b}"

# game/inAlley.rpy:2216
translate pt_br petTheDog_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:2218
translate pt_br petTheDog_2f6d34a3:

    # dog "ARF! ARF!" with vpunch
    dog "ARF! ARF!" with vpunch

# game/inAlley.rpy:2219
translate pt_br petTheDog_2b8101ea:

    # "The dog seems pleased."
    "O cachorro parece contente."

# game/inAlley.rpy:2220
translate pt_br petTheDog_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:2221
translate pt_br petTheDog_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2222
translate pt_br petTheDog_92c9b5da:

    # "You don't feel well."
    "Você não se sente bem."

# game/inAlley.rpy:2223
translate pt_br petTheDog_f8342e66:

    # "Suddenly..."
    "De repente..."

# game/inAlley.rpy:2228
translate pt_br petTheDog_8802d801:

    # "...the sky begins to darken rapidly."
    "...o céu começa a escurecer rapidamente."

# game/inAlley.rpy:2231
translate pt_br petTheDog_73f12812:

    # "You look up along with all the pet owners to see that the sun has been eclipsed by the moon in the blink of an eye."
    "Você olha para cima junto com todos os donos de pets e vê que o sol foi eclipsado pela lua num piscar de olhos."

# game/inAlley.rpy:2232
translate pt_br petTheDog_ff907ae0:

    # "You vaguely remember that you should never look directly at an eclipse... {w}but for some reason..."
    "Você se lembra vagamente de que nunca se deve olhar diretamente para um eclipse... {w}mas por alguma razão..."

# game/inAlley.rpy:2233
translate pt_br petTheDog_906bee7c:

    # "...you don't look away."
    "...você não desvia o olhar."

# game/inAlley.rpy:2235
translate pt_br petTheDog_9ddc62b3:

    # who "{size=+35}{b}REOWWWWRRRRR!!!{/b}{/size}" with vpunch
    who "{size=+35}{b}REOWWWWRRRRR!!!{/b}{/size}" with vpunch

# game/inAlley.rpy:2236
translate pt_br petTheDog_34554171:

    # "A loud piercing yowl fills the air, shaking the ground beneath you."
    "Um rugido agudo e estridente enche o ar, fazendo o chão tremer sob você."

# game/inAlley.rpy:2237
translate pt_br petTheDog_509639fb:

    # "You instinctively move to lift your hands in order to shield your ears..."
    "Você instintivamente se move para levantar suas mãos e proteger os ouvidos..."

# game/inAlley.rpy:2238
translate pt_br petTheDog_bf0874e3:

    # "But..."
    "Mas..."

# game/inAlley.rpy:2250
translate pt_br petTheDog_4e2b93b2:

    # "...but the hand that had been cautiously pressed upon the dog's head comes away with some..."
    "...mas a mão que estava cautelosamente apoiada na cabeça do cachorro sai com um pouco de..."

# game/inAlley.rpy:2251
translate pt_br petTheDog_982bff5c:

    # "...{b}resistance.{/b}"
    "...{b}resistência.{/b}"

# game/inAlley.rpy:2252
translate pt_br petTheDog_990002ee:

    # "...{i}Resistance{/i} like sticky slime almost cementing your hand to the dog's head."
    "...{i}Resistência{/i} quase como uma gosma pegajosa colando sua mão à cabeça do cachorro."

# game/inAlley.rpy:2253
translate pt_br petTheDog_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:2254
translate pt_br petTheDog_2917a3d2:

    # "The slime stretches with your movement."
    "A gosma se estica com seu movimento."

# game/inAlley.rpy:2259
translate pt_br petTheDog_caf85056:

    # "The dog's {i}head{/i} stretches with it too... as the canine begins to just..."
    "A {i}cabeça{/i} do cachorro também se estica... enquanto o cão começa a simplesmente..."

# game/inAlley.rpy:2260
translate pt_br petTheDog_680a68f3:

    # "...{b}melt.{/b}"
    "...{b}derreter.{/b}"

# game/inAlley.rpy:2263
translate pt_br petTheDog_8c69f73c:

    # "It melts..."
    "Ele derrete..."

# game/inAlley.rpy:2264
translate pt_br petTheDog_027c5d74:

    # "And {b}melts{/b}..."
    "E {b}derrete{/b}..."

# game/inAlley.rpy:2265
translate pt_br petTheDog_8dabefc6_3:

    # ".."
    ".."

# game/inAlley.rpy:2266
translate pt_br petTheDog_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:2271
translate pt_br petTheDog_d5860291:

    # "...until it becomes a pile of goo at your feet."
    "...até virar uma substância pegajosa aos seus pés."

# game/inAlley.rpy:2272
translate pt_br petTheDog_d1718122:

    # you "Ah..! Ah..."
    you "Ah..! Ah..."

# game/inAlley.rpy:2273
translate pt_br petTheDog_11b3323e:

    # "You dazedly look around for the dog's owner, only to find an empty pile of familiar clothes where they once stood."
    "Você olha em volta atordoado procurando o dono do cachorro, mas encontra só uma pilha vazia de roupas no lugar onde ele estava."

# game/inAlley.rpy:2274
translate pt_br petTheDog_02dce559:

    # "You see similiar piles of clothes next to piles of goo scattered all across the park's open field."
    "Você vê pilhas semelhantes de roupas ao lado de pilhas de gosma espalhadas por todo o parque."

# game/inAlley.rpy:2275
translate pt_br petTheDog_91eaf471:

    # "All the dogs..."
    "Todos os cachorros..."

# game/inAlley.rpy:2276
translate pt_br petTheDog_ce3e3588:

    # "All their owners..."
    "E seus donos..."

# game/inAlley.rpy:2277
translate pt_br petTheDog_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:2278
translate pt_br petTheDog_4b8cc143:

    # "The melted goo of the dog in front of you then starts to move with a shudder."
    "A gosma derretida do cachorro à sua frente então começa a se mover com um tremor."

# game/inAlley.rpy:2279
translate pt_br petTheDog_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:2296
translate pt_br petTheDog_ae1a0e2d:

    # "It slithers across the grass toward the field in the center of the park..."
    "Ela se arrasta pela grama em direção ao campo no centro do parque..."

# game/inAlley.rpy:2297
translate pt_br petTheDog_9d855a0a:

    # "{size=-5}All the other piles of goo following after it...{/size}"
    "{size=-5}Todas as outras pilhas de gosma a seguem...{/size}"

# game/inAlley.rpy:2313
translate pt_br petTheDog_74d9ed3c:

    # "They mix and meld together into a single entity that shifts and undulates and bulges and {b}grows{/b}..."
    "Elas se misturam e se fundem em uma única entidade que se move, ondula, incha e {b}cresce{/b}..."

# game/inAlley.rpy:2314
translate pt_br petTheDog_56ebb028:

    # you "!!!"
    you "!!!"

# game/inAlley.rpy:2315
translate pt_br petTheDog_14c0cd48:

    # "You watch in dazed horror as it then fills out and shapes itself..."
    "Você assiste completamente horrorizado enquanto ela então toma forma e se molda..."

# game/inAlley.rpy:2342
translate pt_br petTheDog_4f09ae08:

    # "...into a{size=+5} {b}behemoth{/b} {/size}of a dog."
    "...em um cachorro{size=+5} {b}colossal{/b}{/size}."

# game/inAlley.rpy:2343
translate pt_br petTheDog_f6366ef7:

    # "Snarling and frothing at the mouth... red eyes frantic and searching..."
    "Rosnando e espumando pela boca... os olhos vermelhos frenéticos, procurando..."

# game/inAlley.rpy:2344
translate pt_br petTheDog_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:2345
translate pt_br petTheDog_40b96f53:

    # "...before the glowing orbs land directly on you."
    "...até que as esferas brilhantes se fixam diretamente em você."

# game/inAlley.rpy:2347
translate pt_br petTheDog_4a61b65e:

    # who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with hpunch
    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with hpunch

# game/inAlley.rpy:2348
translate pt_br petTheDog_8d3a4df3:

    # who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with vpunch
    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with vpunch

# game/inAlley.rpy:2349
translate pt_br petTheDog_3c469b8e:

    # who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}" with hpunch
    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}" with hpunch

# game/inAlley.rpy:2350
translate pt_br petTheDog_6f38f7c1:

    # "The rumbling growl it emits is so low and deep, you can feel the sound of it crash into you..."
    "O rosnado que sai é tão grave e profundo que você pode sentir o som se chocar contra você..."

# game/inAlley.rpy:2363
translate pt_br petTheDog_8dabefc6_4:

    # ".."
    ".."

# game/inAlley.rpy:2364
translate pt_br petTheDog_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:2365
translate pt_br petTheDog_bcf6dd4d:

    # "No."
    "Não."

# game/inAlley.rpy:2366
translate pt_br petTheDog_6fc296fe:

    # "You had your chance."
    "Você teve sua chance."

# game/inAlley.rpy:2367
translate pt_br petTheDog_7c3bd630:

    # "{b}{size=-10}B e t t e r{/size}{size=+20} \ {/size}{size=-10}s t a r t{/size}{size=+20} \ {/size}{size=-10}r u n n i n g~{/size}{/b}"
    "{b}{size=-10}M e l h o r{/size}{size=+20} \ {/size}{size=-10}c o m e ç a r{/size}{size=+20} \ {/size}{size=-10}a \ c o r r e r~{/size}{/b}"

# game/inAlley.rpy:2368
translate pt_br petTheDog_8dabefc6_5:

    # ".."
    ".."

# game/inAlley.rpy:2369
translate pt_br petTheDog_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:2376
translate pt_br justRunDog_512655b9:

    # "You try to run."
    "Você tenta correr."

# game/inAlley.rpy:2377
translate pt_br justRunDog_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2378
translate pt_br justRunDog_ecb852e9:

    # "{size=-8}...But you're not fast enough.{/size}"
    "{size=-8}...Mas você não é rápido o bastante.{/size}"

# game/inAlley.rpy:2379
translate pt_br justRunDog_16f8c477:

    # "The behemoth barely takes a few leaps before its already towering over you."
    "O colosso mal dá alguns saltos antes de já estar imponente sobre você."

# game/inAlley.rpy:2395
translate pt_br justRunDog_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:2411
translate pt_br justRunDog_38a2a096:

    # you "..!" with vpunch
    you "..!" with vpunch

# game/inAlley.rpy:2427
translate pt_br justRunDog_fa171d08:

    # you "..." with vpunch
    you "..." with vpunch

# game/inAlley.rpy:2428
translate pt_br justRunDog_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2429
translate pt_br justRunDog_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2430
translate pt_br justRunDog_cd0aadea:

    # "It tears you apart until there's {b}nothing{/b} left."
    "Ele te despedaça até não sobrar {b}nada{/b}."

# game/inAlley.rpy:2431
translate pt_br justRunDog_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2432
translate pt_br justRunDog_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2433
translate pt_br justRunDog_d7087055:

    # "Ending 21: {color=#FF0000}d o g{/color} \ person"
    "Final 21: prefiro \ {color=#FF0000}c a c h o r r o s{/color}"

# game/inAlley.rpy:2445
translate pt_br turnedBack_f75320e6:

    # "You sigh a little and walk back to the cat."
    "Você suspira e volta para o gato."

# game/inAlley.rpy:2451
translate pt_br turnedBack_d26d3e42:

    # cat "Meow! Mreowww!" with hpunch
    cat "Miau! Mrriaauuu!" with hpunch

# game/inAlley.rpy:2455
translate pt_br turnedBack_08f3a6f7:

    # "It looks almost hopeful... its tail swishing faster as it leans up a little more towards you..."
    "Ele parece quase esperançoso... seu rabo balança mais rápido enquanto ele se inclina um pouco mais na sua direção..."

# game/inAlley.rpy:2456
translate pt_br turnedBack_3df2e65f:

    # "...as if eager for your next move."
    "...como se estivesse ansioso pelo seu próximo movimento.."

# game/inAlley.rpy:2465
translate pt_br stayWithCat_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:2466
translate pt_br stayWithCat_cba272fa:

    # "...It's strange."
    "...Esquisito."

# game/inAlley.rpy:2467
translate pt_br stayWithCat_9be0e991:

    # "The more you hesitate to leave the alley... the more you find yourself wondering..."
    "Quanto mais você hesita sair do beco... mais você se pergunta..."

# game/inAlley.rpy:2471
translate pt_br stayWithCat_17dfe7fb:

    # "...{i}\"What's the point?\"{/i}"
    "...{i}\"Qual é o sentido disso?\"{/i}"

# game/inAlley.rpy:2472
translate pt_br stayWithCat_a7dcd07a:

    # "You'll go {i}where?{/i}"
    "Você vai para {i}onde?{/i}"

# game/inAlley.rpy:2473
translate pt_br stayWithCat_1c44447e:

    # "Do {i}what?{/i}"
    "Fazer {i}o quê?{/i}"

# game/inAlley.rpy:2477
translate pt_br stayWithCat_3e3445a0:

    # "What's the point when you're always doing all of it completely and utterly {i}alone?{/i}"
    "Qual é o sentido, quando você sempre faz tudo completamente, totalmente {i}sozinho?{/i}"

# game/inAlley.rpy:2478
translate pt_br stayWithCat_780c15a3:

    # "Even going home to your apartment wouldn't help, would it..?"
    "Nem mesmo voltar para o seu apartamento ajudaria, ajudaria...?"

# game/inAlley.rpy:2479
translate pt_br stayWithCat_247ad3ce:

    # "One bedroom. One bathroom."
    "Um quarto. Um banheiro."

# game/inAlley.rpy:2480
translate pt_br stayWithCat_2b464023:

    # "...And one {i}you{/i} living alone in it."
    "...Só {i}você{/i} sozinho vivendo nele."

# game/inAlley.rpy:2481
translate pt_br stayWithCat_53cba332:

    # "It's been like that for so, so long..."
    "Tem sido assim por tanto, tanto tempo..."

# game/inAlley.rpy:2482
translate pt_br stayWithCat_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2483
translate pt_br stayWithCat_2ce5ae19:

    # "{i}So{/i} long..."
    "{i}Tanto{/i} tempo..."

# game/inAlley.rpy:2489
translate pt_br stayWithCat_aa965c11:

    # cat "Meoww..."
    cat "Miauu..."

# game/inAlley.rpy:2491
translate pt_br stayWithCat_38a2a096:

    # you "..!" with vpunch
    you "..!" with vpunch

# game/inAlley.rpy:2494
translate pt_br stayWithCat_cb2e56dc:

    # "You're startled when you feel an impossibly soft paw press lightly against your wet cheek."
    "Você se assusta quando sente uma patinha incrivelmente macia pressionar levemente sua bochecha molhada."

# game/inAlley.rpy:2495
translate pt_br stayWithCat_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2496
translate pt_br stayWithCat_e92a5260:

    # "You didn't realize you'd been crying."
    "Você não tinha percebido que estava chorando."

# game/inAlley.rpy:2497
translate pt_br stayWithCat_6b313aa1:

    # "Or that your little breakdown had literally brought you to your knees... right in front of the cat's box."
    "Ou que sua pequena crise literalmente te colocou de joelhos... bem na frente da caixa do gato."

# game/inAlley.rpy:2498
translate pt_br stayWithCat_7a5c58a5:

    # "You feel slightly embarrassed, but the cat responds as if it can sense your self deprecating feelings creeping in."
    "Você se sente um pouco envergonhado, mas o gato reage como se pudesse sentir seus sentimentos autodepreciativos surgindo."

# game/inAlley.rpy:2503
translate pt_br stayWithCat_fbbaa7ef:

    # cat "Meow! Meoww!" with hpunch
    cat "Miau! Miauu!" with hpunch

# game/inAlley.rpy:2516
translate pt_br stayWithCat_59ede497:

    # "It presses its paw on your cheek three times in quick succession..."
    "Ele pressiona a pata em sua bochecha bem rápido três vezes seguidas..."

# game/inAlley.rpy:2517
translate pt_br stayWithCat_b17e43f8:

    # "...as if trying to slap you out of your melancholic state..."
    "...como se estivesse tentando te dar uns tapas para te tirar do seu estado melancólico..."

# game/inAlley.rpy:2518
translate pt_br stayWithCat_11b3d26b:

    # "...but they're so light, the slaps feel more like getting gently and eagerly petted."
    "...mas são tão leves que os tapas parecem mais uns carinhos ansiosamente suaves."

# game/inAlley.rpy:2519
translate pt_br stayWithCat_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:2522
translate pt_br stayWithCat_c1ba2b2d:

    # you "Heh... Hehe..."
    you "Heh... Hehe..."

# game/inAlley.rpy:2523
translate pt_br stayWithCat_c169d67d:

    # "You can't help but laugh a little."
    "Você não consegue evitar de soltar um riso."

# game/inAlley.rpy:2524
translate pt_br stayWithCat_43d916f4:

    # you "Can't believe I'm having a meltdown in a dirty, old alley... with a stray cat comforting me..."
    you "Não acredito que tô tendo um colapso nesse beco sujo e velho... com um gato de rua me consolando..."

# game/inAlley.rpy:2529
translate pt_br stayWithCat_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/inAlley.rpy:2531
translate pt_br stayWithCat_a0caf1eb:

    # "You smile and show your gratitude with a scratch to the cat's chin."
    "Você sorri e demonstra sua gratidão fazendo um carinho no queixo do gato."

# game/inAlley.rpy:2535
translate pt_br stayWithCat_67107e6c:

    # cat "Purr..."
    cat "Purr..."

# game/inAlley.rpy:2536
translate pt_br stayWithCat_b6d97d6f:

    # you "Thanks... I'm fine, really. That just happens sometimes..."
    you "Valeu... Tô bem, sério. Isso acontece às vezes..."

# game/inAlley.rpy:2540
translate pt_br stayWithCat_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/inAlley.rpy:2541
translate pt_br stayWithCat_b9131292:

    # you "I really {i}do{/i} like being alone most of the time."
    you "Eu realmente {i}gosto{/i} de estar sozinho a maior parte do tempo."

# game/inAlley.rpy:2542
translate pt_br stayWithCat_638b0480:

    # you "It's the only time I feel comfortable being myself, you know?"
    you "É o único momento que me sinto confortável em ser eu mesmo, sabe?"

# game/inAlley.rpy:2543
translate pt_br stayWithCat_bac70924:

    # you "...But even {i}I{/i} get lonely every now and then."
    you "...Mas até {i}eu{/i} me sinto solitário de vez em quando."

# game/inAlley.rpy:2544
translate pt_br stayWithCat_5bf669ab:

    # you "It's easy to ignore when I'm keeping myself busy..."
    you "É fácil de ignorar quando eu me mantenho ocupado..."

# game/inAlley.rpy:2545
translate pt_br stayWithCat_2ba4676d:

    # you "That's why I pushed myself to go out today, I think..."
    you "Por isso que eu me forcei a sair hoje, eu acho..."

# game/inAlley.rpy:2550
translate pt_br stayWithCat_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/inAlley.rpy:2551
translate pt_br stayWithCat_94d526e4:

    # you "Heh, or maybe I was hoping to make a friend or something..."
    you "Heh, ou talvez eu esperasse fazer um amigo ou algo assim..."

# game/inAlley.rpy:2552
translate pt_br stayWithCat_7393f44f:

    # you "...though I guess that wouldn't be a good idea."
    you "...mas acho que isso não seria uma boa ideia."

# game/inAlley.rpy:2553
translate pt_br stayWithCat_623ea201:

    # you "I doubt someone like me would make for a very good friend to anyone..."
    you "Duvido que alguém como eu seria um bom amigo pra qualquer pessoa..."

# game/inAlley.rpy:2558
translate pt_br stayWithCat_33634540:

    # cat "Meow! Meow! {i}Meow!{/i}" with hpunch
    cat "Miau! Miau! {i}Miau!{/i}" with hpunch

# game/inAlley.rpy:2560
translate pt_br stayWithCat_37101878:

    # you "Hehehe! Okay, okay, maybe I won't go so far as to say {i}that,{/i} but..."
    you "Hehehe! Ok, ok, talvez eu não vá tão longe a ponto de dizer {i}isso,{/i} mas..."

# game/inAlley.rpy:2563
translate pt_br stayWithCat_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2564
translate pt_br stayWithCat_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2565
translate pt_br stayWithCat_e7e24fe2:

    # "You stay."
    "Você fica."

# game/inAlley.rpy:2566
translate pt_br stayWithCat_319a0073:

    # "You stay and just... talk to the cat."
    "Você fica e só... conversa com o gato."

# game/inAlley.rpy:2567
translate pt_br stayWithCat_16f8a04a:

    # "About anything that comes to mind."
    "Sobre qualquer coisa que vier à mente."

# game/inAlley.rpy:2568
translate pt_br stayWithCat_42df3336:

    # "Your isolation... {w}your loneliness..."
    "Seu isolamento... {w}sua solidão..."

# game/inAlley.rpy:2569
translate pt_br stayWithCat_297381cd:

    # "Your many fears... {w}your losses... {w}your {i}emptiness{/i}..."
    "Seus muitos medos... {w}suas derrotas... {w}seu {i}vazio{/i}..."

# game/inAlley.rpy:2570
translate pt_br stayWithCat_8dc6e13c:

    # "Although..."
    "Embora..."

# game/inAlley.rpy:2571
translate pt_br stayWithCat_ecd85097:

    # "The longer you stay there... the smaller that once significant emptiness feels."
    "Quanto mais você fica ali, menor a solidão que antes parecia tão significativa."

# game/inAlley.rpy:2572
translate pt_br stayWithCat_bd68e443:

    # "It's been so long since someone just... listened."
    "Já faz tempo desde que alguém simplesmente... ouviu."

# game/inAlley.rpy:2573
translate pt_br stayWithCat_152f4e90:

    # "Your words shift to gentler topics..."
    "Suas palavras mudam para tópicos mais tranquilos..."

# game/inAlley.rpy:2574
translate pt_br stayWithCat_ae2b8e89:

    # "Your hopes... {w}your dreams... {w}happy memories of the past..."
    "Suas esperanças... {w}seus sonhos... {w}memórias felizes do passado..."

# game/inAlley.rpy:2578
translate pt_br stayWithCat_92865e06:

    # "As you talk, you don't even notice the once cold, concrete walls of the alley becoming flesh-like... {w}warm and pink..."
    "Enquanto você fala, você nem percebe que as frias e duras paredes de concreto do beco se tornaram algo parecido com carne... {w}quente e rosada..."

# game/inAlley.rpy:2580
translate pt_br stayWithCat_87393f7d:

    # "...its softness slowly engulfing the both of you."
    "...sua maciez lentamente envolve vocês dois."

# game/inAlley.rpy:2581
translate pt_br stayWithCat_8a1fe200:

    # "The sound of your own voice feels hypnotic as it reaches your ears..."
    "O som da sua própria voz parece hipnótico quando alcança seus ouvidos..."

# game/inAlley.rpy:2582
translate pt_br stayWithCat_fff68cb0:

    # "...encouraging you to speak more of the depths of your heart into the open..."
    "...te encorajando a falar mais sobre as profundezas do seu coração..."

# game/inAlley.rpy:2583
translate pt_br stayWithCat_0e2e8677:

    # "You give in easily..."
    "Você se entrega facilmente..."

# game/inAlley.rpy:2584
translate pt_br stayWithCat_e7e1c877:

    # "When you {i}do{/i} run out of words, you're not sure how long you've been sitting there."
    "Quando você {i}realmente{/i} fica sem palavras, não tem certeza de quanto tempo passou sentado ali."

# game/inAlley.rpy:2585
translate pt_br stayWithCat_0e608ebb:

    # "But not knowing doesn't seem to bother you."
    "Mas não saber não parece te incomodar."

# game/inAlley.rpy:2586
translate pt_br stayWithCat_b3e12ea5:

    # "Still..."
    "Ainda assim..."

# game/inAlley.rpy:2587
translate pt_br stayWithCat_eb93532e:

    # "A strange question enters your mind..."
    "Uma pergunta estranha entra na sua mente..."

# game/inAlley.rpy:2595
translate pt_br stayForever_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2596
translate pt_br stayForever_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2597
translate pt_br stayForever_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:2598
translate pt_br stayForever_30bd3818:

    # you "{i}Why would I want to do that..?{/i}"
    you "{i}Por que eu faria isso..?{/i}"

# game/inAlley.rpy:2601
translate pt_br stayForever_a654ceef:

    # "You're too tired to move."
    "Você está cansado demais para se mover."

# game/inAlley.rpy:2602
translate pt_br stayForever_9655b73f:

    # "Pouring out your heart and soul has taken a surprising toll on you, but you have no regrets."
    "Se abrir de coração e alma te deixou acabado, mas você não se arrepende."

# game/inAlley.rpy:2603
translate pt_br stayForever_411ac15d:

    # "You're so..."
    "Você está tão..."

# game/inAlley.rpy:2604
translate pt_br stayForever_27a37757:

    # "...happy."
    "...feliz."

# game/inAlley.rpy:2605
translate pt_br stayForever_1fa1c68c:

    # "You don't think you've ever felt so heard..."
    "Você nunca se sentiu tão ouvido..."

# game/inAlley.rpy:2606
translate pt_br stayForever_177b5180:

    # "So {i}seen{/i}..."
    "Tão {i}visto{/i}..."

# game/inAlley.rpy:2608
translate pt_br stayForever_925e7315:

    # "You lean forward to rest your head on the box."
    "Você se inclina para descansar a cabeça na caixa."

# game/inAlley.rpy:2609
translate pt_br stayForever_0acae387:

    # "You don't feel the rough cardboard you were expecting..."
    "Não sente o papelão áspero que esperava..."

# game/inAlley.rpy:2610
translate pt_br stayForever_4d5b0ea2:

    # "Instead you find yourself resting on a mass of... {i}something...{/i}"
    "Em vez disso, sua cabeça encontra um amontoado de... {i}algo...{/i}"

# game/inAlley.rpy:2611
translate pt_br stayForever_a51bed06:

    # "Something soft and slightly damp and warm."
    "Algo macio, ligeiramente úmido e quente."

# game/inAlley.rpy:2612
translate pt_br stayForever_b873f6ae:

    # "So, so, {i}so{/i} warm..."
    "Tão, tão, {i}tão{/i} quente..."

# game/inAlley.rpy:2613
translate pt_br stayForever_e8057081:

    # "But you can't find it in you to care on what it could be."
    "Mas você não consegue se importar com o que isso poderia ser."

# game/inAlley.rpy:2614
translate pt_br stayForever_bc4c2b4d:

    # "You're... so tired."
    "Você está... tão cansado."

# game/inAlley.rpy:2618
translate pt_br stayForever_dec216e1:

    # "You close your eyes..."
    "Você fecha os olhos..."

# game/inAlley.rpy:2619
translate pt_br stayForever_bcb743d5:

    # "...and you get the feeling that they'll probably never open again."
    "...e você sente que provavelmente eles nunca mais vão se abrir."

# game/inAlley.rpy:2622
translate pt_br stayForever_9fb636b8:

    # "But as that all-encompassing warmth encases you slowly, {i}completely{/i}..."
    "Mas conforme aquele calor envolvente te abraça lentamente, {i}completamente{/i}..."

# game/inAlley.rpy:2623
translate pt_br stayForever_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2624
translate pt_br stayForever_6c8098ae:

    # "...you feel nothing but pure contentment."
    "...Você não sente nada além de puro contentamento."

# game/inAlley.rpy:2625
translate pt_br stayForever_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2626
translate pt_br stayForever_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2627
translate pt_br stayForever_2dacdaff:

    # "Ending 22: Not Alone"
    "Final 22: Não Estou Sozinho"

# game/inAlley.rpy:2639
translate pt_br leaveCat2_62d83bb2:

    # "You {i}really{/i} can't afford to take the cat home with you."
    "Você {i}realmente{/i} não pode arcar com o custo de levar o gato para casa."

# game/inAlley.rpy:2640
translate pt_br leaveCat2_bfab167e:

    # "Well..."
    "Bom..."

# game/inAlley.rpy:2641
translate pt_br leaveCat2_35db1bfe:

    # "Maybe it wouldn't be {i}completely{/i} impossible..."
    "Talvez não seja {i}completamente{/i} impossível..."

# game/inAlley.rpy:2642
translate pt_br leaveCat2_45d354de:

    # "A few extraneous luxuries cut here and there and you could see things working out, sure."
    "Só cortar alguns luxos aqui e ali e você pode dar um jeito, com certeza."

# game/inAlley.rpy:2643
translate pt_br leaveCat2_b03adc09:

    # "But there's a slight problem that's been making you waver this whole time..."
    "Mas há um probleminha que tem te feito hesitar esse tempo todo..."

# game/inAlley.rpy:2644
translate pt_br leaveCat2_0af247dd:

    # "One you simply can't ignore."
    "Um que você simplesmente não pode ignorar."

# game/inAlley.rpy:2645
translate pt_br leaveCat2_8335c1ba:

    # "That problem being..."
    "O problema é..."

# game/inAlley.rpy:2646
translate pt_br leaveCat2_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2648
translate pt_br leaveCat2_e43e2eb3:

    # "{size=-10}...that you just can't trust this cat.{/size}"
    "{size=-10}...que você não consegue confiar nesse gato.{/size}"

# game/inAlley.rpy:2651
translate pt_br leaveCat2_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:2652
translate pt_br leaveCat2_9bd5d3d6:

    # "It sounds ridiculous even in your head."
    "Isso soa ridículo até na sua cabeça."

# game/inAlley.rpy:2653
translate pt_br leaveCat2_35a1162a:

    # "Cats don't require trust to care for."
    "Gatos não precisam de confiança para serem cuidados."

# game/inAlley.rpy:2654
translate pt_br leaveCat2_6e2bb326:

    # "They're incapable of betrayal or deception specifically because like other animals..."
    "Eles são incapazes de trair ou enganar especificamente porque, como outros animais..."

# game/inAlley.rpy:2655
translate pt_br leaveCat2_4a2b5d96:

    # "...they only seek out the most basic essentials of living, procreation and comfort."
    "eles buscam apenas o básico para viver, reprodução e conforto."

# game/inAlley.rpy:2656
translate pt_br leaveCat2_03e4f8cf:

    # "Malice isn't something that could ever logically be applied to them..."
    "Malícia não é algo que poderia ser logicamente atribuído a eles..."

# game/inAlley.rpy:2657
translate pt_br leaveCat2_da78fda5:

    # "And yet..."
    "E ainda assim..."

# game/inAlley.rpy:2661
translate pt_br leaveCat2_c353258e:

    # "You feel it."
    "Você sente."

# game/inAlley.rpy:2662
translate pt_br leaveCat2_172fd88c:

    # "That behind that gut-wrenchingly adorable face..."
    "Que por trás daquela carinha que dá vontade de apertar de tão fofa..."

# game/inAlley.rpy:2663
translate pt_br leaveCat2_95ccc501:

    # "...is something dangerous."
    "...há algo perigoso."

# game/inAlley.rpy:2664
translate pt_br leaveCat2_f41ec9ee:

    # "And that \"something\"... brought you here."
    "E esse \"algo\"... trouxe você aqui."

# game/inAlley.rpy:2665
translate pt_br leaveCat2_6b709127:

    # "It {i}called{/i} you here."
    "{i}Chamou{/i} você aqui."

# game/inAlley.rpy:2666
translate pt_br leaveCat2_cc7203ce:

    # "You're a curious person, but even {i}you{/i} can't shake the deep, instinctual desire to-"
    "Você é uma pessoa curiosa, mas nem mesmo {i}você{/i} consegue ignorar o profundo desejo instintivo de-"

# game/inAlley.rpy:2668
translate pt_br leaveCat2_7844b763:

    # "{size=-10}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/size}"
    "{size=-10}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/size}"

# game/inAlley.rpy:2670
translate pt_br leaveCat2_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:2673
translate pt_br leaveCat2_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:2674
translate pt_br leaveCat2_ec8eee8f:

    # "The cat's face looks blank."
    "A face do gato parece vazia."

# game/inAlley.rpy:2675
translate pt_br leaveCat2_f138e706:

    # "It's an expression you've seen on many cats before, but something about it feels..."
    "É uma expressão que você já viu em muitos gatos antes, mas algo nela parece..."

# game/inAlley.rpy:2677
translate pt_br leaveCat2_9232c2e0:

    # "{size=-5}{i}...sharper.{/i}{/size}"
    "{size=-5}{i}...mais incisivo.{/i}{/size}"

# game/inAlley.rpy:2678
translate pt_br leaveCat2_f9e83d9e:

    # "Like it's aware of your thoughts and your intention to leave..."
    "Como se estivesse ciente dos seus pensamentos e da sua intenção de ir embora..."

# game/inAlley.rpy:2682
translate pt_br leaveCat2_26b934d7:

    # "...and it's daring you to {b}try.{/b}"
    "...e estivesse desafiando você a {b}tentar.{/b}"

# game/inAlley.rpy:2683
translate pt_br leaveCat2_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:2684
translate pt_br leaveCat2_1d0166ae:

    # "You slowly stand up."
    "Você lentamente se levanta."

# game/inAlley.rpy:2685
translate pt_br leaveCat2_428f29c1:

    # "The cat tracks your movement with its eyes, not bothering to move its head."
    "O gato acompanha seus movimentos com os olhos, sem se dar ao trabalho de mover a cabeça."

# game/inAlley.rpy:2686
translate pt_br leaveCat2_0e2ae1c1:

    # "You don't say a word."
    "Você não diz uma palavra."

# game/inAlley.rpy:2687
translate pt_br leaveCat2_7ca87e19:

    # "You try not to even think..."
    "Você tenta nem pensar..."

# game/inAlley.rpy:2691
translate pt_br leaveCat2_7844b763_1:

    # "{size=-10}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/size}"
    "{size=-10}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/size}"

# game/inAlley.rpy:2694
translate pt_br leaveCat2_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2695
translate pt_br leaveCat2_58e3ca69:

    # "...though you don't really succeed."
    "...embora não tenha muito sucesso."

# game/inAlley.rpy:2701
translate pt_br leaveCat2_8fd85953:

    # "You turn around and quickly leave the alley, feeling those sharp eyes on you the whole way."
    "Você se vira e sai rapidamente do beco, sentindo aqueles olhos penetrantes em você por todo o caminho."

# game/inAlley.rpy:2704
translate pt_br leaveCat2_ec6bd7ee:

    # "When you get a good distance away, you finally take in deep gulps of air."
    "Quando você pega uma boa distância, finalmente consegue respirar fundo."

# game/inAlley.rpy:2705
translate pt_br leaveCat2_83668abb:

    # you "*pant*... *pant*... *pant*..."
    you "*ofegante*... *ofegante*... *ofegante*..."

# game/inAlley.rpy:2706
translate pt_br leaveCat2_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2707
translate pt_br leaveCat2_0f5de544:

    # "You..."
    "Você..."

# game/inAlley.rpy:2708
translate pt_br leaveCat2_9d5e507d:

    # "You feel better now."
    "Você se sente melhor agora."

# game/inAlley.rpy:2709
translate pt_br leaveCat2_336142e1:

    # "And there's still plenty of time left to enjoy your day off!"
    "E ainda há muito tempo para aproveitar seu dia de folga!"

# game/inAlley.rpy:2710
translate pt_br leaveCat2_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2711
translate pt_br leaveCat2_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:2712
translate pt_br leaveCat2_e666a796:

    # "As long as you forget everything that just happened."
    "Contanto que você esqueça tudo que acabou de acontecer."

# game/inAlley.rpy:2713
translate pt_br leaveCat2_33744274:

    # "{b}But what to do?{/b}"
    "{b}Mas o que fazer?{/b}"

# game/inAlley.rpy:2744
translate pt_br getAway1_e4612ec1:

    # you "..!"
    you "..!"

# game/inAlley.rpy:2745
translate pt_br getAway1_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:2746
translate pt_br getAway1_71b06060:

    # "What the..?!"
    "Mas que..?!"

# game/inAlley.rpy:2747
translate pt_br getAway1_5fd62bd2:

    # "How did you get back here?!"
    "Como você voltou aqui?!"

# game/inAlley.rpy:2750
translate pt_br getAway1_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2752
translate pt_br getAway1_f2809dbd:

    # "{size=-10}{color=#FF0000}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/color}{/size}"
    "{size=-10}{color=#FF0000}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/color}{/size}"

# game/inAlley.rpy:2754
translate pt_br getAway1_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2755
translate pt_br getAway1_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2758
translate pt_br getAway1_d4f2db8f:

    # "You leave the alley. {i}Quickly.{/i}"
    "Você deixa o beco. {i}Rapidamente.{/i}"

# game/inAlley.rpy:2761
translate pt_br getAway1_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2762
translate pt_br getAway1_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2763
translate pt_br getAway1_bcf48cbf:

    # "What now..?"
    "E agora..?"

# game/inAlley.rpy:2771
translate pt_br getAway2_e4612ec1:

    # you "..!"
    you "..!"

# game/inAlley.rpy:2777
translate pt_br getAway2_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:2778
translate pt_br getAway2_82f0e91d:

    # "The cat's face looks..."
    "A cara do gato parece..."

# game/inAlley.rpy:2779
translate pt_br getAway2_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2781
translate pt_br getAway2_f2809dbd:

    # "{size=-10}{color=#FF0000}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/color}{/size}"
    "{size=-10}{color=#FF0000}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/color}{/size}"

# game/inAlley.rpy:2783
translate pt_br getAway2_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2784
translate pt_br getAway2_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2788
translate pt_br getAway2_d4f2db8f:

    # "You leave the alley. {i}Quickly.{/i}"
    "Você deixa o beco. {i}Rapidamente.{/i}"

# game/inAlley.rpy:2791
translate pt_br getAway2_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2792
translate pt_br getAway2_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2793
translate pt_br getAway2_bcf48cbf:

    # "What now..?"
    "E agora..?"

# game/inAlley.rpy:2800
translate pt_br getAway3_e4612ec1:

    # you "..!"
    you "..!"

# game/inAlley.rpy:2801
translate pt_br getAway3_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:2802
translate pt_br getAway3_82f0e91d:

    # "The cat's face looks..."
    "A cara do gato parece..."

# game/inAlley.rpy:2803
translate pt_br getAway3_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2805
translate pt_br getAway3_f2809dbd:

    # "{size=-10}{color=#FF0000}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/color}{/size}"
    "{size=-10}{color=#FF0000}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/color}{/size}"

# game/inAlley.rpy:2807
translate pt_br getAway3_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2808
translate pt_br getAway3_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2812
translate pt_br getAway3_d4f2db8f:

    # "You leave the alley. {i}Quickly.{/i}"
    "Você deixa o beco. {i}Rapidamente.{/i}"

# game/inAlley.rpy:2815
translate pt_br getAway3_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2816
translate pt_br getAway3_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2817
translate pt_br getAway3_bcf48cbf:

    # "What now..?"
    "E agora..?"

# game/inAlley.rpy:2826
translate pt_br getAway4_dd4a8909:

    # you "..!" with hpunch
    you "..!" with hpunch

# game/inAlley.rpy:2827
translate pt_br getAway4_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:2828
translate pt_br getAway4_82f0e91d:

    # "The cat's face looks..."
    "A cara do gato parece..."

# game/inAlley.rpy:2829
translate pt_br getAway4_90b93b6a:

    # "It's..."
    "Está..."

# game/inAlley.rpy:2830
translate pt_br getAway4_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2832
translate pt_br getAway4_f2809dbd:

    # "{size=-10}{color=#FF0000}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/color}{/size}"
    "{size=-10}{color=#FF0000}se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso se afasta disso {/color}{/size}"

# game/inAlley.rpy:2835
translate pt_br getAway4_52402223:

    # cat "{b}meow meow meow meow meow meow meow meow meow meow meow meow meow meow{/b}"
    cat "{b}miau miau miau miau miau miau miau miau miau miau miau miau miau miau{/b}"

# game/inAlley.rpy:2837
translate pt_br getAway4_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2838
translate pt_br getAway4_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2842
translate pt_br getAway4_d4f2db8f:

    # "You leave the alley. {i}Quickly.{/i}"
    "Você deixa o beco. {i}Rapidamente.{/i}"

# game/inAlley.rpy:2845
translate pt_br getAway4_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2846
translate pt_br getAway4_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2847
translate pt_br getAway4_bcf48cbf:

    # "What now..?"
    "E agora..?"

# game/inAlley.rpy:2854
translate pt_br goToMoviesFAKE_74698f4f:

    # "It's been a while since a film came out that looked interesting enough for you to drag yourself to a movie theater..."
    "Já faz um tempo que lançou um filme que parecesse interessante o suficiente para você ir ao cinema..."

# game/inAlley.rpy:2855
translate pt_br goToMoviesFAKE_16041c5e:

    # "...but there's a showing of one such film at the old theater."
    "...mas um desses filmes está passando no cinema antigo."

# game/inAlley.rpy:2856
translate pt_br goToMoviesFAKE_86d53b16:

    # "It was a little too niche to be picked up by the new cinema that opened right across the street."
    "Era nichado demais para ser exibido no cinema novo que abriu bem do outro lado da rua."

# game/inAlley.rpy:2857
translate pt_br goToMoviesFAKE_b01bac60:

    # "That's okay though. You're not exactly a fan of the crowds."
    "Mas tudo bem. Você não é exatamente fã de multidões."

# game/inAlley.rpy:2858
translate pt_br goToMoviesFAKE_6430cdc2:

    # "And nothing ruins the experience of watching a new movie for you more than a noisy audience."
    "E nada estraga mais a experiência de assistir a um filme novo para você do que um público barulhento."

# game/inAlley.rpy:2872
translate pt_br oldTheaterFAKE_2c8cdd54:

    # "You eagerly buy your ticket from the kind old man in the booth and head inside..."
    "Você compra ansiosamente seu ingresso com o gentil senhor na bilheteira e entra..."

# game/inAlley.rpy:2876
translate pt_br oldTheaterFAKE_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2877
translate pt_br oldTheaterFAKE_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2884
translate pt_br newCinemaFAKE_927147c9:

    # "You don’t know why...{w} but you don’t really feel great about the idea of being alone right now."
    "Você não sabe porque...{w} mas você não se sente muito bem com a idea de estar sozinho agora."

# game/inAlley.rpy:2887
translate pt_br newCinemaFAKE_fb646a70:

    # "Deciding to wait for the movie you’ve been anticipating to be available on DVD or streaming..."
    "Decidindo esperar o filme que você tanto aguardava ficar disponível em DVD ou em streaming..."

# game/inAlley.rpy:2888
translate pt_br newCinemaFAKE_e6448215:

    # "...you join the long line outside the new cinema."
    "...você entra na longa fila do lado de fora do cinema novo."

# game/inAlley.rpy:2889
translate pt_br newCinemaFAKE_0f82186d:

    # "By the time you’ve reached the ticket booth, you just want to get inside..."
    "Quando você finalmente chega à bilheteria, só quer entrar logo..."

# game/inAlley.rpy:2890
translate pt_br newCinemaFAKE_78abbe21:

    # "...so you pick a movie at random and take your ticket from tired looking teenager manning the booth."
    "...então você escolhe um filme qualquer e pega o ingresso com o adolescente aparentemente cansado que cuida da bilheteria."

# game/inAlley.rpy:2891
translate pt_br newCinemaFAKE_259b126d:

    # "You head inside..."
    "Você entra..."

# game/inAlley.rpy:2895
translate pt_br newCinemaFAKE_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2896
translate pt_br newCinemaFAKE_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2907
translate pt_br goToCarnivalFAKE_54663883:

    # "You spend the day at the carnival."
    "Você passa o dia no festival."

# game/inAlley.rpy:2908
translate pt_br goToCarnivalFAKE_295775c9:

    # "Ferris wheel, roller coaster, pharaoh boat... {w}Rides you’ve been on before."
    "Roda-gigante, montanha-russa, barco viking... {w}Brinquedos nos quais você já esteve antes."

# game/inAlley.rpy:2909
translate pt_br goToCarnivalFAKE_0d9e8fc3:

    # "Hoops, coin toss, balloon darts... {w}Games you’ve played before."
    "Basquete de arcade, arremesso de moedas, dardos... {w}Jogos que você já jogou antes."

# game/inAlley.rpy:2910
translate pt_br goToCarnivalFAKE_32a40a6e:

    # "Funnel cake, popcorn, cotton candy... {w}Food you’ve eaten before."
    "Bolo de funil, pipoca, algodão doce... {w}Comidas que você já comeu antes."

# game/inAlley.rpy:2911
translate pt_br goToCarnivalFAKE_d6de1944:

    # "All things you’ve enjoyed {i}before.{/i}"
    "Você já fez tudo isso {i}antes.{/i}"

# game/inAlley.rpy:2912
translate pt_br goToCarnivalFAKE_c3c9efe7:

    # "You’re surrounded by groups of people all having fun together..."
    "Você está rodeado de grupos de pessoas se divertindo entre si..."

# game/inAlley.rpy:2913
translate pt_br goToCarnivalFAKE_7598c0f4:

    # "Laughing, playing, eating, taking pictures... Making memories..."
    "Rindo, brincando, comendo, tirando fotos... Criando memórias..."

# game/inAlley.rpy:2914
translate pt_br goToCarnivalFAKE_b0255334:

    # "And then there’s you."
    "E aí está você."

# game/inAlley.rpy:2915
translate pt_br goToCarnivalFAKE_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2916
translate pt_br goToCarnivalFAKE_a7421486:

    # "The sun hasn’t started to set yet, still high in the sky, but it will soon."
    "O sol ainda não começou a se pôr, está ainda bem alto no céu, mas logo vai."

# game/inAlley.rpy:2917
translate pt_br goToCarnivalFAKE_527d7f2b:

    # "You start to wonder if maybe you should just go home for the day...{w} when you stop in your tracks."
    "Você começa a se perguntar se talvez não seria melhor ir para casa por hoje...{w} quando para abruptamente."

# game/inAlley.rpy:2920
translate pt_br goToCarnivalFAKE_2f469756:

    # "You see something...{w} {i}new.{/i} {w}An attraction you’ve never seen before."
    "Você vê algo...{w} {i}novo.{/i} {w}Uma atração que nunca tinha visto antes."

# game/inAlley.rpy:2921
translate pt_br goToCarnivalFAKE_ee0a18bc:

    # "A maze of... funhouse mirrors?"
    "Um labirinto... de espelhos?"

# game/inAlley.rpy:2922
translate pt_br goToCarnivalFAKE_c0de53a5:

    # "It sounds..."
    "Parece..."

# game/inAlley.rpy:2923
translate pt_br goToCarnivalFAKE_3a26a699:

    # "...kind of lame, honestly."
    "...meio sem graça, honestamente"

# game/inAlley.rpy:2924
translate pt_br goToCarnivalFAKE_4686437f:

    # "There isn’t even a line to get in."
    "Nem tem fila para entrar."

# game/inAlley.rpy:2925
translate pt_br goToCarnivalFAKE_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2926
translate pt_br goToCarnivalFAKE_cbb84cc7:

    # "But then... {w}what else is there to do..?"
    "Mas então... {w}o que mais há para fazer..?"

# game/inAlley.rpy:2936
translate pt_br enteringMazeFAKE_d4f61e22:

    # "You enter the maze..."
    "Você entra no labirinto..."

# game/inAlley.rpy:2937
translate pt_br enteringMazeFAKE_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2938
translate pt_br enteringMazeFAKE_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2947
translate pt_br goToDogParkFAKE_5c14c202:

    # "You decide to take a stroll in a park or something."
    "Você decide dar uma volta em um parque ou algo assim."

# game/inAlley.rpy:2948
translate pt_br goToDogParkFAKE_184323de:

    # "The only one within your walking distance for the day is the nearby dog park."
    "O único que dá para ir a pé é o parque para cachorros ali perto."

# game/inAlley.rpy:2949
translate pt_br goToDogParkFAKE_31ab9223:

    # "You think it’ll make you feel better."
    "Você acha que vai te fazer se sentir melhor."

# game/inAlley.rpy:2950
translate pt_br goToDogParkFAKE_b35402c8:

    # "First you get to see a cute cat today, now you’ll get to see a cute dog!"
    "Primeiro você viu um gato fofo hoje, agora vai poder ver um cachorro fofo!"

# game/inAlley.rpy:2951
translate pt_br goToDogParkFAKE_a749d8ba:

    # "{i}Several{/i} of them, in fact."
    "{i}Vários{/i} deles, na verdade."

# game/inAlley.rpy:2955
translate pt_br goToDogParkFAKE_3d36b825:

    # "The park is bustling with owners and their canine companions."
    "O parque está movimentado com os donos e seus companheiros caninos."

# game/inAlley.rpy:2956
translate pt_br goToDogParkFAKE_615bff09:

    # "Playing Frisbee, fetch, running, jumping, even napping~!"
    "Brincando de frisbee, de ir buscar, correndo, pulando, e até tirando uma soneca~!"

# game/inAlley.rpy:2957
translate pt_br goToDogParkFAKE_479e8904:

    # "Such cuties--{w=0.3}{nw}"
    "Que fofuras-{w=0.5}{nw}"

# game/inAlley.rpy:2961
translate pt_br goToDogParkFAKE_9b32ff27:

    # "{size=+25}{b}{i}DOGS ARE DISGUSTING!!{/i}{/b}{/size}{w=0.8}{nw}" with hpunch
    "{size=+25}{b}{i}CACHORROS SÃO NOJENTOS!!{/i}{/b}{/size}{w=0.8}{nw}" with hpunch

# game/inAlley.rpy:2963
translate pt_br goToDogParkFAKE_f222b266:

    # "{size=+30}{b}{i}THEY SHOULD ALL JUST DIEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE!!{/i}{/b}{/size}{w=0.8}{nw}" with vpunch
    "{size=+30}{b}{i}TODOS ELES DEVIAM MORREEEEEEEEEEEEEEEEEEEEEEEEEEEEEEER!!{/i}{/b}{/size}{w=0.8}{nw}" with vpunch

# game/inAlley.rpy:2967
translate pt_br goToDogParkFAKE_3d1b02dc:

    # you "{i}!!!{/i}" with vpunch
    you "{i}!!!{/i}" with vpunch

# game/inAlley.rpy:2968
translate pt_br goToDogParkFAKE_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:2969
translate pt_br goToDogParkFAKE_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2970
translate pt_br goToDogParkFAKE_0f5de544:

    # "You..."
    "Você..."

# game/inAlley.rpy:2971
translate pt_br goToDogParkFAKE_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:2972
translate pt_br goToDogParkFAKE_b21fc0cc:

    # "{size=-8}You decide to move on.{/size}"
    "{size=-8}Você decide seguir em frente.{/size}"

# game/inAlley.rpy:2975
translate pt_br goToDogParkFAKE_c5900d2a:

    # "The dogs are all so adorable. You want to pet every single one you come across..."
    "Os cachorros são todos tão adoráveis. Você quer fazer carinho em cada um que encontra..."

# game/inAlley.rpy:2976
translate pt_br goToDogParkFAKE_e4211dcf:

    # "...but you know not all owners are cool with strangers just walking up and manhandling their pets."
    "...mas você sabe que nem todos os donos gostam de estranhos se aproximando e pegando nos seus animais."

# game/inAlley.rpy:2977
translate pt_br goToDogParkFAKE_4f5fba4a:

    # "Not all dogs appreciate it either."
    "Nem todos os cachorros gostam disso também."

# game/inAlley.rpy:2978
translate pt_br goToDogParkFAKE_4f7be349:

    # "So you stroll around the path, trying to exude a welcoming aura that will beckon one of these cute doggies to you."
    "Então você dá uma volta, tentando exalar uma aura acolhedora que atraia um desses cachorrinhos fofos até você."

# game/inAlley.rpy:2982
translate pt_br goToDogParkFAKE_3dd44abb:

    # "You don’t have to wait very long."
    "Você não precisa esperar muito."

# game/inAlley.rpy:2983
translate pt_br goToDogParkFAKE_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:2984
translate pt_br goToDogParkFAKE_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:2987
translate pt_br goToDogParkFAKE_08c12ebd:

    # "You stop as the smallest, cutest puppy you’ve ever seen scampers up to you, blocking your path~"
    "Você para quando o menor e mais fofo filhote que você já viu corre até você, bloqueando seu caminho~"

# game/inAlley.rpy:2998
translate pt_br pickUpPupFAKE_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:2999
translate pt_br pickUpPupFAKE_b6fd4c68:

    # "You pick up the puppy and-"
    "Você pega o filhote e-"

# game/inAlley.rpy:3008
translate pt_br pickUpPupFAKE_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3009
translate pt_br pickUpPupFAKE_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:3016
translate pt_br escapeAlley_71862052:

    # "...Wait."
    "...Espera."

# game/inAlley.rpy:3017
translate pt_br escapeAlley_754ba1f6:

    # "Haven't you..."
    "Você não..."

# game/inAlley.rpy:3018
translate pt_br escapeAlley_9c5945d1:

    # "Haven't you done this before?"
    "Você não fez isso antes?"

# game/inAlley.rpy:3019
translate pt_br escapeAlley_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:3020
translate pt_br escapeAlley_eda5b581:

    # "You feel sick."
    "Você sente um mal-estar."

# game/inAlley.rpy:3021
translate pt_br escapeAlley_a9ce0125:

    # "Looking around, you suddenly realize that unlike earlier..."
    "Olhando em volta, você de repente percebe que, diferente de antes..."

# game/inAlley.rpy:3022
translate pt_br escapeAlley_09fb1093:

    # "...there isn't a single person in sight."
    "...não há uma única pessoa à vista."

# game/inAlley.rpy:3023
translate pt_br escapeAlley_39499d9b:

    # "You're alone."
    "Você está sozinho."

# game/inAlley.rpy:3024
translate pt_br escapeAlley_107c4642:

    # "You're {i}completely{/i} alone..."
    "Você está {i}completamente{/i} sozinho..."

# game/inAlley.rpy:3025
translate pt_br escapeAlley_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:3029
translate pt_br escapeAlley_2d017637:

    # "{size=-10}...So why do you feel like you're being watched right now?{/size}"
    "{size=-10}...Então, por que você sente que está sendo observado agora?{/size}"

# game/inAlley.rpy:3030
translate pt_br escapeAlley_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:3031
translate pt_br escapeAlley_24944022:

    # "You feel your heartbeat start to race."
    "Você sente seu coração começar a acelerar."

# game/inAlley.rpy:3032
translate pt_br escapeAlley_167183bf:

    # "You need to get home."
    "Você precisa ir para casa."

# game/inAlley.rpy:3033
translate pt_br escapeAlley_e42d7264:

    # "{b}Now.{/b}"
    "{b}Agora.{/b}"

# game/inAlley.rpy:3039
translate pt_br escapeAlley_d2c662af:

    # "You walk back home, the feeling of eyes on your back getting worse with each step."
    "Você volta para casa, com a sensação de estar sendo observado pelas costas piorando a cada passo."

# game/inAlley.rpy:3051
translate pt_br escapeAlley_c746b9ce:

    # "By the time you're fumbling with the keys at your door, you're soaked through with cold sweat."
    "Enquanto tenta encontrar as chaves na porta, você está ficando encharcado de suor frio."

# game/inAlley.rpy:3052
translate pt_br escapeAlley_c6dde281:

    # "Your skin prickles and itches..."
    "Sua pele começa a coçar e formigar..."

# game/inAlley.rpy:3053
translate pt_br escapeAlley_173b31a9:

    # "...the heavy gaze you feel might as well be eyeballs physically pressing into your flesh... {w}sticky and unnatural."
    "...o olhar pesado que você sente é quase como se os olhos estivessem pressionando fisicamente sua carne... {w}pegajoso e sobrenatural."

# game/inAlley.rpy:3054
translate pt_br escapeAlley_a73461a6:

    # "You finally get inside and..."
    "Você finalmente consegue entrar e..."

# game/inAlley.rpy:3058
translate pt_br escapeAlley_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3060
translate pt_br escapeAlley_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:3064
translate pt_br escapeAlley_bfcb9214:

    # you "Haaahhhh..!" with hpunch
    you "Haaahhhh..!" with hpunch

# game/inAlley.rpy:3065
translate pt_br escapeAlley_9200f492:

    # "The {b}weight{/b} of relief in the sigh that escapes through your lips actually causes you to physically {i}shudder.{/i}"
    "O alívio que você sente ao suspirar é tão {b}grande{/b} que você fica completamente {i}arrepiado.{/i}"

# game/inAlley.rpy:3066
translate pt_br escapeAlley_9a73ee02:

    # "The horrible feeling from earlier immediately dissipates as if it were never there."
    "Aquela sensação horrível de antes desaparece imediatamente, como se nunca tivesse estado lá."

# game/inAlley.rpy:3067
translate pt_br escapeAlley_940938e5:

    # "In the wake of its departure, you're left shaking and cold in your sweat-soaked clothes..."
    "Após esse sentimento sumir, você começa a tremer e sentir frio nas roupas encharcadas de suor..."

# game/inAlley.rpy:3068
translate pt_br escapeAlley_d1777533:

    # "...but you're too relieved to care."
    "...mas está tão aliviado que não se importa."

# game/inAlley.rpy:3071
translate pt_br escapeAlley_c0c88e96:

    # "Exhausted, you mentally pass on the very {i}concept{/i} of eating and head straight for your bedroom."
    "Exausto, você {i}sequer{/i} cogita a ideia de comer e vai direto para o seu quarto."

# game/inAlley.rpy:3074
translate pt_br escapeAlley_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:3075
translate pt_br escapeAlley_935de6d6:

    # "You open the door, intending to pass out immedia--{w=0.75}{nw}"
    "Você abre a porta, pronto para cair no sono imediat--{w=0.75}{nw}"

# game/inAlley.rpy:3080
translate pt_br escapeAlley_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:3083
translate pt_br escapeAlley_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:3086
translate pt_br escapeAlley_b640810c:

    # "Not again! No..."
    "De novo não! Não..."

# game/inAlley.rpy:3087
translate pt_br escapeAlley_cbb4eb55:

    # "{size=+25}NO!{/size}" with vpunch
    "{size=+25}NÃO!{/size}" with vpunch

# game/inAlley.rpy:3088
translate pt_br escapeAlley_e96e16bd:

    # "You back up in fear... {w}eyes trained on the cat and its horrifying grin."
    "Você recua com medo... {w}seus olhos se fixam no gato e no seu sorriso aterrorizante."

# game/inAlley.rpy:3089
translate pt_br escapeAlley_42a6e76b:

    # "You need to escape."
    "Você precisa fugir."

# game/inAlley.rpy:3090
translate pt_br escapeAlley_20a8bb11:

    # "You need to get out."
    "Você precisa ir embora."

# game/inAlley.rpy:3091
translate pt_br escapeAlley_cc7f2700:

    # "But if even {b}home{/b} isn't safe anymore..."
    "Mas se nem mesmo sua {b}casa{/b} está segura..."

# game/inAlley.rpy:3092
translate pt_br escapeAlley_b120d39e:

    # "Where will you {i}go{/i}..?"
    "Para onde você {i}vai{/i}..?"

# game/inAlley.rpy:3093
translate pt_br escapeAlley_a013ff83:

    # "You risk a glance around you and-"
    "Você arrisca um olhar ao seu redor e-"

# game/inAlley.rpy:3094
translate pt_br escapeAlley_8ca8510a_1:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:3099
translate pt_br escapeAlley_9f28660e:

    # "You see that the walls all around you have become fleshy and lined with sharp teeth..."
    "Você vê que as paredes ao seu redor criaram carne e estão cheias de dentes afiados..."

# game/inAlley.rpy:3100
translate pt_br escapeAlley_e633f9bf:

    # "The ground now a tongue writhing under your feet..."
    "O chão agora é uma língua se contorcendo sob seus pés..."

# game/inAlley.rpy:3106
translate pt_br escapeAlley_69312007:

    # "In horror, you realize that the alley's entrance is getting smaller and smaller..."
    "Horrorizado, você percebe que a entrada do beco está ficando cada vez menor..."

# game/inAlley.rpy:3107
translate pt_br escapeAlley_eb65f2ee:

    # "{i}Closing{/i}... {w}like a mouth..."
    "{i}Fechando{/i}... {w}como uma boca..."

# game/inAlley.rpy:3108
translate pt_br escapeAlley_51da09f7:

    # "You try to run for the exit..."
    "Você tenta correr até a saída..."

# game/inAlley.rpy:3116
translate pt_br escapeAlley_650717a6:

    # "{size=-10}{i}nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide {/i}{/size}"
    "{size=-10}{i}impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder impossível se esconder {/i}{/size}"

# game/inAlley.rpy:3118
translate pt_br escapeAlley_9bb38d7d:

    # "...but trying to run on the tongue slows your speed significantly as you stumble and trip."
    "...mas tentar correr na língua diminui sua velocidade significativamente, fazendo você tropeçar e cair."

# game/inAlley.rpy:3121
translate pt_br escapeAlley_546d120e:

    # you "{size=-8}No...{/size}"
    you "{size=-8}Não...{/size}"

# game/inAlley.rpy:3122
translate pt_br escapeAlley_5ad13b7d:

    # "You watch helplessly as the last sliver of light from the entrance tightens beyond a size you could never hope to squeeze through..."
    "Você observa impotente enquanto o último feixe de luz da entrada diminui para um tamanho que você nunca conseguiria passar..."

# game/inAlley.rpy:3127
translate pt_br escapeAlley_e8c1286e:

    # "As darkness falls over you... {w}you feel the damp humidity of the mouth all around you..."
    "À medida que a escuridão cai sobre você... {w}você sente a umidade da boca ao seu redor..."

# game/inAlley.rpy:3128
translate pt_br escapeAlley_634c4b03:

    # "The walls... the walls of teeth... {i}fangs...{/i}"
    "As paredes... as paredes de dentes... {i}presas...{/i}"

# game/inAlley.rpy:3129
translate pt_br escapeAlley_dbef0163:

    # "...take their time closing in."
    "...demoram a se fechar."

# game/inAlley.rpy:3130
translate pt_br escapeAlley_624b526a:

    # "Closer..."
    "Fechando cada mais..."

# game/inAlley.rpy:3131
translate pt_br escapeAlley_57fba23d:

    # "And closer..."
    "E mais..."

# game/inAlley.rpy:3132
translate pt_br escapeAlley_12317a15:

    # "And-{w=0.2}{nw}"
    "E-{w=0.2}{nw}"

# game/inAlley.rpy:3138
translate pt_br escapeAlley_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:3142
translate pt_br escapeAlley_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:3143
translate pt_br escapeAlley_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:3144
translate pt_br escapeAlley_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:3145
translate pt_br escapeAlley_59e53cf3:

    # "Ending 23: Feedback loop"
    "Final 23: Ciclo sem fim"

# game/inAlley.rpy:3157
translate pt_br feedAlley_60ed29e3:

    # "The cat must be hungry, right?"
    "O gato deve estar com fome, certo?"

# game/inAlley.rpy:3158
translate pt_br feedAlley_ca7535de:

    # "You can't imagine that it's had much to eat if it's so attached to that box it's in."
    "Você imagina que ele não tenha comido muito se está tão apegado àquela caixa em que está."

# game/inAlley.rpy:3159
translate pt_br feedAlley_15894b36:

    # "Though... it doesn't exactly seem malnourished either..."
    "Embora... ele também não pareça desnutrido..."

# game/inAlley.rpy:3160
translate pt_br feedAlley_91d870df:

    # "Surely it {i}must{/i} have left the box to search for food then..?"
    "Certamente ele {i}deve{/i} ter saído da caixa para procurar comida, não é..?"

# game/inAlley.rpy:3161
translate pt_br feedAlley_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:3162
translate pt_br feedAlley_63420a88:

    # "For some reason... something in the back of your mind tells you that's not the case."
    "Por alguma razão... algo no fundo da sua mente diz que não é esse o caso."

# game/inAlley.rpy:3163
translate pt_br feedAlley_f8c64864:

    # "{size=-10}...And not to think on it any further.{/size}"
    "{size=-10}...E que é melhor não pensar mais sobre isso.{/size}"

# game/inAlley.rpy:3164
translate pt_br feedAlley_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:3165
translate pt_br feedAlley_d93fe1cb:

    # "Well, either way..."
    "Bom, de qualquer forma..."

# game/inAlley.rpy:3166
translate pt_br feedAlley_b7ea0fa5:

    # "You can't exactly enjoy your day out knowing you left behind a hungry cat."
    "Você não pode curtir seu dia sabendo que deixou um gato com fome para trás."

# game/inAlley.rpy:3167
translate pt_br feedAlley_0d1b62a9:

    # "Especially when you could have done something to help."
    "Especialmente quando poderia ter feito algo para ajudar."

# game/inAlley.rpy:3170
translate pt_br feedAlleyMenu_42b896f8:

    # "So..."
    "Então..."

# game/inAlley.rpy:3171
translate pt_br feedAlleyMenu_949c2306:

    # "What to do about the hungry kitty?"
    "O que fazer a respeito do gatinho faminto?"

# game/inAlley.rpy:3183
translate pt_br feedAlleyMenu_a2c5487f:

    # "Not yet..."
    "Ainda não..."

# game/inAlley.rpy:3190
translate pt_br feedPockets_5cfb3464:

    # "You dig into your pockets."
    "Você revira os bolsos."

# game/inAlley.rpy:3193
translate pt_br feedPockets_f8c73033:

    # "You find a small piece of string in your left pocket. Not very helpful."
    "Você encontra um pequeno pedaço de linha no bolso esquerdo. Não vai ajudar muito."

# game/inAlley.rpy:3194
translate pt_br feedPockets_ab3079c6:

    # "The string is far too short."
    "A linha é curta demais."

# game/inAlley.rpy:3196
translate pt_br feedPockets_c0209341:

    # "An eager and excited cat leaping for it could easily lead to you getting{w=1.0}{nw}"
    "Um gato ansioso e animado pulando para pegá-la facilmente levaria você a ser{w=1.0}{nw}"

# game/inAlley.rpy:3207
translate pt_br feedPockets_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:3208
translate pt_br feedPockets_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3209
translate pt_br feedPockets_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:3212
translate pt_br feedPockets_f42805d9:

    # "An eager and excited cat leaping for it could easily lead to you getting bitten and scratched."
    "Um gato ansioso e animado pulando para pegá-la facilmente levaria você a ser mordido e arranhado."

# game/inAlley.rpy:3215
translate pt_br feedPockets_f8cb7b4a:

    # "In your right pocket..."
    "No seu bolso direito..."

# game/inAlley.rpy:3220
translate pt_br feedPockets_d38263f6:

    # "{size=-10}...is a bar of {color=#FF0000}chocolate.{/color}{/size}"
    "{size=-10}...tem uma barra de {color=#FF0000}chocolate.{/color}{/size}"

# game/inAlley.rpy:3222
translate pt_br feedPockets_f3654da7:

    # "{size=-5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sor {/size}{w=0.2}{nw}"
    "{size=-5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}descul {/size}{w=0.2}{nw}"

# game/inAlley.rpy:3225
translate pt_br feedPockets_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:3227
translate pt_br feedPockets_31772800:

    # "...is a bar of chocolate."
    "...tem uma barra de chocolate."

# game/inAlley.rpy:3228
translate pt_br feedPockets_3d145f61:

    # "You find a {i}chocolate bar?!{/i}"
    "Você encontra uma {i}barra de chocolate?!{/i}"

# game/inAlley.rpy:3229
translate pt_br feedPockets_1bd01551:

    # "Is it..? Nope, it's not even expired!"
    "Será que..? Nem, Não tá nem vencida!"

# game/inAlley.rpy:3230
translate pt_br feedPockets_7ee41c3c:

    # "Quite the find indeed!"
    "Um baita achado, de fato!"

# game/inAlley.rpy:3233
translate pt_br feedPockets_5fd3d678:

    # "You're about to offer it to the cat..."
    "Você está prestes a oferecer ao gato..."

# game/inAlley.rpy:3234
translate pt_br feedPockets_632d1a35_1:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:3235
translate pt_br feedPockets_f4a2553e:

    # "...when suddenly, you're hit with guilt as you remember something gut-curdling..."
    "...quando, de repente, você é tomado pela culpa ao se lembrar de algo que revira seu estômago..."

# game/inAlley.rpy:3236
translate pt_br feedPockets_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:3239
translate pt_br feedPockets_c0157c69:

    # "Chocolate is {color=#FF0000}{b}toxic{/b}{/color} to cats."
    "Chocolate é {color=#FF0000}{b}tóxico{/b}{/color} para gatos."

# game/inAlley.rpy:3241
translate pt_br feedPockets_8abfb425:

    # you "Oh my gosh! I'm so..."
    you "Meu Deus! Eu..."

# game/inAlley.rpy:3242
translate pt_br feedPockets_44e1c462:

    # "You resist the urge to vomit at your near mistake."
    "Você resiste ao impulso de vomitar diante do erro que quase cometeu."

# game/inAlley.rpy:3246
translate pt_br feedPockets_71316bbd:

    # "You feel so guilty, you throw the chocolate bar away into a nearby trash bin."
    "Você se sente tão culpado que joga a barra de chocolate em uma lixeira próxima."

# game/inAlley.rpy:3247
translate pt_br feedPockets_3c3040ce:

    # "An almost-cat-killer doesn't deserve chocolate."
    "Um quase assassino de gatos não merece chocolate."

# game/inAlley.rpy:3248
translate pt_br feedPockets_87694524:

    # "You go back to the cat, barely able to stand its innocently oblivious expression."
    "Você volta para o gato, mal conseguindo suportar sua expressão inocente e alheia."

# game/inAlley.rpy:3252
translate pt_br feedPockets_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/inAlley.rpy:3254
translate pt_br feedPockets_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:3255
translate pt_br feedPockets_2c29b15f:

    # "It doesn't even know that you almost..."
    "Ele nem sabe que você quase..."

# game/inAlley.rpy:3256
translate pt_br feedPockets_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:3257
translate pt_br feedPockets_f37947e9:

    # you "I... I'm so sorry... I don't even know what to say..."
    you "Eu... Eu sinto muito... Eu nem sei o que dizer..."

# game/inAlley.rpy:3261
translate pt_br feedPockets_8b57cab4:

    # cat "Meowww?"
    cat "Miauuu?"

# game/inAlley.rpy:3263
translate pt_br feedPockets_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:3265
translate pt_br feedPockets_5cd20361:

    # "you're a {b}h o r r i b l e{/b} person..."
    "você é uma pessoa {b}h o r r í v e l{/b}..."

# game/inAlley.rpy:3266
translate pt_br feedPockets_0bfbcb68:

    # you "...Y-You know what? Stay there, I'll be right back!"
    you "...Q-Quer saber? Fica paradinho aí, eu já volto!"

# game/inAlley.rpy:3268
translate pt_br feedPockets_16879ce5_1:

    # cat "Meow?"
    cat "Miau?"

# game/inAlley.rpy:3269
translate pt_br feedPockets_ab8229b4:

    # "You leave the alley..."
    "Você deixa o beco..."

# game/inAlley.rpy:3270
translate pt_br feedPockets_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:3271
translate pt_br feedPockets_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:3274
translate pt_br feedPockets_82310cee:

    # "...And return with a {i}whole fish{/i} you bought at a nearby grocery shop."
    "...E volta com um {i}peixe inteiro{/i} que você comprou em um mercadinho próximo."

# game/inAlley.rpy:3275
translate pt_br feedPockets_3926ea50:

    # "It was a bit pricey..."
    "Foi um pouco caro..."

# game/inAlley.rpy:3276
translate pt_br feedPockets_2b3ea52c:

    # "{size=-8}...but it was the {b}least{/b} you could do.{/size}"
    "{size=-8}...mas era o {b}mínimo{/b} que você podia fazer.{/size}"

# game/inAlley.rpy:3281
translate pt_br feedPockets_ec1974d4:

    # cat "Meow!" with hpunch
    cat "Miau!" with hpunch

# game/inAlley.rpy:3283
translate pt_br feedPockets_8c4b404a:

    # "The cat eagerly accepts your offering, munching happily at the fish after you'd placed it in the box."
    "O gato aceita seu presente com entusiasmo, mastigando contentemente o peixe depois que você o colocou na caixa."

# game/inAlley.rpy:3286
translate pt_br feedPockets_1c62c81c:

    # cat "Meow! Meow! Meow!!" with hpunch
    cat "Miau! Miau! Miau!!" with hpunch

# game/inAlley.rpy:3288
translate pt_br feedPockets_be47b116:

    # "You want to smile at the sight, but you just feel so..."
    "Você gostaria de sorrir ao ver isso, mas se sente..."

# game/inAlley.rpy:3289
translate pt_br feedPockets_b690d28d:

    # "...{i}awful.{/i}"
    "...{i}péssimo.{/i}"

# game/inAlley.rpy:3290
translate pt_br feedPockets_d14a2a5b:

    # you "...S-Sorry again."
    you "...D-Desculpa de novo."

# game/inAlley.rpy:3291
translate pt_br feedPockets_dd5772de:

    # "The cat seemingly pays you no mind as you slip back out of the alley."
    "O gato aparentemente não presta muita atenção em você enquanto você sai do beco."

# game/inAlley.rpy:3294
translate pt_br feedPockets_7b39a56c:

    # "Not feeling like you deserve a peaceful day out, you decide to just head back home."
    "Sentindo que não merece ter um dia tranquilo, você decide voltar para casa."

# game/inAlley.rpy:3295
translate pt_br feedPockets_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:3296
translate pt_br feedPockets_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:3298
translate pt_br feedPockets_730bba6f:

    # who "Reow..."
    who "Reow..."

# game/inAlley.rpy:3299
translate pt_br feedPockets_90b68c87:

    # you "..?"
    you "..?"

# game/inAlley.rpy:3306
translate pt_br feedPockets_3c4d90d1:

    # "On the way home, you notice more cats than usual, watching you from their hiding spots..."
    "No caminho para casa, você percebe mais gatos do que o normal, o observando de seus esconderijos..."

# game/inAlley.rpy:3307
translate pt_br feedPockets_905314c8:

    # "...but you try not to think about it."
    "...mas você tenta não pensar muito nisso."

# game/inAlley.rpy:3313
translate pt_br feedPockets_2d48655c:

    # "You can't help but wonder..."
    "Você não consegue deixar de se perguntar..."

# game/inAlley.rpy:3314
translate pt_br feedPockets_c4bde9d1:

    # "...if they know what you'd nearly {b}done.{/b}"
    "...se eles sabem o que você quase {b}fez.{/b}"

# game/inAlley.rpy:3315
translate pt_br feedPockets_bf0874e3:

    # "But..."
    "Mas..."

# game/inAlley.rpy:3321
translate pt_br feedPockets_703b363c:

    # "It's not like you meant to hurt anyone..."
    "Não é como se você tivesse a intenção de machucar alguém..."

# game/inAlley.rpy:3326
translate pt_br feedPockets_c53bacd0:

    # "{size=-8}...right?{/size}"
    "{size=-8}...certo?{/size}"

# game/inAlley.rpy:3329
translate pt_br feedPockets_8dabefc6_3:

    # ".."
    ".."

# game/inAlley.rpy:3330
translate pt_br feedPockets_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:3333
translate pt_br feedPockets_3eb6f147:

    # "You finally reach your apartment building. You're about to unlock the door when..."
    "Finalmente chegando ao seu prédio, você está prestes a destrancar a porta quando..."

# game/inAlley.rpy:3337
translate pt_br feedPockets_0fcae0c9:

    # who "Reow... Reow... Reowwww...!"
    who "Reow... Reow... Reowwww...!"

# game/inAlley.rpy:3338
translate pt_br feedPockets_90b68c87_1:

    # you "..?"
    you "..?"

# game/inAlley.rpy:3339
translate pt_br feedPockets_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:3343
translate pt_br feedPockets_eefed842:

    # "You look behind you... only to see {i}dozens{/i} of cats standing there."
    "Você olha para trás... e vê {i}dezenas{/i} de gatos parados ali."

# game/inAlley.rpy:3344
translate pt_br feedPockets_3c7fb7cb:

    # "Looking at you."
    "Olhando para você."

# game/inAlley.rpy:3345
translate pt_br feedPockets_4184a661:

    # "Did they see you feeding the cat in the alley and thought that you had more food for all of them..?"
    "Será que eles viram você alimentando o gato no beco e acharam que você tinha comida para todos eles..?"

# game/inAlley.rpy:3346
translate pt_br feedPockets_f32454e0:

    # you "I... I'm sorry I don't have anymore food for you..."
    you "Foi... Foi mal, não tenho mais comida para vocês..."

# game/inAlley.rpy:3347
translate pt_br feedPockets_4bb08b75:

    # "None of them move an inch."
    "Nenhum deles move um centímetro."

# game/inAlley.rpy:3348
translate pt_br feedPockets_7f4239d9:

    # "You're starting to feel a little unnerved when finally a single cat pushes its way to the front and..."
    "Você começa a ficar um pouco desconfortável, até que, finalmente, um único gato dá um passo para frente e..."

# game/inAlley.rpy:3357
translate pt_br feedPockets_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:3358
translate pt_br feedPockets_06197af2:

    # you "Oh! It's y-!"
    you "Ah! É vo-!"

# game/inAlley.rpy:3359
translate pt_br feedPockets_8ca8510a_1:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:3360
translate pt_br feedPockets_9ed134ce:

    # "Oh..."
    "Oh..."

# game/inAlley.rpy:3361
translate pt_br feedPockets_90b93b6a:

    # "It's..."
    "Está..."

# game/inAlley.rpy:3362
translate pt_br feedPockets_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:3363
translate pt_br feedPockets_3f4e0e68:

    # "Held carefully between its teeth is the chocolate bar you'd thrown away earlier."
    "Cuidadosamente colocada entre seus dentes está a barra de chocolate que você havia jogado fora antes."

# game/inAlley.rpy:3369
translate pt_br feedPockets_ba9d5a1b:

    # "It places the chocolate bar down in front of it before looking back up at you."
    "Ele coloca a barra de chocolate no chão à sua frente antes de olhar de volta para você."

# game/inAlley.rpy:3370
translate pt_br feedPockets_0fa5f48b:

    # "{i}All{/i} the cats look up at you..."
    "{i}Todos{/i} os gatos olham para você..."

# game/inAlley.rpy:3371
translate pt_br feedPockets_a20cefa7_8:

    # "..."
    "..."

# game/inAlley.rpy:3373
translate pt_br feedPockets_cb8b1ea4:

    # "{size=-5}You can feel their judgment...{/size}"
    "{size=-5}Você consegue sentir o julgamento deles...{/size}"

# game/inAlley.rpy:3375
translate pt_br feedPockets_ca13fffe:

    # you "!!" with hpunch
    you "!!" with hpunch

# game/inAlley.rpy:3376
translate pt_br feedPockets_8ca8510a_2:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:3377
translate pt_br feedPockets_61c83dbb:

    # "You feel your sins weighing down heavily on your back."
    "Você sente seus pecados pesando sobre suas costas."

# game/inAlley.rpy:3378
translate pt_br feedPockets_3a1db100:

    # "But without the money to buy enough food for all of them..."
    "Mas sem dinheiro para comprar comida suficiente para todos eles..."

# game/inAlley.rpy:3379
translate pt_br feedPockets_f1fb8cef:

    # "You don't know what to do..."
    "Você não sabe o que fazer..."

# game/inAlley.rpy:3390
translate pt_br begForgive_c11b9ea5:

    # "You collapse to your knees and bow down low as you start to earnestly beg for their forgiveness."
    "Você cai de joelhos e se curva, começando a implorar sinceramente pelo perdão deles."

# game/inAlley.rpy:3391
translate pt_br begForgive_5d26ba72:

    # you "I'm so sorry! I swear!" with vpunch
    you "Sinto muito! Eu juro!" with vpunch

# game/inAlley.rpy:3392
translate pt_br begForgive_11f39ee6:

    # you "I... I'd do anything to make it up to all of you, but...!"
    you "Eu... Eu faria qualquer coisa para compensar, mas...!"

# game/inAlley.rpy:3393
translate pt_br begForgive_0b6b468c:

    # "...but you're out of options."
    "...mas você está sem opções."

# game/inAlley.rpy:3394
translate pt_br begForgive_f8342e66:

    # "Suddenly..."
    "De repente..."

# game/inAlley.rpy:3397
translate pt_br begForgive_b3351a0a:

    # you "Hrk! Hmp! *choke*!!" with vpunch
    you "Argh! Hmp! *engasgo*!!" with vpunch

# game/inAlley.rpy:3398
translate pt_br begForgive_1a0306e2:

    # "You feel something stir in your stomach and swim its way up to your throat..."
    "Você sente algo se agitar em seu estômago e subir até a sua garganta..."

# game/inAlley.rpy:3399
translate pt_br begForgive_9d069fba:

    # "...closing off your airway as it tries to force its way out of your esophogus."
    "...fechando suas vias aéreas enquanto tenta forçar a saída pelo seu esôfago."

# game/inAlley.rpy:3402
translate pt_br begForgive_f00aa018:

    # you "Bl-Blgh!" with vpunch
    you "Bl-Blgh!" with vpunch

# game/inAlley.rpy:3403
translate pt_br begForgive_7e07a3c9:

    # "It finally succeeds with aid from your helpless gagging."
    "Finalmente consegue, com a ajuda da sua ânsia."

# game/inAlley.rpy:3410
translate pt_br begForgive_c76c10fb:

    # you "Blurgh!!" with hpunch
    you "Blergh!!" with hpunch

# game/inAlley.rpy:3414
translate pt_br begForgive_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:3416
translate pt_br begForgive_90b68c87:

    # you "..?"
    you "..?"

# game/inAlley.rpy:3417
translate pt_br begForgive_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:3418
translate pt_br begForgive_9035e3f2:

    # you "{size=-8}What... the...?{/size}"
    you "{size=-8}Mas... que...?{/size}"

# game/inAlley.rpy:3419
translate pt_br begForgive_30e5bd77:

    # "Lying on the ground in front of you..."
    "Caído no chão à sua frente..."

# game/inAlley.rpy:3425
translate pt_br begForgive_3c6fad90:

    # "...is a flopping fish."
    "...está um peixe se debatendo."

# game/inAlley.rpy:3426
translate pt_br begForgive_0fa59e4c:

    # "You just... {w}threw up a {i}living{/i} fish..."
    "Você simplesmente... {w}vomitou um peixe {i}vivo{/i}..."

# game/inAlley.rpy:3427
translate pt_br begForgive_2e05a79f:

    # you "{size=-8}What the hell...?{/size}"
    you "{size=-8}Mas que porra...?{/size}"

# game/inAlley.rpy:3430
translate pt_br begForgive_28305204:

    # "The cats come rushing forward, all tearing hungrily at the fish."
    "Os gatos avançam, todos famintos, atacando o peixe com voracidade."

# game/inAlley.rpy:3431
translate pt_br begForgive_23a3bbe5:

    # "You're..."
    "Você está..."

# game/inAlley.rpy:3432
translate pt_br begForgive_a360cc29:

    # "You're {i}happy{/i} to finally be of help, truly... {w}but how-{w=0.2}{nw}"
    "Você está {i}feliz{/i} por finalmente poder ajudar, de verdade... {w}mas como-{w=0.2}{nw}"

# game/inAlley.rpy:3438
translate pt_br begForgive_d69064ca:

    # you "Blurgh!!" with vpunch
    you "Blergh!!" with vpunch

# game/inAlley.rpy:3439
translate pt_br begForgive_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3440
translate pt_br begForgive_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:3441
translate pt_br begForgive_15d57735:

    # "...You throw up another fish."
    "...Você vomita outro peixe."

# game/inAlley.rpy:3449
translate pt_br begForgive_c76c10fb_1:

    # you "Blurgh!!" with hpunch
    you "Blergh!!" with hpunch

# game/inAlley.rpy:3453
translate pt_br begForgive_27069f53:

    # "And another..."
    "E outro..."

# game/inAlley.rpy:3461
translate pt_br begForgive_c76c10fb_2:

    # you "Blurgh!!" with hpunch
    you "Blergh!!" with hpunch

# game/inAlley.rpy:3465
translate pt_br begForgive_f2db7641:

    # "And {i}another{/i}..."
    "E {i}outro{/i}..."

# game/inAlley.rpy:3473
translate pt_br begForgive_c76c10fb_3:

    # you "Blurgh!!" with hpunch
    you "Blergh!!" with hpunch

# game/inAlley.rpy:3478
translate pt_br begForgive_cb64e404:

    # "And..."
    "E..."

# game/inAlley.rpy:3479
translate pt_br begForgive_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:3480
translate pt_br begForgive_dbd6d155:

    # "Your stomach hurts. {w}You’re getting... dizzy."
    "Seu estômago dói. {w}Você está ficando... tonto."

# game/inAlley.rpy:3481
translate pt_br begForgive_971a5312:

    # "You fall to your knees..."
    "Você se ajoelha..."

# game/inAlley.rpy:3482
translate pt_br begForgive_fe9dfa69:

    # "Tears and snot are streaming down your face by the time you cough up a final, tiny, {i}{color=#FF0000}bloody{/color}{/i} fish and collapse forward."
    "Lágrimas e muco escorrem pelo seu rosto quando você tosse um último, pequeno e {i}{color=#FF0000}ensanguentado{/color}{/i} peixe e cai para trás."

# game/inAlley.rpy:3483
translate pt_br begForgive_a7387d16:

    # "Your throat and stomach both {i}burn{/i} in a way that feels dangerous."
    "Sua garganta e estômago {i}queimam{/i} de um jeito que parece perigoso.."

# game/inAlley.rpy:3484
translate pt_br begForgive_0f08eefa:

    # "You start to fade out..."
    "Você começa a apagar..."

# game/inAlley.rpy:3487
translate pt_br begForgive_21f2fb4d:

    # "Despite the pain..."
    "Apesar da dor..."

# game/inAlley.rpy:3490
translate pt_br begForgive_2585da06:

    # "...you strangely feel a more overwhelming sense of hopeful pride."
    "...estranhamente, você sente um grande orgulho, que te enche de esperança."

# game/inAlley.rpy:3491
translate pt_br begForgive_56367ba7:

    # "That you've made up for your {b}disgusting{/b} actions..."
    "Que você compensou suas ações {b}repugnantes{/b}..."

# game/inAlley.rpy:3492
translate pt_br begForgive_f0ecbc05:

    # "...That you've been forgiven."
    "...Que você foi perdoado."

# game/inAlley.rpy:3529
translate pt_br begForgive_edbc3af1:

    # "The sound of happy cats munching away at their fish fills your ears..."
    "O som dos gatos felizes comendo seus peixes enche seus ouvidos..."

# game/inAlley.rpy:3530
translate pt_br begForgive_f64ee9d8:

    # "Then..."
    "Até que..."

# game/inAlley.rpy:3546
translate pt_br begForgive_5bfd48b0:

    # "...you feel something being nudged into your hand."
    "...você sente algo sendo empurrado para dentro da sua mão."

# game/inAlley.rpy:3547
translate pt_br begForgive_f3f141f9:

    # "It feels like..."
    "Parece que..."

# game/inAlley.rpy:3548
translate pt_br begForgive_28b3ac41:

    # you "!!"
    you "!!"

# game/inAlley.rpy:3549
translate pt_br begForgive_5da9aa6a:

    # "It's the bar of chocolate you'd found in your pocket."
    "É a barra de chocolate que você achou no seu bolso."

# game/inAlley.rpy:3550
translate pt_br begForgive_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:3551
translate pt_br begForgive_10d5d7ff:

    # you "{size=-8}H-Heh...{/size}"
    you "{size=-8}H-Heh...{/size}"

# game/inAlley.rpy:3552
translate pt_br begForgive_254220ed:

    # "You smile weakly."
    "Você sorri com dificuldade."

# game/inAlley.rpy:3555
translate pt_br begForgive_08515ef1:

    # "You’ve successfully atoned, but you don’t really have the strength to eat your reward."
    "Você conseguiu se redimir, mas não tem forças para comer sua recompensa."

# game/inAlley.rpy:3556
translate pt_br begForgive_aa483b68:

    # "Sadly, the last taste in your mouth as you leave this mortal coil doesn't get to be that of chocolate..."
    "Infelizmente, o último gosto em sua boca ao deixar este mundo não é o de chocolate..."

# game/inAlley.rpy:3557
translate pt_br begForgive_5408dec4:

    # "...but raw fish."
    "...mas de peixe cru."

# game/inAlley.rpy:3558
translate pt_br begForgive_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:3559
translate pt_br begForgive_1ecfdb72:

    # "Ending 24: Fishing for pardon"
    "Final 24: {i}Pesco{/i} desculpas"

# game/inAlley.rpy:3574
translate pt_br leaveHungryCats_919a1f52:

    # "You decide to cut your losses and head inside."
    "Você decide deixar pra lá e entrar."

# game/inAlley.rpy:3575
translate pt_br leaveHungryCats_32bb90cb:

    # "Your sins weigh down on you, but you’re only human. What more can you do?"
    "Seus pecados pesam sobre você, mas você é humano. O que mais poderia fazer?"

# game/inAlley.rpy:3581
translate pt_br leaveHungryCats_8f6616fa:

    # you "{i}Geez...{/i}"
    you "{i}Pô...{/i}"

# game/inAlley.rpy:3582
translate pt_br leaveHungryCats_e7b16877:

    # "You try to ignore the yowling of the neighborhood cats as you go about your chores."
    "Você tenta ignorar os miados dos gatos da vizinhança enquanto faz suas tarefas."

# game/inAlley.rpy:3583
translate pt_br leaveHungryCats_5a3d572d:

    # "You consider preparing dinner..."
    "Você pensa em preparar o jantar..."

# game/inAlley.rpy:3584
translate pt_br leaveHungryCats_b1727d2d:

    # "...but how could you enjoy it knowing how hungry those poor cats outside are?"
    "...mas como poderia aproveitá-lo sabendo o quanto aqueles pobres gatos lá fora estão com fome?"

# game/inAlley.rpy:3585
translate pt_br leaveHungryCats_d620406e:

    # "The ones you’ve wronged?"
    "Gatos esses que você deixou pra trás?"

# game/inAlley.rpy:3588
translate pt_br leaveHungryCats_4814405d:

    # "You decide to take a bath and go straight to bed {b}without{/b} dinner."
    "Você decide tomar um banho e ir direto para cama {b}sem{/b} jantar."

# game/inAlley.rpy:3589
translate pt_br leaveHungryCats_f9c0255f:

    # "A fitting punishment for someone like you."
    "Uma punição adequada para alguém como você."

# game/inAlley.rpy:3592
translate pt_br leaveHungryCats_ae952792:

    # "You forgo the fancy bath bubbles because you don’t deserve them and sink into the water with a sigh."
    "Você abre mão do luxo das bolhas de banho porque acha que não merece e afunda na água com um suspiro."

# game/inAlley.rpy:3593
translate pt_br leaveHungryCats_ff1845cf:

    # "Your mind races but you can’t really think of any immediate solution that doesn’t require more money."
    "Seus pensamentos disparam, mas você não consegue pensar em nenhuma solução imediata que não precise de dinheiro."

# game/inAlley.rpy:3594
translate pt_br leaveHungryCats_2bf55488:

    # "You wish there was something, {i}anything{/i}, you could do to make things right."
    "Você queria que tivesse algo, {i}qualquer coisa{/i}, que você pudesse fazer para consertar as coisas."

# game/inAlley.rpy:3595
translate pt_br leaveHungryCats_3e71eb84:

    # "Suddenly... {w}your legs start to feel really itchy."
    "De repente... {w}suas pernas começam a coçar muito."

# game/inAlley.rpy:3596
translate pt_br leaveHungryCats_17310a3f:

    # "You try to lift one to see what’s going on, but what rises out of the water isn’t a pair of legs..."
    "Você tenta levantar uma para ver o que está acontecendo, mas o que sai da água não são pernas..."

# game/inAlley.rpy:3597
translate pt_br leaveHungryCats_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:3612
translate pt_br leaveHungryCats_67f84009:

    # "It’s...{w} It's a fish tail..?"
    "É...{w} É uma cauda de peixe..?"

# game/inAlley.rpy:3613
translate pt_br leaveHungryCats_867810a1:

    # "You... You feel dizzy at the sight... Maybe you’re hallucinating from the stress?"
    "Você... Você fica tonto ao ver aquilo... Talvez esteja alucinando por causa do estresse?"

# game/inAlley.rpy:3614
translate pt_br leaveHungryCats_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:3615
translate pt_br leaveHungryCats_5c9b6efd:

    # "You try to climb out of the tub to cool your head... but instead of your hand rising up to brace itself..."
    "Você tenta sair da banheira para esfriar a cabeça... mas, em vez de sua mão se levantar para se apoiar..."

# game/inAlley.rpy:3619
translate pt_br leaveHungryCats_d0c358fd:

    # "...a wet fin stretches out to plop on the rim."
    "...uma barbatana molhada se estica e bate na borda da banheira."

# game/inAlley.rpy:3620
translate pt_br leaveHungryCats_c20b4b4f:

    # "It’s too weak to hold your weight and you’re so startled by the sight..."
    "Ela é muito fraca para sustentar seu peso, e você fica tão assustado com a visão..."

# game/inAlley.rpy:3635
translate pt_br leaveHungryCats_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/inAlley.rpy:3636
translate pt_br leaveHungryCats_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:3637
translate pt_br leaveHungryCats_34e36922:

    # "...that you slip and smack your head on the side of the bathtub, passing out almost immediately."
    "...que você escorrega e bate a cabeça na borda, desmaiando quase imediatamente."

# game/inAlley.rpy:3638
translate pt_br leaveHungryCats_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3639
translate pt_br leaveHungryCats_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:3640
translate pt_br leaveHungryCats_08a2bbac:

    # "You’re... awake. You {i}think,{/i} anyway."
    "Você está... acordado. Pelo menos, é o que {i}acha{/i}."

# game/inAlley.rpy:3641
translate pt_br leaveHungryCats_15f20a2c:

    # "You open your eyes and..."
    "Você abre os olhos e..."

# game/inAlley.rpy:3645
translate pt_br leaveHungryCats_36e9324f:

    # "..? You’re.. underwater..?"
    "..? Você está.. debaixo d'água..?"

# game/inAlley.rpy:3646
translate pt_br leaveHungryCats_80806592:

    # "..! You must’ve slid beneath the surface of the bathwater! You gasp instinctively."
    "..! Você deve ter escorregado para baixo da superfície da água do banho! Você ofega instintivamente."

# game/inAlley.rpy:3647
translate pt_br leaveHungryCats_29b1a09a:

    # "...Except not really."
    "...Mas não foi bem isso."

# game/inAlley.rpy:3660
translate pt_br leaveHungryCats_e46f8488:

    # "A bubble simply floats out of your mouth... up, up, {i}up{/i} to the surface."
    "Uma bolha simplesmente flutua para fora da sua boca... subindo, subindo, {i}subindo{/i} até a superfície."

# game/inAlley.rpy:3661
translate pt_br leaveHungryCats_424a2cfe:

    # "You’re broke as heck, so you {i}know{/i} your bathtub isn’t {i}that{/i} big."
    "Você mal tem onde cair morto, então {i}sabe{/i} que sua banheira não é {i}tão{/i} grande assim."

# game/inAlley.rpy:3662
translate pt_br leaveHungryCats_9e0f57e7:

    # "Did..?"
    "Você..?"

# game/inAlley.rpy:3663
translate pt_br leaveHungryCats_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:3664
translate pt_br leaveHungryCats_a2da44e5:

    # "Did you... {w}{b}shrink?{/b}"
    "Você... {w}{b}encolheu?{/b}"

# game/inAlley.rpy:3665
translate pt_br leaveHungryCats_eac07da9:

    # "But {i}how?{/i}"
    "Mas {i}como?{/i}"

# game/inAlley.rpy:3666
translate pt_br leaveHungryCats_e1102cc4:

    # "And even if there were a reasonable answer..."
    "E mesmo que houvesse uma resposta razoável..."

# game/inAlley.rpy:3667
translate pt_br leaveHungryCats_09da957d:

    # "...it wouldn’t explain how you haven’t {b}drowned{/b} yet..."
    "...ainda não explicaria como você ainda não se {b}afogou{/b}..."

# game/inAlley.rpy:3668
translate pt_br leaveHungryCats_6d9bb603:

    # "You swim to the edge of the tub and see the truth in your shadow's silhouette..."
    "Você nada até a borda da banheira e vê a verdade na silhueta da sua sombra..."

# game/inAlley.rpy:3669
translate pt_br leaveHungryCats_28b3ac41:

    # you "!!"
    you "!!"

# game/inAlley.rpy:3675
translate pt_br leaveHungryCats_18e23bb0:

    # "You’ve been... {w}turned into a {i}{b}fish?!{/b}{/i}"
    "Você... {w}virou um {i}{b}peixe?!{/b}{/i}"

# game/inAlley.rpy:3676
translate pt_br leaveHungryCats_be932f7f:

    # you "{i}{size=-5}This... This isn't {b}possible{/b}...{/size}{/i}"
    you "{i}{size=-5}Isso... Isso não é {b}possível{/b}...{/size}{/i}"

# game/inAlley.rpy:3677
translate pt_br leaveHungryCats_06e0acd2:

    # "You don’t get any time to ponder over this unfortunately..."
    "Infelizmente, você não tem tempo para refletir sobre esse infortúnio..."

# game/inAlley.rpy:3678
translate pt_br leaveHungryCats_2c77c5b6:

    # "Because just then..."
    "Porque, naquele instante.."

# game/inAlley.rpy:3681
translate pt_br leaveHungryCats_6274a0c8:

    # "...a shadow looms over you from above."
    "...uma sombra se projeta sobre você."

# game/inAlley.rpy:3682
translate pt_br leaveHungryCats_16744c4a:

    # "You look up and see... the cat?"
    "Você olha para cima e vê... o gato?"

# game/inAlley.rpy:3683
translate pt_br leaveHungryCats_7a9ce7a5:

    # "It peers down at you from beyond the water's surface..."
    "Ele olha para você de além da superfície da água..."

# game/inAlley.rpy:3684
translate pt_br leaveHungryCats_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:3685
translate pt_br leaveHungryCats_8ca8510a_1:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:3686
translate pt_br leaveHungryCats_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:3687
translate pt_br leaveHungryCats_637fa4bd:

    # "And then..."
    "E então..."

# game/inAlley.rpy:3689
translate pt_br leaveHungryCats_1141e85b:

    # "Then you {i}realize.{/i}"
    "Então você {i}percebe.{/i}"

# game/inAlley.rpy:3690
translate pt_br leaveHungryCats_3613f8e2:

    # "{b}This{/b} is the answer..."
    "{b}Essa{/b} é a resposta..."

# game/inAlley.rpy:3691
translate pt_br leaveHungryCats_c16f4226:

    # "This... {w}is how you're meant to atone."
    "Assim... {w}é como você deve se redimir."

# game/inAlley.rpy:3693
translate pt_br leaveHungryCats_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:3694
translate pt_br leaveHungryCats_2387281a:

    # "With a heavy heart..."
    "Com o coração pesado..."

# game/inAlley.rpy:3695
translate pt_br leaveHungryCats_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:3696
translate pt_br leaveHungryCats_23382f12:

    # "...you swim up to the surface."
    "...você nada até a superfície."

# game/inAlley.rpy:3700
translate pt_br leaveHungryCats_c44e377e:

    # cat "Meoww!" with hpunch
    cat "Miauu!" with hpunch

# game/inAlley.rpy:3705
translate pt_br leaveHungryCats_479c3431_1:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/inAlley.rpy:3706
translate pt_br leaveHungryCats_49411296:

    # "The cat scoops you up, tossing you out of the tub and onto the bathroom tiles."
    "O gato te pega, te jogando para fora da banheira, sobre os azulejos do banheiro."

# game/inAlley.rpy:3712
translate pt_br leaveHungryCats_3c17e5ed:

    # "As you flop around gasping for air..."
    "Enquanto você se debate, ofegando por ar..."

# game/inAlley.rpy:3713
translate pt_br leaveHungryCats_26f6c95f:

    # "(or water..?)"
    "(ou água..?)"

# game/inAlley.rpy:3714
translate pt_br leaveHungryCats_74646257:

    # "...you realize the cat wasn’t alone."
    "...você percebe que o gato não está sozinho."

# game/inAlley.rpy:3717
translate pt_br leaveHungryCats_5fa71d4e:

    # "Dozens of hungry eyes peer down at you."
    "Dezenas de olhos famintos olham para você de cima."

# game/inAlley.rpy:3718
translate pt_br leaveHungryCats_6494036d:

    # "You can hear the yowling of what sounds like hundreds of cats outside your bathroom window."
    "Você pode ouvir o miado do que parece ser centenas de gatos do lado de fora da janela do banheiro."

# game/inAlley.rpy:3721
translate pt_br leaveHungryCats_2c0a5c25:

    # "You send one last look to the cat before closing your eyes and accepting your fate."
    "Você lança um último olhar para o gato antes de fechar os olhos e aceitar seu destino."

# game/inAlley.rpy:3730
translate pt_br leaveHungryCats_716c98f8:

    # "As the cats descend upon you, tearing at your flesh..."
    "À medida que os gatos descem sobre você, rasgando sua carne..."

# game/inAlley.rpy:3748
translate pt_br leaveHungryCats_d6080537:

    # "...you find yourself mourning the fact..."
    "...você se vê lamentando o fato..."

# game/inAlley.rpy:3749
translate pt_br leaveHungryCats_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:3750
translate pt_br leaveHungryCats_4d9c1486:

    # "{size=-6}...that you’re not even big enough to feed all of them.{/size}"
    "{size=-6}...de que nem mesmo é grande o suficiente para alimentar todos eles.{/size}"

# game/inAlley.rpy:3759
translate pt_br leaveHungryCats_75e13727:

    # "Even in the end..."
    "Mesmo no final..."

# game/inAlley.rpy:3760
translate pt_br leaveHungryCats_6e125249:

    # "...you couldn’t properly atone."
    "...você não pôde se redimir adequadamente."

# game/inAlley.rpy:3769
translate pt_br leaveHungryCats_0328dbd4:

    # "Your efforts, your {i}life{/i}..."
    "Seus esforços, sua {i}vida{/i}..."

# game/inAlley.rpy:3770
translate pt_br leaveHungryCats_9f0317b6:

    # "All of it..."
    "Tudo isso..."

# game/inAlley.rpy:3771
translate pt_br leaveHungryCats_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:3773
translate pt_br leaveHungryCats_d2cc2d23:

    # "...amounted to {b}nothing{/b}."
    "...não valeu {b}nada{/b}."

# game/inAlley.rpy:3774
translate pt_br leaveHungryCats_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:3775
translate pt_br leaveHungryCats_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:3776
translate pt_br leaveHungryCats_06568472:

    # "Ending 25: Seafood Sacrifice"
    "Final 25: Sacrifício de Frutos do Mar"

# game/inAlley.rpy:3790
translate pt_br feedLookAround_6adec316:

    # "You glance around the dark, dingy alley..."
    "Você olha ao redor do beco escuro e sujo..."

# game/inAlley.rpy:3791
translate pt_br feedLookAround_172f73ee:

    # "...and only see garbage bags, trash bins, empty cardboard boxes, and scattered litter here and there."
    "...e só vê sacos de lixo, latas de lixo, caixas de papelão vazias e sujeira espalhada aqui e ali."

# game/inAlley.rpy:3792
translate pt_br feedLookAround_8a2477ca:

    # "If there were something for the cat to eat, surely it would’ve found it by now, right?"
    "Se houvesse algo para o gato comer, com certeza ele já teria encontrado, certo?"

# game/inAlley.rpy:3793
translate pt_br feedLookAround_1c7afc63:

    # "But you don't want to just give up so easily."
    "Mas você não quer desistir tão fácil."

# game/inAlley.rpy:3794
translate pt_br feedLookAround_1b9dbcae:

    # "You keep looking."
    "Você continua procurando."

# game/inAlley.rpy:3795
translate pt_br feedLookAround_37ccdc14:

    # "You look and only see garbage."
    "Olha e só vê lixo."

# game/inAlley.rpy:3796
translate pt_br feedLookAround_7206a2c2:

    # "You sniff and only smell garbage."
    "Cheira e só sente o odor de lixo."

# game/inAlley.rpy:3798
translate pt_br feedLookAround_15a42f3c:

    # "You listen..."
    "Ouve..."

# game/inAlley.rpy:3799
translate pt_br feedLookAround_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3800
translate pt_br feedLookAround_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:3803
translate pt_br feedLookAround_8a367b77:

    # "{size=-10}*scritch* *scritch*{/size}"
    "{size=-10}*scritch* *scritch*{/size}"

# game/inAlley.rpy:3804
translate pt_br feedLookAround_a513413e:

    # "..!"
    "..!"

# game/inAlley.rpy:3805
translate pt_br feedLookAround_4f966ec3:

    # "You just barely make out the sound of faint scurrying by a trash bin a few feet away."
    "Você mal consegue distinguir o som de passos rápidos e leves perto de uma lixeira a alguns metros de distância."

# game/inAlley.rpy:3806
translate pt_br feedLookAround_b659571e:

    # "Quietly... Oh so quietly... you creep over to the bin..."
    "Silenciosamente... Muito silenciosamente... você se arrasta até a lixeira..."

# game/inAlley.rpy:3807
translate pt_br feedLookAround_cb64e404:

    # "And..."
    "E..."

# game/inAlley.rpy:3808
translate pt_br feedLookAround_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:3809
translate pt_br feedLookAround_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:3810
translate pt_br feedLookAround_a513413e_1:

    # "..!"
    "..!"

# game/inAlley.rpy:3811
translate pt_br feedLookAround_d8c7093a:

    # "{size=+5}You {i}lunge!{/i}{/size}"
    "{size=+5}Você {i}salta!{/i}{/size}"

# game/inAlley.rpy:3813
translate pt_br feedLookAround_d304d4e5:

    # "{size=+20}{b}CRASH!!{/b}{/size}" with vpunch
    "{size=+20}{b}CRASH!!{/b}{/size}" with vpunch

# game/inAlley.rpy:3814
translate pt_br feedLookAround_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:3815
translate pt_br feedLookAround_2ea47ee5:

    # "You weren't very graceful in your attempt."
    "O pouso não foi muito gracioso."

# game/inAlley.rpy:3816
translate pt_br feedLookAround_262f7f90:

    # "You'd stumbled and knocked over a stack of nearby boxes full of more trash, {w}but as you stand up..."
    "Você tropeçou e derrubou uma pilha de caixas próximas, cheias de mais lixo, {w}mas ao se levantar..."

# game/inAlley.rpy:3817
translate pt_br feedLookAround_5398ed86:

    # "...grasped in your hand..."
    "...apanhado na sua mão..."

# game/inAlley.rpy:3818
translate pt_br feedLookAround_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:3821
translate pt_br feedLookAround_7d0b6abb:

    # "...is a small mouse."
    "...está um ratinho."

# game/inAlley.rpy:3823
translate pt_br feedLookAround_9db0dda0:

    # rat "Squeak! Squeak!" with vpunch
    rat "Squeak! Squeak!" with vpunch

# game/inAlley.rpy:3824
translate pt_br feedLookAround_2f69184a:

    # "The mouse squeaks and shrieks in distress, wriggling and struggling desperately in your grip."
    "O rato chia e grita de aflição, se contorcendo e debatendo desesperadamente em sua mão."

# game/inAlley.rpy:3825
translate pt_br feedLookAround_bb6730d7:

    # "You’re holding it too tightly and carefully for it to be able to bite or scratch you though."
    "Você o está segurando com muita firmeza e cuidado, para que ele não possa te morder ou arranhar."

# game/inAlley.rpy:3826
translate pt_br feedLookAround_204f821b:

    # "It wears itself out eventually and looks up at you with black eyes..."
    "Eventualmente, ele se cansa e olha para você com esses olhinhos pretos..."

# game/inAlley.rpy:3827
translate pt_br feedLookAround_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:3828
translate pt_br feedLookAround_0d800538:

    # "It’s {i}completely{/i} at your mercy."
    "Está {i}completamente{/i} à sua mercê."

# game/inAlley.rpy:3856
translate pt_br spareMouse_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/inAlley.rpy:3858
translate pt_br spareMouse_37478095:

    # "Are... you sure?"
    "Você... tem certeza?"

# game/inAlley.rpy:3868
translate pt_br spareMouse2_9cad6637:

    # cat "Meowww..."
    cat "Miauuuu..."

# game/inAlley.rpy:3870
translate pt_br spareMouse2_317daa48:

    # "You can hear the cat's stomach growling."
    "Você pode ouvir o estômago do gato roncando."

# game/inAlley.rpy:3871
translate pt_br spareMouse2_3b182f71:

    # "It must be so hungry..."
    "Deve estar tão faminto..."

# game/inAlley.rpy:3872
translate pt_br spareMouse2_302b36d5:

    # "It must be {b}starving...{/b}"
    "Deve estar {b}morrendo{/b} de fome..."

# game/inAlley.rpy:3878
translate pt_br spareMouse3_2cea6c44:

    # ".{w=1.0}.{w=1.0}.{w=1.0}{nw}"
    ".{w=1.0}.{w=1.0}.{w=1.0}{nw}"

# game/inAlley.rpy:3881
translate pt_br spareMouse3_8c265d6b:

    # cat "{size=+10}{b}MREOW!{/b}{/size}" with hpunch
    cat "{size=+10}{b}MIAAU!{/b}{/size}" with hpunch

# game/inAlley.rpy:3883
translate pt_br spareMouse3_b7235e3b:

    # "You know the cat is hungry."
    "Você sabe que o gato está com fome."

# game/inAlley.rpy:3884
translate pt_br spareMouse3_33159e4f:

    # "Why are you hesitating?"
    "Por que está hesitando?"

# game/inAlley.rpy:3885
translate pt_br spareMouse3_f002086d:

    # "You caught prey for the cat's sake, didn't you?"
    "Você pegou a presa por causa do gato, não foi?"

# game/inAlley.rpy:3886
translate pt_br spareMouse3_e75c361b:

    # "Are you really going to value the life of a filthy rodent more than the cat's?"
    "Você realmente vai valorizar mais a vida de um rato imundo do que a do gato?"

# game/inAlley.rpy:3900
translate pt_br spareMouse4_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3901
translate pt_br spareMouse4_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:3905
translate pt_br spareMouse4_ee44cce1:

    # "{size=-8}{color=#FF0000}You're mocking me, aren't you?{/color}{/size}"
    "{size=-8}{color=#FF0000}Tá de sacanagem, né?{/color}{/size}"

# game/inAlley.rpy:3906
translate pt_br spareMouse4_dd07c1d2:

    # "Last chance..."
    "Última chance..."

# game/inAlley.rpy:3912
translate pt_br spareMouse4_8f248444:

    # "H a n d... {w}o v e r... {w}t h e... {w}p r e y..."
    "E n t r e g a... {w}a... {w}p r e s a... {w}..."

# game/inAlley.rpy:3913
translate pt_br spareMouse4_e7eb980b:

    # "{b}{color=#FF0000}Now.{/color}{/b}"
    "{b}{color=#FF0000}Agora.{/color}{/b}"

# game/inAlley.rpy:3920
translate pt_br freeMouse_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3921
translate pt_br freeMouse_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:3922
translate pt_br freeMouse_85bf2796:

    # "You let the mouse go."
    "Você solta o rato."

# game/inAlley.rpy:3927
translate pt_br freeMouse_2dd146aa:

    # "It scurries away, squeezing into a tiny hole in the wall..."
    "Ele corre, se espremendo em um pequeno buraco na parede..."

# game/inAlley.rpy:3928
translate pt_br freeMouse_dac972a5:

    # "But you don't pay it much mind."
    "Mas você não presta muita atenção."

# game/inAlley.rpy:3934
translate pt_br freeMouse_edd804dd:

    # "You don't flinch as a giant clawed paw slowly falls in front of you..."
    "Você não se surpreende quando uma enorme pata com garras lentamente cai na sua frente..."

# game/inAlley.rpy:3935
translate pt_br freeMouse_27890332:

    # "...blocking your path to the alley's entrance..."
    "...bloqueando seu caminho para a entrada do beco..."

# game/inAlley.rpy:3936
translate pt_br freeMouse_19d2abd9:

    # "Not that you had any delusions about escaping."
    "Não que você tivesse alguma ilusão de escapar."

# game/inAlley.rpy:3937
translate pt_br freeMouse_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:3938
translate pt_br freeMouse_c4176d5e:

    # "The cat is hungry after all."
    "O gato está com fome, afinal de contas."

# game/inAlley.rpy:3947
translate pt_br freeMouse_3e1401c3:

    # "You close your eyes in acceptance as the paw gently pulls you back..."
    "Você fecha os olhos em aceitação enquanto a pata gentilmente te puxa para trás..."

# game/inAlley.rpy:3948
translate pt_br freeMouse_068b5ee7:

    # "And back..."
    "E para trás..."

# game/inAlley.rpy:3949
translate pt_br freeMouse_057a9a91:

    # "And-{w=0.175}{nw}"
    "E-{w=0.175}{nw}"

# game/inAlley.rpy:3955
translate pt_br freeMouse_cc8fcc0d:

    # "{size=+20}{b}CHOMP!!{/b}{/size}" with hpunch
    "{size=+20}{b}CHOMP!!{/b}{/size}" with hpunch

# game/inAlley.rpy:3959
translate pt_br freeMouse_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:3960
translate pt_br freeMouse_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:3961
translate pt_br freeMouse_8b12d547:

    # "Ending 26: A life spared"
    "Final 26: Uma vida poupada"

# game/inAlley.rpy:3975
translate pt_br feedCatMouse_927f34df:

    # "The mouse looks scared, as if it can sense your intentions."
    "O rato parece assustado, como se pudesse sentir suas intenções."

# game/inAlley.rpy:3994
translate pt_br feedCatMouse_7313e03e:

    # "It weakly starts to struggle again."
    "Ele tenta se debater novamente, mas sem força."

# game/inAlley.rpy:3997
translate pt_br feedCatMouse_ff457211:

    # rat "{size=+10}SQUEAK! SQUEAK! {b}SQUEEEAAK!!{/b}{/size}" with hpunch
    rat "{size=+10}SQUEAK! SQUEAK! {b}SQUEEEAAK!!{/b}{/size}" with hpunch

# game/inAlley.rpy:3998
translate pt_br feedCatMouse_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:3999
translate pt_br feedCatMouse_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:4000
translate pt_br feedCatMouse_ca6ee73d:

    # "{size=-10}The mouse is reluctant.{/size}"
    "{size=-10}O rato está hesitante.{/size}"

# game/inAlley.rpy:4008
translate pt_br feedCatMouse2_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:4009
translate pt_br feedCatMouse2_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:4010
translate pt_br feedCatMouse2_32660fc9:

    # "You feed the mouse to the cat."
    "Você dá o rato para o gato comer."

# game/inAlley.rpy:4014
translate pt_br feedCatMouse2_0e994b53:

    # cat "Meowww!" with hpunch
    cat "Miauuu!" with hpunch

# game/inAlley.rpy:4015
translate pt_br feedCatMouse2_d59fd9a8:

    # "The cat tears it apart instantly..."
    "O gato o despedaça instantaneamente..."

# game/inAlley.rpy:4019
translate pt_br feedCatMouse2_ff68e97c:

    # rat "SQUEAK!" with hpunch
    rat "SQUEAK!" with hpunch

# game/inAlley.rpy:4021
translate pt_br feedCatMouse2_b09043ec:

    # rat "SQUEAK! {b}SQUEEEAAK!!{/b}" with hpunch
    rat "SQUEAK! {b}SQUEEEAAK!!{/b}" with hpunch

# game/inAlley.rpy:4023
translate pt_br feedCatMouse2_02199255:

    # rat "SQUE-{w=0.175}{nw}" with hpunch
    rat "SQUE-{w=0.175}{nw}" with hpunch

# game/inAlley.rpy:4035
translate pt_br feedCatMouse2_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:4036
translate pt_br feedCatMouse2_6240b97d:

    # "The mouse's pained squeaks and squeals pierce through you until they're abruptly cut off."
    "Os chiados de dor do rato atravessam você até serem abruptamente interrompidos."

# game/inAlley.rpy:4039
translate pt_br feedCatMouse2_5318aee4:

    # "Satisfied, the cat mewls happily at you, red tinting its fangs."
    "Satisfeito, o gato mia feliz para você, com as presas pintadas de vermelho."

# game/inAlley.rpy:4041
translate pt_br feedCatMouse2_b003a621:

    # cat "Meoww!"
    cat "Miauu!"

# game/inAlley.rpy:4042
translate pt_br feedCatMouse2_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:4043
translate pt_br feedCatMouse2_50910e06:

    # "The cat curls up in its now blood-stained box and goes to sleep."
    "O gato se enrola na sua caixa agora manchada de sangue e adormece."

# game/inAlley.rpy:4044
translate pt_br feedCatMouse2_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:4047
translate pt_br feedCatMouse2_f737576e:

    # "You take the chance to leave."
    "Você aproveita a chance para sair."

# game/inAlley.rpy:4048
translate pt_br feedCatMouse2_10a52902:

    # "A well-fed cat will likely follow you home, after all..."
    "Um gato bem alimentado provavelmente vai te seguir até em casa, no fim das contas..."

# game/inAlley.rpy:4049
translate pt_br feedCatMouse2_991cb618:

    # "...and cute as the cat is, you..."
    "...e por mais que o gato seja fofo, você..."

# game/inAlley.rpy:4050
translate pt_br feedCatMouse2_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:4051
translate pt_br feedCatMouse2_2316a09e:

    # "...you really can’t afford a pet right now."
    "...você realmente não pode manter um pet agora."

# game/inAlley.rpy:4054
translate pt_br feedCatMouse2_8045cc18:

    # "Still feeling a little guilty about the mouse, you decide to just go home."
    "Ainda se sentindo meio culpado pelo rato, você decide ir para casa."

# game/inAlley.rpy:4057
translate pt_br feedCatMouse2_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:4060
translate pt_br feedCatMouse2_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:4063
translate pt_br feedCatMouse2_dae0ec55_3:

    # you "..."
    you "..."

# game/inAlley.rpy:4066
translate pt_br feedCatMouse2_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:4075
translate pt_br feedCatMouse2_dae0ec55_4:

    # you "..."
    you "..."

# game/inAlley.rpy:4079
translate pt_br feedCatMouse2_0338822b:

    # "After a long walk home, you finally enter your apartment..."
    "Após uma longa caminhada para casa, você finalmente entra em seu apartamento..."

# game/inAlley.rpy:4082
translate pt_br feedCatMouse2_99073e13:

    # "You head straight for your room..."
    "Você segue direto para seu quarto..."

# game/inAlley.rpy:4089
translate pt_br feedCatMouse2_fead6e35:

    # "...and collapse on your bed, falling into a fitful sleep."
    "...e capota na cama, caindo em um sono leve e perturbado."

# game/inAlley.rpy:4090
translate pt_br feedCatMouse2_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:4091
translate pt_br feedCatMouse2_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:4092
translate pt_br feedCatMouse2_9669528e:

    # "Later..."
    "Mais tarde..."

# game/inAlley.rpy:4093
translate pt_br feedCatMouse2_0e0f046c:

    # "You wake up..."
    "Você acorda..."

# game/inAlley.rpy:4098
translate pt_br feedCatMouse2_3ef36ef7:

    # "{size=-5}*scritch* *scritch*{/size}"
    "{size=-5}*arranha* *arranha*{/size}"

# game/inAlley.rpy:4100
translate pt_br feedCatMouse2_aed29e03:

    # who "{size=-5}squeak squeak squeak...{/size}"
    who "{size=-5}squeak squeak squeak...{/size}"

# game/inAlley.rpy:4101
translate pt_br feedCatMouse2_75fd645a:

    # "...to squeaking and scurrying noises {b}all{/b} around you..."
    "...com sons de chiados e correria em {b}toda{/b} a sua volta..."

# game/inAlley.rpy:4102
translate pt_br feedCatMouse2_731d880d:

    # "...so loud and constant, they sound like {i}screams.{/i}"
    "...tão altos e constantes que parecem {i}gritos.{/i}."

# game/inAlley.rpy:4103
translate pt_br feedCatMouse2_3502244d:

    # "In the darkness of your room..."
    "Na escuridão do seu quarto..."

# game/inAlley.rpy:4104
translate pt_br feedCatMouse2_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:4108
translate pt_br feedCatMouse2_3b018980:

    # "...you see the shifting shadows of {b}{i}hundreds{/i}{/b} of mice surrounding your bed."
    "...você vê as sombras em movimento de {b}{i}centenas{/i}{/b} de ratos cercando sua cama."

# game/inAlley.rpy:4109
translate pt_br feedCatMouse2_56ebb028:

    # you "!!!"
    you "!!!"

# game/inAlley.rpy:4110
translate pt_br feedCatMouse2_a55f18e5:

    # "You try to run..."
    "Você tenta correr..."

# game/inAlley.rpy:4114
translate pt_br feedCatMouse2_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:4115
translate pt_br feedCatMouse2_5c6c5752:

    # you "AHH!" with vpunch
    you "AHH!" with vpunch

# game/inAlley.rpy:4116
translate pt_br feedCatMouse2_2ffa7999:

    # "But you cry out as twin lances of pain race up your legs."
    "Mas você grita ao sentir uma dor lancinante subindo pelas suas pernas."

# game/inAlley.rpy:4117
translate pt_br feedCatMouse2_a5230802:

    # "You fall off the bed in your attempt to escape..."
    "Você cai da cama ao tentar fugir..."

# game/inAlley.rpy:4118
translate pt_br feedCatMouse2_d6ce36d0:

    # "...the hoards of mice dodging you as you crash to the ground."
    "...as hordas de ratos desviam de você enquanto você despenca no chão."

# game/inAlley.rpy:4119
translate pt_br feedCatMouse2_0f5de544:

    # "You..."
    "Você..."

# game/inAlley.rpy:4120
translate pt_br feedCatMouse2_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:4121
translate pt_br feedCatMouse2_ea714275:

    # "{size=-8}You can't stand up.{/size}"
    "{size=-8}Você não consegue ficar de pé.{/size}"

# game/inAlley.rpy:4122
translate pt_br feedCatMouse2_191bfb14:

    # "Looking back and squinting in the dark, {w}you just about make out the source of your pain..."
    "Olhando para trás e forçando a vista na escuridão, {w}você consegue quase distinguir a fonte da sua dor..."

# game/inAlley.rpy:4126
translate pt_br feedCatMouse2_4b8f74bf:

    # "The flesh and tendons of your heels and ankles are mangled..."
    "A carne e os tendões dos seus calcanhares e tornozelos estão mutilados..."

# game/inAlley.rpy:4127
translate pt_br feedCatMouse2_017438eb:

    # "{b}Bitten{/b} through your socks..."
    "{b}Mordidos{/b} através das suas meias..."

# game/inAlley.rpy:4128
translate pt_br feedCatMouse2_2f0d3863:

    # you "N-No... No! L-Leave me alone..!" with hpunch
    you "N-Não... Não! M-Me deixa em paz..!" with hpunch

# game/inAlley.rpy:4130
translate pt_br feedCatMouse2_af41a66d:

    # "Desperate, you crawl with only your arms towards the door..."
    "Desesperado, você rasteja apenas com os braços em direção à porta..."

# game/inAlley.rpy:4133
translate pt_br feedCatMouse2_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:4134
translate pt_br feedCatMouse2_a20cefa7_8:

    # "..."
    "..."

# game/inAlley.rpy:4136
translate pt_br feedCatMouse2_bc2fabcc:

    # "The mice descend upon you..."
    "Os ratos descem sobre você..."

# game/inAlley.rpy:4144
translate pt_br feedCatMouse2_8ca8510a_1:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:4145
translate pt_br feedCatMouse2_21d8e99a:

    # "...biting into your skin."
    "...mordendo sua pele."

# game/inAlley.rpy:4153
translate pt_br feedCatMouse2_8ca8510a_2:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:4154
translate pt_br feedCatMouse2_f62320f5:

    # "Gnawing away {b}pieces{/b} of you..."
    "Roendo {b}pedaços{/b} de você..."

# game/inAlley.rpy:4162
translate pt_br feedCatMouse2_dae0ec55_5:

    # you "..."
    you "..."

# game/inAlley.rpy:4163
translate pt_br feedCatMouse2_9943b33e:

    # "You start to fade in and out of consciousness..."
    "Você começa a desmaiar e a voltar à consciência..."

# game/inAlley.rpy:4164
translate pt_br feedCatMouse2_efcd9d02:

    # "...but you still reach up for the doorknob..."
    "...mas ainda estende a mão em direção à maçaneta..."

# game/inAlley.rpy:4167
translate pt_br feedCatMouse2_2cb23dbf:

    # "...your arm heavy, weighed down by the mice clinging to it with little claws and tiny teeth."
    "...seu braço pesado, pressionado pelos ratos que se agarram a ele com suas garras pequenas e dentes minúsculos."

# game/inAlley.rpy:4168
translate pt_br feedCatMouse2_fb2f2154:

    # "You manage to jostle the knob enough for the door to slowly swing open..."
    "Você consegue girar a maçaneta o suficiente para que a porta se abra lentamente..."

# game/inAlley.rpy:4183
translate pt_br feedCatMouse2_7128cb1f:

    # "*PLOP!*" with hpunch
    "*PLOP!*" with hpunch

# game/inAlley.rpy:4184
translate pt_br feedCatMouse2_a20cefa7_9:

    # "..."
    "..."

# game/inAlley.rpy:4187
translate pt_br feedCatMouse2_50f50169:

    # "...But your outstretched arm suddenly falls to the ground, lifeless."
    "...Mas seu braço estendido de repente cai no chão, sem vida."

# game/inAlley.rpy:4188
translate pt_br feedCatMouse2_56ebb028_1:

    # you "!!!"
    you "!!!"

# game/inAlley.rpy:4189
translate pt_br feedCatMouse2_f764243f:

    # "The mice managed to chew through the flesh and bone of your now dismembered limb."
    "Os ratos conseguiram roer a carne e o osso do seu membro agora desmembrado."

# game/inAlley.rpy:4190
translate pt_br feedCatMouse2_3b178dd0:

    # "As a few mice creep forward to curiously inspect your arm, you stare blankly at it for a moment before sliding your gaze up."
    "Enquanto alguns ratos se aproximam curiosamente para examinar seu braço, você o encara em estado de choque por um momento antes de desviar o olhar para cima."

# game/inAlley.rpy:4193
translate pt_br feedCatMouse2_9ffc28d3:

    # "In the newly opened doorway, sits a familiar looking..."
    "Na porta recém-aberta, está um..."

# game/inAlley.rpy:4194
translate pt_br feedCatMouse2_40d9ca73:

    # "..?"
    "..?"

# game/inAlley.rpy:4195
translate pt_br feedCatMouse2_6d3f28fc:

    # "...mouse?"
    "...rato? Familiar..."

# game/inAlley.rpy:4196
translate pt_br feedCatMouse2_115c17a3:

    # "It stares at you."
    "Ele te encara."

# game/inAlley.rpy:4197
translate pt_br feedCatMouse2_95e298fc:

    # "The darkness in its beady, black eyes... {w}You can’t begin to measure their depths..."
    "A escuridão em seus olhos pretos e brilhantes... {w}Você não consegue nem medir sua profundidade..."

# game/inAlley.rpy:4206
translate pt_br feedCatMouse2_a20cefa7_10:

    # "..."
    "..."

# game/inAlley.rpy:4207
translate pt_br feedCatMouse2_bb419a8e:

    # "Nor the hatred pouring out from within them..."
    "Nem o ódio que emana de dentro deles..."

# game/inAlley.rpy:4210
translate pt_br feedCatMouse2_9f0317b6:

    # "All of it..."
    "Tudo isso..."

# game/inAlley.rpy:4213
translate pt_br feedCatMouse2_fa45f11e:

    # "...aimed at {b}you.{/b}"
    "...direcionado a {b}você.{/b}"

# game/inAlley.rpy:4220
translate pt_br feedCatMouse2_63539327:

    # you "A-Ah..."
    you "A-Ah..."

# game/inAlley.rpy:4221
translate pt_br feedCatMouse2_11499480:

    # "You collapse, head hitting the floor as your other arm is eaten away as well."
    "Você desaba, batendo a cabeça no chão enquanto seu outro braço também é devorado."

# game/inAlley.rpy:4222
translate pt_br feedCatMouse2_771b6f54:

    # "You’re not sure how you’re still conscious. The pain should be indescribable..."
    "Você não sabe como ainda está consciente. A dor deveria ser indescritível..."

# game/inAlley.rpy:4223
translate pt_br feedCatMouse2_595186a8:

    # "And yet... you just feel a cold sense of loss..."
    "E ainda assim... você sente apenas uma fria sensação de perda..."

# game/inAlley.rpy:4224
translate pt_br feedCatMouse2_33bce6c6:

    # "The mice have clustered along your back now..."
    "Os ratos agora estão agrupados nas suas costas..."

# game/inAlley.rpy:4225
translate pt_br feedCatMouse2_c3e0a8e8:

    # "...gnawing and ripping their way between your shoulder blades..."
    "...roendo e rasgando um caminho entre suas escápulas..."

# game/inAlley.rpy:4226
translate pt_br feedCatMouse2_8019dadd:

    # "Into your back... Into your {i}chest--{/i}"
    "Para suas costas... Para seu {i}peito--{/i}"

# game/inAlley.rpy:4232
translate pt_br feedCatMouse2_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:4233
translate pt_br feedCatMouse2_bfc63f92:

    # you "*cough*! *cough*!.." with hpunch
    you "*cof*! *cof*!.." with hpunch

# game/inAlley.rpy:4237
translate pt_br feedCatMouse2_30ab43e2:

    # "...You weakly cough up blood. They must have damaged something important..."
    "...Você tosse já sem força, expelindo sangue. Eles devem ter danificado algo importante..."

# game/inAlley.rpy:4238
translate pt_br feedCatMouse2_8b59ccb1:

    # "You feel something being {i}pulled out of you...{/i}"
    "Você sente algo sendo {i}arrancado de dentro de você...{/i}"

# game/inAlley.rpy:4239
translate pt_br feedCatMouse2_f2234e60:

    # "And in between the moments that blankets of darkness fade out your vision..."
    "E, entre os momentos em que os mantos de escuridão obscurecem sua visão..."

# game/inAlley.rpy:4241
translate pt_br feedCatMouse2_13fb74b2:

    # "{size=-8}*splat*{/size}"
    "{size=-8}*splat*{/size}"

# game/inAlley.rpy:4242
translate pt_br feedCatMouse2_633ae29e:

    # "...you hear something wet plop on the ground in front of you."
    "...você ouve algo molhado cair no chão à sua frente."

# game/inAlley.rpy:4243
translate pt_br feedCatMouse2_bbaaac8d:

    # "You pry your eyes open and see {i}it{/i} in front of the mouse..."
    "Você força os olhos a se abrirem e vê {i}isso{/i} na frente do rato..."

# game/inAlley.rpy:4246
translate pt_br feedCatMouse2_b7184c45:

    # "Weirdly shaped, red with your blood and {b}pulsing{/b} and..."
    "Formato estranho, vermelho com seu sangue, {b}pulsando{/b} e..."

# game/inAlley.rpy:4247
translate pt_br feedCatMouse2_9330ef6a:

    # "Oh, that’s..."
    "Ah, isso é..."

# game/inAlley.rpy:4248
translate pt_br feedCatMouse2_55a10ea9:

    # "That’s your heart... {w}isn’t it..?"
    "Isso é o seu coração... {w}não é..?"

# game/inAlley.rpy:4252
translate pt_br feedCatMouse2_e608f022:

    # "The other mice all descend upon it, abandoning your half-eaten body."
    "Os outros ratos descem sobre ele, abandonando seu corpo semi-devorado."

# game/inAlley.rpy:4256
translate pt_br feedCatMouse2_c5119fab:

    # "You’re... losing a lot of blood."
    "Você está... perdendo muito sangue."

# game/inAlley.rpy:4257
translate pt_br feedCatMouse2_98bc0f41:

    # "You feel sleepy... {w}But..."
    "Você se sente sonolento... {w}Mas..."

# game/inAlley.rpy:4258
translate pt_br feedCatMouse2_84fb2e85:

    # "You... also feel..."
    "Você... também sente..."

# game/inAlley.rpy:4260
translate pt_br feedCatMouse2_40d9ca73_1:

    # "..?"
    "..?"

# game/inAlley.rpy:4261
translate pt_br feedCatMouse2_1e59d740:

    # "Anger?"
    "Raiva?"

# game/inAlley.rpy:4262
translate pt_br feedCatMouse2_c33553a7:

    # "...{b}Yes.{/b}"
    "...{b}Sim.{/b}"

# game/inAlley.rpy:4263
translate pt_br feedCatMouse2_f367bb97:

    # "So... {i}so{/i} much anger."
    "Tanta... {i}tanta{/i} raiva."

# game/inAlley.rpy:4264
translate pt_br feedCatMouse2_bc4dfa80:

    # "How dare they..?"
    "Como eles ousam..?"

# game/inAlley.rpy:4265
translate pt_br feedCatMouse2_a20cefa7_11:

    # "..."
    "..."

# game/inAlley.rpy:4266
translate pt_br feedCatMouse2_481997a6:

    # "{size=-6}How {b}dare{/b} they..?{/size}"
    "{size=-6}Como eles {b}ousam{/b}..?{/size}"

# game/inAlley.rpy:4270
translate pt_br feedCatMouse2_b41033e1:

    # "The last thing you see before your vision fails you..."
    "A última coisa que você vê antes de sua visão falhar..."

# game/inAlley.rpy:4275
translate pt_br feedCatMouse2_0f017232:

    # "...is a pair of glowing eyes leering in from the darkness beyond the doorway."
    "...é um par de olhos brilhantes espreitando na escuridão além da porta."

# game/inAlley.rpy:4290
translate pt_br feedCatMouse2_262f03ab:

    # "You can hear squeaks and shrieks of terror all around you..."
    "Você pode ouvir chiados e gritos de terror ao seu redor..."

# game/inAlley.rpy:4296
translate pt_br feedCatMouse2_8b513e6c:

    # "Low yowls... {w}deep snarls... {w}{i}gnashing teeth...{/i} {w}{b}tearing flesh...{/b}"
    "Uivos graves... {w}rosnados profundos... {w}{i}dentes rangendo...{/i} {w}{b}carne rasgando...{/b}"

# game/inAlley.rpy:4297
translate pt_br feedCatMouse2_9e1e42e3:

    # "As your remaining senses leave you..."
    "À medida que seus sentidos restantes te abandonam..."

# game/inAlley.rpy:4298
translate pt_br feedCatMouse2_588df3af:

    # "...you smile weakly with the last of your strength..."
    "...você sorri timidamente com o resto de sua força..."

# game/inAlley.rpy:4299
translate pt_br feedCatMouse2_7f3c4ffb:

    # "...when something with soft, slightly damp and sticky fur nuzzles your cheek."
    "...quando algo com pelagem macia, ligeiramente úmida e pegajosa acaricia sua bochecha."

# game/inAlley.rpy:4301
translate pt_br feedCatMouse2_8c8e6f27:

    # who "Purr..."
    who "Purr..."

# game/inAlley.rpy:4302
translate pt_br feedCatMouse2_8dabefc6_3:

    # ".."
    ".."

# game/inAlley.rpy:4303
translate pt_br feedCatMouse2_a20cefa7_12:

    # "..."
    "..."

# game/inAlley.rpy:4304
translate pt_br feedCatMouse2_2c38d82c:

    # you "{i}Good kitty.{/i}"
    you "{i}Bom gatinho.{/i}"

# game/inAlley.rpy:4305
translate pt_br feedCatMouse2_a20cefa7_13:

    # "..."
    "..."

# game/inAlley.rpy:4306
translate pt_br feedCatMouse2_85830579:

    # "Ending 27: Well-Fed"
    "Final 27: Bem Alimentado"

# game/inAlley.rpy:4324
translate pt_br feedBlood_9cad6637:

    # cat "Meowww..."
    cat "Miauuu"

# game/inAlley.rpy:4326
translate pt_br feedBlood_81d09fc7:

    # "The cat lets out a sad, pleading little sound."
    "O gato solta um miado baixinho, triste e suplicante."

# game/inAlley.rpy:4327
translate pt_br feedBlood_77603d0b:

    # "It's hungry."
    "Está faminto."

# game/inAlley.rpy:4328
translate pt_br feedBlood_2ecc0964:

    # "It must be starving."
    "Deve estar morrendo de fome."

# game/inAlley.rpy:4329
translate pt_br feedBlood_42b896f8:

    # "So..."
    "Então..."

# game/inAlley.rpy:4330
translate pt_br feedBlood_0f5de544:

    # "You..."
    "Você..."

# game/inAlley.rpy:4331
translate pt_br feedBlood_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:4334
translate pt_br feedBlood_5ca2097f:

    # "You look around and see a nearby shard of glass..."
    "Você olha em volta e vê um caco de vidro próximo..."

# game/inAlley.rpy:4335
translate pt_br feedBlood_6d915dc6:

    # "Your body moves as if it knows what to do... {w}What {i}needs{/i} to be done..."
    "Seu corpo se move como se soubesse o que fazer... {w}O que {i}precisa{/i} ser feito..."

# game/inAlley.rpy:4338
translate pt_br feedBlood_71be69bc:

    # "You take the shard and..."
    "Você pega o caco e..."

# game/inAlley.rpy:4339
translate pt_br feedBlood_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:4349
translate pt_br feedBlood_39a0ef61:

    # "..?!" with hpunch
    "..?!" with hpunch

# game/inAlley.rpy:4352
translate pt_br feedBlood_1a1c5607:

    # "Wh-"
    "Por qu-"

# game/inAlley.rpy:4353
translate pt_br feedBlood_7ecd134e:

    # "{b}{i}Why would you—{/i}{/b}"
    "{b}{i}Por que você—{/i}{/b}"

# game/inAlley.rpy:4354
translate pt_br feedBlood_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:4356
translate pt_br feedBlood_01b83f04:

    # "{size=-8}Why would you {b}do{/b} that?{/size}"
    "{size=-8}Por que você {b}faria{/b} isso?{/size}"

# game/inAlley.rpy:4368
translate pt_br feedBlood_762defa2:

    # "You carefully hold your finger over the cat."
    "Você cuidadosamente segura seu dedo sobre o gato."

# game/inAlley.rpy:4369
translate pt_br feedBlood_7d18846b:

    # "Dark red blood beads at the wound..."
    "Sangue vermelho escuro se acumula na ferida..."

# game/inAlley.rpy:4388
translate pt_br feedBlood_e39facbe:

    # "...before growing heavy enough to drip into the cat’s open, waiting jaws."
    "...até pesar o suficiente para pingar nas mandíbulas abertas e ansiosas do gato."

# game/inAlley.rpy:4391
translate pt_br feedBlood_c4ed09d4:

    # "It mewls happily at you."
    "Ele mia feliz para você."

# game/inAlley.rpy:4393
translate pt_br feedBlood_ba1796d7:

    # cat "Meowww!"
    cat "Miauuu!"

# game/inAlley.rpy:4394
translate pt_br feedBlood_c2c5bcf6:

    # "You smile warmly and lower your hand into the box..."
    "Você sorri com ternura e abaixa a mão na caixa..."

# game/inAlley.rpy:4395
translate pt_br feedBlood_45c2e033:

    # "...stroking the cat’s cheek before letting it lap gently at your bleeding finger."
    "...acariciando a bochecha do gato antes de deixá-lo lamber suavemente seu dedo ensanguentado."

# game/inAlley.rpy:4396
translate pt_br feedBlood_dbbb8fed:

    # "When the flow gets weak and the cat meows for more, you squeeze below the wound, coaxing more blood out."
    "Quando o fluxo diminui e o gato mia por mais, você aperta abaixo da ferida, fazendo sair mais sangue."

# game/inAlley.rpy:4399
translate pt_br feedBlood_28db8729:

    # "You feel a strange, but welcome sense of comfort from the odd exchange."
    "Você sente uma estranha, mas bem-vinda sensação de conforto com essa troca esquisita."

# game/inAlley.rpy:4400
translate pt_br feedBlood_51e619d4:

    # "A being other than yourself was hungry..."
    "Um ser além de você estava faminto..."

# game/inAlley.rpy:4401
translate pt_br feedBlood_ebe79259:

    # "...and {i}you{/i} were able to provide it sustenance."
    "...e {i}você{/i} conseguiu lhe fornecer sustento."

# game/inAlley.rpy:4402
translate pt_br feedBlood_74acde15:

    # "A small wrong in the world made right... {w}even if so strangely done and only temporarily."
    "Um pequeno erro no mundo foi corrigido... {w}mesmo que de forma tão estranha e apenas temporariamente."

# game/inAlley.rpy:4405
translate pt_br feedBlood_4c836b64:

    # "Ironically, it’s at that moment that you start to feel... dizzy..."
    "Ironicamente, é nesse momento que você começa a se sentir... tonto..."

# game/inAlley.rpy:4406
translate pt_br feedBlood_19b6fd1b:

    # "You didn’t think you were losing that much blood..."
    "Você não achou que estava perdendo tanto sangue assim..."

# game/inAlley.rpy:4409
translate pt_br feedBlood_6207f576:

    # "You slump against the cat’s box and listen to it mewl in distress."
    "Você se encosta na caixa do gato e ouve ele miar angustiado."

# game/inAlley.rpy:4411
translate pt_br feedBlood_6bbdcd7a:

    # cat "Mreow! Mreowww!" with hpunch
    cat "Miau! Miaauuu!" with hpunch

# game/inAlley.rpy:4412
translate pt_br feedBlood_31c0a678:

    # "You think it sounds worried about you. Or at least you'd {i}like{/i} to think so."
    "Você acha que ele parece preocupado com você. Ou, pelo menos, {i}gostaria{/i} de pensar assim."

# game/inAlley.rpy:4413
translate pt_br feedBlood_7db1edf8:

    # "It {i}could{/i} just want more blood as well."
    "Ele também {i}pode{/i} estar só querendo mais sangue."

# game/inAlley.rpy:4414
translate pt_br feedBlood_cbe24519:

    # "The cat hops out of the box and into your lap, nuzzling at your stomach and meowing unhappily."
    "O gato pula para fora da caixa e se aconchega no seu colo, encostando na sua barriga e miando descontente."

# game/inAlley.rpy:4415
translate pt_br feedBlood_e33e9f59:

    # "You wish you could ease its concerns, but it’s not like you can just talk to each other."
    "Você queria poder acalmá-lo, mas não é como se vocês pudessem simplesmente conversar um com o outro."

# game/inAlley.rpy:4416
translate pt_br feedBlood_7c678cc4:

    # "You can’t help but try to remember the last time you talked to {i}anyone{/i}, actually..."
    "Você tenta se lembrar da última vez que falou com {i}algúem{/i}, na verdade..."

# game/inAlley.rpy:4419
translate pt_br feedBlood_e9b924ed:

    # "If you were to die here and now in this alley..."
    "Se você fosse morrer aqui e agora neste beco..."

# game/inAlley.rpy:4420
translate pt_br feedBlood_78256794:

    # "...how long would it take for someone to realize you were missing?"
    "...quanto tempo levaria para alguém perceber seu sumiço?"

# game/inAlley.rpy:4422
translate pt_br feedBlood_dba3e829:

    # "That you were {b}{i}gone{/i}{/b}..?"
    "Que você {b}{i}se foi{/i}{/b}..?"

# game/inAlley.rpy:4424
translate pt_br feedBlood_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:4426
translate pt_br feedBlood_b0768480:

    # cat "{size=+10}Mreow!!{/size}" with hpunch
    cat "{size=+10}Miaau!!{/size}" with hpunch

# game/inAlley.rpy:4429
translate pt_br feedBlood_28b3ac41:

    # you "!!"
    you "!!"

# game/inAlley.rpy:4430
translate pt_br feedBlood_1742e74d:

    # "Your thoughts are interrupted when the cat yowls loudly, tensing up in your lap."
    "Seus pensamentos são interrompidos quando o gato mia alto, ficando nervoso no seu colo."

# game/inAlley.rpy:4431
translate pt_br feedBlood_2183d3c6:

    # "You don’t have time to wonder why as a voice rings out from the entryway to the alley."
    "Você não tem tempo para se perguntar o porquê, quando uma voz ressoa na entrada do beco."

# game/inAlley.rpy:4432
translate pt_br feedBlood_f44a447d:

    # who "Hello..?"
    who "Olá..?"

# game/inAlley.rpy:4438
translate pt_br feedBlood_e7a89ae7:

    # who "Hey, you! Are you... alright?"
    who "Ei, amigo! Tá tudo... bem?"

# game/inAlley.rpy:4439
translate pt_br feedBlood_d209807a:

    # "You don’t answer. You don't think you {i}can.{/i}"
    "Você não responde. Você não acha que {i}consegue.{/i}"

# game/inAlley.rpy:4440
translate pt_br feedBlood_8208fd13:

    # "Your voice feels locked away... deep, deep within you."
    "Sua voz parece estar trancada... Bem fundo em você."

# game/inAlley.rpy:4441
translate pt_br feedBlood_bc95f001:

    # "The cat looks up at you with a long stare... {w}as if assessing you."
    "O gato olha para você por um bom tempo... {w}como se estivesse te avaliando."

# game/inAlley.rpy:4442
translate pt_br feedBlood_c058177f:

    # "It looks back towards the voice and with a final nuzzle to your stomach..."
    "Ele olha para trás na direção da voz e, com um último afago na sua barriga..."

# game/inAlley.rpy:4447
translate pt_br feedBlood_93a5d8f4:

    # "...it hops out of your lap, walking towards the alley's entrance..."
    "...ele pula do seu colo e caminha em direção à entrada do beco..."

# game/inAlley.rpy:4448
translate pt_br feedBlood_4e4b3a2b:

    # "But then..."
    "Mas então..."

# game/inAlley.rpy:4451
translate pt_br feedBlood_6e3d0e44:

    # "...it starts to {b}shift{/b}... as—{w=0.5}{nw}"
    "...ele começa a {b}mudar{/b}... enquanto—{w=0.5}{nw}"

# game/inAlley.rpy:4455
translate pt_br feedBlood_922194c3:

    # "Crack!" with vpunch
    "Crec!" with vpunch

# game/inAlley.rpy:4456
translate pt_br feedBlood_90b68c87:

    # you "..?"
    you "..?"

# game/inAlley.rpy:4465
translate pt_br feedBlood_56ebb028:

    # you "!!!"
    you "!!!"

# game/inAlley.rpy:4466
translate pt_br feedBlood_bcc1608b:

    # "Its face... {i}opens up{/i}..."
    "Sua face... {i}se abre{/i}..."

# game/inAlley.rpy:4470
translate pt_br feedBlood_1a0a44a7:

    # "{size=+15}{b}CRACK!!{/b}{/size}" with vpunch
    "{size=+15}{b}CREC!!{/b}{/size}" with vpunch

# game/inAlley.rpy:4471
translate pt_br feedBlood_6a8f2f72:

    # "It peels back."
    "Ela se descasca."

# game/inAlley.rpy:4480
translate pt_br feedBlood_18494b91:

    # "...and opens {i}again{/i}..."
    "...e se abre {i}novamente{/i}..."

# game/inAlley.rpy:4486
translate pt_br feedBlood_54d0e137:

    # "...writhing tendrils peeking out from where you think its mouth should be."
    "...surgindo tentáculos retorcidos de onde você imagina que deveria estar a boca."

# game/inAlley.rpy:4489
translate pt_br feedBlood_30bf4da2:

    # "The stranger’s silhouette freezes in the light beyond the alley..."
    "A silhueta do estranho congela na luz além do beco..."

# game/inAlley.rpy:4490
translate pt_br feedBlood_300597e8:

    # who "W-What the hell is-?"
    who "Q-Que porra é-?"

# game/inAlley.rpy:4491
translate pt_br feedBlood_84218509:

    # "But they don’t have the chance to finish their question."
    "Mas ele não tem a chance de terminar a pergunta."

# game/inAlley.rpy:4502
translate pt_br feedBlood_aa46e9c3:

    # "The tendrils converge into one..."
    "Os tentáculos se juntam em um só..."

# game/inAlley.rpy:4505
translate pt_br feedBlood_7e5bb0e2:

    # "...before shooting out of the cat’s jaws-"
    "...antes de disparar das mandíbulas do gato-"

# game/inAlley.rpy:4523
translate pt_br feedBlood_168a8ded:

    # "...and {i}{b}piercing{/b}{/i} into the stranger’s shoulder."
    "...e {i}{b}atravessar{/b}{/i} o ombro do estranho."

# game/inAlley.rpy:4524
translate pt_br feedBlood_71716684:

    # who "{size=+10}GAH!!{/size}" with vpunch
    who "{size=+10}GAH!!{/size}" with vpunch

# game/inAlley.rpy:4525
translate pt_br feedBlood_c13159e5:

    # who "{size=+10}{i}A-AAAHHHHH!{/i}{/size}" with vpunch
    who "{size=+10}{i}A-AAAHHHHH!{/i}{/size}" with vpunch

# game/inAlley.rpy:4527
translate pt_br feedBlood_e6c19910:

    # "They let a out a pained cry... a fearful yell."
    "Ele solta um grito de dor... um berro cheio de medo."

# game/inAlley.rpy:4528
translate pt_br feedBlood_bc6e9a70:

    # "They claw at the tendrils, trying to pull them loose... {w}but to no avail."
    "Ele agarra os tentáculos, tentando soltá-los... {w}mas sem sucesso."

# game/inAlley.rpy:4529
translate pt_br feedBlood_55e0cee4:

    # "You... {w}can’t seem to process their screams."
    "Você... {w}não consegue processar os gritos dele."

# game/inAlley.rpy:4533
translate pt_br feedBlood_d3b6988c:

    # "You stare at the creature before you..."
    "Você encara a criatura à sua frente..."

# game/inAlley.rpy:4534
translate pt_br feedBlood_f2277d90:

    # "So different from the cat who mewled out of concern for you earlier..."
    "Tão diferente do gato que antes miou, preocupado com você..."

# game/inAlley.rpy:4545
translate pt_br blood_stopCat_282f048b:

    # "You can't..."
    "Você não pode..."

# game/inAlley.rpy:4546
translate pt_br blood_stopCat_aba81e88:

    # "You can't let this happen.."
    "Você não pode deixar isso acontecer.."

# game/inAlley.rpy:4547
translate pt_br blood_stopCat_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:4550
translate pt_br blood_stopCat_e5406a2e:

    # "You shakily crawl forward..."
    "Tremendo, você se arrasta para frente..."

# game/inAlley.rpy:4556
translate pt_br blood_stopCat_b4131218:

    # "...and weakly grab at the conjoined tendrils that pulse as they drain the stranger’s blood."
    "...e, sem forças, agarra os tentáculos unidos que pulsam enquanto drenam o sangue do estranho."

# game/inAlley.rpy:4557
translate pt_br blood_stopCat_072b7df9:

    # "When you tug as firmly as you’re able, the tendrils' pulsing halts... and the cat turns to you."
    "Quando você puxa com toda a força que consegue, o pulsar dos tentáculos para... e o gato se vira para você."

# game/inAlley.rpy:4559
translate pt_br blood_stopCat_36245d43:

    # cat "Plrr? Pllrrr?"
    cat "Plrr? Pllrrr?"

# game/inAlley.rpy:4560
translate pt_br blood_stopCat_6fca227b:

    # "It makes a strange trilling noise that sounds like a question..."
    "Ele emite um miado estranho, que soa como uma pergunta..."

# game/inAlley.rpy:4561
translate pt_br blood_stopCat_e1a9cee7:

    # "But you have no answer."
    "Mas você não tem uma resposta."

# game/inAlley.rpy:4562
translate pt_br blood_stopCat_f007bcff:

    # "You can't even understand the question..."
    "Você nem consegue entender a pergunta..."

# game/inAlley.rpy:4563
translate pt_br blood_stopCat_b9b06782:

    # "So you simply scoop up the creature... {w}the {i}cat{/i}... {w}cradling it in your arms."
    "Então, você simplesmente pega a criatura... {w}o {i}gato{/i}... {w}acolhendo-o em seus braços."

# game/inAlley.rpy:4567
translate pt_br blood_stopCat_6a141fd0:

    # "You gaze almost longingly at the light beyond the alley's entrance."
    "Você olha quase anseiosamente para a luz além da entrada do beco."

# game/inAlley.rpy:4568
translate pt_br blood_stopCat_f70d6c24:

    # "You don’t know what’s going on..."
    "Você não sabe o que está acontecendo..."

# game/inAlley.rpy:4569
translate pt_br blood_stopCat_53834d64:

    # "...but you just can’t sit by and watch someone else be eaten so viciously..."
    "...mas não pode simplesmente ficar sentado e ver alguém ser devorado tão brutalmente..."

# game/inAlley.rpy:4570
translate pt_br blood_stopCat_d84cf8f5:

    # "Not when they’d tried to see if you were okay..."
    "Não quando a pessoa tentou saber se você estava bem..."

# game/inAlley.rpy:4571
translate pt_br blood_stopCat_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:4573
translate pt_br blood_stopCat_da22d380:

    # "...Not when you could offer yourself instead."
    "...Não quando você poderia se oferecer em seu lugar."

# game/inAlley.rpy:4577
translate pt_br blood_stopCat_705c4802:

    # "You think the stranger is set free..."
    "Você pensa que o estranho está livre..."

# game/inAlley.rpy:4578
translate pt_br blood_stopCat_0c3e5209:

    # "...because after the sound of shoes hastily scuffing on the pavement fades into the distance..."
    "...porque, depois que o som de sapatos arrastando com pressa no chão se afasta..."

# game/inAlley.rpy:4585
translate pt_br blood_stopCat_5b8efe03:

    # you "Nn!" with vpunch
    you "Nn!" with vpunch

# game/inAlley.rpy:4586
translate pt_br blood_stopCat_3a5f5491:

    # "...you feel something sharp pierce your back."
    "...você sente algo afiado perfurando suas costas."

# game/inAlley.rpy:4587
translate pt_br blood_stopCat_183312a6:

    # "It feels thin... {w}almost like a needle... {w}so the pain passes quickly as your body adjusts to the intrusion."
    "Parece fino... {w}quase como uma agulha... {w}então a dor passa rapidamente enquanto seu corpo se ajusta à intrusão."

# game/inAlley.rpy:4588
translate pt_br blood_stopCat_123c6d3b:

    # "You're sure it wasn't so thin when it skewered through the stranger's shoulder earlier..."
    "Você tem certeza de que não era tão fina quando atravessou o ombro do estranho mais cedo..."

# game/inAlley.rpy:4593
translate pt_br blood_stopCat_c69f0708:

    # "...but as you feel your blood leave your body, slowly as if being pumped out..."
    "...mas, à medida que sente seu sangue sair do corpo, lentamente, como se estivesse sendo bombeado..."

# game/inAlley.rpy:4594
translate pt_br blood_stopCat_5a001e33:

    # "...it gets harder to think and your vision starts to fail you."
    "...fica mais difícil pensar e sua visão começa a falhar."

# game/inAlley.rpy:4599
translate pt_br blood_stopCat_67bd589d:

    # "The creature in your arms makes a soft sound."
    "A criatura em seus braços emite um som suave."

# game/inAlley.rpy:4601
translate pt_br blood_stopCat_f316015b:

    # "You hold it as tightly and closely to you as your weak arms can manage."
    "Você a segura o mais firme e próximo de você que seus braços fracos aguentam."

# game/inAlley.rpy:4605
translate pt_br blood_stopCat_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:4606
translate pt_br blood_stopCat_aca7b3c0:

    # "This is fine... {w}You’re okay with this..."
    "Está tudo bem... {w}Você aceita isso..."

# game/inAlley.rpy:4607
translate pt_br blood_stopCat_b8bfa8a5:

    # "You don’t know if this will change anything..."
    "Você não sabe se isso vai mudar alguma coisa..."

# game/inAlley.rpy:4608
translate pt_br blood_stopCat_07e8897d:

    # "Surely the cat will get hungry again at some point after you’re gone and..."
    "Certamente, o gato vai sentir fome de novo em algum momento depois que você se for e..."

# game/inAlley.rpy:4609
translate pt_br blood_stopCat_436f749d:

    # "...{i}no longer an {b}option{/b}{/i}..."
    "...{i}não for mais uma {b}opção{/b}{/i}..."

# game/inAlley.rpy:4614
translate pt_br blood_stopCat_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:4615
translate pt_br blood_stopCat_bf0874e3:

    # "But..."
    "Mas..."

# game/inAlley.rpy:4616
translate pt_br blood_stopCat_4145e893:

    # "At least {i}this{/i} time..."
    "Pelo menos {i}dessa{/i} vez..."

# game/inAlley.rpy:4620
translate pt_br blood_stopCat_6cf080cc:

    # "...you were able... {w}to save someone."
    "...você conseguiu... {w}salvar alguém."

# game/inAlley.rpy:4621
translate pt_br blood_stopCat_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:4622
translate pt_br blood_stopCat_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:4623
translate pt_br blood_stopCat_68d32565:

    # "Ending 28: Personal care package"
    "Final 28: Pacote de cuidados pessoais"

# game/inAlley.rpy:4640
translate pt_br blood_letCatFeed_af799a70:

    # who "AAAHH!" with hpunch
    who "AAAHH!" with hpunch

# game/inAlley.rpy:4645
translate pt_br blood_letCatFeed_f1a276a2:

    # who "Someone! Help me! Help!" with vpunch
    who "Alguém! Me ajuda! Socorro!" with vpunch

# game/inAlley.rpy:4653
translate pt_br blood_letCatFeed_7ec51c3a:

    # who "*gurgle* Hel..p... ..."
    who "*balbucia* Soc..or... ..."

# game/inAlley.rpy:4658
translate pt_br blood_letCatFeed_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:4659
translate pt_br blood_letCatFeed_849e135c:

    # "You look away as the creature devours the stranger..."
    "Você desvia o olhar enquanto a criatura devora o estranho..."

# game/inAlley.rpy:4667
translate pt_br blood_letCatFeed_dd2ab70b:

    # "...draining them until they’re nothing but a husk of bone, skin and clothes heaped on the floor."
    "...drenando-o até que não reste nada além de uma carcaça de ossos, pele e roupas empilhadas no chão."

# game/inAlley.rpy:4668
translate pt_br blood_letCatFeed_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:4669
translate pt_br blood_letCatFeed_b7ce0db6:

    # "You feel awful but..."
    "Você se sente horrível, mas..."

# game/inAlley.rpy:4670
translate pt_br blood_letCatFeed_1357f3f7:

    # "What could you do?"
    "O que você você poderia fazer?"

# game/inAlley.rpy:4671
translate pt_br blood_letCatFeed_e77a0648:

    # "The creature is also a living thing..."
    "A criatura também é um ser vivo..."

# game/inAlley.rpy:4672
translate pt_br blood_letCatFeed_44d1ec02:

    # "Shouldn’t it be allowed to eat what it needs to?"
    "Não deveria ser natural que ela comesse o que precisa?"

# game/inAlley.rpy:4673
translate pt_br blood_letCatFeed_37410cf6:

    # "Does it not also have a right to do what it must to survive?"
    "Ela não tem o direito de fazer o que precisa para sobreviver?"

# game/inAlley.rpy:4674
translate pt_br blood_letCatFeed_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:4675
translate pt_br blood_letCatFeed_53cc9d41:

    # "You ignore the voice in the back of your head that questions if there could’ve been another way."
    "Você ignora a voz na sua cabeça que se pergunta se poderia haver outra saída."

# game/inAlley.rpy:4676
translate pt_br blood_letCatFeed_a6d2e181:

    # "It’s not like you tried to see if it could eat anything other blood... {w}{i}Human blood{/i}..."
    "Não é como se você tivesse tentado descobrir se poderia alimentar o gato com algo além de sangue... {w}{i}Sangue humano{/i}..."

# game/inAlley.rpy:4679
translate pt_br blood_letCatFeed_48f6f1e3:

    # "{size=-10}{b}...now {i}did{/i} you?{/b}{/size}"
    "{size=-10}{b}...você {i}tentou{/i}?{/b}{/size}"

# game/inAlley.rpy:4683
translate pt_br blood_letCatFeed_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:4687
translate pt_br blood_letCatFeed_d7365832:

    # "The creature purrs as it rubs its side into your arm."
    "A criatura ronrona enquanto se esfrega em seu braço."

# game/inAlley.rpy:4688
translate pt_br blood_letCatFeed_1282871c:

    # "You realize that after a bit of rest, you’ve already started feeling better."
    "Você percebe que após descansar um pouco, já está começando a se sentir melhor."

# game/inAlley.rpy:4689
translate pt_br blood_letCatFeed_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:4690
translate pt_br blood_letCatFeed_bf0874e3:

    # "But..."
    "Mas..."

# game/inAlley.rpy:4693
translate pt_br blood_letCatFeed_84f45571:

    # "You also think..."
    "Você também pensa..."

# game/inAlley.rpy:4694
translate pt_br blood_letCatFeed_3d2f6324:

    # "...that something inside you..."
    "...que algo dentro de você..."

# game/inAlley.rpy:4695
translate pt_br blood_letCatFeed_90f90ddb:

    # "{size=-8}...feels a little bit broken too.{/size}"
    "{size=-8}...também parece meio quebrado.{/size}"

# game/inAlley.rpy:4698
translate pt_br blood_letCatFeed_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:4699
translate pt_br blood_letCatFeed_e93c9366:

    # "You're just not quite sure what it is yet."
    "Você ainda não tem muita certeza do quê."

# game/inAlley.rpy:4700
translate pt_br blood_letCatFeed_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:4701
translate pt_br blood_letCatFeed_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:4702
translate pt_br blood_letCatFeed_cbc44f0b:

    # "You stand and hold out your arms."
    "Você se levanta e estende os braços."

# game/inAlley.rpy:4703
translate pt_br blood_letCatFeed_8517210f:

    # you "Still hungry?"
    you "Ainda com fome?"

# game/inAlley.rpy:4705
translate pt_br blood_letCatFeed_f8095b37:

    # cat "Pllrrrrrrp!" with hpunch
    cat "Pllrrrrrrp!" with hpunch

# game/inAlley.rpy:4706
translate pt_br blood_letCatFeed_3cdc6c20:

    # "The creature trills happily and hops into your outstretched arms."
    "A criatura dá um miado feliz e pula para seus braços."

# game/inAlley.rpy:4707
translate pt_br blood_letCatFeed_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:4708
translate pt_br blood_letCatFeed_7255bffc:

    # you "...Let's go then, yeah?"
    you "...Vamos lá então, certo?"

# game/inAlley.rpy:4710
translate pt_br blood_letCatFeed_33f9f94c:

    # cat "Plrrrr..."
    cat "Plrrrr..."

# game/inAlley.rpy:4711
translate pt_br blood_letCatFeed_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:4712
translate pt_br blood_letCatFeed_ce06cd2d:

    # "You leave the alley together."
    "Vocês deixam o beco juntos."

# game/inAlley.rpy:4716
translate pt_br blood_letCatFeed_f363c184:

    # "You go out into the world {i}together.{/i}"
    "Vocês saem para o mundo {i}juntos.{/i}"

# game/inAlley.rpy:4717
translate pt_br blood_letCatFeed_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:4718
translate pt_br blood_letCatFeed_53d0da23:

    # "The cat is hungry..."
    "O gato está faminto..."

# game/inAlley.rpy:4719
translate pt_br blood_letCatFeed_4919a924:

    # "...and it will be hungry often from now on."
    "...e ele vai estar com fome frequentemente de agora em diante."

# game/inAlley.rpy:4720
translate pt_br blood_letCatFeed_d58fc52c:

    # "{i}Very{/i} often."
    "{i}Muito{/i} frequentemente."

# game/inAlley.rpy:4722
translate pt_br blood_letCatFeed_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:4728
translate pt_br blood_letCatFeed_701eb808:

    # "Screams of fear and terror follow you both wherever you go..."
    "Gritos de medo e terror seguem vocês dois aonde quer que vão..."

# game/inAlley.rpy:4729
translate pt_br blood_letCatFeed_7a7de0ae:

    # "And without thought or care or concern for any of it..."
    "E sem pensar, se importar ou se preocupar com nada disso..."

# game/inAlley.rpy:4730
translate pt_br blood_letCatFeed_d2542ef5:

    # "You just stand back..."
    "Você apenas se afasta..."

# game/inAlley.rpy:4733
translate pt_br blood_letCatFeed_fb3d9cf0:

    # "{size=-8}...and \ {b}w a t c h{/b}.{/size}"
    "{size=-8}...e \ {b}a s s i s t e{/b}.{/size}"

# game/inAlley.rpy:4734
translate pt_br blood_letCatFeed_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:4735
translate pt_br blood_letCatFeed_a20cefa7_8:

    # "..."
    "..."

# game/inAlley.rpy:4736
translate pt_br blood_letCatFeed_637cffb5:

    # "Ending 29: All You Can Eat Blood-fey"
    "Final 29: Rodízio Sangrento"

# game/inAlley.rpy:4752
translate pt_br playAlley_4367a7aa:

    # cat "Meow! Meowww!"
    cat "Miau! Miauuuu!"

# game/inAlley.rpy:4753
translate pt_br playAlley_eea1ecbb:

    # you "Awww... You just want a little attention, don't you~?"
    you "Ownnn... Você só quer um pouco de atenção, não é~?"

# game/inAlley.rpy:4756
translate pt_br playAlley_67107e6c:

    # cat "Purr..."
    cat "Purr..."

# game/inAlley.rpy:4757
translate pt_br playAlley_4926c274:

    # "The poor thing must be bored sitting in that box all day."
    "O coitadinho deve estar entediado de ficar sentado nessa caixa o dia todo."

# game/inAlley.rpy:4758
translate pt_br playAlley_bab8d9a9:

    # "You're not sure you're much of an interesting companion, but you're willing to do your best."
    "Você não tem certeza se é uma companhia muito interessante, mas está disposto a dar o seu melhor."

# game/inAlley.rpy:4759
translate pt_br playAlley_f719e5a9:

    # "There's got to be something you can entertain the little critter with..."
    "Deve haver algo com o que você possa entreter essa criaturinha..."

# game/inAlley.rpy:4761
translate pt_br playAlley_66c13733:

    # "But what?"
    "Mas o quê?"

# game/inAlley.rpy:4777
translate pt_br play_pockets_5cfb3464:

    # "You dig into your pockets."
    "Você revira os bolsos."

# game/inAlley.rpy:4780
translate pt_br play_pockets_f8c73033:

    # "You find a small piece of string in your left pocket. Not very helpful."
    "Você encontra um pequeno pedaço de linha no bolso esquerdo. Não vai ajudar muito."

# game/inAlley.rpy:4781
translate pt_br play_pockets_ab3079c6:

    # "The string is far too short."
    "A linha é curta demais."

# game/inAlley.rpy:4783
translate pt_br play_pockets_c0209341:

    # "An eager and excited cat leaping for it could easily lead to you getting{w=1.0}{nw}"
    "Um gato ansioso e animado pulando para pegá-la facilmente levaria você a ser{w=1.0}{nw}"

# game/inAlley.rpy:4794
translate pt_br play_pockets_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:4795
translate pt_br play_pockets_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:4796
translate pt_br play_pockets_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:4799
translate pt_br play_pockets_f42805d9:

    # "An eager and excited cat leaping for it could easily lead to you getting bitten and scratched."
    "Um gato ansioso e animado pulando para pegá-la facilmente levaria você a ser mordido e arranhado."

# game/inAlley.rpy:4802
translate pt_br play_pockets_f8cb7b4a:

    # "In your right pocket..."
    "No seu bolso direito..."

# game/inAlley.rpy:4807
translate pt_br play_pockets_d38263f6:

    # "{size=-10}...is a bar of {color=#FF0000}chocolate.{/color}{/size}"
    "{size=-10}...tem uma barra de {color=#FF0000}chocolate.{/color}{/size}"

# game/inAlley.rpy:4809
translate pt_br play_pockets_f3654da7:

    # "{size=-5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sor {/size}{w=0.2}{nw}"
    "{size=-5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}desculpa {w=0.5}descul {/size}{w=0.2}{nw}"

# game/inAlley.rpy:4812
translate pt_br play_pockets_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:4814
translate pt_br play_pockets_31772800:

    # "...is a bar of chocolate."
    "...tem uma barra de chocolate."

# game/inAlley.rpy:4815
translate pt_br play_pockets_d3dcd610:

    # "Not too helpful either right now."
    "Também não é muito útil agora."

# game/inAlley.rpy:4821
translate pt_br play_pockets_632cc2c6:

    # "The only other thing you’ve got on you is your phone."
    "A única outra coisa que você tem com você é seu telefone."

# game/inAlley.rpy:4822
translate pt_br play_pockets_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:4823
translate pt_br play_pockets_6a7c031d:

    # "It's not much of anything the cat can play with but..."
    "Não é exatamente algo com que o gato possa brincar, mas..."

# game/inAlley.rpy:4826
translate pt_br play_pockets_ff3c3ccc:

    # "There {i}is{/i} something {i}you{/i} can do..."
    "{i}Tem{/i} uma coisa que {i}você{/i} pode fazer..."

# game/inAlley.rpy:4838
translate pt_br play_pockets_4e248d1e:

    # "{size=+15}{b}{i}Photo montage~!!!{/i}{/b}{/size}" with hpunch
    "{size=+15}{b}{i}Tirar fotos~!!!{/i}{/b}{/size}" with hpunch

# game/inAlley.rpy:4840
translate pt_br play_pockets_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:4841
translate pt_br play_pockets_297839ea:

    # you "Well, that was fun, right?"
    you "Isso foi divertido, né?"

# game/inAlley.rpy:4843
translate pt_br play_pockets_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:4844
translate pt_br play_pockets_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:4845
translate pt_br play_pockets_fa1cff19:

    # "Well {i}you{/i} enjoyed yourself..."
    "Bom, {i}você{/i} se divertiu..."

# game/inAlley.rpy:4846
translate pt_br play_pockets_aa21a61c:

    # "With nothing else to do and no intention of taking the cat home..."
    "Sem mais nada para fazer e sem intenção de levar o gato para casa..."

# game/inAlley.rpy:4847
translate pt_br play_pockets_3d3eeb7e:

    # "...you decide it's probably best to just leave."
    "...você decide que provavelmente é melhor só ir embora."

# game/inAlley.rpy:4848
translate pt_br play_pockets_be1c1ed6:

    # "You don't want the cat to get too attached after all."
    "Você não quer que o gato se apegue demais, afinal."

# game/inAlley.rpy:4849
translate pt_br play_pockets_f0eb3116:

    # "At least you'll have some memories to take with you."
    "Pelo menos você terá algumas lembranças para levar com você."

# game/inAlley.rpy:4850
translate pt_br play_pockets_dfcd2239:

    # you "Okay, um... See you around, I guess. Good luck?"
    you "Beleza, ééé... A gente se vê, eu acho. Boa sorte?"

# game/inAlley.rpy:4851
translate pt_br play_pockets_7f0ac95c_1:

    # cat "..."
    cat "..."

# game/inAlley.rpy:4852
translate pt_br play_pockets_fa41c4c2:

    # you "...Okay."
    you "...Tá."

# game/inAlley.rpy:4855
translate pt_br play_pockets_18133987:

    # "You turn and walk away, but as you leave the alley-{w=1.2}{nw}"
    "Você se vira e se afasta, mas ao deixar o beco-{w=1.2}{nw}"

# game/inAlley.rpy:4857
translate pt_br play_pockets_1919fb1f:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4858
translate pt_br play_pockets_5d06f92b:

    # you "Hm?"
    you "Hm?"

# game/inAlley.rpy:4859
translate pt_br play_pockets_bc2cce8e:

    # "Your phone just got a message."
    "Chega uma mensagem no seu celular."

# game/inAlley.rpy:4860
translate pt_br play_pockets_ab96140d:

    # "You open it up and..."
    "Você abre e..."

# game/inAlley.rpy:4861
translate pt_br play_pockets_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:4862
translate pt_br play_pockets_40d9ca73:

    # "..?"
    "..?"

# game/inAlley.rpy:4863
translate pt_br play_pockets_74be92cd:

    # you "What..?"
    you "O quê..?"

# game/inAlley.rpy:4870
translate pt_br play_pockets_4b6994e1:

    # phoneText "{b}--aren't i cutte??--{/b}"
    phoneText "{b}--não sou foffo??--{/b}"

# game/inAlley.rpy:4871
translate pt_br play_pockets_f8a1ca53:

    # "It's a picture of a familiar looking cat..."
    "É uma foto de um gato familiar..."

# game/inAlley.rpy:4872
translate pt_br play_pockets_c90675bd:

    # you "Huh?"
    you "Hã?"

# game/inAlley.rpy:4873
translate pt_br play_pockets_c4799a25:

    # "The cat {i}does{/i} look cute..."
    "O gato {i}realmente{/i} parece fofo..."

# game/inAlley.rpy:4874
translate pt_br play_pockets_308c65d2:

    # "And happier in the picture..."
    "E mais feliz na foto..."

# game/inAlley.rpy:4875
translate pt_br play_pockets_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:4876
translate pt_br play_pockets_122874da:

    # "...but it's {b}not{/b} a picture you recognize."
    "...mas {b}não{/b} é uma foto que você reconhece."

# game/inAlley.rpy:4877
translate pt_br play_pockets_22b5aa5b:

    # you "What the heck..? D-Did I..?"
    you "Mas que porra..? E-Eu tirei..?"

# game/inAlley.rpy:4878
translate pt_br play_pockets_5f369989:

    # "{size=-10}you didn't take this picture.{/size}"
    "{size=-10}você não tirou essa foto.{/size}"

# game/inAlley.rpy:4879
translate pt_br play_pockets_63fc373e:

    # "You peek over your shoulder at the cat..."
    "Você olha para o gato por cima do ombro..."

# game/inAlley.rpy:4882
translate pt_br play_pockets_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:4883
translate pt_br play_pockets_6d6c3c7a:

    # "...but the cat is simply looking at you."
    "...mas o gato está apenas olhando para você."

# game/inAlley.rpy:4890
translate pt_br play_pockets_9cad6637:

    # cat "Meowww..."
    cat "Miauuu..."

# game/inAlley.rpy:4892
translate pt_br play_pockets_f0c613db:

    # "It mewls sadly, as if pleading you to come back."
    "Ele mia triste, como se estivesse implorando para você voltar."

# game/inAlley.rpy:4896
translate pt_br play_pockets_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:4897
translate pt_br play_pockets_10090c2b:

    # you "Well... I guess I could stay a little longer..."
    you "Bom... Acho que posso ficar mais um pouco..."

# game/inAlley.rpy:4903
translate pt_br play_pockets_c44e377e:

    # cat "Meoww!" with hpunch
    cat "Miauu!" with hpunch

# game/inAlley.rpy:4905
translate pt_br play_pockets_a43f8b59:

    # you "But now what to do.."
    you "Mas o que fazer agora.."

# game/inAlley.rpy:4908
translate pt_br play_pockets_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/inAlley.rpy:4914
translate pt_br phoneHome_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:4915
translate pt_br phoneHome_b31d124d:

    # "You ignore the cat and briskly walk out of the alley without another look."
    "Você ignora o gato e sai do beco com pressa, sem olhar para trás."

# game/inAlley.rpy:4921
translate pt_br phoneHome_b0f8881c:

    # you "Phew..."
    you "Ufa..."

# game/inAlley.rpy:4922
translate pt_br phoneHome_474b3625:

    # you "That was weird..."
    you "Isso foi estranho..."

# game/inAlley.rpy:4923
translate pt_br phoneHome_48a233a3:

    # "You're a good distance away when-"
    "Você já está bem longe, quando-"

# game/inAlley.rpy:4925
translate pt_br phoneHome_1919fb1f:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4926
translate pt_br phoneHome_8a8661d4:

    # you "..! Not again..."
    you "..! De novo não..."

# game/inAlley.rpy:4927
translate pt_br phoneHome_d472fea1:

    # "You reluctantly look at the new message and..."
    "Você olha relutante para a nova mensagem e..."

# game/inAlley.rpy:4934
translate pt_br phoneHome_f6b2a9a9:

    # phoneText "{b}--dont ignore meeee ;_;--{/b}"
    phoneText "{b}--nn me ignoraaaa ;_;--{/b}"

# game/inAlley.rpy:4935
translate pt_br phoneHome_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:4936
translate pt_br phoneHome_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:4937
translate pt_br phoneHome_e1c95b67:

    # "Creeped out... you decide to just go home."
    "Assustado... você decide simplesmente ir para casa."

# game/inAlley.rpy:4941
translate pt_br phoneHome_1919fb1f_1:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4945
translate pt_br phoneHome_934d45d4:

    # phoneText "{b}--i know youre seeing these--{/b}"
    phoneText "{b}--eu sei q vc ta vendo isso--{/b}"

# game/inAlley.rpy:4947
translate pt_br phoneHome_1919fb1f_2:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4951
translate pt_br phoneHome_f089ea18:

    # phoneText "{b}--come back--{/b}"
    phoneText "{b}--volta--{/b}"

# game/inAlley.rpy:4953
translate pt_br phoneHome_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:4955
translate pt_br phoneHome_1919fb1f_3:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4962
translate pt_br phoneHome_f089ea18_1:

    # phoneText "{b}--come back--{/b}"
    phoneText "{b}--volta--{/b}"

# game/inAlley.rpy:4966
translate pt_br phoneHome_1919fb1f_4:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4973
translate pt_br phoneHome_f089ea18_2:

    # phoneText "{b}--come back--{/b}"
    phoneText "{b}--volta--{/b}"

# game/inAlley.rpy:4977
translate pt_br phoneHome_1919fb1f_5:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4984
translate pt_br phoneHome_f089ea18_3:

    # phoneText "{b}--come back--{/b}"
    phoneText "{b}--volta--{/b}"

# game/inAlley.rpy:4988
translate pt_br phoneHome_1919fb1f_6:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4992
translate pt_br phoneHome_f089ea18_4:

    # phoneText "{b}--come back--{/b}"
    phoneText "{b}--volta--{/b}"

# game/inAlley.rpy:4994
translate pt_br phoneHome_1919fb1f_7:

    # "*BZZT*!" with hpunch
    "*BZZT*!" with hpunch

# game/inAlley.rpy:4996
translate pt_br phoneHome_d4d2616a:

    # "*BZZT*! *BZZT*!" with hpunch
    "*BZZT*! *BZZT*!" with hpunch

# game/inAlley.rpy:5000
translate pt_br phoneHome_65ea3a0a:

    # phoneText "{b}--come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back--{/b}"
    phoneText "{b}--volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta volta --{/b}"

# game/inAlley.rpy:5001
translate pt_br phoneHome_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:5015
translate pt_br phoneHome_99f007c0:

    # "{size=-8}*bzzt*...{/size}"
    "{size=-8}*bzzt*...{/size}"

# game/inAlley.rpy:5020
translate pt_br phoneHome_4b8a63af:

    # phoneText "{b}--can see you--{/b}"
    phoneText "{b}--posso ver vc--{/b}"

# game/inAlley.rpy:5022
translate pt_br phoneHome_99f007c0_1:

    # "{size=-8}*bzzt*...{/size}"
    "{size=-8}*bzzt*...{/size}"

# game/inAlley.rpy:5026
translate pt_br phoneHome_42283d6e:

    # phoneText "{b}--can ALWAYS see you--{/b}"
    phoneText "{b}--posso SEMPRE ver vc--{/b}"

# game/inAlley.rpy:5030
translate pt_br phoneHome_36feac05:

    # phoneText "{b}--YOU CANT HIDE--{/b}"
    phoneText "{b}--VC N PODE SE ESCONDER--{/b}"

# game/inAlley.rpy:5034
translate pt_br phoneHome_4f8f387e:

    # phoneText "{b}--i'll always find uuuuu OwO--{/b}"
    phoneText "{b}--eu sempre vou achar vccccc OwO--{/b}"

# game/inAlley.rpy:5037
translate pt_br phoneHome_dae0ec55_3:

    # you "..."
    you "..."

# game/inAlley.rpy:5038
translate pt_br phoneHome_6ba80fd4:

    # "Your eyes dart around nervously... {i}certain{/i} that you're being followed."
    "Seus olhos se movem ansiosamente... {i}certos{/i} de que você está sendo seguido."

# game/inAlley.rpy:5039
translate pt_br phoneHome_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:5040
translate pt_br phoneHome_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:5041
translate pt_br phoneHome_f89b839f:

    # "{size=-8}But there's nothing there.{/size}"
    "{size=-8}Mas não há nada ali.{/size}"

# game/inAlley.rpy:5045
translate pt_br phoneHome_dae0ec55_4:

    # you "..."
    you "..."

# game/inAlley.rpy:5049
translate pt_br phoneHome_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:5050
translate pt_br phoneHome_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:5053
translate pt_br phoneHome_e6e0bd68:

    # "You're finally home, but you feel too shaken for any relief to calm you down."
    "Você finalmente chega em casa, mas se sente abalado demais para que o alívio te acalme."

# game/inAlley.rpy:5056
translate pt_br phoneHome_86f767b7:

    # "You rush to the bathroom and slam the door behind you."
    "Você corre para o banheiro, entra e bate a porta"

# game/inAlley.rpy:5061
translate pt_br phoneHome_5489dbe4:

    # you "Everything's okay..."
    you "Tá tudo bem..."

# game/inAlley.rpy:5064
translate pt_br phoneHome_1d1ef86b:

    # you "This isn't real..."
    you "Isso não é real..."

# game/inAlley.rpy:5067
translate pt_br phoneHome_cb8665e3:

    # "It's just like a bad dream..."
    "É só um sonho ruim..."

# game/inAlley.rpy:5068
translate pt_br phoneHome_88b66f2a:

    # "Everything's... okay..."
    "Tá tudo... bem..."

# game/inAlley.rpy:5069
translate pt_br phoneHome_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:5070
translate pt_br phoneHome_fa440177:

    # "You fumble in the dark to turn on the sink and splash your face with some cold water..."
    "Você tateia no escuro para ligar a torneira da pia e joga água fria no rosto..."

# game/inAlley.rpy:5071
translate pt_br phoneHome_274213b7:

    # "...hoping it will calm your mind... {w}and stop the hallucinations."
    "...na esperança de acalmar sua mente... {w}e parar com as alucinações."

# game/inAlley.rpy:5072
translate pt_br phoneHome_ba425576:

    # "{size=-5}Because that's all they are, right?{/size}"
    "{size=-5}...porque não passa disso, né?{/size}"

# game/inAlley.rpy:5073
translate pt_br phoneHome_03f60dc4:

    # "{size=-8}...Hallucinations?{/size}"
    "{size=-8}...Alucinações?{/size}"

# game/inAlley.rpy:5074
translate pt_br phoneHome_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:5075
translate pt_br phoneHome_366ae109:

    # "You’re really regretting leaving home today."
    "Você realmente está se arrependendo de ter saído de casa hoje."

# game/inAlley.rpy:5076
translate pt_br phoneHome_207ad5fd:

    # "You must have been overworking yourself more than you realized..."
    "Você deve ter se sobrecarregado de trabalho mais do que imaginava..."

# game/inAlley.rpy:5077
translate pt_br phoneHome_d200e00e:

    # "Yeah... That must be-"
    "É... Deve ter sid-"

# game/inAlley.rpy:5080
translate pt_br phoneHome_05b04601:

    # "{b}*BZZT*!{/b}" with hpunch
    "{b}*BZZT*!{/b}" with hpunch

# game/inAlley.rpy:5081
translate pt_br phoneHome_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:5095
translate pt_br phoneHome_d4eb578f:

    # "You jump as your phone alerts you to yet another message received."
    "Você salta ao ouvir seu celular te notificando mais uma mensagem recebida."

# game/inAlley.rpy:5096
translate pt_br phoneHome_dae0ec55_5:

    # you "..."
    you "..."

# game/inAlley.rpy:5107
translate pt_br checkPhone_8fa7a50f:

    # "With shaking hands, you look at your phone..."
    "Com as mãos tremendo, você olha para o seu celular..."

# game/inAlley.rpy:5110
translate pt_br checkPhone_2bd17ff9:

    # phoneText "{b}--hI FRienD--{/b}"
    phoneText "{b}--oI AMigO--{/b}"

# game/inAlley.rpy:5114
translate pt_br checkPhone_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:5123
translate pt_br checkPhone_af7e27d2:

    # you "Wh... What...?"
    you "O qu... O quê...?"

# game/inAlley.rpy:5128
translate pt_br checkPhone_db4a3473:

    # "Startled, you whirl around and instinctively jump back..."
    "Você se vira, assustado, e instintivamente salta para trás..."

# game/inAlley.rpy:5129
translate pt_br checkPhone_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:5130
translate pt_br checkPhone_0f5de544:

    # "You..."
    "Você..."

# game/inAlley.rpy:5131
translate pt_br checkPhone_8b35204f:

    # "You {i}slip...{/i}"
    "Você {i}escorrega...{/i}"

# game/inAlley.rpy:5135
translate pt_br checkPhone_22c24f7e:

    # "...smashing the back of your head into the bathroom mirror."
    "...batendo a parte de trás da cabeça no espelho do banheiro."

# game/inAlley.rpy:5136
translate pt_br checkPhone_2168405d:

    # "You don't register the pain just yet, your eyes shifting wildly around the room."
    "Você não sente a dor na hora, seus olhos se movem freneticamente pelo cômodo."

# game/inAlley.rpy:5139
translate pt_br checkPhone_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:5140
translate pt_br checkPhone_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:5141
translate pt_br checkPhone_7af4a8ac:

    # "There’s..."
    "Não..."

# game/inAlley.rpy:5142
translate pt_br checkPhone_a9f7a5de:

    # "There’s nothing there."
    "Não tem nada aqui."

# game/inAlley.rpy:5143
translate pt_br checkPhone_bd69546a:

    # "Nothing at all..."
    "Absolutamente nada..."

# game/inAlley.rpy:5147
translate pt_br checkPhone_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:5148
translate pt_br checkPhone_f887a3f9:

    # "...You feel dizzy."
    "...Você se sente zonzo."

# game/inAlley.rpy:5149
translate pt_br checkPhone_74fa22f3:

    # "You dazedly feel the back of your head and examine your hand."
    "Atordoado, você sente a parte de trás da sua cabeça e examina sua mão."

# game/inAlley.rpy:5150
translate pt_br checkPhone_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:5151
translate pt_br checkPhone_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:5152
translate pt_br checkPhone_9eca284d:

    # "You can't really see anything..."
    "Você não consegue ver muita coisa..."

# game/inAlley.rpy:5153
translate pt_br checkPhone_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:5154
translate pt_br checkPhone_e5477b1e:

    # "But it feels warm..."
    "Mas parece morno…"

# game/inAlley.rpy:5155
translate pt_br checkPhone_fb2e25e6:

    # "...and {i}wet.{/i}"
    "...e {i}úmido.{/i}"

# game/inAlley.rpy:5158
translate pt_br checkPhone_8e7eed80:

    # "The smell of copper fills the air..."
    "O cheiro de cobre preenche o ar..."

# game/inAlley.rpy:5159
translate pt_br checkPhone_c953e0ca:

    # "The dizziness overwhelms you and you collapse on the bathroom tiles."
    "Sentindo muita tontura, você cai sobre o piso do banheiro."

# game/inAlley.rpy:5162
translate pt_br checkPhone_bf69ea4a:

    # you "Hel..p..."
    you "Soc..orro..."

# game/inAlley.rpy:5163
translate pt_br checkPhone_72ca9f5f:

    # "You reach for your phone to call an ambulance..."
    "Você alcança o celular para chamar uma ambulância..."

# game/inAlley.rpy:5164
translate pt_br checkPhone_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:5165
translate pt_br checkPhone_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:5166
translate pt_br checkPhone_842f2398:

    # "...The batteries are dead."
    "...A bateria acabou."

# game/inAlley.rpy:5167
translate pt_br checkPhone_8dabefc6_3:

    # ".."
    ".."

# game/inAlley.rpy:5168
translate pt_br checkPhone_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:5169
translate pt_br checkPhone_a5333c46:

    # "Ending 30: Photo bomber"
    "Final 30: Fotogênico"

# game/inAlley.rpy:5182
translate pt_br ignorePhone_05b04601:

    # "{b}*BZZT*!{/b}" with hpunch
    "{b}*BZZT*!{/b}" with hpunch

# game/inAlley.rpy:5185
translate pt_br ignorePhone_45e226d6:

    # "{b}*BZZT*! *BZZT*! *BZZT*! {/b}" with hpunch
    "{b}*BZZT*! *BZZT*! *BZZT*! {/b}" with hpunch

# game/inAlley.rpy:5187
translate pt_br ignorePhone_3e5256b6:

    # "{size=+20}{b}*BZZT*!{/b}{/size}" with hpunch
    "{size=+20}{b}*BZZT*!{/b}{/size}" with hpunch

# game/inAlley.rpy:5188
translate pt_br ignorePhone_43511216:

    # "The phone vibrates insistently over and over..."
    "Seu celular vibra insistentemente, de novo e de novo..."

# game/inAlley.rpy:5189
translate pt_br ignorePhone_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:5191
translate pt_br ignorePhone_6741af6f:

    # "...but you just can’t look."
    "...mas você simplesmente não consegue olhar."

# game/inAlley.rpy:5194
translate pt_br ignorePhone_97d37cc5:

    # "You keep your eyes squeezed shut. Your fingers tightly grip the sink."
    "Você mantém os olhos bem fechados. Seus dedos se agarram firmemente à pia."

# game/inAlley.rpy:5195
translate pt_br ignorePhone_9e64b774:

    # "In your mind, you beg whoever... or {i}whatever{/i} is doing this to just stop already..."
    "Na sua mente, você implora para quem... ou {i}o que{/i} quer que esteja fazendo isso parar logo..."

# game/inAlley.rpy:5196
translate pt_br ignorePhone_702b5575:

    # "Please... Please..."
    "Por favor... Por favor..."

# game/inAlley.rpy:5197
translate pt_br ignorePhone_6a348634:

    # you "Please... Just put me out of my misery..."
    you "Por favor... Me tira logo desse sofrimento...."

# game/inAlley.rpy:5198
translate pt_br ignorePhone_dcdacf88:

    # "You mutter this quietly. You don’t... {i}really{/i} mean it."
    "Você murmura isso baixinho. Você... não quer dizer isso {i}de verdade{/i}."

# game/inAlley.rpy:5199
translate pt_br ignorePhone_6ce1cb34:

    # "You {i}don't.{/i}"
    "Você {i}não quer.{/i}"

# game/inAlley.rpy:5200
translate pt_br ignorePhone_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:5201
translate pt_br ignorePhone_7bc58a93:

    # "But as the words take shape in the darkest corners of your mind..."
    "Mas, enquanto que as palavras tomam forma nos cantos mais sombrios da sua mente..."

# game/inAlley.rpy:5203
translate pt_br ignorePhone_58827019:

    # "...the phone {i}immediately{/i} stops vibrating."
    "...o celular {i}imediatamente{/i} para de vibrar."

# game/inAlley.rpy:5204
translate pt_br ignorePhone_e2a45fdf:

    # "You’d think that this would give you relief..."
    "Você pensaria que isso lhe traria um alívio..."

# game/inAlley.rpy:5205
translate pt_br ignorePhone_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:5206
translate pt_br ignorePhone_ae9f462d:

    # "...but you only feel dread sinking heavily into your stomach."
    "...mas você só sente um horror se instalando pesado no seu estômago."

# game/inAlley.rpy:5207
translate pt_br ignorePhone_698fca08:

    # "You can feel eyes on you..."
    "Você pode sentir olhos em você..."

# game/inAlley.rpy:5209
translate pt_br ignorePhone_19e3c7ae:

    # "You can feel puffs of air on the back of your neck... {w}damp and deep and {b}slow{/b}..."
    "Você pode sentir sopros de ar na sua nuca... {w}úmidos, profundos e {b}lentos{/b}..."

# game/inAlley.rpy:5210
translate pt_br ignorePhone_0f7f3730:

    # "You take a deep breath and open your eyes..."
    "Você respira fundo e abre os olhos..."

# game/inAlley.rpy:5211
translate pt_br ignorePhone_d6fac14d:

    # "You look..."
    "Você olha..."

# game/inAlley.rpy:5212
translate pt_br ignorePhone_0f5c8741:

    # "...at the mirror."
    "...para o espelho."

# game/inAlley.rpy:5213
translate pt_br ignorePhone_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:5214
translate pt_br ignorePhone_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:5217
translate pt_br ignorePhone_97d7e1ff:

    # "...Nothing."
    "...Nada."

# game/inAlley.rpy:5218
translate pt_br ignorePhone_7688b87e:

    # "You peek around the room."
    "Você espia pelo banheiro."

# game/inAlley.rpy:5219
translate pt_br ignorePhone_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:5220
translate pt_br ignorePhone_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:5221
translate pt_br ignorePhone_d39ba71d:

    # "...Still nothing. {w}Nothing at all..."
    "...Ainda nada. {w}Nada mesmo..."

# game/inAlley.rpy:5222
translate pt_br ignorePhone_fa14a2fd:

    # "But you know. You {i}know{/i} that something is there..."
    "Mas você sabe. Você {i}sabe{/i} que algo está ali..."

# game/inAlley.rpy:5223
translate pt_br ignorePhone_3a16261e:

    # "Waiting to be acknowledged..."
    "Esperando ser descoberto..."

# game/inAlley.rpy:5224
translate pt_br ignorePhone_9080b186:

    # "For you to accept the fact of its existence."
    "Que você aceite o fato de sua existência."

# game/inAlley.rpy:5225
translate pt_br ignorePhone_195993dc:

    # "Only {i}then{/i} will it deign to give you peace.."
    "Somente {i}então{/i} ele se dignará a te dar paz.."

# game/inAlley.rpy:5226
translate pt_br ignorePhone_0d88251d:

    # "...to free you from a life of constantly looking over your shoulder..."
    "...te libertar de uma vida de insegurança constante..."

# game/inAlley.rpy:5227
translate pt_br ignorePhone_98aa90d7:

    # "...of fearing your own image... {w}your own reflection."
    "...de temer sua própria imagem... {w}seu próprio reflexo."

# game/inAlley.rpy:5228
translate pt_br ignorePhone_0a31632a:

    # "You can feel its patience, limitless and old."
    "Você pode sentir sua paciência, ilimitada e antiga."

# game/inAlley.rpy:5229
translate pt_br ignorePhone_7d6512f3:

    # "You can’t win against it in a war of attrition."
    "Você não pode vencê-lo no cansaço."

# game/inAlley.rpy:5230
translate pt_br ignorePhone_f8fa2106:

    # "Your lifespan will long expire before it tires of you."
    "Sua vida se esgotará muito antes que ele se enjoe de você."

# game/inAlley.rpy:5231
translate pt_br ignorePhone_42b896f8:

    # "So..."
    "Então..."

# game/inAlley.rpy:5232
translate pt_br ignorePhone_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:5235
translate pt_br ignorePhone_dec216e1:

    # "You close your eyes..."
    "Você fecha os olhos..."

# game/inAlley.rpy:5236
translate pt_br ignorePhone_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:5237
translate pt_br ignorePhone_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:5238
translate pt_br ignorePhone_3275149d:

    # "...and accept it."
    "...e aceita."

# game/inAlley.rpy:5247
translate pt_br ignorePhone_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:5248
translate pt_br ignorePhone_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:5252
translate pt_br ignorePhone_902a5fbf:

    # "As your head is severed from your neck, you’re filled with peace... {w}grateful that at the very least..."
    "Enquanto sua cabeça é separada do seu pescoço, você se sente em paz... {w}grato por, pelo menos..."

# game/inAlley.rpy:5253
translate pt_br ignorePhone_e515cfae:

    # "...you never had to see {color=#FF0000}it.{/color}"
    "...nunca ter que ver {color=#FF0000}isso.{/color}"

# game/inAlley.rpy:5254
translate pt_br ignorePhone_faca898b:

    # "Whatever {color=#FF0000}it{/color} was.."
    "O que quer que {color=#FF0000}isso{/color} fosse.."

# game/inAlley.rpy:5255
translate pt_br ignorePhone_8dabefc6_3:

    # ".."
    ".."

# game/inAlley.rpy:5256
translate pt_br ignorePhone_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:5257
translate pt_br ignorePhone_3d7f79a0:

    # "Ending 31: Headshot"
    "Final 31: Perdendo a cabeça"

# game/inAlley.rpy:5271
translate pt_br play_lookAround_fe95c45e:

    # "You search around..."
    "Você olha ao redor..."

# game/inAlley.rpy:5272
translate pt_br play_lookAround_26d8fe49:

    # "...but there's really nothing in the alley that looks interesting enough for the cat to play with."
    "...mas não há nada no beco que pareça interessante o suficiente para o gato brincar."

# game/inAlley.rpy:5273
translate pt_br play_lookAround_d230d6d0:

    # "So maybe..."
    "Então..."

# game/inAlley.rpy:5276
translate pt_br play_lookAround_8895ca7b:

    # you "How about... a game?"
    you "Que tal... um jogo?"

# game/inAlley.rpy:5278
translate pt_br play_lookAround_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/inAlley.rpy:5279
translate pt_br play_lookAround_09d74134:

    # "You decide on a game you've known since childhood..."
    "Você escolhe uma brincadeira que conhece desde a infância..."

# game/inAlley.rpy:5280
translate pt_br play_lookAround_6a840dc3:

    # "Red Light, Green Light... {w}a classic."
    "Batata Quente... {w}um clássico."

# game/inAlley.rpy:5281
translate pt_br play_lookAround_fb2631f7:

    # "Teaching a cat how to play might be a bit of a challenge..."
    "Ensinar um gato a jogar pode ser um tanto desafiador..."

# game/inAlley.rpy:5282
translate pt_br play_lookAround_fcf103dd:

    # "...but you get the feeling the feline’s natural hunting instincts will help it along."
    "...mas você tem a sensação de que os instintos naturais de caça do felino vão ajudar."

# game/inAlley.rpy:5285
translate pt_br play_lookAround_ef9d4eaf:

    # "You walk to the entrance of the alley, the cat meowing at you."
    "Você caminha até a entrada do beco, com o gato miando para você."

# game/inAlley.rpy:5287
translate pt_br play_lookAround_4367a7aa:

    # cat "Meow! Meowww!"
    cat "Miau! Miauuu!"

# game/inAlley.rpy:5288
translate pt_br play_lookAround_cfb6ac60:

    # you "Don't worry, I'm not going anywhere~"
    you "Não se preocupe, eu não vou a lugar nenhum~"

# game/inAlley.rpy:5289
translate pt_br play_lookAround_3d7739d9:

    # "You exaggerate your movements, covering your eyes with your hands... and turn around."
    "Você exagera nos movimentos, cobrindo os olhos com as mãos... e se vira."

# game/inAlley.rpy:5292
translate pt_br play_lookAround_79b5cf51:

    # you "One... {w}Two... {w}Three... {w}.{w}.{w}."
    you "Um... {w}Dois... {w}Três... {w}.{w}.{w}."

# game/inAlley.rpy:5293
translate pt_br play_lookAround_1b42e081:

    # you "...Red light!" with hpunch
    you "...Queimou!" with hpunch

# game/inAlley.rpy:5296
translate pt_br play_lookAround_93fd1982:

    # "You spin around."
    "Você se vira rapidamente."

# game/inAlley.rpy:5306
translate pt_br play_lookAround_b4e52671:

    # "The cat hasn’t left the box, tilting its head at you in curious confusion."
    "O gato não saiu da caixa, inclinando a cabeça para você, confuso e curioso."

# game/inAlley.rpy:5313
translate pt_br play_lookAround_7c7b7c3d:

    # "Maybe the concept is too advanced for a cat after all..."
    "Talvez o conceito seja muito avançado para um gato, afinal..."

# game/inAlley.rpy:5314
translate pt_br play_lookAround_e64afe7e:

    # "That's okay. You'll think of something else to do."
    "Tudo bem. Você vai pensar em outra coisa para fazer."

# game/inAlley.rpy:5324
translate pt_br playRedLight_ddbe32ac:

    # "You try again."
    "Você tenta de novo."

# game/inAlley.rpy:5325
translate pt_br playRedLight_3c3c3328:

    # "This time you go a bit slower."
    "Dessa vez, você vai um pouco mais devagar."

# game/inAlley.rpy:5328
translate pt_br playRedLight_e64b19d2:

    # you "One..."
    you "Um..."

# game/inAlley.rpy:5329
translate pt_br playRedLight_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:5330
translate pt_br playRedLight_382ca646:

    # you "Twooo~"
    you "Dooois~"

# game/inAlley.rpy:5331
translate pt_br playRedLight_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:5332
translate pt_br playRedLight_68231842:

    # you "Threeee~"
    you "Trêeeees~"

# game/inAlley.rpy:5333
translate pt_br playRedLight_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:5334
translate pt_br playRedLight_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:5335
translate pt_br playRedLight_652686fc:

    # you "RED LIGHT~!" with hpunch
    you "QUEIMOU~!" with hpunch

# game/inAlley.rpy:5341
translate pt_br playRedLight_5f5eef33:

    # "When you turn around this time..."
    "Dessa vez, quando você se vira..."

# game/inAlley.rpy:5345
translate pt_br playRedLight_6319ec5c:

    # "...the cat is out of the box."
    "...o gato está fora da caixa."

# game/inAlley.rpy:5347
translate pt_br playRedLight_ab6d5659:

    # cat "!!!" with hpunch
    cat "!!!" with hpunch

# game/inAlley.rpy:5348
translate pt_br playRedLight_20c4e0a4:

    # "The cat freezes under your stare, as if it thinks you can’t see it if it doesn’t move."
    "O gato congela sob o seu olhar, como se pensasse que você não pode vê-lo se ele não se mexer."

# game/inAlley.rpy:5349
translate pt_br playRedLight_13bef835:

    # you "{i}So cute~{/i}"
    you "{i}Tão fofo~{/i}"

# game/inAlley.rpy:5352
translate pt_br playRedLight_0743b011:

    # "Satisfied that the cat is getting the hang of the game, you turn again... speeding back up."
    "Satisfeito que o gato está pegando o jeito da brincadeira, você se vira de novo... acelerando o ritmo."

# game/inAlley.rpy:5355
translate pt_br playRedLight_488ec393:

    # you "One... Two... Three..."
    you "Um... Dois... Três..."

# game/inAlley.rpy:5356
translate pt_br playRedLight_30030125:

    # you "Red light!" with hpunch
    you "Queimou!" with hpunch

# game/inAlley.rpy:5362
translate pt_br playRedLight_65781c81:

    # "You turn around..."
    "Você se vira..."

# game/inAlley.rpy:5366
translate pt_br playRedLight_d6257afb:

    # "The cat is a few steps away from the box now, peeking out from behind a dumpster..."
    "O gato está a alguns passos da caixa agora, espiando por trás de uma lixeira..."

# game/inAlley.rpy:5367
translate pt_br playRedLight_74164412:

    # "...its eyes trained rather... {w}{i}intensely{/i} on you."
    "...com os olhos fixos... {w}{i}intensamente{/i} em você."

# game/inAlley.rpy:5368
translate pt_br playRedLight_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:5369
translate pt_br playRedLight_c450b224:

    # "Well... {w}at least it’s having fun?"
    "Bom... {w}pelo menos está se divertindo?"

# game/inAlley.rpy:5370
translate pt_br playRedLight_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:5373
translate pt_br playRedLight_5a29d90a:

    # "You turn again..."
    "Você se vira de novo..."

# game/inAlley.rpy:5375
translate pt_br playRedLight_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:5376
translate pt_br playRedLight_e3ca830a:

    # "...and feel a sudden chill run down your spine."
    "...e sente um arrepio repentino percorrer sua espinha de cima a baixo."

# game/inAlley.rpy:5377
translate pt_br playRedLight_90b68c87:

    # you "..?"
    you "..?"

# game/inAlley.rpy:5380
translate pt_br playRedLight_0c09560a:

    # "You feel silly... {w}but you can't help counting just a {i}little{/i} faster this time..."
    "Você se sente meio ridículo... {w}mas acaba contando um {i}pouco{/i} mais rápido desta vez..."

# game/inAlley.rpy:5381
translate pt_br playRedLight_7f66eaea:

    # you "One, two, three, red light!" with hpunch
    you "Um, dois, três, queimou!" with hpunch

# game/inAlley.rpy:5387
translate pt_br playRedLight_79eb9703:

    # "...whirling around after saying \"red light!\""
    "...se virando bem rápido após dizer \"queimou!\""

# game/inAlley.rpy:5388
translate pt_br playRedLight_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:5389
translate pt_br playRedLight_3f788947:

    # "You... look at the cat."
    "Você... olha para o gato."

# game/inAlley.rpy:5393
translate pt_br playRedLight_18019ca8:

    # "It’s halfway down the alley closer to you now, but..."
    "Está na metade do caminho do beco, mais perto de você agora, mas..."

# game/inAlley.rpy:5394
translate pt_br playRedLight_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:5395
translate pt_br playRedLight_5812c142:

    # "...it’s as if the perspective of what you’re seeing is {b}off{/b} somehow."
    "...é como se a perspectiva do que você está vendo estivesse {b}errada{/b} de alguma forma."

# game/inAlley.rpy:5396
translate pt_br playRedLight_325acab7:

    # "Doesn’t the cat look a little... {w}{i}bigger{/i}..?"
    "O gato não parece um pouco... {w}{i}maior{/i}..?"

# game/inAlley.rpy:5398
translate pt_br playRedLight_4390a056:

    # "Its pupils are thin slits now."
    "Suas pupilas são como fendas agora."

# game/inAlley.rpy:5399
translate pt_br playRedLight_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:5400
translate pt_br playRedLight_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:5401
translate pt_br playRedLight_973413d4:

    # "Something..."
    "Algo..."

# game/inAlley.rpy:5402
translate pt_br playRedLight_2aad8b65:

    # "{size=-5}Something’s not right.{/size}"
    "{size=-5}Algo não está certo.{/size}"

# game/inAlley.rpy:5404
translate pt_br playRedLight_4f37bfcc:

    # cat "Reowrrr..."
    cat "Reowrrr..."

# game/inAlley.rpy:5405
translate pt_br playRedLight_84627845:

    # "The cat meows at you again, but it sounds much {b}deeper{/b} than earlier."
    "O gato mia para você novamente, mas soa muito mais {b}grave{/b} do que antes."

# game/inAlley.rpy:5406
translate pt_br playRedLight_cee07e8b:

    # "It’s crouched down... as if poised to lunge forward..."
    "Está agachado... como se estivesse prestes a saltar..."

# game/inAlley.rpy:5407
translate pt_br playRedLight_133b6978:

    # "Your breath shudders a little as your heart starts to race."
    "Sua respiração tremula um pouco enquanto seu coração acelera."

# game/inAlley.rpy:5408
translate pt_br playRedLight_e43c0e50:

    # "Your foot instinctively shifts back-"
    "Seu pé instintivamente recua-"

# game/inAlley.rpy:5419
translate pt_br playRedLight_1948cb48:

    # cat "{size=+20}{b}REAAWWWRRR!{/b}{/size}" with hpunch
    cat "{size=+20}{b}REAAWWWRRR!{/b}{/size}" with hpunch

# game/inAlley.rpy:5420
translate pt_br playRedLight_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:5421
translate pt_br playRedLight_4f55a03f:

    # "You freeze immediately."
    "Você congela imediatamente."

# game/inAlley.rpy:5422
translate pt_br playRedLight_0e14e06c:

    # "The cat looks..."
    "O gato parece..."

# game/inAlley.rpy:5423
translate pt_br playRedLight_a34925d6:

    # "...{b}impatient{/b}."
    "...{b}impaciente{/b}."

# game/inAlley.rpy:5424
translate pt_br playRedLight_8dbd85ab:

    # "It... It wants to keep playing?"
    "Ele... Ele quer continuar brincando?"

# game/inAlley.rpy:5425
translate pt_br playRedLight_9897df30:

    # "{size=-5}But...{/size}"
    "{size=-5}Mas...{/size}"

# game/inAlley.rpy:5426
translate pt_br playRedLight_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:5427
translate pt_br playRedLight_8ed89f65:

    # "You gulp and turn around, {w}swiftly counting and turning again as you gasp out..."
    "Você engole seco e se vira, {w}contando rápido e se virando novamente enquanto ofega..."

# game/inAlley.rpy:5432
translate pt_br playRedLight_41759c18:

    # you "{size=-5}O-One-two-three-red-light!!{/size}"
    you "{size=-5}U-Um-dois-três-queimou!!{/size}"

# game/inAlley.rpy:5435
translate pt_br playRedLight_3aae9beb:

    # "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch
    "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch

# game/inAlley.rpy:5436
translate pt_br playRedLight_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:5439
translate pt_br playRedLight_6022342a:

    # "The ground shakes as you whirl back around..."
    "O chão treme enquanto você se vira de volta..."

# game/inAlley.rpy:5442
translate pt_br playRedLight_100dd9e8:

    # "...to find yourself staring at a long surface of black fur."
    "...se deparando com uma longa superfície de pelo preto."

# game/inAlley.rpy:5443
translate pt_br playRedLight_e2847060:

    # "You slowly look up..."
    "Você olha lentamente para cima..."

# game/inAlley.rpy:5444
translate pt_br playRedLight_435dd3ca:

    # "And up..."
    "E para cima..."

# game/inAlley.rpy:5448
translate pt_br playRedLight_c9db0979:

    # "And {i}up{/i}..."
    "E para {i}cima{/i}..."

# game/inAlley.rpy:5449
translate pt_br playRedLight_a20cefa7_8:

    # "..."
    "..."

# game/inAlley.rpy:5454
translate pt_br playRedLight_40543d82:

    # "...to see a giant, shadowy figure leering down from its position hunched over you."
    "...para ver uma figura gigantesca e sombria olhando para baixo, curvada sobre você."

# game/inAlley.rpy:5455
translate pt_br playRedLight_caf41941:

    # "Fangs dripping with saliva..."
    "Presas pingando saliva..."

# game/inAlley.rpy:5456
translate pt_br playRedLight_26619c65:

    # "Claws crushing into the concrete walls of the alley..."
    "Garras cravadas nas paredes de concreto do beco..."

# game/inAlley.rpy:5457
translate pt_br playRedLight_70fb954c:

    # "Its glowing eyes are unblinking as they look back at you... {w}the cat waiting for your next turn."
    "Seus olhos brilhantes não piscam enquanto olham para você... {w}o gato está esperando sua próxima jogada."

# game/inAlley.rpy:5458
translate pt_br playRedLight_c97b388a:

    # "But it's so {b}close{/b}... {w}If you turn around {i}{b}now{/b}...{/i}"
    "Mas está tão {b}perto{/b}... {w}Se você se virar {i}{b}agora{/b}...{/i}"

# game/inAlley.rpy:5459
translate pt_br playRedLight_dae0ec55_2:

    # you "..."
    you "..."

# game/inAlley.rpy:5460
translate pt_br playRedLight_0f5de544:

    # "You..."
    "Você..."

# game/inAlley.rpy:5461
translate pt_br playRedLight_9fd59da9:

    # "{size=-10}you don’t want to play anymore{/size}"
    "{size=-10}você não quer mais brincar{/size}"

# game/inAlley.rpy:5478
translate pt_br play_gameRun_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:5482
translate pt_br play_gameRun_08ea5e28:

    # "You don’t even finish turning around before claws grip your torso..."
    "Você nem termina de se virar antes que as garras agarrem seu tórax..."

# game/inAlley.rpy:5483
translate pt_br play_gameRun_65b129bb:

    # "...digging in and piercing the soft flesh of your stomach with ease."
    "...cravando e perfurando a carne macia do seu abdômen facilmente."

# game/inAlley.rpy:5484
translate pt_br play_gameRun_fbb16dfe:

    # "As you’re lifted into the drooling, gaping jaws above you..."
    "Enquanto você é levantado, vê as mandíbulas se abrindo acima de você, pingando saliva..."

# game/inAlley.rpy:5485
translate pt_br play_gameRun_8515e08c:

    # "...you can’t help but think that there must’ve been another way out of this."
    "...e não consegue evitar de pensar que devia haver outra maneira de sair dessa."

# game/inAlley.rpy:5486
translate pt_br play_gameRun_cacea3a1:

    # "But pointless regrets are pretty typical for you..."
    "Mas arrependimentos inúteis são bem típicos de você..."

# game/inAlley.rpy:5487
translate pt_br play_gameRun_55ef6376:

    # "{size=-5}...aren't they?{/size}"
    "{size=-5}...não são?{/size}"

# game/inAlley.rpy:5488
translate pt_br play_gameRun_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:5489
translate pt_br play_gameRun_479119e0:

    # "Ending 32: Fear Quitter"
    "Final 32: Medroso"

# game/inAlley.rpy:5500
translate pt_br play_backUp_50e0caa3:

    # "Keeping your eyes trained on the giant looming over you..."
    "Com os olhos fixos no gigante que se ergue sobre você..."

# game/inAlley.rpy:5501
translate pt_br play_backUp_1f17c6e2:

    # "...you take a step back."
    "...você dá um passo para trás."

# game/inAlley.rpy:5505
translate pt_br play_backUp_f2f2471a:

    # who "No."
    who "Não."

# game/inAlley.rpy:5506
translate pt_br play_backUp_d36f2d70:

    # who "That's {b}cheating{/b}."
    who "Isso é {b}trapaça{/b}."

# game/inAlley.rpy:5720
translate pt_br runBackUp_93206a37:

    # who "What are you doing?"
    who "O que você está fazendo?"

# game/inAlley.rpy:5721
translate pt_br runBackUp_0a8c0018:

    # who "{size=+15}{b}STOP!{/b}{/size}" with hpunch
    who "{size=+15}{b}PARE!{/b}{/size}" with hpunch

# game/inAlley.rpy:5722
translate pt_br runBackUp_5110274f:

    # who "{size=+25}{b}YOU'LL BREAK EVERYTH-{/b}{/size}{w=0.5}{nw}" with hpunch
    who "{size=+25}{b}VOCÊ VAI QUEBRAR TUD-{/b}{/size}{w=0.5}{nw}" with hpunch

# game/inAlley.rpy:5736
translate pt_br backedUp_895b7892:

    # "The cat \ {b}s t a r e s {/b} as you keep eye contact and back up..."
    "O gato te \ {b}e n c a r a {/b} \ enquanto você mantém contato visual e volta..."

# game/inAlley.rpy:5737
translate pt_br backedUp_4050e13d:

    # "You step bAck..."
    "Você dá um passo pra trÁs..."

# game/inAlley.rpy:5738
translate pt_br backedUp_ea56939f:

    # "AnD baCk..."
    "E PaRa tRás..."

# game/inAlley.rpy:5741
translate pt_br backedUp_d13e6e4f:

    # "ANd aS YOu takE one mOre stEP baCk OuT oF tHe aLLeY..."
    "E cOnfoRme VOcê DÁ mais uM paSSO PrA ForA dO bECo..."

# game/inAlley.rpy:5742
translate pt_br backedUp_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:5743
translate pt_br backedUp_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:5746
translate pt_br backedUp_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:5750
translate pt_br backedUp_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:5751
translate pt_br backedUp_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:5753
translate pt_br backedUp_05374f43:

    # "ERROR."
    "ERRO."

# game/inAlley.rpy:5758
translate pt_br backedUp_05374f43_1:

    # "ERROR."
    "ERRO."

# game/inAlley.rpy:5769
translate pt_br backedUp_05374f43_2:

    # "ERROR."
    "ERRO."

# game/inAlley.rpy:5778
translate pt_br backedUp_05374f43_3:

    # "ERROR."
    "ERRO."

# game/inAlley.rpy:5784
translate pt_br backedUp_dc5c1f8b:

    # "ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR."
    "ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO. ERRO."

# game/inAlley.rpy:5812
translate pt_br backedUp_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:5813
translate pt_br backedUp_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:5814
translate pt_br backedUp_9ff185ae:

    # "The world outside the alley seems to be... {w}{i}broken.{/i}"
    "O mundo fora do beco parece estar... {w}{i}quebrado.{/i}"

# game/inAlley.rpy:5815
translate pt_br backedUp_f8eca25b:

    # "{size=-8}What exactly did you {b}do?{/b}{/size}"
    "{size=-8}O que exatamente você {b}fez?{/b}{/size}"

# game/inAlley.rpy:5816
translate pt_br backedUp_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:5817
translate pt_br backedUp_da5037e5:

    # "Ending 33: {b}eRRoR{/b} \ FoUnD"
    "Final 33: {b}eRRo{/b}  EnCoNtRaDo"

# game/inAlley.rpy:5829
translate pt_br play_buyToy_17b6ceba:

    # "After being out in this alley all alone for who knows how long..."
    "Depois de ficar nesse beco, completamente sozinho, por sabe-se lá quanto tempo..."

# game/inAlley.rpy:5830
translate pt_br play_buyToy_dc10009e:

    # "...you personally think your furry friend deserves something {b}special{/b}."
    "...você acha que seu amigo peludo merece algo {b}especial{/b}."

# game/inAlley.rpy:5834
translate pt_br play_buyToy_c0eeee5a:

    # you "I'll be right back, okay?"
    you "Já volto, tá?"

# game/inAlley.rpy:5836
translate pt_br play_buyToy_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/inAlley.rpy:5840
translate pt_br play_buyToy_29937c3a:

    # "You quickly leave the alley and rush to the nearby pet store."
    "Você sai rapidamente do beco e corre até o pet shop mais próximo."

# game/inAlley.rpy:5841
translate pt_br play_buyToy_ec2f406b:

    # "You browse through all the different toys for cats."
    "Você examina todos os diferentes brinquedos para gatos."

# game/inAlley.rpy:5842
translate pt_br play_buyToy_bf05eeff:

    # "There are so many to choose from... plush and bright-colored and scented with catnip..."
    "São tantos para escolher... de pelúcia, coloridos e com cheiro de catnip..."

# game/inAlley.rpy:5843
translate pt_br play_buyToy_bf0874e3:

    # "But..."
    "Mas..."

# game/inAlley.rpy:5844
translate pt_br play_buyToy_e86004a8:

    # "You realize that most of the toys aren't meant for a cat to play with alone."
    "Você percebe que a maioria dos brinquedos não são feitos para o gato brincar sozinho."

# game/inAlley.rpy:5845
translate pt_br play_buyToy_57b2fbb2:

    # "You can't stay in the alley playing {i}forever...{/i}"
    "Você não pode ficar no beco brincando {i}para sempre...{/i}"

# game/inAlley.rpy:5846
translate pt_br play_buyToy_9b14289c:

    # "And you can't exactly afford to get {i}another{/i} cat as a playmate..."
    "E também não pode arrumar {i}outro{/i} gato para fazer companhia..."

# game/inAlley.rpy:5847
translate pt_br play_buyToy_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:5848
translate pt_br play_buyToy_5c68eec6:

    # "\"Another...\""
    "\"Outro...\""

# game/inAlley.rpy:5849
translate pt_br play_buyToy_0fdaeb98:

    # you "{i}{size=+8}That's it!{/size}{/i}" with vpunch
    you "{i}{size=+8}É isso!{/size}{/i}" with vpunch

# game/inAlley.rpy:5850
translate pt_br play_buyToy_ce5d2ac5:

    # "You know exactly what to get now!"
    "Você sabe exatamente o que comprar agora!"

# game/inAlley.rpy:5851
translate pt_br play_buyToy_72c661ba:

    # "After a quick and successful search of the store..."
    "Depois de uma busca rápida e bem-sucedida pela loja..."

# game/inAlley.rpy:5852
translate pt_br play_buyToy_c96d5702:

    # "...you make your purchase and rush back to the alley... {w}eager to show off your find."
    "...você faz sua compra e corre de volta para o beco... {w}ansioso para mostrar o que encontrou."

# game/inAlley.rpy:5859
translate pt_br play_buyToy_d120113b:

    # you "I'm back~!"
    you "Tô de volta~!"

# game/inAlley.rpy:5862
translate pt_br play_buyToy_ec1974d4:

    # cat "Meow!" with hpunch
    cat "Miau!" with hpunch

# game/inAlley.rpy:5864
translate pt_br play_buyToy_755cfe9c:

    # "The alley feels even gloomier after spending time in direct sunlight..."
    "O beco parece ainda mais sombrio depois de passar um tempo diretamente sob a luz do sol..."

# game/inAlley.rpy:5865
translate pt_br play_buyToy_0f6e5e68:

    # "It makes you feel that much prouder of your gift."
    "Isso faz você se sentir ainda mais orgulhoso do seu presente."

# game/inAlley.rpy:5866
translate pt_br play_buyToy_84f515b2:

    # "You skip over to the cat and dig in the store's plastic bag."
    "Você corre até o gato e vasculha a sacola plástica da loja."

# game/inAlley.rpy:5867
translate pt_br play_buyToy_50f51005:

    # you "I've got something for you~"
    you "Trouxe uma coisa pra você~"

# game/inAlley.rpy:5870
translate pt_br play_buyToy_16879ce5_1:

    # cat "Meow?"
    cat "Miau?"

# game/inAlley.rpy:5871
translate pt_br play_buyToy_94919086:

    # "The cat leans up, curious at the bag's contents."
    "O gato se levanta, curioso com o conteúdo da sacola."

# game/inAlley.rpy:5872
translate pt_br play_buyToy_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:5873
translate pt_br play_buyToy_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:5876
translate pt_br play_buyToy_c8e2fc6b:

    # "You pull out your gift to the cat..."
    "Você tira seu presente para o gato..."

# game/inAlley.rpy:5879
translate pt_br play_buyToy_e5e73efe:

    # you "{size=+5}TADA~!{/size}" with hpunch
    you "{size=+5}TCHARAM~!{/size}" with hpunch

# game/inAlley.rpy:5880
translate pt_br play_buyToy_6003bca0:

    # "It's a small cat plushie."
    "É um gatinho de pelúcia."

# game/inAlley.rpy:5881
translate pt_br play_buyToy_4f8666f2:

    # "The plushie is a light orange-cream color with burnt sepia stripes, {w}making it resemble a tabby cat."
    "O boneco de pelúcia tem uma cor laranja clara com listras marrons, {w}fazendo-o parecer um gato tigrado."

# game/inAlley.rpy:5882
translate pt_br play_buyToy_b5de0f8d:

    # "The synthetic fur is soft, but not unrealistically so..."
    "O pelo sintético é macio, mas não de um jeito artificial..."

# game/inAlley.rpy:5883
translate pt_br play_buyToy_54c1b109:

    # "...and the large eyes are a pale green more subdued than you would've expected for a toy."
    "...e os olhos grandes têm cor verde pálido, mais discretos do que você esperaria para um brinquedo."

# game/inAlley.rpy:5884
translate pt_br play_buyToy_053e2879:

    # "There's no denying it's just a plushie, but the thoughtful details still make it almost..."
    "Não há como negar que é apenas um boneco de pelúcia, mas os detalhes cuidadosos ainda o tornam quase..."

# game/inAlley.rpy:5885
translate pt_br play_buyToy_55022625:

    # "...{b}uncanny{/b} to the real thing."
    "...{b}misterioso{/b} em relação à coisa real."

# game/inAlley.rpy:5886
translate pt_br play_buyToy_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:5887
translate pt_br play_buyToy_1b1eee42:

    # "Which makes it {i}perfect.{/i}"
    "O que o torna {i}perfeito.{/i}"

# game/inAlley.rpy:5888
translate pt_br play_buyToy_c1f68b0f:

    # "A companion for the cat, {w}and one you could actually afford."
    "Um companheiro para o gato, {w}e um que você pode bancar."

# game/inAlley.rpy:5889
translate pt_br play_buyToy_6b205f71:

    # "Win-win."
    "Só vantagem."

# game/inAlley.rpy:5891
translate pt_br play_buyToy_16879ce5_2:

    # cat "Meow?"
    cat "Miau?"

# game/inAlley.rpy:5892
translate pt_br play_buyToy_2d9feb3d:

    # you "That's not all!"
    you "E não é só isso!"

# game/inAlley.rpy:5895
translate pt_br play_buyToy_54cca3c7:

    # "You give the plushie a little squeeze and-"
    "Você aperta a pelúcia e-"

# game/inAlley.rpy:5898
translate pt_br play_buyToy_b4578bdf:

    # catDoll "{i}meeooww{/i}"
    catDoll "{i}miiaauu{/i}"

# game/inAlley.rpy:5899
translate pt_br play_buyToy_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:5903
translate pt_br play_buyToy_0e14e06c:

    # "The cat looks..."
    "O gato parece..."

# game/inAlley.rpy:5904
translate pt_br play_buyToy_335f91cb:

    # "...unimpressed."
    "...indiferente."

# game/inAlley.rpy:5905
translate pt_br play_buyToy_f297b97b:

    # you "{i}Hmph.{/i}"
    you "{i}Hum.{/i}"

# game/inAlley.rpy:5906
translate pt_br play_buyToy_750dec0e:

    # "Well. {w}{i}You{/i} think it's cute..."
    "Bem. {w}{i}Você{/i} acha fofo..."

# game/inAlley.rpy:5907
translate pt_br play_buyToy_c7218d6f:

    # "Guess your purchase wasn't so successful after all."
    "Parece que sua compra não foi tão bem-sucedida assim."

# game/inAlley.rpy:5908
translate pt_br play_buyToy_fd1a09e7:

    # "Out of options and lower on cash, {w}you awkwardly place the plushie in the box next to the cat."
    "Sem opções e sem dinheiro, {w}você, sem graça, coloca a pelúcia na caixa, ao lado do gato."

# game/inAlley.rpy:5909
translate pt_br play_buyToy_0c88972c:

    # "You get up and turn to leave."
    "Você se levanta e se vira para sair."

# game/inAlley.rpy:5912
translate pt_br play_buyToy_82edeab8:

    # "You're a few steps away when you hear an electronic meow behind you."
    "Está a alguns passos de distância quando ouve um miado eletrônico atrás de você."

# game/inAlley.rpy:5914
translate pt_br play_buyToy_b4578bdf_1:

    # catDoll "{i}meeooww{/i}"
    catDoll "{i}miiaauu{/i}"

# game/inAlley.rpy:5915
translate pt_br play_buyToy_c90675bd:

    # you "Huh?"
    you "Hã?"

# game/inAlley.rpy:5922
translate pt_br play_buyToy_0776796a:

    # "You turn to see the plushie on the ground next to the box."
    "Você se vira e vê o boneco de pelúcia no chão ao lado da caixa."

# game/inAlley.rpy:5923
translate pt_br play_buyToy_d1cca908:

    # "The cat is watching you closely, staring."
    "O gato está te observando atentamente, com o olhar fixo."

# game/inAlley.rpy:5933
translate pt_br pickUpDoll_82161d60:

    # "You sigh and go over to pick up the stuffed toy..."
    "Você suspira e vai pegar o boneco..."

# game/inAlley.rpy:5939
translate pt_br pickUpDoll_2aa568f9:

    # you "You really {i}do{/i} just want attention, don't you?"
    you "Você só {i}quer{/i} um pouco de atenção, não é?"

# game/inAlley.rpy:5942
translate pt_br pickUpDoll_022b9bff:

    # cat "Meow! Meoww!"
    cat "Miau! Miauu!"

# game/inAlley.rpy:5947
translate pt_br pickUpDoll_89a6495c:

    # "You hold up the cat doll, examining it a little..."
    "Você pega o boneco do gato, dando uma olhada..."

# game/inAlley.rpy:5948
translate pt_br pickUpDoll_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:5949
translate pt_br pickUpDoll_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:5950
translate pt_br pickUpDoll_704e0eb5:

    # "It looks a little... different."
    "Ele parece um pouco... diferente."

# game/inAlley.rpy:5958
translate pt_br pickUpDoll_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/inAlley.rpy:5959
translate pt_br pickUpDoll_e22dd6c2:

    # "Did it just..."
    "Ele acabou de..."

# game/inAlley.rpy:5960
translate pt_br pickUpDoll_23c671a1:

    # "{size=-8}...{b}look{/b} at you?{/size}"
    "{size=-8}...{b}olhar{/b} para você?{/size}"

# game/inAlley.rpy:5962
translate pt_br pickUpDoll_b4578bdf:

    # catDoll "{i}meeooww{/i}"
    catDoll "{i}miiaauu{/i}"

# game/inAlley.rpy:5965
translate pt_br pickUpDoll_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:5967
translate pt_br pickUpDoll_69d038c5:

    # catDoll "{i}{b}m e e o o w w...{/b}{/i}{w=0.8}{nw}"
    catDoll "{i}{b}m i i a a u u...{/b}{/i}{w=0.8}{nw}"

# game/inAlley.rpy:5969
translate pt_br pickUpDoll_bd45ae33:

    # catDoll "{i}{b}m e e o o w w-ow...{/b}{/i}{w=0.8}{nw}"
    catDoll "{i}{b}m i i a a u u-au...{/b}{/i}{w=0.8}{nw}"

# game/inAlley.rpy:5971
translate pt_br pickUpDoll_8606d94b:

    # catDoll "{i}{b}m e e o o w w-ow-ow...{/b}{/i}{w=0.8}{nw}"
    catDoll "{i}{b}m i i a a u u-au-au...{/b}{/i}{w=0.8}{nw}"

# game/inAlley.rpy:5973
translate pt_br pickUpDoll_f88ef7f7:

    # catDoll "{i}{b}m e e o o w w-ow-ow-ow...{/b}{/i}{w=0.8}{nw}"
    catDoll "{i}{b}m i i a a u u-au-au-au...{/b}{/i}{w=0.8}{nw}"

# game/inAlley.rpy:5975
translate pt_br pickUpDoll_3b489aee:

    # catDoll "{i}{b}m e e o o w w-ow-ow-ow-ow...{/b}{/i}"
    catDoll "{i}{b}m i i a a u u-au-au-au-au...{/b}{/i}"

# game/inAlley.rpy:5996
translate pt_br pickUpDoll_12a250d7:

    # "{size=+20}{b}{i}CHOMP!!{/i}{/b}{/size}" with hpunch
    "{size=+20}{b}{i}CHOMP!!{/i}{/b}{/size}" with hpunch

# game/inAlley.rpy:5997
translate pt_br pickUpDoll_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:6003
translate pt_br pickUpDoll_6e0cdb4a:

    # "The plushie somehow opens it sewn-on mouth before biting into your wrist!"
    "A pelúcia, de alguma forma, abre a boca costurada antes de morder seu pulso!"

# game/inAlley.rpy:6004
translate pt_br pickUpDoll_9275ba69:

    # you "{b}OW!!{/b} S-STOP!" with vpunch
    you "{b}AI!!{/b} P-PARA!" with vpunch

# game/inAlley.rpy:6005
translate pt_br pickUpDoll_4afb1a12:

    # "You try to fling it off, but its grip on you is strong as it drinks your blood, ravenous and frantic."
    "Você tenta jogá-lo para longe, mas sua mordida é muito forte. Enquanto isso, ele suga seu sangue, voraz e frenético."

# game/inAlley.rpy:6010
translate pt_br pickUpDoll_05c892b0:

    # "You hit it against the concrete walls of the alley..."
    "Você bate a pelúcia contra as paredes de concreto do beco..."

# game/inAlley.rpy:6015
translate pt_br pickUpDoll_6530086c:

    # "You try to tear at its sturdy fabric..."
    "Tenta rasgar seu tecido resistente..."

# game/inAlley.rpy:6020
translate pt_br pickUpDoll_354ced13:

    # "But try as you might, you can’t seem to hurt it or make it stop..."
    "Mas, por mais que tente, não consegue feri-la ou fazê-la parar..."

# game/inAlley.rpy:6021
translate pt_br pickUpDoll_ed657fd0:

    # "It’s just a toy after all."
    "Afinal, é apenas um brinquedo."

# game/inAlley.rpy:6024
translate pt_br pickUpDoll_d9df7f92:

    # "Eventually, you start to feel faint... {w}enough to collapse to your knees in defeat."
    "Eventualmente, você começa a se sentir sem forças... {w}O suficiente para cair de joelhos, derrotado."

# game/inAlley.rpy:6027
translate pt_br pickUpDoll_ae5955fe:

    # "The stuffed doll is drinking more calmly now..."
    "O boneco de pelúcia está bebendo mais calmo agora..."

# game/inAlley.rpy:6028
translate pt_br pickUpDoll_3458d0b1:

    # "...as if its previous aggression had been a mere reaction to your desperation."
    "...como se sua agressão anterior tivesse sido apenas uma reação ao seu desespero."

# game/inAlley.rpy:6029
translate pt_br pickUpDoll_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:6030
translate pt_br pickUpDoll_e5b804f8:

    # "It seems satisfied that you’re no longer putting up a fight."
    "Ele parece satisfeito por você não estar mais lutando."

# game/inAlley.rpy:6034
translate pt_br pickUpDoll_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:6035
translate pt_br pickUpDoll_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:6036
translate pt_br pickUpDoll_17adc77a:

    # "You think you blacked out for a second..."
    "Por um segundo você pensa ter desmaiado..."

# game/inAlley.rpy:6037
translate pt_br pickUpDoll_cb31072e:

    # "...because though you're still sitting the next time you're conscious, your eyes are closed."
    "...porque quando volta a si, ainda está sentado com os olhos fechados."

# game/inAlley.rpy:6038
translate pt_br pickUpDoll_0f5de544:

    # "You..."
    "Você..."

# game/inAlley.rpy:6039
translate pt_br pickUpDoll_79beda1e:

    # "You feel so weak..."
    "Você se sente tão fraco..."

# game/inAlley.rpy:6040
translate pt_br pickUpDoll_8c840e9e:

    # "You have to use all your strength just to pry open your eyes and when you do..."
    "Você precisa usar toda a sua força apenas para abrir os olhos, e quando consegue..."

# game/inAlley.rpy:6044
translate pt_br pickUpDoll_40d9ca73:

    # "..?"
    "..?"

# game/inAlley.rpy:6047
translate pt_br pickUpDoll_35a7a74d:

    # "...you see a... {w}kitten?"
    "...você vê um... {w}gatinho?"

# game/inAlley.rpy:6048
translate pt_br pickUpDoll_47bd6cb5:

    # "Its fur a familiar orange-cream with burnt sepia stripes..."
    "Seu pelo é um tom familiar laranja claro com listras marrons..."

# game/inAlley.rpy:6049
translate pt_br pickUpDoll_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:6050
translate pt_br pickUpDoll_b3f7547c:

    # "It's lapping at your wrist..."
    "Ele está lambendo seu pulso..."

# game/inAlley.rpy:6053
translate pt_br pickUpDoll_d587e6e7:

    # "The kitten lifts its head and looks at you with piercing, pale green eyes..."
    "O gatinho levanta a cabeça e olha para você com seus penetrantes olhos verde-pálido..."

# game/inAlley.rpy:6057
translate pt_br pickUpDoll_07d3bffa:

    # kitten "Miiiiew!"
    kitten "Miiiiau!"

# game/inAlley.rpy:6058
translate pt_br pickUpDoll_e1a39f3b:

    # "It mewls at you with a high, squeaky pitch..."
    "Ele mia para você com um tom agudo e estridente..."

# game/inAlley.rpy:6059
translate pt_br pickUpDoll_5c40811b:

    # "...mouth covered in blood."
    "...a boca coberta de sangue."

# game/inAlley.rpy:6062
translate pt_br pickUpDoll_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:6063
translate pt_br pickUpDoll_d40d5f1c:

    # "It’d be downright adorable... {w}if you weren’t about to die from blood loss..."
    "Seria absolutamente adorável... {w}se você não estivesse prestes a morrer por perda de sangue..."

# game/inAlley.rpy:6079
translate pt_br pickUpDoll_90071059:

    # "The cat strolls into your line of vision and picks the kitten up."
    "O gato aparece na sua vista e pega o filhote."

# game/inAlley.rpy:6080
translate pt_br pickUpDoll_3f40ce34:

    # "It gives you an indecipherable look..."
    "Ele lhe lança um olhar indecifrável..."

# game/inAlley.rpy:6081
translate pt_br pickUpDoll_ca09ce4e:

    # "...before turning away."
    "...antes de se afastar."

# game/inAlley.rpy:6084
translate pt_br pickUpDoll_461d72a5:

    # "The cat carries the kitten back to the box and starts to carefully and dutifully clean it."
    "O gato leva o filhote de volta para a caixa e começa a limpá-lo com cuidado."

# game/inAlley.rpy:6086
translate pt_br pickUpDoll_19878d53:

    # kitten "Miiieeww..."
    kitten "Miiiaauu..."

# game/inAlley.rpy:6088
translate pt_br pickUpDoll_67107e6c:

    # cat "Purr..."
    cat "Purr..."

# game/inAlley.rpy:6089
translate pt_br pickUpDoll_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:6090
translate pt_br pickUpDoll_fb698b9d:

    # "You sway and find you can’t right yourself before falling to the ground."
    "Você desequilibra e percebe que não consegue se manter de pé antes de cair no chão."

# game/inAlley.rpy:6094
translate pt_br pickUpDoll_d573f842:

    # "It would seem that in the end..."
    "Pelo visto, no fim das contas..."

# game/inAlley.rpy:6095
translate pt_br pickUpDoll_d8af5247:

    # "...you'd gotten the cat a playmate after all."
    "...você conseguiu arranjar um companheiro para o gato, afinal."

# game/inAlley.rpy:6096
translate pt_br pickUpDoll_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:6097
translate pt_br pickUpDoll_51267a7a:

    # "Ending 34: Living doll"
    "Final 34: Brinquedo vivo"

# game/inAlley.rpy:6109
translate pt_br leaveDoll_7f0ac95c:

    # cat "..."
    cat "..."

# game/inAlley.rpy:6110
translate pt_br leaveDoll_dae0ec55:

    # you "..."
    you "..."

# game/inAlley.rpy:6112
translate pt_br leaveDoll_9e098551:

    # "{size=-10}Ungrateful little monster.{/size}"
    "{size=-10}Monstrinho ingrato.{/size}"

# game/inAlley.rpy:6114
translate pt_br leaveDoll_f34f5817:

    # "You huff in annoyance."
    "Você expira, irritado."

# game/inAlley.rpy:6115
translate pt_br leaveDoll_c6883583:

    # you "You're {i}{b}welcome{/b}{/i}..."
    you "De nada, {i}{b}viu?{/b}{/i}..."

# game/inAlley.rpy:6118
translate pt_br leaveDoll_10532c8a:

    # "Shaking your head, you turn to leave once again-"
    "Balançando a cabeça, você se vira para ir embora mais uma vez-"

# game/inAlley.rpy:6122
translate pt_br leaveDoll_56ebb028:

    # you "!!!"
    you "!!!"

# game/inAlley.rpy:6123
translate pt_br leaveDoll_5ef96487:

    # you "{b}AHH!{/b}" with vpunch
    you "{b}AHH!{/b}" with vpunch

# game/inAlley.rpy:6125
translate pt_br leaveDoll_1542f023:

    # "...when a sharp pain lances up your arm."
    "...quando uma dor aguda atravessa seu braço."

# game/inAlley.rpy:6129
translate pt_br leaveDoll_d75c3479:

    # you "{b}{size=+10}GAHH!!{/size}{/b}" with vpunch
    you "{b}{size=+10}GAHH!!{/size}{/b}" with vpunch

# game/inAlley.rpy:6130
translate pt_br leaveDoll_41de37fd:

    # "Crying out, you grab at your arm only for it to-"
    "Gritando de dor, você agarra o braço, fazendo ele-"

# game/inAlley.rpy:6135
translate pt_br leaveDoll_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/inAlley.rpy:6138
translate pt_br leaveDoll_47103633:

    # "{size=-5}...fall off.{/size}"
    "{size=-5}...cair.{/size}"

# game/inAlley.rpy:6139
translate pt_br leaveDoll_f7c10c20:

    # "{size=-8}Your arm just falls right {i}off.{/i}{/size}"
    "{size=-8}Seu braço simplesmente {i}cai.{/i}{/size}"

# game/inAlley.rpy:6140
translate pt_br leaveDoll_145d5b9e:

    # "You stare in shock at your severed limb on the ground."
    "Você encara, em choque, o seu membro amputado no chão."

# game/inAlley.rpy:6141
translate pt_br leaveDoll_cb3b97dc:

    # "Gathering your courage..."
    "Juntando coragem..."

# game/inAlley.rpy:6142
translate pt_br leaveDoll_3461876b:

    # "...you turn to look at where your arm had once connected to the rest of you, only to see..."
    "...você se vira para olhar onde seu braço costumava estar ligado ao resto do corpo, apenas para ver..."

# game/inAlley.rpy:6145
translate pt_br leaveDoll_b8178942:

    # you "..!?"
    you "..!?"

# game/inAlley.rpy:6146
translate pt_br leaveDoll_4579d27c:

    # "Not blood..? It’s..."
    "Não é sangue..? É..."

# game/inAlley.rpy:6147
translate pt_br leaveDoll_6cca42de:

    # "It’s {i}{b}cotton?!{/b}{/i}"
    "É {i}{b}algodão?!{/b}{/i}"

# game/inAlley.rpy:6150
translate pt_br leaveDoll_9e6ab9f6:

    # "Touching it, the stump doesn’t even hurt..."
    "Você encosta no toco e percebe que não dói..."

# game/inAlley.rpy:6151
translate pt_br leaveDoll_a20cefa7:

    # "..."
    "..."

# game/inAlley.rpy:6152
translate pt_br leaveDoll_5cf9ed70:

    # "That is..."
    "Isso é..."

# game/inAlley.rpy:6166
translate pt_br leaveDoll_a20cefa7_1:

    # "..."
    "..."

# game/inAlley.rpy:6167
translate pt_br leaveDoll_0c436653:

    # "{size=-8}...until the same thing happens to your other arm.{/size}"
    "{size=-8}...até que a mesma coisa acontece com seu outro braço.{/size}"

# game/inAlley.rpy:6170
translate pt_br leaveDoll_b61a60d7:

    # you "{b}{size=+10}AAAAHHH!!{/size}{/b}" with vpunch
    you "{b}{size=+10}AAAAHHH!!{/size}{/b}" with vpunch

# game/inAlley.rpy:6172
translate pt_br leaveDoll_cd0981ae:

    # you "{b}{size=+20}{i}GAAAHHH!!!{/i}{/size}{/b}" with vpunch
    you "{b}{size=+20}{i}GAAAHHH!!!{/i}{/size}{/b}" with vpunch

# game/inAlley.rpy:6176
translate pt_br leaveDoll_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/inAlley.rpy:6180
translate pt_br leaveDoll_658780db:

    # you "AHH!!" with vpunch
    you "AHH!!" with vpunch

# game/inAlley.rpy:6182
translate pt_br leaveDoll_43d120d4:

    # "You fall when both your legs succumb to the same nonsensical fate..."
    "Você cai quando ambas as pernas sucumbem ao mesmo destino sem sentido..."

# game/inAlley.rpy:6183
translate pt_br leaveDoll_75cd7bfe:

    # "...crying out at the agony that comes and goes like it never happened..."
    "...gritando pela agonia que vai e vem como se nunca tivesse acontecido..."

# game/inAlley.rpy:6184
translate pt_br leaveDoll_4461f216:

    # "...as if you're not currently laying on the dirty ground of an alley..."
    "...como se você não estivesse atualmente deitado no chão sujo de um beco..."

# game/inAlley.rpy:6185
translate pt_br leaveDoll_5ca04004:

    # "{b}...limbless{/b}."
    "{b}...sem membros{/b}."

# game/inAlley.rpy:6186
translate pt_br leaveDoll_c03a3d82:

    # "{size=-8}What in the world is going on..?{/size}"
    "{size=-8}O que diabos está acontecendo..?{/size}"

# game/inAlley.rpy:6187
translate pt_br leaveDoll_78f5a0cd:

    # "You can't make sense of it..."
    "Você não consegue entender..."

# game/inAlley.rpy:6188
translate pt_br leaveDoll_97f38b80:

    # "You can't think straight..."
    "Não consegue pensar direito..."

# game/inAlley.rpy:6189
translate pt_br leaveDoll_8dabefc6:

    # ".."
    ".."

# game/inAlley.rpy:6190
translate pt_br leaveDoll_a20cefa7_2:

    # "..."
    "..."

# game/inAlley.rpy:6193
translate pt_br leaveDoll_a20cefa7_3:

    # "..."
    "..."

# game/inAlley.rpy:6196
translate pt_br leaveDoll_ef40bdc4:

    # "The pain has receded..."
    "A dor passou..."

# game/inAlley.rpy:6197
translate pt_br leaveDoll_95257a22:

    # "...leaving you with a strangely empty pit in your stomach."
    "...te deixando com uma estranha sensação de vazio no estômago."

# game/inAlley.rpy:6198
translate pt_br leaveDoll_d38ad1a6:

    # "Considering you still {i}have{/i} a stomach and it wasn't replaced with..."
    "Considerando que você ainda {i}tem{/i} um estômago e que não foi substituído por..."

# game/inAlley.rpy:6199
translate pt_br leaveDoll_a20cefa7_4:

    # "..."
    "..."

# game/inAlley.rpy:6200
translate pt_br leaveDoll_8ba140ab:

    # "As you lay back... helpless and still in shock, staring at the sky..."
    "Enquanto você se deita... impotente e ainda em choque, olhando para o céu..."

# game/inAlley.rpy:6203
translate pt_br leaveDoll_70f07f0b:

    # "...the cat’s face appears in your line of vision."
    "...o rosto do gato aparece em sua linha de visão."

# game/inAlley.rpy:6204
translate pt_br leaveDoll_dae0ec55_1:

    # you "..."
    you "..."

# game/inAlley.rpy:6205
translate pt_br leaveDoll_7f0ac95c_1:

    # cat "..."
    cat "..."

# game/inAlley.rpy:6219
translate pt_br leaveDoll_2453d78c:

    # "It lunges at your torso and starts biting and clawing into your chest like you’re a chew toy."
    "Ele salta em direção ao seu torso e começa a morder e arranhar seu peito como se você fosse um brinquedo de mastigar."

# game/inAlley.rpy:6220
translate pt_br leaveDoll_af8ce120:

    # "It doesn’t hurt anymore..."
    "Não dói mais..."

# game/inAlley.rpy:6221
translate pt_br leaveDoll_650a397d:

    # "You feel like it {i}should.{/i}"
    "Mas você sente que {i}deveria.{/i}"

# game/inAlley.rpy:6222
translate pt_br leaveDoll_360e2c6a:

    # "You’re... not sure if you’re glad that it {i}{b}doesn’t{/b}{/i}..."
    "Você... não tem certeza se fica feliz por {i}{b}não doer{/b}{/i}..."

# game/inAlley.rpy:6223
translate pt_br leaveDoll_a20cefa7_5:

    # "..."
    "..."

# game/inAlley.rpy:6228
translate pt_br leaveDoll_9b7b97b5:

    # "Eventually, you feel the cat {i}pull{/i} something out of you..."
    "Eventualmente, você sente o gato {i}puxar{/i} algo de dentro de você..."

# game/inAlley.rpy:6232
translate pt_br leaveDoll_af048f08:

    # "...a small doll, that looks very, very familiar."
    "...um bonequinho, que parece muito, muito familiar."

# game/inAlley.rpy:6233
translate pt_br leaveDoll_230dc578:

    # "It's hard to tell but... that doll is..."
    "É difícil afirmar, mas... esse boneco é..."

# game/inAlley.rpy:6234
translate pt_br leaveDoll_eceefbf1:

    # "That's {i}you{/i}..."
    "É {i}você{/i}..."

# game/inAlley.rpy:6235
translate pt_br leaveDoll_31f42f2f:

    # "{size=-8}...isn't it?{/size}"
    "{size=-8}...não é?{/size}"

# game/inAlley.rpy:6241
translate pt_br leaveDoll_e99f1253:

    # "The cat hops off of you and heads back to the box with its prize."
    "O gato pula de você e volta para a caixa com seu prêmio."

# game/inAlley.rpy:6242
translate pt_br leaveDoll_4397d1db:

    # "At least you {i}think{/i} so..."
    "Pelo menos, é o que você {i}acha{/i}..."

# game/inAlley.rpy:6243
translate pt_br leaveDoll_32485deb:

    # "Everything’s... {w}{size=-5}too dark...{/size} {w}{size=-8}to tell...{/size}"
    "Está tudo... {w}{size=-5}escuro demais...{/size} {w}{size=-8}para saber...{/size}"

# game/inAlley.rpy:6244
translate pt_br leaveDoll_8dabefc6_1:

    # ".."
    ".."

# game/inAlley.rpy:6245
translate pt_br leaveDoll_a20cefa7_6:

    # "..."
    "..."

# game/inAlley.rpy:6248
translate pt_br leaveDoll_233e66b3:

    # "...You wake up and find that you can’t move an inch."
    "...Você acorda e descobre que não consegue se mexer nem um centímetro."

# game/inAlley.rpy:6249
translate pt_br leaveDoll_816001ad:

    # "You can’t look around."
    "Você não consegue olhar à sua volta."

# game/inAlley.rpy:6250
translate pt_br leaveDoll_bb663b42:

    # "You can’t even breathe."
    "Nem ao menos respirar."

# game/inAlley.rpy:6251
translate pt_br leaveDoll_6665f0ba:

    # "Though none of those realizations seem to be... a {i}problem?{/i}"
    "Embora nenhuma dessas constatações pareça ser... um {i}problema?{/i}"

# game/inAlley.rpy:6252
translate pt_br leaveDoll_cac600dc:

    # "All you can see is the face of a familiar looking cat curled around you, purring in its sleep."
    "Tudo o que você consegue ver é a face de um gato familiar enroscado em você, ronronando enquanto dorme."

# game/inAlley.rpy:6254
translate pt_br leaveDoll_b53c4107:

    # cat "Purr... Purrr..."
    cat "Purr... Purrr..."

# game/inAlley.rpy:6255
translate pt_br leaveDoll_aae0b1be:

    # "For some reason, this doesn’t bother you."
    "Por alguma razão, isso não te incomoda."

# game/inAlley.rpy:6256
translate pt_br leaveDoll_2f662c10:

    # "You’re not sure why you feel like it should."
    "Você não sabe por que sente que deveria."

# game/inAlley.rpy:6257
translate pt_br leaveDoll_a8aca17f:

    # "You try to latch on to thoughts in your head, that feel like memories of another life..."
    "Você tenta se agarrar a pensamentos na sua mente, que parecem memórias de outra vida..."

# game/inAlley.rpy:6258
translate pt_br leaveDoll_8e65e29b:

    # "Another time..."
    "Outro tempo..."

# game/inAlley.rpy:6259
translate pt_br leaveDoll_f93d2a1b:

    # "Another {i}you{/i}..."
    "Outro {i}você{/i}..."

# game/inAlley.rpy:6260
translate pt_br leaveDoll_b846ccd9:

    # "...but the thoughts slip away like forgotten dreams."
    "...mas os pensamentos escapam como sonhos esquecidos."

# game/inAlley.rpy:6261
translate pt_br leaveDoll_8dabefc6_2:

    # ".."
    ".."

# game/inAlley.rpy:6262
translate pt_br leaveDoll_a20cefa7_7:

    # "..."
    "..."

# game/inAlley.rpy:6266
translate pt_br leaveDoll_2521d867:

    # "Oh well."
    "Ah, ok."

# game/inAlley.rpy:6267
translate pt_br leaveDoll_6ff54d13:

    # "That's fine, isn't it?"
    "Tá tudo bem, né?"

# game/inAlley.rpy:6268
translate pt_br leaveDoll_dbcfd29d:

    # "{size=-5}You're just a \ {b}d o l l{/b}, after all...{/size}"
    "{size=-5}Você é só um \ {b}b o n e c o{/b}, afinal...{/size}"

# game/inAlley.rpy:6269
translate pt_br leaveDoll_f17d3908:

    # "And a doll’s role isn’t to have silly {i}thoughts{/i} or to {i}remember{/i} unimportant things..."
    "E o papel de um boneco não é ter {i}pensamentos{/i} bobos ou {i}lembrar{/i} de coisas sem importância..."

# game/inAlley.rpy:6270
translate pt_br leaveDoll_ad9a2f7f:

    # "...but to be a {i}companion.{/i}"
    "...mas sim ser uma {i}companhia.{/i}"

# game/inAlley.rpy:6272
translate pt_br leaveDoll_8d3133d1:

    # cat "Purrr..."
    cat "Purrr..."

# game/inAlley.rpy:6273
translate pt_br leaveDoll_35fc12aa:

    # "And judging from the cat’s contented purring..."
    "E, a julgar pelo ronronar satisfeito do gato..."

# game/inAlley.rpy:6274
translate pt_br leaveDoll_55c51d80:

    # "...you seem to be performing your role perfectly."
    "...você parece estar cumprindo o seu papel perfeitamente."

# game/inAlley.rpy:6275
translate pt_br leaveDoll_8efdd0d0:

    # "You are filled with an overwhelmingly strong sense of pride at this fact."
    "Você é preenchido com uma sensação de orgulho avassaladora por isso."

# game/inAlley.rpy:6278
translate pt_br leaveDoll_8dbe9dfc:

    # "And so you {i}too{/i}... {w}feel content."
    "E assim, você {i}também{/i}... {w}se sente contente."

# game/inAlley.rpy:6279
translate pt_br leaveDoll_8dabefc6_3:

    # ".."
    ".."

# game/inAlley.rpy:6280
translate pt_br leaveDoll_a20cefa7_8:

    # "..."
    "..."

# game/inAlley.rpy:6281
translate pt_br leaveDoll_bac39afa:

    # "Ending 35: Cotton Headed"
    "Final 35: Bonequinho"

translate pt_br strings:

    # game/inAlley.rpy:733
    old "Leave cat"
    new "Deixar o gato"

    # game/inAlley.rpy:733
    old "?????"
    new "?????"

    # game/inAlley.rpy:733
    old "{b}You are ready...{/b}"
    new "{b}Você está pronto...{/b}"

    # game/inAlley.rpy:733
    old "{color=#FF0000}{b}K I L L{/b}{/color}  cat.."
    new "{color=#FF0000}{b}M A T A R{/b}{/color}  o gato.."

    # game/inAlley.rpy:789
    old "Ignore"
    new "Ignorar"

    # game/inAlley.rpy:789
    old "Turn back"
    new "Se virar"

    # game/inAlley.rpy:814
    old "I think I'll..."
    new "Acho que..."

    # game/inAlley.rpy:814
    old "Go watch a movie"
    new "Vou assistir um filme"

    # game/inAlley.rpy:814
    old "Go to the carnival"
    new "Vou ao festival"

    # game/inAlley.rpy:814
    old "Go to dog park"
    new "Vou ao parque para cachorros"

    # game/inAlley.rpy:836
    old "Go to the old theater."
    new "Ir ao cinema antigo."

    # game/inAlley.rpy:836
    old "Go to the new cinema."
    new "Ir ao cinema novo."

    # game/inAlley.rpy:913
    old "Move to another spot."
    new "Mudar para outro lugar."

    # game/inAlley.rpy:913
    old "Confront the stranger."
    new "Confrontar o estranho."

    # game/inAlley.rpy:913
    old "Leave the theater."
    new "Sair do cinema."

    # game/inAlley.rpy:1076
    old "{size=-8}Don't look behind you. Don't look behind you. Don't look behind you. Don't look behind you.{/size}"
    new "{size=-8}Não olhe para trás. Não olhe para trás. Não olhe para trás. Não olhe para trás.{/size}"

    # game/inAlley.rpy:1076
    old "{b}{color=#FF0000}{s}Don't{/s}{/color} look behind you...{/b}"
    new "{b}{color=#FF0000}{s}Não{/s}{/color} olhe para trás...{/b}"

    # game/inAlley.rpy:1257
    old "Try to leave the theater."
    new "Tentar sair da sala."

    # game/inAlley.rpy:1257
    old "Try to blend in with the crowd."
    new "Tentar se misturar à multidão."

    # game/inAlley.rpy:1677
    old "Do something else."
    new "Caçar outra coisa pra fazer."

    # game/inAlley.rpy:1677
    old "Enter the maze."
    new "Entrar no labirinto."

    # game/inAlley.rpy:1803
    old "Leave the park."
    new "Sair do parque."

    # game/inAlley.rpy:1803
    old "Kick the puppy."
    new "Chutar o filhote."

    # game/inAlley.rpy:1803
    old "Kill the puppy."
    new "Matar o filhote."

    # game/inAlley.rpy:1803
    old "Eat the puppy."
    new "Devorar o filhote."

    # game/inAlley.rpy:1803
    old "Pick up the puppy."
    new "Segurar o filhote."

    # game/inAlley.rpy:1848
    old "{size=+5}DROP IT!{/size}"
    new "{size=+5}SOLTA!{/size}"

    # game/inAlley.rpy:1848
    old "{size=-5}Hold on!{/size}"
    new "{size=-5}Calma aí!{/size}"

    # game/inAlley.rpy:1888
    old "LEAVE THE PARK."
    new "SAIR DO PARQUE."

    # game/inAlley.rpy:1888
    old "Stay at the park..."
    new "Ficar no parque..."

    # game/inAlley.rpy:1979
    old "{size=+40}{b}LEAVE! LEAVE! {color=#FF0000}LEAVE!{/color}{/b}{/size}"
    new "{size=+40}{b}VÁ EMBORA! VÁ EMBORA! {color=#FF0000}VÁ EMBORA!{/color}{/b}{/size}"

    # game/inAlley.rpy:1979
    old "{size=-6}THROW!{/size}"
    new "{size=-6}JOGA!{/size}"

    # game/inAlley.rpy:2058
    old "LEAVE."
    new "VÁ EMBORA."

    # game/inAlley.rpy:2058
    old "Pet dog."
    new "Acariciar o cachorro."

    # game/inAlley.rpy:2180
    old "{size=+5}{color=#FF0000}l e av e...{/color}{/size}"
    new "{size=+5}{color=#FF0000}v á  em b o ra...{/color}{/size}"

    # game/inAlley.rpy:2180
    old "{size=-5}pet the {b}d{/b}oG.{/size}"
    new "{size=-5}acariciar o {b}c{/b}aChoRro.{/size}"

    # game/inAlley.rpy:2352
    old "Leave the park?"
    new "Ir embora do parque?"

    # game/inAlley.rpy:2458
    old "Stay?"
    new "Ficar?"

    # game/inAlley.rpy:2458
    old "Leave?"
    new "Ir embora?"

    # game/inAlley.rpy:2589
    old "Leave and... go home..?"
    new "Sair e... ir para casa..?"

    # game/inAlley.rpy:2720
    old "I... I think I'll..."
    new "Eu... eu acho que..."

    # game/inAlley.rpy:2720
    old "G o  WAtc h  A  mo vIe"
    new "VOu  AsSis Tir  uM  F iL me"

    # game/inAlley.rpy:2720
    old "G o  To tHe cArn iVa l"
    new "V Ou  Ao fEst iVa l"

    # game/inAlley.rpy:2720
    old "gO  t o DOG pAr k"
    new "vOU  a o  pAr Que pAr a  CACHORROS"

    # game/inAlley.rpy:2720
    old "Go home..."
    new "Vou para casa..."

    # game/inAlley.rpy:2863
    old "G o tO {b}old theater.{/b}"
    new "V ou aO {b}cinema antigo.{/b}"

    # game/inAlley.rpy:2863
    old "go t o {b}new cinema.{/b}"
    new "vou  a o {b}cinema novo.{/b}"

    # game/inAlley.rpy:2928
    old ".ezam eht retnE"
    new ".otniribal on rartnE"

    # game/inAlley.rpy:2993
    old "{size=-8}{b}p u p p y.{/b}{/size}"
    new "{size=-8}{b}c a c h o r r i n h o.{/b}{/size}"

    # game/inAlley.rpy:3176
    old "Check pockets"
    new "Olhar os bolsos"

    # game/inAlley.rpy:3176
    old "Look around the area"
    new "Dar uma olhada ao redor"

    # game/inAlley.rpy:3176
    old "{color=#FF0000}Blood...{/color}"
    new "{color=#FF0000}Sangue...{/color}"

    # game/inAlley.rpy:3381
    old "Beg for forgiveness."
    new "Implorar por perdão."

    # game/inAlley.rpy:3381
    old "Go inside."
    new "Entrar em casa."

    # game/inAlley.rpy:3833
    old "Spare the mouse."
    new "Poupar o rato."

    # game/inAlley.rpy:3833
    old "Spare the mouse..."
    new "Poupar o rato..."

    # game/inAlley.rpy:3833
    old "{i}Spare the mouse.{/i}"
    new "{i}Poupar o rato.{/i}"

    # game/inAlley.rpy:3833
    old "{b}{i}Spare the mouse.{/i}{/b}"
    new "{b}{i}Poupar o rato.{/i}{/b}"

    # game/inAlley.rpy:3833
    old "SpaRe tHe {color=#FF0000}{b}mouse{/b}{/color}."
    new "PouPaR O {color=#FF0000}{b}rato{/b}{/color}."

    # game/inAlley.rpy:3833
    old "Feed mouse to cat."
    new "Dar o rato ao gato."

    # game/inAlley.rpy:3833
    old "{color=#FF0000}{b}Feed mouse to cat.{/b}{/color}"
    new "{color=#FF0000}{b}Dar o rato ao gato.{/b}{/color}"

    # game/inAlley.rpy:4536
    old "Stop the cat."
    new "Impedir o gato."

    # game/inAlley.rpy:4536
    old "Let cat feed."
    new "Deixar o gato se alimentar."

    # game/inAlley.rpy:4768
    old "Check pockets."
    new "Checar os bolsos."

    # game/inAlley.rpy:4768
    old "Look around the area."
    new "Olhar em volta."

    # game/inAlley.rpy:4768
    old "Buy a toy"
    new "Comprar um brinquedo."

    # game/inAlley.rpy:4894
    old "Hang out and do something else?"
    new "Ficar por aqui e fazer outra coisa?"

    # game/inAlley.rpy:4894
    old "Get out of the alley."
    new "Sair do beco."

    # game/inAlley.rpy:5098
    old "Check phone..."
    new "Olhar o celular..."

    # game/inAlley.rpy:5098
    old "Ignore phone..."
    new "Ignorar o celular..."

    # game/inAlley.rpy:5311
    old "Try something else?"
    new "Tentar outra coisa?"

    # game/inAlley.rpy:5311
    old "Keep playing?"
    new "Continuar brincando?"

    # game/inAlley.rpy:5463
    old "Run..."
    new "Fugir..."

    # game/inAlley.rpy:5463
    old "Back up..."
    new "Voltar..."

    # game/inAlley.rpy:5508
    old "Run {size=-10}restoreBACKUP.exe{/size}"
    new "Rodar {size=-10}VOLTARsave.exe{/size}"

    # game/inAlley.rpy:5520
    old "Begin restoration: _ _ _ _  _ _"
    new "Comece a restauração: _ _ _ _ _ _"

    # game/inAlley.rpy:5520
    old "Begin restoration: B _ _ _  _ _"
    new "Comece a restauração: V _ _ _ _ _"

    # game/inAlley.rpy:5520
    old "Begin restoration: B A _ _  _ _"
    new "Comece a restauração: V O _ _ _ _"

    # game/inAlley.rpy:5520
    old "Begin restoration: B A C _  _ _"
    new "Comece a restauração: V O L _ _ _"

    # game/inAlley.rpy:5520
    old "Begin restoration: B A C K  _ _"
    new "Comece a restauração: V O L T _ _"

    # game/inAlley.rpy:5520
    old "Begin restoration: B A C K  U _"
    new "Comece a restauração: V O L T A _"

    # game/inAlley.rpy:5520
    old "Restoration Complete: B A C K  U P"
    new "Restauração concluída: V O L T A R"

    # game/inAlley.rpy:5725
    old "{b}B A C K  U P{/b}"
    new "{b}V O L T A R  S A V E{/b}"

    # game/inAlley.rpy:5748
    old "gO HOmE..."
    new "iR PAra CAsA..."

    # game/inAlley.rpy:5925
    old "Pick up plushie."
    new "Pegar a pelúcia. "

    # game/inAlley.rpy:5925
    old "Leave."
    new "Sair."
