﻿# TODO: Translation updated at 2024-11-02 03:15

# game/endgame.rpy:374
translate pt_br encounterCat_a20cefa7:

    # "..."
    "..."

# game/endgame.rpy:375
translate pt_br encounterCat_07879361:

    # "Back again, are you?"
    "De volta, hein?"

# game/endgame.rpy:376
translate pt_br encounterCat_310653c5:

    # "You've already reached the best outcome you're going to get."
    "Você já alcançou o melhor resultado possível."

# game/endgame.rpy:377
translate pt_br encounterCat_4961a2a7:

    # "What more are you hoping to achieve?"
    "O que mais você espera conseguir?"

# game/endgame.rpy:378
translate pt_br encounterCat_8dabefc6:

    # ".."
    ".."

# game/endgame.rpy:379
translate pt_br encounterCat_a20cefa7_1:

    # "..."
    "..."

# game/endgame.rpy:382
translate pt_br encounterCat_ebdf273c:

    # "You wouldn't be thinking of going back on your promise to join me..."
    "Você não estaria pensando em voltar atrás na sua promessa de se juntar a mim..."

# game/endgame.rpy:383
translate pt_br encounterCat_810e5b21:

    # "{color=#FF0000}...right?{/color}"
    "{color=#FF0000}...certo?{/color}"

# game/endgame.rpy:384
translate pt_br encounterCat_beec6484:

    # "Have I not yet satisfied your curiosity?"
    "Ainda não consegui satisfazer sua curiosidade?"

# game/endgame.rpy:387
translate pt_br encounterCat_a20cefa7_2:

    # "..."
    "..."

# game/endgame.rpy:388
translate pt_br encounterCat_90b68c87:

    # you "..?"
    you "..?"

# game/endgame.rpy:389
translate pt_br encounterCat_19d97e41:

    # you "{i}Where... {w}Where am I..?{/i}"
    you "{i}Onde... {w}Onde eu tô..?{/i}"

# game/endgame.rpy:390
translate pt_br encounterCat_a20cefa7_3:

    # "..."
    "..."

# game/endgame.rpy:391
translate pt_br encounterCat_3fdc70e9:

    # "{alpha=0.4}And so...{/alpha}"
    "{alpha=0.4}E então...{/alpha}"

# game/endgame.rpy:392
translate pt_br encounterCat_ef29c92b:

    # "{alpha=0.7}You find yourself here...{/alpha}"
    "{alpha=0.7}Você se encontra aqui...{/alpha}"

# game/endgame.rpy:393
translate pt_br encounterCat_5032d21f:

    # "...yet again."
    "...mais uma vez."

# game/endgame.rpy:394
translate pt_br encounterCat_28b3ac41:

    # you "!!"
    you "!!"

# game/endgame.rpy:395
translate pt_br encounterCat_5991bb93:

    # you "Wha-"
    you "O qu-"

# game/endgame.rpy:396
translate pt_br encounterCat_548c1316:

    # you "Who said that?!"
    you "Quem disse isso?!"

# game/endgame.rpy:397
translate pt_br encounterCat_964f0af4:

    # you "And where is {i}\"here\"?{/i} {w}I can't {i}see{/i} anything!"
    you "E onde é {i}\"aqui\"?{/i} {w}Eu não consigo {i}ver{/i} nada!"

# game/endgame.rpy:398
translate pt_br encounterCat_a20cefa7_4:

    # "..."
    "..."

# game/endgame.rpy:399
translate pt_br encounterCat_f27122fb:

    # who "Why..."
    who "Ora..."

# game/endgame.rpy:405
translate pt_br encounterCat_a995ea3c:

    # cat "...\"here\" is {i}here,{/i} silly!"
    cat "...\"aqui\" é {i}aqui,{/i} bobinho!"

# game/endgame.rpy:407
translate pt_br encounterCat_56ebb028:

    # you "!!!"
    you "!!!"

# game/endgame.rpy:408
translate pt_br encounterCat_2a440d93:

    # you "Y... You're..."
    you "V... Você é..."

# game/endgame.rpy:410
translate pt_br encounterCat_49e410bc:

    # cat "Well? {w}Do you remember me, this time?"
    cat "Bem? {w}Você se lembra de mim, dessa vez?"

# game/endgame.rpy:412
translate pt_br encounterCat_187ca1e5:

    # cat "I never would've thought of my self as being forgettable..."
    cat "Nunca me imaginei como alguém fácil de esquecer..."

# game/endgame.rpy:414
translate pt_br encounterCat_cfb7cc33:

    # cat "...but I suppose there's a first time for everything~!"
    cat "...mas, pelo visto, sempre há uma primeira vez para tudo~!"

# game/endgame.rpy:416
translate pt_br encounterCat_dae0ec55:

    # you "..."
    you "..."

# game/endgame.rpy:417
translate pt_br encounterCat_48bb4310:

    # "Your memory slowly pieces together fragments of a moment... {w}An encounter..."
    "Sua memória lentamente junta os pedaços de um momento... {w}Um encontro..."

# game/endgame.rpy:418
translate pt_br encounterCat_b4fa62a0:

    # you "A cat in... {w}in an alley..."
    you "Um gato em... {w}em um beco..."

# game/endgame.rpy:419
translate pt_br encounterCat_b5914067:

    # you "I... {w}took you home with me... {w}didn't I?"
    you "Eu... {w}te levei para casa comigo... {w}não levei?"

# game/endgame.rpy:421
translate pt_br encounterCat_c46e050e:

    # cat "{size=+5}{b}Correct!{/b}{/size}" with hpunch
    cat "{size=+5}{b}Correto!{/b}{/size}" with hpunch

# game/endgame.rpy:423
translate pt_br encounterCat_e32fc389:

    # cat "You were daydreaming so long, you even had {i}me{/i} worried! {w}Can you imagine that?"
    cat "Você ficou sonhando acordado por tanto tempo que até {i}eu{/i} fiquei preocupado! {w}Dá pra imaginar?"

# game/endgame.rpy:425
translate pt_br encounterCat_42fcd5d4:

    # cat "Here I am indulging a little in playing with my prey..."
    cat "Aqui estou eu, me divertindo um pouco brincando com minha presa..."

# game/endgame.rpy:427
translate pt_br encounterCat_8cf8606b:

    # cat "...only for you to completely zone out on me!"
    cat "...e você simplesmente fica distraído!"

# game/endgame.rpy:429
translate pt_br encounterCat_dc1e93f2:

    # cat "The game's no fun if you're not {i}present{/i}, you know..."
    cat "A brincadeira não tem graça se você não estiver {i}presente{/i}, sabe..."

# game/endgame.rpy:431
translate pt_br encounterCat_99f64913:

    # you "I..."
    you "Eu..."

# game/endgame.rpy:432
translate pt_br encounterCat_d26ddf18:

    # you "No, I {i}don't{/i} know! I don't understand what's going on at all!"
    you "Não, eu {i}não{/i} sei! Eu não tô entendendo nada do que tá acontecendo!"

# game/endgame.rpy:434
translate pt_br encounterCat_10cb6b4e:

    # cat "Hmm... Curious as you are, I should've expected that you'd have questions..."
    cat "Hmm... Curioso como você é, eu devia imaginar que teria perguntas..."

# game/endgame.rpy:436
translate pt_br encounterCat_c3e84f44:

    # cat "Well, I suppose you've put me in a good enough mood to be generous and hear you out..."
    cat "Bem, acho que você me deixou de bom humor o suficiente para ser generoso e ouvir o que tem a dizer..."

# game/endgame.rpy:438
translate pt_br encounterCat_6a840c3c:

    # cat "Very well..."
    cat "Muito bem..."

# game/endgame.rpy:445
translate pt_br questionCat_44076b5e:

    # cat "What would you like to know~?"
    cat "O que você gostaria de saber~?"

# game/endgame.rpy:466
translate pt_br noMoreQuestions_be011780:

    # "Really?"
    "É mesmo?"

# game/endgame.rpy:467
translate pt_br noMoreQuestions_b132aa27:

    # "Perhaps you're not as curious as I thought..."
    "Talvez você não seja tão curioso quanto pensei..."

# game/endgame.rpy:468
translate pt_br noMoreQuestions_b3e12ea5:

    # "Still..."
    "Ainda assim..."

# game/endgame.rpy:474
translate pt_br moreQuestions_e92c7456:

    # "Well then... I'll ask again..."
    "Muito bem... Vou perguntar de novo..."

# game/endgame.rpy:475
translate pt_br moreQuestions_92e00d5e:

    # "I'm sure you'll pick the correct answer."
    "Tenho certeza de que você escolherá a resposta correta."

# game/endgame.rpy:481
translate pt_br moreQuestions_cc5f9d9d:

    # "Will you join me..."
    "Você vai se juntar a mim..."

# game/endgame.rpy:482
translate pt_br moreQuestions_560e6e27:

    # "...or perish?"
    "...ou perecer?"

# game/endgame.rpy:485
translate pt_br moreQuestions_6b3fef84:

    # "No?"
    "Não?"

# game/endgame.rpy:486
translate pt_br moreQuestions_76297ef4:

    # "Well, in that case..."
    "Bem, nesse caso..."

# game/endgame.rpy:502
translate pt_br questionCat1_c495dba3:

    # cat "Hm... It's the first thing that came to mind, really."
    cat "Hm... Foi a primeira coisa que me veio à mente, na verdade."

# game/endgame.rpy:504
translate pt_br questionCat1_64bab19b:

    # cat "You were on the brink of death..."
    cat "Você estava à beira da morte..."

# game/endgame.rpy:505
translate pt_br questionCat1_0c0abb1c:

    # cat "But instead of watching your life flash before your eyes..."
    cat "Mas, em vez de ver sua vida passar diante dos olhos..."

# game/endgame.rpy:507
translate pt_br questionCat1_fa75ee80:

    # cat "...you got stuck reliving the moment we met... {w}subconsciously coming up with scenarios in which you managed to survive."
    cat "...você ficou preso relembrando o momento em que nos conhecemos... {w}subconscientemente criando cenários em que conseguiria sobreviver."

# game/endgame.rpy:509
translate pt_br questionCat1_e15e92be:

    # cat "Well. {w}Maybe you {i}would{/i} have... but..."
    cat "Bem. {w}Talvez você {i}conseguisse{/i}... mas..."

# game/endgame.rpy:511
translate pt_br questionCat1_c0153aab:

    # cat "I couldn't resist messing with your imagination a little bit~"
    cat "Não consegui resistir e brinquei um pouco com sua imaginação~"

# game/endgame.rpy:513
translate pt_br questionCat1_7b103b48:

    # cat "You {i}did{/i} just start ignoring me out of nowhere, after all."
    cat "Afinal, você {i}começou{/i} a me ignorar do nada."

# game/endgame.rpy:515
translate pt_br questionCat1_e24fd6e6:

    # cat "You know by now how much I love attention~"
    cat "Você já sabe o quanto eu adoro atenção~"

# game/endgame.rpy:517
translate pt_br questionCat1_5f80ea18:

    # cat "Your little thought experiments were rather amusing..."
    cat "Seus pequenos experimentos mentais foram bastante divertidos..."

# game/endgame.rpy:518
translate pt_br questionCat1_315adaa1:

    # cat "But... If I might say..."
    cat "Mas... Se me permite dizer..."

# game/endgame.rpy:520
translate pt_br questionCat1_23467746:

    # cat "...you must have had a {i}pretty{/i} dull life to forgo indulging in precious memories of bygone days..."
    cat "...você deve ter tido uma vida {i}bem{/i} chata para deixar de se entregar a memórias preciosas de dias que se foram..."

# game/endgame.rpy:521
translate pt_br questionCat1_d06d7a92:

    # cat "...in favor of daydreaming about a single encounter..."
    cat "...em vez disso, sonhou acordado sobre um único encontro..."

# game/endgame.rpy:523
translate pt_br questionCat1_05c50243:

    # cat "...over and over and over again."
    cat "...várias e várias vezes."

# game/endgame.rpy:525
translate pt_br questionCat1_6de8f265:

    # cat "I've heard of having regrets on one's deathbed, but this has been ridiculous!"
    cat "Já ouvi falar de arrependimentos no leito de morte, mas isso tem sido ridículo!"

# game/endgame.rpy:526
translate pt_br questionCat1_a20cefa7:

    # "..."
    "..."

# game/endgame.rpy:528
translate pt_br questionCat1_d4a2484f:

    # cat "...Ridiculously {i}intriguing,{/i} that is!"
    cat "...Ridiculamente {i}intrigante,{/i} quero dizer!"

# game/endgame.rpy:530
translate pt_br questionCat1_89d17f6f:

    # cat "Or perhaps rather than regrets, {i}{b}I{/b}{/i} was what you found intriguing~?"
    cat "Ou talvez, em vez de arrependimentos, foi {i}{b}eu{/b}{/i} quem você achou intrigante~?"

# game/endgame.rpy:535
translate pt_br questionCat1_153670a4:

    # cat "You're lucid, I'd say. Since you've finally remembered me and all..."
    cat "Você está lúcido, eu diria. Já que finalmente se lembrou de mim e tudo mais..."

# game/endgame.rpy:537
translate pt_br questionCat1_f61b0df4:

    # cat "Seems you're finally ready to end this farce... amusing as it has been."
    cat "Parece que você está finalmente pronto para acabar com essa farsa... por mais divertida que tenha sido."

# game/endgame.rpy:544
translate pt_br questionCat2_78b85363:

    # cat "Inside your head, silly!"
    cat "Dentro da sua cabeça, bobo!"

# game/endgame.rpy:546
translate pt_br questionCat2_3b6637ed:

    # cat "The real versions of ourselves are halted in time back in your reality. Though I doubt much time has actually passed."
    cat "Nossas versões reais estão suspensas no tempo na sua realidade. Embora eu duvide que muito tempo tenha realmente passado."

# game/endgame.rpy:547
translate pt_br questionCat2_cea70401:

    # cat "These things tend to happen in the blink of an eye after all..."
    cat "Essas coisas tendem a acontecer em um piscar de olhos, afinal..."

# game/endgame.rpy:549
translate pt_br questionCat2_90ceece1:

    # cat "Well... {w}{i}usually,{/i} anyway."
    cat "Bem... {w}{i}geralmente,{/i} de qualquer forma."

# game/endgame.rpy:558
translate pt_br questionCat3_91c433ff:

    # cat "Oh don't be so dramatic~"
    cat "Ah, não seja tão dramático~"

# game/endgame.rpy:560
translate pt_br questionCat3_628a0e7a:

    # cat "I don't {i}keep{/i} killing you! I haven't even killed you {i}once{/i} yet..."
    cat "Eu não {i}fico{/i} te matando! Eu não cheguei a te matar nem {i}uma vez{/i} ainda..."

# game/endgame.rpy:562
translate pt_br questionCat3_d29cd430:

    # cat "Those were just thoughts and ideas floating around in your head..."
    cat "Eram apenas pensamentos e ideias pairando pela sua cabeça..."

# game/endgame.rpy:564
translate pt_br questionCat3_03a9b169:

    # cat "...that I admittedly had a little fun with."
    cat "...com os quais eu admito ter me divertido um pouco."

# game/endgame.rpy:566
translate pt_br questionCat3_faf0ac79:

    # cat "Can you blame me? I would've gotten {i}bored{/i} just waiting for you to wake up."
    cat "Dá pra me culpar? Eu teria ficado {i}entediado{/i} só esperando você acordar."

# game/endgame.rpy:571
translate pt_br questionCat3_444467b1:

    # cat "Hm, yes... I suppose I was curious to see if you actually would."
    cat "Hum, sim... Suponho que eu estava curioso para ver se você realmente faria isso."

# game/endgame.rpy:573
translate pt_br questionCat3_bbec1b37:

    # cat "You certainly didn't hold back... {w}You must have been quite angry with me~"
    cat "Você com certeza não se conteve... {w}Você deve ter ficado bem bravo comigo~"

# game/endgame.rpy:575
translate pt_br questionCat3_142ac461:

    # cat "It's fine though. You know what they say about curiosity, yes?"
    cat "Mas tudo bem. Você sabe o que dizem sobre a curiosidade, não é?"

# game/endgame.rpy:577
translate pt_br questionCat3_9d6e8628:

    # cat "It was my own choice. And besides..."
    cat "Foi uma escolha minha. E além disso..."

# game/endgame.rpy:581
translate pt_br questionCat3_7b530356:

    # cat "{color=#FF0000}...I got you back, didn't I~?{/color}"
    cat "{color=#FF0000}...Eu trouxe você de volta, não foi~?{/color}"

# game/endgame.rpy:590
translate pt_br questionCat4_346e4804:

    # cat "..? What do you mean?"
    cat "..? O que quer dizer?"

# game/endgame.rpy:591
translate pt_br questionCat4_723b2270:

    # cat "I've been talking to you all along."
    cat "Eu sempre estive falando com você."

# game/endgame.rpy:593
translate pt_br questionCat4_2537f593:

    # cat "Intriguing as your imagination is, it would've ran wild without my help."
    cat "Por mais intrigante que seja sua imaginação, ela teria se descontrolado sem a minha ajuda."

# game/endgame.rpy:595
translate pt_br questionCat4_6dea765f:

    # "I was {b}guiding{/b} you the {i}whole{/i} time..."
    "Eu estava {b}guiando{/b} você o tempo {i}todo{/i}..."

# game/endgame.rpy:596
translate pt_br questionCat4_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/endgame.rpy:598
translate pt_br questionCat4_a7b878cb:

    # "Didn't you hear me in your thoughts..?"
    "Você não me ouviu nos seus pensamentos..?"

# game/endgame.rpy:600
translate pt_br questionCat4_40a8ff0b:

    # "Like {i}this~?{/i}"
    "Tipo {i}assim~?{/i}"

# game/endgame.rpy:601
translate pt_br questionCat4_dae0ec55:

    # you "..."
    you "..."

# game/endgame.rpy:606
translate pt_br questionCat4_4ee1bb0a:

    # cat "I'm quite powerful, yes... but also not so much."
    cat "Sou bastante poderoso, sim... mas nem tanto assim."

# game/endgame.rpy:607
translate pt_br questionCat4_f6a21734:

    # you "{i}What does {b}that{/b} mean..?{/i}"
    you "{i}E o que {b}isso{/b} quer dizer..?{/i}"

# game/endgame.rpy:608
translate pt_br questionCat4_6f7f3d7e:

    # cat "Besides, what makes you so sure I'm a cat?"
    cat "Além disso, o que te faz ter tanta certeza de que sou um gato?"

# game/endgame.rpy:610
translate pt_br questionCat4_9f54e05d:

    # cat "My appearance? I doubt I resemble any cat you've ever seen before, right?"
    cat "Minha aparência? Duvido que eu me pareça com qualquer gato que você já tenha visto, certo?"

# game/endgame.rpy:612
translate pt_br questionCat4_8e3ec6ea:

    # you "Then what the hell are you, if you're not a cat?"
    you "Então, se não é um gato, que porra é você?"

# game/endgame.rpy:614
translate pt_br questionCat4_2373210e:

    # cat "I didn't say I {i}wasn't{/i} a cat, did I?"
    cat "Eu não disse que {i}não sou{/i} um gato, disse?"

# game/endgame.rpy:616
translate pt_br questionCat4_dae0ec55_1:

    # you "..."
    you "..."

# game/endgame.rpy:617
translate pt_br questionCat4_7f0ac95c:

    # cat "..."
    cat "..."

# game/endgame.rpy:620
translate pt_br questionCat4_0c9311a0:

    # cat "I could be a demon... {w}or a god... {w}or an alien from another galaxy... {w}or an interdimensional abomination..."
    cat "Posso ser um demônio... {w}ou um deus... {w}ou um alienígena de outra galáxia... {w}ou uma abominação interdimensional..."

# game/endgame.rpy:622
translate pt_br questionCat4_7338daf3:

    # cat "...or I really {i}could{/i} just be a cat."
    cat "...ou eu realmente {i}posso{/i} ser apenas um gato."

# game/endgame.rpy:623
translate pt_br questionCat4_0239290e:

    # cat "It doesn't {i}really{/i} matter what I am, does it?"
    cat "Não importa {i}de verdade{/i} o que eu sou, importa?"

# game/endgame.rpy:625
translate pt_br questionCat4_1c318240:

    # cat "Certainly what I can {b}do{/b} would be a more pressing matter, yes?"
    cat "Certamente o que eu posso {b}fazer{/b} seria uma questão mais urgente, não acha?"

# game/endgame.rpy:626
translate pt_br questionCat4_a00b7c5d:

    # you "A real cat couldn't have done all this!"
    you "Um gato de verdade não poderia ter feito tudo isso!"

# game/endgame.rpy:628
translate pt_br questionCat4_5ef345ac:

    # cat "You're really hung up on appearances, aren't you..."
    cat "Você realmente está preso às aparências, não é..."

# game/endgame.rpy:630
translate pt_br questionCat4_ec53df3b:

    # cat "Do you have some kind of proof that cats {i}don't{/i} possess powers like mine? {w}I doubt it~"
    cat "Você tem algum tipo de prova de que gatos {i}não{/i} possuem poderes como os meus? {w}Duvido~"

# game/endgame.rpy:632
translate pt_br questionCat4_89c7e144:

    # cat "And you know, it's pretty rude of you to keep going on and on about {i}what{/i} I am..."
    cat "E sabe, é bem rude da sua parte ficar falando e falando sobre {i}o que{/i} eu sou..."

# game/endgame.rpy:634
translate pt_br questionCat4_6ab4c9ee:

    # cat "...before you've even asked {i}who{/i} I am or what my {i}name{/i} is!"
    cat "...antes mesmo de perguntar {i}quem{/i} eu sou ou qual é o meu {i}nome{/i}!"

# game/endgame.rpy:636
translate pt_br questionCat4_dae0ec55_2:

    # you "..."
    you "..."

# game/endgame.rpy:637
translate pt_br questionCat4_976ad5e8:

    # you "*sigh* Okay... then what's your name-"
    you "*suspiro* Tá... qual é o seu nome então-"

# game/endgame.rpy:639
translate pt_br questionCat4_7494f9b5:

    # cat "Well I'm not going to tell you {i}{b}now!{/b}{/i}"
    cat "Bom, eu não vou te contar {i}{b}agora!{/b}{/i}"

# game/endgame.rpy:641
translate pt_br questionCat4_bf0f44ce:

    # cat "Learn some manners first and we'll see. {w}Well..."
    cat "Aprenda um pouco de educação primeiro e veremos. {w}Bem..."

# game/endgame.rpy:643
translate pt_br questionCat4_23bc3a7d:

    # cat "...maybe in your {i}next{/i} life, anyway."
    cat "...talvez na sua {i}próxima{/i} vida, quem sabe."

# game/endgame.rpy:652
translate pt_br questionCat5_0a5f3e64:

    # cat "Hmm..."
    cat "Hmm..."

# game/endgame.rpy:653
translate pt_br questionCat5_9dde11ef:

    # cat "Well if we're talking about my original goals... those are a bit personal, I'd say~"
    cat "Se estamos falando dos meus objetivos originais... são um pouco pessoais, eu diria~"

# game/endgame.rpy:654
translate pt_br questionCat5_dae0ec55:

    # you "..."
    you "..."

# game/endgame.rpy:656
translate pt_br questionCat5_b3148994:

    # cat "And anyway, things have changed!"
    cat "E, de qualquer forma, as coisas mudaram!"

# game/endgame.rpy:657
translate pt_br questionCat5_c5905ab0:

    # cat "Right now?"
    cat "Agora?"

# game/endgame.rpy:659
translate pt_br questionCat5_ea6e786a:

    # cat "Well presently, I'd like to have some more fun with you. {w}Your company has been very entertaining thus far."
    cat "Bem, no momento, eu gostaria de me divertir um pouco mais com você. {w}Sua companhia tem sido muito divertida até agora."

# game/endgame.rpy:661
translate pt_br questionCat5_03ab381b:

    # cat "Given more time... {w}and under different circumstances... {w}perhaps we could've even been..."
    cat "Dado mais tempo... {w}e em outras circunstâncias... {w}quem sabe nós até pudéssemos ter sido..."

# game/endgame.rpy:663
translate pt_br questionCat5_7f0ac95c:

    # cat "..."
    cat "..."

# game/endgame.rpy:665
translate pt_br questionCat5_c38e7b98:

    # cat "Well... All good things must come to an end."
    cat "Bem... tudo que é bom precisa chegar ao fim."

# game/endgame.rpy:666
translate pt_br questionCat5_1029e671:

    # cat "You can't truly want to spend what little time you have left in regret and delusion, right?"
    cat "Você não pode realmente querer passar o pouco tempo que lhe resta em arrependimento e ilusão, certo?"

# game/endgame.rpy:668
translate pt_br questionCat5_d4182ef1:

    # cat "Alternatively, {w}I'm also quite {i}hungry{/i} after waiting so long for you to wake up."
    cat "Por outro lado, {w}também estou bastante {i}faminto{/i} depois de esperar tanto para você acordar."

# game/endgame.rpy:670
translate pt_br questionCat5_fd56ebb0:

    # cat "At this point, I could go either way."
    cat "Neste ponto, tanto faz para mim."

# game/endgame.rpy:677
translate pt_br finalQuestion_1e7e7eba:

    # cat "Have I satisfied your curiosity now?"
    cat "Satisfiz sua curiosidade agora?"

# game/endgame.rpy:679
translate pt_br finalQuestion_dae0ec55:

    # you "..."
    you "..."

# game/endgame.rpy:680
translate pt_br finalQuestion_97e7bd6b:

    # you "I just have one more question..."
    you "Só tenho mais uma pergunta..."

# game/endgame.rpy:681
translate pt_br finalQuestion_36d620f5:

    # you "Why me? Why call out to {i}me{/i} of all people..?"
    you "Por que eu? Por que logo {i}eu{/i} fui chamado no meio de tanta gente..?"

# game/endgame.rpy:683
translate pt_br finalQuestion_91cd85d7:

    # cat "All I did was call out for {i}someone{/i} to hear me."
    cat "Tudo o que eu fiz foi chamar para {i}alguém{/i} me ouvir."

# game/endgame.rpy:684
translate pt_br finalQuestion_aae09cc1:

    # cat "I called out... and you were the first person who came to me. {w}Simple as that."
    cat "Eu chamei... e você foi a primeira pessoa que veio até mim. {w}Simples assim."

# game/endgame.rpy:686
translate pt_br finalQuestion_dae0ec55_1:

    # you "..."
    you "..."

# game/endgame.rpy:688
translate pt_br finalQuestion_25add7f4:

    # cat "...Were you hoping for some special reason?"
    cat "...Você estava esperando alguma razão especial?"

# game/endgame.rpy:689
translate pt_br finalQuestion_dae0ec55_2:

    # you "..."
    you "..."

# game/endgame.rpy:691
translate pt_br finalQuestion_e304cf84:

    # cat "...I'm afraid I don't have one."
    cat "...Receio não ter nenhuma."

# game/endgame.rpy:693
translate pt_br finalQuestion_5d037f74:

    # cat "Everything I've come to like about you were things discovered {i}after{/i} our initial encounter."
    cat "Tudo o que passei a gostar em você foram coisas que descobri {i}depois{/i} do nosso primeiro encontro."

# game/endgame.rpy:695
translate pt_br finalQuestion_9e1cd95d:

    # you "So there's no big reason for any of this?"
    you "Então não tem um grande motivo por trás de nada disso?"

# game/endgame.rpy:696
translate pt_br finalQuestion_c86c8dcc:

    # cat "The reason is far less interesting than the results that came about from our interaction."
    cat "O motivo é bem menos interessante do que os resultados que vieram da nossa interação."

# game/endgame.rpy:698
translate pt_br finalQuestion_1ff3d913:

    # cat "I only called to satiate my hunger, but in doing so, I found something far more valuable."
    cat "Eu só chamei para saciar minha fome, mas, ao fazer isso, encontrei algo muito mais valioso."

# game/endgame.rpy:700
translate pt_br finalQuestion_8f6f37e7:

    # cat "I know for a fact that regardless of how this plays out..."
    cat "Tenho certeza de que, independentemente de como isso termine..."

# game/endgame.rpy:702
translate pt_br finalQuestion_f1cd85f2:

    # cat "...I will never forget you."
    cat "...nunca vou me esquecer de você."

# game/endgame.rpy:703
translate pt_br finalQuestion_fec1fe3c:

    # you "What do you mean?"
    you "Como assim?"

# game/endgame.rpy:708
translate pt_br returnOrigin_bf22af67:

    # cat "I've taken a liking to you, human. And so... I'll grant you another chance..."
    cat "Eu criei uma afeição por você, humano. Então... vou te conceder outra chance..."

# game/endgame.rpy:714
translate pt_br returnOrigin_42029590:

    # cat "Another choice..."
    cat "Outra escolha..."

# game/endgame.rpy:721
translate pt_br returnOrigin_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/endgame.rpy:722
translate pt_br returnOrigin_8e03588c:

    # you "{i}This place is...{/i}"
    you "{i}Este lugar é...{/i}"

# game/endgame.rpy:726
translate pt_br returnOrigin_a20cefa7:

    # "..."
    "..."

# game/endgame.rpy:730
translate pt_br returnOrigin_9c3e8dd9:

    # "You {i}{b}remember{/b}{/i} this place..."
    "Você {i}{b}se lembra{/b}{/i} deste lugar..."

# game/endgame.rpy:734
translate pt_br returnOrigin_f1426fe6:

    # "Being chased..."
    "Sendo perseguido..."

# game/endgame.rpy:738
translate pt_br returnOrigin_626dfd4e:

    # "Being {b}hunted{/b}..."
    "Sendo {b}caçado{/b}..."

# game/endgame.rpy:742
translate pt_br returnOrigin_c204d717:

    # "Being afraid..."
    "Sentindo medo..."

# game/endgame.rpy:747
translate pt_br returnOrigin_7591fb3e:

    # "{b}So{/b} afraid..."
    "{b}Tanto{/b} medo..."

# game/endgame.rpy:748
translate pt_br returnOrigin_642290f0:

    # "That fear that {i}so{/i} attracted me to you..."
    "Esse medo que {i}tanto{/i} me atraiu para você..."

# game/endgame.rpy:749
translate pt_br returnOrigin_eee55388:

    # "...that instinctive desperation to survive..."
    "...esse desespero instintivo de sobreviver..."

# game/endgame.rpy:750
translate pt_br returnOrigin_f7d54ac5:

    # "I craved it all..."
    "Eu ansiava por tudo isso..."

# game/endgame.rpy:751
translate pt_br returnOrigin_738c58c2:

    # "As I am the origin of those delectable emotions..."
    "Afinal, sou a origem dessas emoções deliciosas..."

# game/endgame.rpy:752
translate pt_br returnOrigin_850be2a3:

    # "...you are {i}already{/i} \ {b}m i n e .{/b}"
    "...você {i}já{/i} é \ {b}m e u .{/b}"

# game/endgame.rpy:753
translate pt_br returnOrigin_a20cefa7_1:

    # "..."
    "..."

# game/endgame.rpy:754
translate pt_br returnOrigin_bf0874e3:

    # "But..."
    "Mas..."

# game/endgame.rpy:755
translate pt_br returnOrigin_9042cfe9:

    # "I will still permit you the chance to accept the reality of your fate."
    "Eu ainda lhe darei a chance de aceitar a realidade do seu destino."

# game/endgame.rpy:756
translate pt_br returnOrigin_186f39f2:

    # cat "Human..."
    cat "Humano..."

# game/endgame.rpy:757
translate pt_br returnOrigin_e8f7c347:

    # cat "Join me..."
    cat "Junte-se a mim..."

# game/endgame.rpy:758
translate pt_br returnOrigin_aca58e0a:

    # cat "...or perish."
    cat "...ou pereça."

# game/endgame.rpy:776
translate pt_br joinCat_cd8ba4c0:

    # cat "Splendid."
    cat "Esplêndido."

# game/endgame.rpy:778
translate pt_br joinCat_1ab5bac9:

    # cat "Come forward, my human."
    cat "Aproxime-se, meu humano."

# game/endgame.rpy:781
translate pt_br joinCat_2c7927e3:

    # "You step forward and pick up the cat."
    "Você dá um passo a frente e pega o gato."

# game/endgame.rpy:782
translate pt_br joinCat_e00dae14:

    # "You cradle it in your arms, reaching up to scratch its head."
    "Você o aconchega em seus braços, estendendo a mão para esfregar sua cabeça."

# game/endgame.rpy:784
translate pt_br joinCat_67107e6c:

    # cat "Purr..."
    cat "Purr..."

# game/endgame.rpy:787
translate pt_br joinCat_f8342e66:

    # "Suddenly..."
    "De repente..."

# game/endgame.rpy:788
translate pt_br joinCat_b0821d91:

    # you "Wh..?"
    you "O qu..?"

# game/endgame.rpy:789
translate pt_br joinCat_d401595a:

    # "...you start to feel... {w}sleepy."
    "...você começa a se sentir... {w}sonolento."

# game/endgame.rpy:790
translate pt_br joinCat_69c0188b:

    # "But the sudden wave of fatigue doesn't cause you to sway on your feet or stumble at all."
    "Mas a onda repentina de fadiga não faz você desequilibrar ou tropeçar."

# game/endgame.rpy:791
translate pt_br joinCat_cedc8e66:

    # you "What's... Wha's hap... pen...?"
    you "O que... O que tá acon... ecendo...?"

# game/endgame.rpy:794
translate pt_br joinCat_5e8da3e5:

    # cat "Shh..."
    cat "Shh..."

# game/endgame.rpy:795
translate pt_br joinCat_b474b001:

    # cat "Don't worry... You no longer need to worry about anything anymore..."
    cat "Não se preocupe... Você não precisa se preocupar com mais nada, nunca mais..."

# game/endgame.rpy:796
translate pt_br joinCat_85b30929:

    # cat "Just sleep... and dream those sweet, sweet dreams... for me..."
    cat "Apenas durma... durma e sonhe com os anjos... por mim..."

# game/endgame.rpy:797
translate pt_br joinCat_dae0ec55:

    # you "..."
    you "..."

# game/endgame.rpy:798
translate pt_br joinCat_2f74697b:

    # you "... {w}... {w}..."
    you "... {w}... {w}..."

# game/endgame.rpy:799
translate pt_br joinCat_60daf151:

    # cat "...Excellent."
    cat "...Excelente."

# game/endgame.rpy:802
translate pt_br joinCat_7a46e73a:

    # cat "With this, you will soon become a part of me..."
    cat "Com isso, você em breve se tornará parte de mim..."

# game/endgame.rpy:806
translate pt_br joinCat_8dabefc6:

    # ".."
    ".."

# game/endgame.rpy:807
translate pt_br joinCat_a20cefa7:

    # "..."
    "..."

# game/endgame.rpy:808
translate pt_br joinCat_a110b86c:

    # "Ending 37: \ {b}F o r e v e r{/b}"
    "Final 37: \ {b}P a r a  S e m p r e{/b}"

# game/endgame.rpy:820
translate pt_br refuseCat_4599308d:

    # cat ".."
    cat ".."

# game/endgame.rpy:821
translate pt_br refuseCat_7f0ac95c:

    # cat "..."
    cat "..."

# game/endgame.rpy:822
translate pt_br refuseCat_1280d577:

    # cat "I see. Then there's nothing left to say."
    cat "Entendo. Então não há mais nada a dizer."

# game/endgame.rpy:825
translate pt_br refuseCat_dae0ec55:

    # you "..."
    you "..."

# game/endgame.rpy:826
translate pt_br refuseCat_401c177b:

    # cat "...{w}\"Resigned to your fate...\""
    cat "...{w}\"Conformado com o seu destino...\""

# game/endgame.rpy:827
translate pt_br refuseCat_568bc2ee:

    # "...you finally {w}{b} t u r n {w} a r o u n d .{/b}"
    "...você finalmente {w}{b} s e {w} v i r a .{/b}"

# game/endgame.rpy:834
translate pt_br refuseCat_8dabefc6:

    # ".."
    ".."

# game/endgame.rpy:835
translate pt_br refuseCat_a20cefa7:

    # "..."
    "..."

# game/endgame.rpy:836
translate pt_br refuseCat_998be557:

    # "...It's {i}{b}enormous.{/b}{/i}"
    "...É {i}{b}enorme.{/b}{/i}"

# game/endgame.rpy:839
translate pt_br refuseCat_073f9da6:

    # "Shapeless... billowing like thick smoke in the wind..."
    "Desforme... ondulando como fumaça espessa ao vento..."

# game/endgame.rpy:841
translate pt_br refuseCat_2e28e1bd:

    # "The shadowlike entity towers above you..."
    "A entidade sombria se ergue acima de você..."

# game/endgame.rpy:842
translate pt_br refuseCat_9e637eeb:

    # "So high it looks like the sky poured it down to Earth... is {i}still{/i} pouring it, even..."
    "Tão alta que parece que o céu a derramou sobre a Terra... e {i}ainda{/i} está derramando..."

# game/endgame.rpy:845
translate pt_br refuseCat_1d4c6563:

    # "It is... unfathomable... that your tiny world is even able to stand..."
    "É... incompreensível... que seu ínfimo mundo sequer consiga suportar..."

# game/endgame.rpy:847
translate pt_br refuseCat_1aee61d8:

    # "...under the weight of the {i}reality{/i} of such a being's existence..."
    "...sob o peso da {i}realidade{/i} da existência de tal ser..."

# game/endgame.rpy:848
translate pt_br refuseCat_57d2ac22:

    # "...and that {i}you{/i} and your fragile mind haven't fallen to ruin as well."
    "...e que {i}você{/i} e sua mente frágil não tenham caído em ruína também."

# game/endgame.rpy:849
translate pt_br refuseCat_a20cefa7_1:

    # "..."
    "..."

# game/endgame.rpy:863
translate pt_br refuseCat_bedb2983:

    # "You step forward into the monstrous miasma..."
    "Você dá um passo à frente no miasma monstruoso..."

# game/endgame.rpy:874
translate pt_br refuseCat_a20cefa7_2:

    # "..."
    "..."

# game/endgame.rpy:876
translate pt_br refuseCat_b290aff1:

    # "...and offer yourself to it."
    "...e se oferece a isso."

# game/endgame.rpy:893
translate pt_br refuseCat_8dabefc6_1:

    # ".."
    ".."

# game/endgame.rpy:894
translate pt_br refuseCat_a20cefa7_3:

    # "..."
    "..."

# game/endgame.rpy:895
translate pt_br refuseCat_ce151d3e:

    # "{b}{size=+5}d a r k n e s s . . .{/size}{/b}"
    "{b}{size=+5}e s c u r i d ã o . . .{/size}{/b}"

# game/endgame.rpy:896
translate pt_br refuseCat_9255f3aa:

    # "Surrounded by pure and absolute darkness..."
    "Cercado por uma absoluta e pura escuridão..."

# game/endgame.rpy:897
translate pt_br refuseCat_1ecc4a0c:

    # "...you are very suddenly hit with the feeling..."
    "...você é subitamente tomado pela sensação..."

# game/endgame.rpy:900
translate pt_br refuseCat_ba4f1a80:

    # "{size=-10}...that you are {b}not{/b} alone.{/size}"
    "{size=-10}...de que você {b}não{/b} está sozinho.{/size}"

# game/endgame.rpy:901
translate pt_br refuseCat_0a4a23c7:

    # "Like you've just stepped into an unbearably, {i}impossibly{/i} crowded space..."
    "Como se você acabasse de entrar em um espaço insuportavelmente, {i}impossivelmente{/i} lotado..."

# game/endgame.rpy:902
translate pt_br refuseCat_7e162144:

    # "Your ears even start to ring with the sensation of countless conversations..."
    "Seus ouvidos começam a zumbir com a sensação de inúmeras conversas..."

# game/endgame.rpy:903
translate pt_br refuseCat_403137b9:

    # "Words, whispers, {i}screams{/i}... {w}all overlapping..."
    "Palavras, sussurros, {i}gritos{/i}... {w}todos sobrepostos..."

# game/endgame.rpy:904
translate pt_br refuseCat_bf0874e3:

    # "But..."
    "Mas..."

# game/endgame.rpy:905
translate pt_br refuseCat_134c63de:

    # "You don't actually see or hear anyone or anything..."
    "Você não vê ou ouve realmente algo ou alguém..."

# game/endgame.rpy:906
translate pt_br refuseCat_93bc4adf:

    # "You're alone..."
    "Você está sozinho..."

# game/endgame.rpy:907
translate pt_br refuseCat_1a0c257a:

    # "Even as your senses lie to you, trying to make you think otherwise..."
    "Mesmo enquanto seus sentidos mentem para você, tentando fazer você pensar o contrário..."

# game/endgame.rpy:908
translate pt_br refuseCat_3fa3800d:

    # "{size=-8}...you're more alone than you've ever been.{/size}"
    "{size=-8}...você está mais sozinho do que nunca.{/size}"

# game/endgame.rpy:936
translate pt_br refuseCat_237125a9:

    # who "lies... {w}lies... {w}listen... {w}listen, {i}please{/i}..."
    who "mentiras... {w}mentiras... {w}ouça... {w}ouça, {i}por favor{/i}..."

# game/endgame.rpy:937
translate pt_br refuseCat_90b68c87:

    # you "..?"
    you "..?"

# game/endgame.rpy:938
translate pt_br refuseCat_ba0d7c87:

    # you "Is someone really...?"
    you "Tem alguém mesmo...?"

# game/endgame.rpy:939
translate pt_br refuseCat_955160b2:

    # you "I can't see you..."
    you "Não consigo te ver..."

# game/endgame.rpy:940
translate pt_br refuseCat_0d7e3dc7:

    # you "Where are you?"
    you "Onde você tá?"

# game/endgame.rpy:962
translate pt_br refuseCat_986b4bb4:

    # who "nothing... {w}nothing left... {w}to see... {w}only hear... {w}hear us..."
    who "nada... {w}não sobrou nada... {w}para ver... {w}apenas ouvir... {w}nos ouvir..."

# game/endgame.rpy:984
translate pt_br refuseCat_2d7097aa:

    # who "listen... {w}please..."
    who "ouça... {w}por favor..."

# game/endgame.rpy:985
translate pt_br refuseCat_30099ff9:

    # you "Are you... Are you all trapped too? In this place..?"
    you "Vocês... Vocês todos estão presos também? Nesse lugar..?"

# game/endgame.rpy:1007
translate pt_br refuseCat_da793f6a:

    # who "no place... {w}us... {w}all you see... {w}hear... {w}feel... {w}is {i}us{/i}..."
    who "sem lugar... {w}nós... {w}tudo que vê... {w}ouve... {w}sente... {w}somos {i}nós{/i}..."

# game/endgame.rpy:1029
translate pt_br refuseCat_0e4deed6:

    # who "us... {w}and {b}{color=#FF0000}I T...{/color}{/b}"
    who "nós... {w}e {b}{color=#FF0000}I S S O...{/color}{/b}"

# game/endgame.rpy:1051
translate pt_br refuseCat_b46126fe:

    # who "we are victims... {w}prey... {w}like you... {w}we are many... {w}beyond counting..."
    who "nós somos vítimas... {w}presas... {w}como você... {w}somos muitos... {w}incontáveis..."

# game/endgame.rpy:1073
translate pt_br refuseCat_5306dd79:

    # who "our bodies gone... {w}with time..."
    who "nossos corpos se foram... {w}com o tempo..."

# game/endgame.rpy:1095
translate pt_br refuseCat_174a45b9:

    # who "wills left behind... {w}us... {w}us... {w}we became... {w}what you see... {w}this \"place\"..."
    who "desejos abandonados... {w}nós... {w}nós... {w}nos tornamos... {w}o que você vê... {w}esse \"lugar\"..."

# game/endgame.rpy:1122
translate pt_br refuseCat_f03c0d18:

    # who "need you... {w}need your help... {w}help..."
    who "precisamos de você... {w}precisamos da sua ajuda... {w}ajuda..."

# game/endgame.rpy:1123
translate pt_br refuseCat_3abb33dd:

    # you "But... What can {i}I{/i} do..?"
    you "Mas... O que {i}eu{/i} posso fazer..?"

# game/endgame.rpy:1145
translate pt_br refuseCat_82878ab6:

    # who "{b}{color=#FF0000}I T{/color}{/b} too greedy... {w}make mistake... {w}ate too many... {w}we are many... {w}now strong..."
    who "{b}{color=#FF0000}I S S O{/color}{/b} é muito ganancioso... {w}cometeu erro... {w}comeu muitos... {w}somos muitos... {w}agora fortes..."

# game/endgame.rpy:1172
translate pt_br refuseCat_70c5c2af:

    # who "made {b}{color=#FF0000}I T{/color}{/b} strong... {w}but make mistake... {w}mistake... {w}error... {w}flaw..."
    who "fizemos {b}{color=#FF0000}I S S O{/color}{/b} forte... {w}mas cometeu erro... {w}erro... {w}descuido... {w}falha..."

# game/endgame.rpy:1194
translate pt_br refuseCat_85afd939:

    # who "{i}weakness{/i}..."
    who "{i}fraqueza{/i}..."

# game/endgame.rpy:1195
translate pt_br refuseCat_5d0fa6b9:

    # you "Then why not escape yourselves?"
    you "Então por que não escapam por conta própria?"

# game/endgame.rpy:1217
translate pt_br refuseCat_88e7cfa8:

    # who "too long here... {w}too long... {w}one... {w}we are one... {w}with {b}{color=#FF0000}I T...{/color}{/b}"
    who "muito tempo aqui... {w}muito tempo... {w}um... {w}somos um... {w}com {b}{color=#FF0000}I S S O...{/color}{/b}"

# game/endgame.rpy:1239
translate pt_br refuseCat_1eaa7cb8:

    # who "bodies lost... {w}minds... {w}wills... {w}us... {w}all corrupted... {w}no body... {w}can't escape..."
    who "corpos perdidos... {w}mentes... {w}desejos... {w}nós... {w}todos corrompidos... {w}sem corpo... {w}sem fuga..."

# game/endgame.rpy:1261
translate pt_br refuseCat_c9b4decc:

    # who "you too... {w}you... {w}we... {w}{b}{color=#FF0000}I T...{/color}{/b} {w}one... {w}all of us... {w}all now one..."
    who "você também... {w}você... {w}nós... {w}{b}{color=#FF0000}I S S O...{/color}{/b} {w}um... {w}todos nós... {w}agora somos um..."

# game/endgame.rpy:1262
translate pt_br refuseCat_6f50b679:

    # who "..."
    who "..."

# game/endgame.rpy:1284
translate pt_br refuseCat_028c3ae6:

    # who "but you... {w}{i}new{/i}... {w}fresh... {w}body..."
    who "mas você... {w}{i}novo{/i}... {w}corpo... {w}fresco..."

# game/endgame.rpy:1306
translate pt_br refuseCat_4cfc5eb7:

    # who "still have body..."
    who "ainda tem corpo..."

# game/endgame.rpy:1328
translate pt_br refuseCat_40326cc1:

    # who "escape is possible..."
    who "fuga é possível..."

# game/endgame.rpy:1350
translate pt_br refuseCat_dd4998c0:

    # who "because still one... {w}with {b}{color=#FF0000}I T...{/color}{/b}"
    who "porque ainda um... {w}com {b}{color=#FF0000}I S S O...{/color}{/b}"

# game/endgame.rpy:1372
translate pt_br refuseCat_b6dc0c49:

    # who "even just you... {w}if escape... {w}with mind... {w}with body..."
    who "mesmo só você... {w}se fugir... {w}com mente... {w}com corpo..."

# game/endgame.rpy:1394
translate pt_br refuseCat_793d75bf:

    # who "{b}{color=#FF0000}I T{/color}{/b} would unravel..."
    who "{b}{color=#FF0000}I S S O{/color}{/b} se desfaria..."

# game/endgame.rpy:1416
translate pt_br refuseCat_2bd9b13a:

    # who "lose power... {w}lose strength... {w}lose {i}us{/i}..."
    who "perderia poder... {w}perderia força... {w}{i}nos{/i} perderia..."

# game/endgame.rpy:1438
translate pt_br refuseCat_8e7cd0c9:

    # who "us... {w}set free... {w}forever... {w}finally... {w}escape... {w}help..."
    who "nós... {w}libertos... {w}para sempre... {w}finalmente... {w}fuga... {w}ajuda..."

# game/endgame.rpy:1439
translate pt_br refuseCat_73dce3cc:

    # you "How do I do that?"
    you "Como faço isso?"

# game/endgame.rpy:1461
translate pt_br refuseCat_5e2c21a6:

    # who "remember {b}{color=#FF0000}I T{/color}{/b} lies... {w}hidden in truths... {w}lies... {w}lies..."
    who "lembre-se {b}{color=#FF0000}I S S O{/color}{/b} repousa... {w}escondido em verdades... {w}e mentiras... {w}mentiras..."

# game/endgame.rpy:1483
translate pt_br refuseCat_482c36ac:

    # who "escape... {w}push forward... {w}{b}{color=#FF0000}I T{/color}{/b} lies..."
    who "fuja... {w}avance... {w}{b}{color=#FF0000}I S S O{/color}{/b} repousa..."

# game/endgame.rpy:1516
translate pt_br refuseCat_bd01a240:

    # who "{size=-8}{b}persist...{/b}{/size}"
    who "{size=-8}{b}persista...{/b}{/size}"

# game/endgame.rpy:1517
translate pt_br refuseCat_dae0ec55_1:

    # you "..."
    you "..."

# game/endgame.rpy:1524
translate pt_br fakePerish_8dabefc6:

    # ".."
    ".."

# game/endgame.rpy:1525
translate pt_br fakePerish_a20cefa7:

    # "..."
    "..."

# game/endgame.rpy:1530
translate pt_br fakePerish_0d3bcba3:

    # "{size=-10}you ignore their words.{/size}"
    "{size=-10}você ignora suas palavras.{/size}"

# game/endgame.rpy:1531
translate pt_br fakePerish_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/endgame.rpy:1532
translate pt_br fakePerish_96593730:

    # "deep down you know, there's no way someone like you could win against something like {b}{color=#FF0000}I T...{/color}{/b}"
    "no fundo você sabe, não há como alguém como você ganhar de alguém como {b}{color=#FF0000}I S S O...{/color}{/b}"

# game/endgame.rpy:1533
translate pt_br fakePerish_9b198811:

    # "the cat..."
    "o gato..."

# game/endgame.rpy:1534
translate pt_br fakePerish_44a490b1:

    # "trying would be pointless-{w=0.5}{nw}"
    "tentar seria inútil-{w=0.5}{nw}"

# game/endgame.rpy:1535
translate pt_br fakePerish_4b851161:

    # "absurd{w=0.15}{nw}"
    "absurdo{w=0.15}{nw}"

# game/endgame.rpy:1536
translate pt_br fakePerish_0dc07c58:

    # "futile{w=0.15}{nw}"
    "fútil{w=0.15}{nw}"

# game/endgame.rpy:1537
translate pt_br fakePerish_5028df96:

    # "insignficant{w=0.15}{nw}"
    "insignficante{w=0.15}{nw}"

# game/endgame.rpy:1538
translate pt_br fakePerish_3369598c:

    # "meaningless{w=0.15}{nw}"
    "sem sentido{w=0.15}{nw}"

# game/endgame.rpy:1539
translate pt_br fakePerish_527621cb:

    # "stupid{w=0.15}{nw}"
    "estúpido{w=0.15}{nw}"

# game/endgame.rpy:1540
translate pt_br fakePerish_9eed9e56:

    # "useless{w=0.15}{nw}"
    "sem propósito{w=0.15}{nw}"

# game/endgame.rpy:1541
translate pt_br fakePerish_a20cefa7_1:

    # "..."
    "..."

# game/endgame.rpy:1542
translate pt_br fakePerish_127944b9:

    # "...a pointless effort."
    "...um esforço em vão."

# game/endgame.rpy:1543
translate pt_br fakePerish_3e0d2470:

    # "the hopes of those words... their wills..."
    "a esperança dessas palavras... seus desejos..."

# game/endgame.rpy:1544
translate pt_br fakePerish_0f38a5d5:

    # "...it would all be wasted on you."
    "...tudo isso seria desperdiçado em você."

# game/endgame.rpy:1545
translate pt_br fakePerish_69c369af:

    # "so..."
    "então..."

# game/endgame.rpy:1546
translate pt_br fakePerish_05311e61:

    # "you accept your fate..."
    "você aceita seu destino..."

# game/endgame.rpy:1547
translate pt_br fakePerish_bfe65f60:

    # "...and choose to \ {b}p e r i s h.{/b}"
    "...e escolhe  {b}p e r e c e r.{/b}"

# game/endgame.rpy:1548
translate pt_br fakePerish_8dabefc6_1:

    # ".."
    ".."

# game/endgame.rpy:1549
translate pt_br fakePerish_a20cefa7_2:

    # "..."
    "..."

# game/endgame.rpy:1553
translate pt_br fakePerish_92f9f8f7:

    # "you're not sure how long it takes, but their pathetic pleas eventually grow silent."
    "você não sabe quanto tempo levaria, mas seus apelos patéticos eventualmente se silenciariam."

# game/endgame.rpy:1554
translate pt_br fakePerish_2b4577cf:

    # "you almost wish they would've simply turned to insults and threats..."
    "você quase deseja que eles simplesmente tivessem se tornado insultos e ameaças..."

# game/endgame.rpy:1555
translate pt_br fakePerish_f1634dcc:

    # "this endless silence... it bears the weight of your guilt and shame..."
    "esse silêncio interminável... carrega o peso da sua culpa e vergonha..."

# game/endgame.rpy:1556
translate pt_br fakePerish_2214de5d:

    # "...long after your body fades away..."
    "...muito tempo depois de seu corpo se desfazer..."

# game/endgame.rpy:1558
translate pt_br fakePerish_4bc243e3:

    # "...and becomes one..."
    "...e se tornar um..."

# game/endgame.rpy:1559
translate pt_br fakePerish_b21d553c:

    # "{alpha=0.5}one...{/alpha}"
    "{alpha=0.5}um...{/alpha}"

# game/endgame.rpy:1560
translate pt_br fakePerish_e1317257:

    # "{alpha=0.3}...with me.{/alpha}"
    "{alpha=0.3}...comigo.{/alpha}"

# game/endgame.rpy:1561
translate pt_br fakePerish_a20cefa7_3:

    # "..."
    "..."

# game/endgame.rpy:1562
translate pt_br fakePerish_5a9b49fc:

    # "Ending ???: Perish the thought"
    "Ending ???: Deus me livre"

# game/endgame.rpy:1573
translate pt_br finalShowdown_8dabefc6:

    # ".."
    ".."

# game/endgame.rpy:1574
translate pt_br finalShowdown_a20cefa7:

    # "..."
    "..."

# game/endgame.rpy:1575
translate pt_br finalShowdown_dae0ec55:

    # you "..."
    you "..."

# game/endgame.rpy:1576
translate pt_br finalShowdown_8105eadd:

    # you "No..."
    you "Não..."

# game/endgame.rpy:1577
translate pt_br finalShowdown_4d6b47c4:

    # you "No, this... This is another \"daydream\"..."
    you "Não, estou... Estou \"sonhando acordado\" de novo..."

# game/endgame.rpy:1578
translate pt_br finalShowdown_ed47dfcc:

    # you "...isn't it?"
    you "...não é?"

# game/endgame.rpy:1580
translate pt_br finalShowdown_f0fcfbb0:

    # cat "!!"
    cat "!!"

# game/endgame.rpy:1581
translate pt_br finalShowdown_d9b65ba2:

    # cat "You're lucid again? {w}In {i}here?{/i}"
    cat "Você está lúcido de novo? {w}{i}Aqui{/i} dentro?"

# game/endgame.rpy:1582
translate pt_br finalShowdown_f6c6b67c:

    # cat "But... how did you..?"
    cat "Mas... como você..?"

# game/endgame.rpy:1583
translate pt_br finalShowdown_dae0ec55_1:

    # you "..."
    you "..."

# game/endgame.rpy:1584
translate pt_br finalShowdown_685847ec:

    # you "Well..."
    you "Bem..."

# game/endgame.rpy:1585
translate pt_br finalShowdown_62715eb3:

    # you "When you've been dreaming about the same day over and over... {w}you kinda start to notice the patterns..."
    you "Quando você está sonhando com o mesmo dia de novo e de novo... {w}você começa a notar os padrões..."

# game/endgame.rpy:1586
translate pt_br finalShowdown_7f0ac95c:

    # cat "..."
    cat "..."

# game/endgame.rpy:1587
translate pt_br finalShowdown_16651853:

    # you "Listen... {w}I'm nothing special."
    you "Escuta... {w}Eu não sou nada especial."

# game/endgame.rpy:1588
translate pt_br finalShowdown_0560b398:

    # you "I don't really have any friends."
    you "Na verdade, eu não tenho amigos."

# game/endgame.rpy:1589
translate pt_br finalShowdown_28a71a07:

    # you "I don't like crowds or going out most of the time."
    you "Não gosto de multidões ou de sair na maior parte do tempo."

# game/endgame.rpy:1590
translate pt_br finalShowdown_ddfefb8c:

    # you "And more often than not..."
    you "E na maioria das vezes..."

# game/endgame.rpy:1591
translate pt_br finalShowdown_ff3731cf:

    # you "...I'm alone."
    you "...Eu estou sozinho."

# game/endgame.rpy:1592
translate pt_br finalShowdown_6c53330d:

    # you "Even in my home..."
    you "Mesmo na minha casa..."

# game/endgame.rpy:1593
translate pt_br finalShowdown_0c78bdf6:

    # you "One bedroom... {w}one bathroom... {w}and one {i}me{/i} living alone in it."
    you "Um quarto... {w}um banheiro... {w}e só {i}eu{/i} vivendo sozinho nela."

# game/endgame.rpy:1594
translate pt_br finalShowdown_ea6f4afe:

    # you "It'd be easy to say that I don't have much to lose."
    you "Seria fácil dizer que não tenho muito a perder."

# game/endgame.rpy:1595
translate pt_br finalShowdown_e7a5aced:

    # you "My life is admittedly pretty boring."
    you "Minha vida, admito, é bem chata."

# game/endgame.rpy:1596
translate pt_br finalShowdown_dae0ec55_2:

    # you "..."
    you "..."

# game/endgame.rpy:1597
translate pt_br finalShowdown_9af744e4:

    # you "But it {i}is{/i}... {w}{i}{b}my{/b}{/i}... {w}life."
    you "Mas {i}é{/i}... {w}{i}{b}a minha{/b}{/i}... {w}vida."

# game/endgame.rpy:1598
translate pt_br finalShowdown_bccf0c1b:

    # you "And if this is {i}my{/i} dream..."
    you "E se esse é {i}meu{/i} sonho..."

# game/endgame.rpy:1599
translate pt_br finalShowdown_b8c07162:

    # you "...then you're not calling the shots anymore."
    you "...então você não está mais no controle."

# game/endgame.rpy:1600
translate pt_br finalShowdown_7f0ac95c_1:

    # cat "..."
    cat "..."

# game/endgame.rpy:1607
translate pt_br finalShowdown_a20cefa7_1:

    # "..."
    "..."

# game/endgame.rpy:1608
translate pt_br finalShowdown_97790092:

    # "{size=-8}I don't think you understand what's going on here.{/size}"
    "{size=-8}Acho que você não está entendendo o que está acontecendo aqui.{/size}"

# game/endgame.rpy:1609
translate pt_br finalShowdown_55077811:

    # you "No, {i}you're{/i} the one who isn't getting it."
    you "Não, {i}você{/i} é quem não está entendendo."

# game/endgame.rpy:1610
translate pt_br finalShowdown_a513413e:

    # "..!"
    "..!"

# game/endgame.rpy:1611
translate pt_br finalShowdown_a86ce62e:

    # you "{b}You{/b} called {i}me.{/i}"
    you "{b}Você{/b} que {i}me{/i} chamou."

# game/endgame.rpy:1612
translate pt_br finalShowdown_4a5124d3:

    # you "{b}You're{/b} the one who needs {i}me.{/i}"
    you "{b}Você{/b} é quem precisa de {i}mim.{/i}"

# game/endgame.rpy:1613
translate pt_br finalShowdown_0833d501:

    # you "Whether it's to eat me or kill me or make me yours forever, it doesn't matter."
    you "Seja para me comer, me matar ou me fazer seu para sempre, não importa."

# game/endgame.rpy:1614
translate pt_br finalShowdown_64ab99ef:

    # you "I'm {b}done{/b} here."
    you "Já {b}acabei{/b} por aqui."

# game/endgame.rpy:1615
translate pt_br finalShowdown_dae0ec55_3:

    # you "..."
    you "..."

# game/endgame.rpy:1616
translate pt_br finalShowdown_144a76cd:

    # you "I'm going {b}home.{/b}"
    you "Tô indo pra {b}casa.{/b}"

# game/endgame.rpy:1630
translate pt_br finalShowdown_62708cb5:

    # "{size=+15}YOU FORGET YOURSELF, HUMAN!{/size}" with vpunch
    "{size=+15}PONHA-SE NO SEU LUGAR, HUMANO!{/size}" with vpunch

# game/endgame.rpy:1631
translate pt_br finalShowdown_a20cefa7_2:

    # "..."
    "..."

# game/endgame.rpy:1632
translate pt_br finalShowdown_0f5de544:

    # "You..."
    "Sua..."

# game/endgame.rpy:1634
translate pt_br finalShowdown_944b8194:

    # "You ungrateful little creature..."
    "Sua criaturinha ingrata..."

# game/endgame.rpy:1635
translate pt_br finalShowdown_0476e12b:

    # "I give you my patience... my attention... my {i}love...{/i} and you think you can just {i}{b}leave?{/b}{/i}"
    "Eu lhe dou minha paciência... minha atenção... meu {i}amor...{/i} e você acha que pode só {i}{b}ir embora?{/b}{/i}"

# game/endgame.rpy:1636
translate pt_br finalShowdown_c1890fde:

    # "I didn't {i}have{/i} to, you know? I could've just {b}eaten{/b} you whenever I liked, but instead..."
    "Eu não {i}precisava{/i}, sabia? Eu poderia ter apenas te {b}devorado{/b} quando quisesse, mas em vez disso..."

# game/endgame.rpy:1637
translate pt_br finalShowdown_111422a8:

    # "I gave you time to understand... time to accept what was happening..."
    "Dei a você tempo para entender... tempo para aceitar o que estava acontecendo..."

# game/endgame.rpy:1638
translate pt_br finalShowdown_6ce15ddb:

    # "I gave you a {b}choice.{/b}"
    "Dei a você uma {b}escolha.{/b}"

# game/endgame.rpy:1639
translate pt_br finalShowdown_262e06a7:

    # "{b}YOU.{/b}"
    "{b}A VOCÊ.{/b}"

# game/endgame.rpy:1640
translate pt_br finalShowdown_e4b6e292:

    # "An unremarkable little nothing of an existence whom NO ONE would even notice was missing if I'd just taken you as I pleased."
    "Uma existência insignificante cuja ausência NINGUÉM sequer notaria se eu o tivesse tomado como quisesse."

# game/endgame.rpy:1641
translate pt_br finalShowdown_5ec00c47:

    # "Dreaming away about endless possibilities..."
    "Sonhando inutilmente com possibilidades infinitas..."

# game/endgame.rpy:1642
translate pt_br finalShowdown_27e84286:

    # "Never having to worry about permanent consequences ever again... About choosing wrong..."
    "Nunca mais precisando se preocupar com consequências permanentes de novo... Sobre escolher errado..."

# game/endgame.rpy:1643
translate pt_br finalShowdown_94c81802:

    # "A little world all your own inside your head..."
    "Um pequeno mundo só seu dentro da sua cabeça..."

# game/endgame.rpy:1644
translate pt_br finalShowdown_4be86aa8:

    # "I offered it all to you... I gave you the choice to join me and have it all..."
    "Eu te ofereci tudo isso... Eu te dei a escolha de se juntar a mim e ter tudo..."

# game/endgame.rpy:1645
translate pt_br finalShowdown_8e138c4d:

    # "And you refused."
    "E você recusou."

# game/endgame.rpy:1646
translate pt_br finalShowdown_7ab438d2:

    # "You said you'd rather die, didn't you? And yet here you are trying to go back on your choices..."
    "Você disse preferir morrer, não disse? E ainda assim, aqui está você, tentando voltar atrás em suas escolhas..."

# game/endgame.rpy:1647
translate pt_br finalShowdown_ee2480c9:

    # "...only to continue to reject me."
    "...apenas para continuar me rejeitando."

# game/endgame.rpy:1648
translate pt_br finalShowdown_ec08c7ee:

    # "To reject my love..."
    "Rejeitando meu amor..."

# game/endgame.rpy:1649
translate pt_br finalShowdown_380a9730:

    # "So foolish..."
    "Tão tolo..."

# game/endgame.rpy:1650
translate pt_br finalShowdown_ed1d138e:

    # "So ungrateful..."
    "Tão ingrato..."

# game/endgame.rpy:1651
translate pt_br finalShowdown_f5ff6d04:

    # "Just like the others, you don't even know what you want..."
    "Assim como os outros, você não sabe nem o que quer..."

# game/endgame.rpy:1652
translate pt_br finalShowdown_08772fff:

    # "Another bundle of contradictions..."
    "Outro emaranhado de contradições..."

# game/endgame.rpy:1653
translate pt_br finalShowdown_ea286119:

    # "You wish for solitude, yet you fear being left alone..."
    "Você deseja solidão, ainda assim teme ficar sozinho..."

# game/endgame.rpy:1654
translate pt_br finalShowdown_38a1d032:

    # "You fear being forgotten... undesired... unloved..."
    "Teme ser esquecido... indesejado... não amado..."

# game/endgame.rpy:1655
translate pt_br finalShowdown_427c7ef2:

    # "Yet even I though I love you and desire you..."
    "Ainda assim, mesmo eu, que amo você e o desejo..."

# game/endgame.rpy:1656
translate pt_br finalShowdown_26d7a1f6:

    # "Even though I promised to never forget you..."
    "Mesmo que eu tenha prometido nunca esquecer você..."

# game/endgame.rpy:1657
translate pt_br finalShowdown_9b5e410c:

    # "Even though {b}I{/b} am the {i}only{/i} one willing to never leave you..."
    "Mesmo que {b}eu{/b} seja o {i}único{/i} disposto a nunca deixá-lo..."

# game/endgame.rpy:1658
translate pt_br finalShowdown_a5b54e8a:

    # "YOU STILL REJECT ME."
    "VOCÊ AINDA ME REJEITA."

# game/endgame.rpy:1659
translate pt_br finalShowdown_3e31e4a4:

    # "Stupid little {b}{i}child.{/i}{/b}"
    "{b}{i}Criança{/i}{/b} estúpida."

# game/endgame.rpy:1660
translate pt_br finalShowdown_fe885e9e:

    # "I'm {i}done{/i} waiting."
    "Estou {i}cansado{/i} de esperar."

# game/endgame.rpy:1661
translate pt_br finalShowdown_90c94c9e:

    # "You do not get a second chance. You made your choice and you {b}{i}will{/i}{/b} accept the consequences of that choice."
    "Você não terá uma segunda chance. Você fez sua escolha e {b}{i}irá{/i}{/b} aceitar suas consequências."

# game/endgame.rpy:1662
translate pt_br finalShowdown_a4585081:

    # "You are going to stay here with the rest of these ingrates..."
    "Você vai ficar aqui com o resto desses ingratos..."

# game/endgame.rpy:1663
translate pt_br finalShowdown_9ab7bfe1:

    # ".{w=0.7}.{w=0.7}.{w=0.7}.{w=0.7}f{w=0.7}o{w=0.7}r{w=0.7}e{w=0.7}v{w=0.7}e{w=0.7}r{w=0.7}."
    ".{w=0.7}.{w=0.7}.{w=0.7}.{w=0.7}p{w=0.7}a{w=0.7}r{w=0.7}a{w=0.7} {w=0.7}s{w=0.7}e{w=0.7}m{w=0.7}p{w=0.7}r{w=0.7}e{w=0.7}."

# game/endgame.rpy:1664
translate pt_br finalShowdown_dae0ec55_4:

    # you "..."
    you "..."

# game/endgame.rpy:1665
translate pt_br finalShowdown_21096a12:

    # you "Haven't you ever heard of changing your mind?"
    you "Você nunca ouviu falar em mudar de ideia?"

# game/endgame.rpy:1666
translate pt_br finalShowdown_240d387e:

    # "Such a thing doesn't erase your original decision. It has been permanently etched into reality."
    "Isso não apaga a sua decisão original. Ela foi gravada permanentemente na realidade."

# game/endgame.rpy:1667
translate pt_br finalShowdown_985e2f87:

    # "Do you think yourself so important that you are {b}above{/b} facing the truth of that reality?"
    "Você se acha tão importante a ponto de estar {b}acima{/b} de encarar a verdade dessa realidade?"

# game/endgame.rpy:1668
translate pt_br finalShowdown_49817c9e:

    # you "No... But that doesn't mean I can't do my best to make things right."
    you "Não... Mas isso não significa que eu não possa fazer o meu melhor para corrigir as coisas."

# game/endgame.rpy:1669
translate pt_br finalShowdown_6346d171:

    # you "I'm still here, aren't I? That means I can always make more choices... Better choices..."
    you "Eu ainda estou aqui, não estou? Isso significa que sempre posso fazer mais escolhas... Escolhas melhores..."

# game/endgame.rpy:1670
translate pt_br finalShowdown_a20cefa7_3:

    # "..."
    "..."

# game/endgame.rpy:1671
translate pt_br finalShowdown_c6c45632:

    # "You gave yourself to me... {w}{i}You{/i} are already a part of {b}me{/b}..."
    "Você se entregou a mim... {w}{i}Você{/i} já faz parte de {b}mim{/b}..."

# game/endgame.rpy:1672
translate pt_br finalShowdown_f79cd161:

    # "This might be your pathetic little delusion..."
    "Isso pode ser uma ilusãozinha patética sua..."

# game/endgame.rpy:1673
translate pt_br finalShowdown_0e17c1eb:

    # "...but don't forget that {i}I'm{/i} the one in control here, human."
    "...mas não se esqueça de que {i}eu{/i} é que estou no controle aqui, humano."

# game/endgame.rpy:1674
translate pt_br finalShowdown_4d71bde9:

    # you "Oh yeah, that's right. {w}Those twisted \"choices\" in my dreams were all you, weren't they?"
    you "Ah, é mesmo. {w}Aquelas \"escolhas\" distorcidas nos meus sonhos foram todas você, não foram?"

# game/endgame.rpy:1677
translate pt_br finalShowdown_297c677e:

    # who "{alpha=0.3}we help... help...{/alpha}"
    who "{alpha=0.3}nós ajudamos... ajudamos...{/alpha}"

# game/endgame.rpy:1678
translate pt_br finalShowdown_697cd04e:

    # who "{alpha=0.5}running...{/alpha} endDream.exe..."
    who "{alpha=0.5}rodando...{/alpha} acabarSonho.exe..."

# game/endgame.rpy:1679
translate pt_br finalShowdown_3c44db14:

    # "What's-"
    "O que está-"

# game/endgame.rpy:1681
translate pt_br finalShowdown_d8c402b1:

    # who "P {w=0.3}E {w=0.3}R {w=0.3}S {w=0.3}I {w=0.3}S {w=0.3}T"
    who "P {w=0.3}E {w=0.3}R {w=0.3}S {w=0.3}I {w=0.3}S {w=0.3}T {w=0.3}A"

# game/endgame.rpy:1682
translate pt_br finalShowdown_210d572a:

    # "!!!" with hpunch
    "!!!" with hpunch

# game/endgame.rpy:1683
translate pt_br finalShowdown_10402de1:

    # "What are you doing you useless traitors?!"
    "O que estão fazendo, seus traidores inúteis?!"

# game/endgame.rpy:1685
translate pt_br finalShowdown_7daca311:

    # "{size=+15}STOP!{/size}" with hpunch
    "{size=+15}PAREM!{/size}" with hpunch

# game/endgame.rpy:1686
translate pt_br finalShowdown_7bbc0a26:

    # you "I think it's about time I started making my {i}own{/i} choices."
    you "Acho que já era hora de eu começar a fazer minhas {i}próprias{/i} escolhas."

# game/endgame.rpy:1691
translate pt_br finalShowdown_c7b05810:

    # cat "{size=+35}{b}STO-!!{/b}{/size}{w=0.3}{nw}" with hpunch
    cat "{size=+35}{b}PAR-!!{/b}{/size}{w=0.3}{nw}" with hpunch

# game/endgame.rpy:1725
translate pt_br whereItBegan_8dabefc6:

    # ".."
    ".."

# game/endgame.rpy:1726
translate pt_br whereItBegan_a20cefa7:

    # "..."
    "..."

# game/endgame.rpy:1729
translate pt_br whereItBegan_a20cefa7_1:

    # "..."
    "..."

# game/endgame.rpy:1730
translate pt_br whereItBegan_355c83da:

    # "I'm back..."
    "Tô de volta..."

# game/endgame.rpy:1731
translate pt_br whereItBegan_e91717e2:

    # "Back where it all began..."
    "De volta aonde tudo começou..."

# game/endgame.rpy:1732
translate pt_br whereItBegan_939db7b6:

    # "The alley..."
    "O beco..."

# game/endgame.rpy:1735
translate pt_br whereItBegan_99fcd215:

    # "And in the cardboard box... {w}at the back of the alley..."
    "E na caixa de papelão... {w}no fundo do beco..."

# game/endgame.rpy:1736
translate pt_br whereItBegan_8dabefc6_1:

    # ".."
    ".."

# game/endgame.rpy:1737
translate pt_br whereItBegan_a20cefa7_2:

    # "..."
    "..."

# game/endgame.rpy:1740
translate pt_br whereItBegan_dae0ec55:

    # you "..."
    you "..."

# game/endgame.rpy:1741
translate pt_br whereItBegan_b0381c02:

    # "There you are..."
    "Lá está você..."

# game/endgame.rpy:1744
translate pt_br whereItBegan_3064d8e1:

    # "You look nothing like the impossibly cute cat I met... {w}well... {w}what feels like a lifetime ago..."
    "Não se parece em nada com o gato incrivelmente fofo que conheci... {w}bom... {w}o que parece ter sido há séculos..."

# game/endgame.rpy:1745
translate pt_br whereItBegan_c94b4764:

    # "After escaping and releasing the wills of all of your victims..."
    "Depois de fugir e libertar os desejos de todas as suas vítimas..."

# game/endgame.rpy:1746
translate pt_br whereItBegan_46986469:

    # "...all that's left of you now is an inky black blob seething up at me."
    "...tudo o que sobrou de você agora é uma massa preta viscosa fervendo diante de mim."

# game/endgame.rpy:1747
translate pt_br whereItBegan_87df935d:

    # cat3 "..."
    cat3 "..."

# game/endgame.rpy:1748
translate pt_br whereItBegan_c127cc5c:

    # "The endless hatred pouring out of your singular eye..."
    "O ódio interminável emanando do seu único olho..."

# game/endgame.rpy:1749
translate pt_br whereItBegan_a20cefa7_3:

    # "..."
    "..."

# game/endgame.rpy:1750
translate pt_br whereItBegan_083faea7:

    # "...doesn't scare me at all."
    "...não me assusta nem um pouco."

# game/endgame.rpy:1754
translate pt_br whereItBegan_7e6715dd:

    # cat3 "dont leave"
    cat3 "não vá"

# game/endgame.rpy:1755
translate pt_br whereItBegan_5071d7c2:

    # cat3 "youre mine"
    cat3 "você é meu"

# game/endgame.rpy:1756
translate pt_br whereItBegan_8105eadd:

    # you "No..."
    you "Não..."

# game/endgame.rpy:1757
translate pt_br whereItBegan_5288c6f4:

    # "I'm not."
    "Não sou."

# game/endgame.rpy:1758
translate pt_br whereItBegan_9a3acbc4:

    # cat3 "you took them away"
    cat3 "você os tirou de mim"

# game/endgame.rpy:1759
translate pt_br whereItBegan_472c0f2d:

    # cat3 "they were mine"
    cat3 "eles eram meus"

# game/endgame.rpy:1760
translate pt_br whereItBegan_ba12304a:

    # cat3 "and now theyre gone"
    cat3 "e agora se foram"

# game/endgame.rpy:1761
translate pt_br whereItBegan_9a3acbc4_1:

    # cat3 "you took them away"
    cat3 "você os tirou de mim"

# game/endgame.rpy:1762
translate pt_br whereItBegan_94d1d734:

    # cat3 "you took everything from me"
    cat3 "você tirou tudo de mim"

# game/endgame.rpy:1763
translate pt_br whereItBegan_dae0ec55_1:

    # you "..."
    you "..."

# game/endgame.rpy:1764
translate pt_br whereItBegan_77bc0354:

    # you "They weren't yours either."
    you "Eles também nunca foram seus."

# game/endgame.rpy:1765
translate pt_br whereItBegan_f379ba27:

    # cat3 "alone"
    cat3 "sozinho"

# game/endgame.rpy:1766
translate pt_br whereItBegan_dae0ec55_2:

    # you "..."
    you "..."

# game/endgame.rpy:1767
translate pt_br whereItBegan_9d45b838:

    # "You never {i}had{/i} to be..."
    "Você nunca {i}teve{/i} de ser..."

# game/endgame.rpy:1768
translate pt_br whereItBegan_85be2ed9:

    # "If you were lonely... {w}You could've just been their friend..."
    "Se você estava solitário... {w}Poderia simplesmente ter sido amigo deles..."

# game/endgame.rpy:1769
translate pt_br whereItBegan_a17d72a6:

    # "But you didn't want friendship."
    "Mas você não queria amizade."

# game/endgame.rpy:1770
translate pt_br whereItBegan_8fe47c61:

    # "They left because you tricked them..."
    "Eles foram embora porque você enganou eles..."

# game/endgame.rpy:1771
translate pt_br whereItBegan_4fe27187:

    # "Kidnapped them..."
    "Sequestrou eles..."

# game/endgame.rpy:1772
translate pt_br whereItBegan_5f26a1dd:

    # "{b}Hurt{/b} them..."
    "{b}Machucou{/b} eles..."

# game/endgame.rpy:1773
translate pt_br whereItBegan_139aec37:

    # "You stole their lives... {w}Their time... {w}Never to get any of it back..."
    "Roubou suas vidas... {w}Seu tempo... {w}E eles nunca poderão recuperar isso..."

# game/endgame.rpy:1774
translate pt_br whereItBegan_a20cefa7_4:

    # "..."
    "..."

# game/endgame.rpy:1775
translate pt_br whereItBegan_7b3789fb:

    # "You brought this on yourself."
    "Você causou tudo isso."

# game/endgame.rpy:1779
translate pt_br whereItBegan_46dd9501:

    # cat3 "you are perfect"
    cat3 "você é perfeito"

# game/endgame.rpy:1780
translate pt_br whereItBegan_60798589:

    # you "I'm not."
    you "Não sou."

# game/endgame.rpy:1781
translate pt_br whereItBegan_b18d5776:

    # cat3 "you {i}are{/i}"
    cat3 "você {i}é{/i}"

# game/endgame.rpy:1782
translate pt_br whereItBegan_1cddd9bb:

    # cat3 "dont need the others"
    cat3 "não preciso dos outros"

# game/endgame.rpy:1783
translate pt_br whereItBegan_057f9031:

    # cat3 "just need you"
    cat3 "só de você"

# game/endgame.rpy:1784
translate pt_br whereItBegan_3f0d14d7:

    # cat3 "stay with me"
    cat3 "fique comigo"

# game/endgame.rpy:1785
translate pt_br whereItBegan_3ee5d6e5:

    # you "I won't."
    you "Não vou."

# game/endgame.rpy:1786
translate pt_br whereItBegan_51949c19:

    # cat3 "can give you anything"
    cat3 "posso te dar tudo"

# game/endgame.rpy:1787
translate pt_br whereItBegan_eeb62c46:

    # cat3 "can be everything for you"
    cat3 "posso ser tudo por você"

# game/endgame.rpy:1788
translate pt_br whereItBegan_ff690f3e:

    # you "No... You can't."
    you "Não... Você não pode."

# game/endgame.rpy:1789
translate pt_br whereItBegan_1244bbaf:

    # "You couldn't even {i}before...{/i}"
    "Não poderia nem mesmo {i}antes...{/i}"

# game/endgame.rpy:1790
translate pt_br whereItBegan_0c8bb1e9:

    # "You definitely can't {i}now...{/i}"
    "Definitivamente não pode {i}agora...{/i}"

# game/endgame.rpy:1791
translate pt_br whereItBegan_cb64e404:

    # "And..."
    "E..."

# game/endgame.rpy:1792
translate pt_br whereItBegan_d38bed87:

    # "Even if you {i}could{/i} give me everything I ever wanted and more..."
    "Mesmo que você {i}pudesse{/i} me dar tudo que sempre quis e mais..."

# game/endgame.rpy:1793
translate pt_br whereItBegan_a20cefa7_5:

    # "..."
    "..."

# game/endgame.rpy:1794
translate pt_br whereItBegan_2dad4a80:

    # "I'd {b}still{/b} never stay."
    "Eu {b}ainda assim{/b} nunca ficaria."

# game/endgame.rpy:1798
translate pt_br whereItBegan_68cdb263:

    # cat3 "i love you"
    cat3 "eu te amo"

# game/endgame.rpy:1799
translate pt_br whereItBegan_9cf90ed4:

    # you "No you-{w=0.3}{nw}"
    you "Você não-{w=0.3}{nw}"

# game/endgame.rpy:1802
translate pt_br whereItBegan_d49ea8d6:

    # cat3 "i {b}do{/b}"
    cat3 "eu {b}amo{/b}"

# game/endgame.rpy:1803
translate pt_br whereItBegan_dae0ec55_3:

    # you "..."
    you "..."

# game/endgame.rpy:1804
translate pt_br whereItBegan_258ecaf3:

    # cat3 "so much"
    cat3 "tanto"

# game/endgame.rpy:1805
translate pt_br whereItBegan_68cdb263_1:

    # cat3 "i love you"
    cat3 "eu te amo"

# game/endgame.rpy:1809
translate pt_br whereItBegan_6cdd727d:

    # cat3 "{size=-5}i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you i love you {/size}"
    cat3 "{size=-5}eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo eu te amo {/size}"

# game/endgame.rpy:1812
translate pt_br whereItBegan_f9bff14e:

    # you "{b}{i}Stop.{/i}{/b}"
    you "{b}{i}Para.{/i}{/b}"

# game/endgame.rpy:1813
translate pt_br whereItBegan_87df935d_1:

    # cat3 "..."
    cat3 "..."

# game/endgame.rpy:1814
translate pt_br whereItBegan_8753550f:

    # you "Maybe you {i}do{/i} love me..."
    you "Talvez você {i}realmente{/i} me ame..."

# game/endgame.rpy:1815
translate pt_br whereItBegan_26b2f544:

    # you "In some strange, screwed up way I'll never understand..."
    you "De um jeito estranho e distorcido que eu nunca vou entender..."

# game/endgame.rpy:1816
translate pt_br whereItBegan_8d59fc22:

    # you "But even if that's the case..."
    you "Mas mesmo que seja o caso..."

# game/endgame.rpy:1817
translate pt_br whereItBegan_dae0ec55_4:

    # you "..."
    you "..."

# game/endgame.rpy:1818
translate pt_br whereItBegan_a4a76912:

    # you "...It's not enough."
    you "...Isso não basta."

# game/endgame.rpy:1819
translate pt_br whereItBegan_87df935d_2:

    # cat3 "..."
    cat3 "..."

# game/endgame.rpy:1820
translate pt_br whereItBegan_ce7d4730:

    # cat3 "please"
    cat3 "por favor"

# game/endgame.rpy:1821
translate pt_br whereItBegan_4f636a45:

    # cat3 "dont go"
    cat3 "não vá"

# game/endgame.rpy:1822
translate pt_br whereItBegan_5b4c342f:

    # cat3 "ill be good"
    cat3 "vou ser bom"

# game/endgame.rpy:1823
translate pt_br whereItBegan_dae0ec55_5:

    # you "..."
    you "..."

# game/endgame.rpy:1824
translate pt_br whereItBegan_97b5d2b0:

    # you "I don't believe you."
    you "Eu não acredito eu você."

# game/endgame.rpy:1825
translate pt_br whereItBegan_dc4cb259:

    # cat3 "i promise"
    cat3 "eu prometo"

# game/endgame.rpy:1826
translate pt_br whereItBegan_dae0ec55_6:

    # you "..."
    you "..."

# game/endgame.rpy:1827
translate pt_br whereItBegan_e301b7d9:

    # you "I can't trust you."
    you "Não posso confiar em você."

# game/endgame.rpy:1828
translate pt_br whereItBegan_944f9217:

    # cat3 "{size=+10}i promise{/size}" with hpunch
    cat3 "{size=+10}eu prometo{/size}" with hpunch

# game/endgame.rpy:1829
translate pt_br whereItBegan_c8d092d5:

    # cat3 "just dont {b}leave{/b}"
    cat3 "só não {b}vá{/b}"

# game/endgame.rpy:1834
translate pt_br whereItBegan_1b817c48:

    # cat3 "{size=-5}dont leave me alone{/size}"
    cat3 "{size=-5}não me deixe sozinho{/size}"

# game/endgame.rpy:1835
translate pt_br whereItBegan_e81e0eae:

    # cat3 "{size=-8}please{/size}"
    cat3 "{size=-8}por favor{/size}"

# game/endgame.rpy:1836
translate pt_br whereItBegan_556d4f53:

    # cat3 "{size=-8}ill die{/size}"
    cat3 "{size=-8}vou morrer{/size}"

# game/endgame.rpy:1837
translate pt_br whereItBegan_9a0ddf1d:

    # cat3 "{size=-8}ill {b}die{/b} without you{/size}"
    cat3 "{size=-8}vou {b}morrer{/b} sem você{/size}"

# game/endgame.rpy:1838
translate pt_br whereItBegan_dae0ec55_7:

    # you "..."
    you "..."

# game/endgame.rpy:1843
translate pt_br whereItBegan_26f6da8b:

    # cat3 ".."
    cat3 ".."

# game/endgame.rpy:1844
translate pt_br whereItBegan_87df935d_3:

    # cat3 "..."
    cat3 "..."

# game/endgame.rpy:1851
translate pt_br whereItBegan_e94cd667:

    # cat3 "{size=-10}i {color=#FF0000}{b}hate{/b}{/color} you{/size}"
    cat3 "{size=-10}eu {color=#FF0000}{b}odeio{/b}{/color} você{/size}"

# game/endgame.rpy:1852
translate pt_br whereItBegan_dae0ec55_8:

    # you "..."
    you "..."

# game/endgame.rpy:1853
translate pt_br whereItBegan_8d18066c:

    # you "Now {b}{i}that{/i}{/b}... {w}I {i}can{/i} believe."
    you "Agora, {b}{i}isso{/i}{/b} sim... {w}Eu {i}consigo{/i} acreditar."

# game/endgame.rpy:1854
translate pt_br whereItBegan_87df935d_4:

    # cat3 "..."
    cat3 "..."

# game/endgame.rpy:1855
translate pt_br whereItBegan_8dabefc6_2:

    # ".."
    ".."

# game/endgame.rpy:1856
translate pt_br whereItBegan_a20cefa7_6:

    # "..."
    "..."

# game/endgame.rpy:1857
translate pt_br whereItBegan_bca6c5f8:

    # "There's nothing left to say."
    "Não há mais nada a dizer."

# game/endgame.rpy:1875
translate pt_br whereItBegan_2e1ef17d:

    # "I watch in silence as the cat..."
    "Você assiste em silêncio enquanto o gato..."

# game/endgame.rpy:1876
translate pt_br whereItBegan_53a0111a:

    # "...as {color=#FF0000}{b}it{/b}{/color}... {w}fades away into nothing..."
    "...enquanto {color=#FF0000}{b}isso{/b}{/color}... {w}se desfaz por completo..."

# game/endgame.rpy:1877
translate pt_br whereItBegan_a20cefa7_7:

    # "..."
    "..."

# game/endgame.rpy:1881
translate pt_br whereItBegan_dae0ec55_9:

    # you "..."
    you "..."

# game/endgame.rpy:1882
translate pt_br whereItBegan_0214ad62:

    # "{i}Goodbye...{/i}"
    "{i}Adeus...{/i}"

# game/endgame.rpy:1885
translate pt_br whereItBegan_d831204f:

    # "With one last glance around the alley..."
    "Com um último vislumbre pelo beco..."

# game/endgame.rpy:1888
translate pt_br whereItBegan_18671b5a:

    # "I turn..."
    "Eu me viro..."

# game/endgame.rpy:1896
translate pt_br whereItBegan_78e07a96:

    # "...and leave."
    "...e vou embora."

# game/endgame.rpy:1897
translate pt_br whereItBegan_8dabefc6_3:

    # ".."
    ".."

# game/endgame.rpy:1898
translate pt_br whereItBegan_a20cefa7_8:

    # "..."
    "..."

# game/endgame.rpy:1899
translate pt_br whereItBegan_ebb653f4:

    # "Ending 38: Do NOT Take This Cat Home"
    "Final 38: NÃO Leve Esse Gato Para Casa"

translate pt_br strings:

    # game/endgame.rpy:450
    old "What do you mean I was \"daydreaming\"?"
    new "Como assim eu tava \"sonhando acordado\"?"

    # game/endgame.rpy:450
    old "Where are we right now?"
    new "Onde a gente tá agora?"

    # game/endgame.rpy:450
    old "Why do you keep killing me?!"
    new "Por que você fica me matando?!"

    # game/endgame.rpy:450
    old "You're a cat, how are you talking?"
    new "Você é um gato, como consegue falar?"

    # game/endgame.rpy:450
    old "What do you want?"
    new "O que você quer?"

    # game/endgame.rpy:450
    old "Nothing, I don't care!"
    new "Nada, tô cagando e andando!"

    # game/endgame.rpy:472
    #old "Yes."
    #new "Sim."

    # game/endgame.rpy:472
    old "No..."
    new "Não..."

    # game/endgame.rpy:532
    old "Am I still dreaming?"
    new "Ainda estou sonhando?"

    # game/endgame.rpy:568
    old "You even made me kill {i}you{/i} in the end!"
    new "Você fez até eu {i}te{/i} matar no final!"

    # game/endgame.rpy:603
    old "But you're a {i}cat!{/i} How are you doing this?!"
    new "Mas você é um {i}gato!{/i} Como tá fazendo isso?!"

    # game/endgame.rpy:766
    old "\"I'll join you...\""
    new "\"Vou me juntar a você...\""

    # game/endgame.rpy:766
    old "\"I'd rather die.\""
    new "\"Prefiro morrer.\""

    # game/endgame.rpy:1519
    old "{size=-6}persist...{/size}"
    new "{size=-6}persistir...{/size}"

    # game/endgame.rpy:1688
    old "{b}P E R S I S T{/b}"
    new "{b}P E R S I S T I R{/b}"

    # game/endgame.rpy:1752
    old "Do not take this cat home."
    new "Não leve esse gato para casa."

    # game/endgame.rpy:1841
    old "Do {b}NOT{/b} take this cat home."
    new "{b}NÃO{/b} leve esse gato para casa."

    old "lies..."
    new "mentiras..."

    old "is {i}us{/i}..."
    new "somos {i}nós{/i}..."

    old "{i}we{/i} are strong..."
    new "{i}somos{/i} fortes..."

    old "persist..."
    new "persista..."

    old "{i}persist...{/i}"
    new "{i}persista...{/i}"
