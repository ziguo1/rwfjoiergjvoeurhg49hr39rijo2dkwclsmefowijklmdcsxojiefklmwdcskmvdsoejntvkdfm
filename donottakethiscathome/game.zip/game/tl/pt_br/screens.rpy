﻿# TODO: Translation updated at 2024-11-02 03:15

translate pt_br strings:

    # game/screens.rpy:256
    old "Back"
    new "Voltar"

    # game/screens.rpy:257
    old "History"
    new "Histórico"

    # game/screens.rpy:258
    old "Skip"
    new "Pular"

    # game/screens.rpy:259
    old "Auto"
    new "Auto"

    # game/screens.rpy:260
    old "Save"
    new "Salvar"

    # game/screens.rpy:261
    old "Q.Save"
    new "R.Salvar"

    # game/screens.rpy:262
    old "Q.Load"
    new "R.Carregar"

    # game/screens.rpy:263
    old "Prefs"
    new "Opções"

    # game/screens.rpy:306
    old "..."
    new "..."

    # game/screens.rpy:308
    old "Continue"
    new "Continuar"

    # game/screens.rpy:310
    old "Start"
    new "Começar"

    # game/screens.rpy:320
    old "Load"
    new "Carregar"

    # game/screens.rpy:330
    old "Preferences"
    new "Opções"

    # game/screens.rpy:334
    old "End Replay"
    new "Terminar repetição"

    # game/screens.rpy:338
    old "Main Menu"
    new "Menu Principal"

    # game/screens.rpy:341
    old "Endings"
    new "Finais"

    # game/screens.rpy:343
    old "???"
    new "???"

    # game/screens.rpy:345
    old "About"
    new "Sobre"

    # game/screens.rpy:350
    old "Help"
    new "Ajuda"

    # game/screens.rpy:352
    old "Credits"
    new "Créditos"

    # game/screens.rpy:358
    old "Quit"
    new "Sair"

    # game/screens.rpy:549
    old "Return"
    new "Voltar"

    old "\nYou find a cat on your day off. From there, you decide what happens next.\n"
    new "\nVocê encontra um gato no seu dia de folga. \nA partir daí, você decide o que acontece a seguir.\n"

    old "...Or {i}do{/i} you?"
    new "...Ou {i}será{/i} que não?"

    old "\n{size=+20}Content/Trigger Warnings{/size}"
    new "{size=+20}Avisos de Conteúdo/Gatilhos{/size}"

    # game/screens.rpy:640
    old "{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"
    new "{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"

    # game/screens.rpy:647
    old "\nContains {color=#FF0000}spoilers{/color}!\n\n"
    new "\nContém {color=#FF0000}spoilers{/color}!\n\n"

    # game/screens.rpy:649
    old "Abuse / abusive relationship(s)"
    new "Abuso / Relacionamento(s) abusivo(s)"

    # game/screens.rpy:650
    old "Agoraphobia"
    new "Agorafobia"

    # game/screens.rpy:651
    old "Amnesia"
    new "Amnésia"

    # game/screens.rpy:652
    old "Amputation / Dismemberment"
    new "Amputação / Desmembramento"

    # game/screens.rpy:653
    old "Animal abuse"
    new "Abuso de animais"

    # game/screens.rpy:654
    old "Animal death"
    new "Morte de animais"

    # game/screens.rpy:655
    old "Animals/monsters eating humans"
    new "Animais/monstros comendo humanos"

    # game/screens.rpy:656
    old "Anxiety / Social Anxiety"
    new "Ansiedade / Ansiedade Social"

    # game/screens.rpy:657
    old "Blood & gore"
    new "Sangue & gore"

    # game/screens.rpy:658
    old "Body horror"
    new "Horror corporal"

    # game/screens.rpy:659
    old "Body injury"
    new "Lesão corporal"

    # game/screens.rpy:660
    old "Cannibalism"
    new "Canibalismo"

    # game/screens.rpy:661
    old "Child abuse (minor mention/hint of)"
    new "Abuso infantil (menção/insinuação leve)"

    # game/screens.rpy:662
    old "Cosmic horror"
    new "Horror cósmico"

    # game/screens.rpy:663
    old "Dead bodies & body parts"
    new "Corpos mortos & partes do corpo"

    # game/screens.rpy:664
    old "Death / dying"
    new "Morte"

    # game/screens.rpy:665
    old "Decapitation"
    new "Decapitação"

    # game/screens.rpy:666
    old "Depression"
    new "Depressão"

    # game/screens.rpy:667
    old "Dissociation"
    new "Dissociação"

    # game/screens.rpy:668
    old "Doll animation"
    new "Animação de bonecos"

    # game/screens.rpy:669
    old "Emotional abuse"
    new "Abuso emocional"

    # game/screens.rpy:670
    old "Entrapment"
    new "Confinamento"

    # game/screens.rpy:671
    old "Epilepsy warning - flashing images & lights/static"
    new "Aviso de epilepsia - imagens e luzes/padrões piscantes"

    # game/screens.rpy:672
    old "Glitches"
    new "Glitches"

    # game/screens.rpy:673
    old "Hallucinations"
    new "Alucinações"

    # game/screens.rpy:674
    old "Heart attack"
    new "Ataque cardíaco"

    # game/screens.rpy:675
    old "Intrusive thoughts"
    new "Pensamentos intrusivos"

    # game/screens.rpy:676
    old "Isolation"
    new "Isolamento"

    # game/screens.rpy:677
    old "Kidnapping / abduction"
    new "Sequestro / abdução"

    # game/screens.rpy:678
    old "Loss of vision"
    new "Perda de visão"

    # game/screens.rpy:679
    old "Loud, sudden and/or repeating noises"
    new "Ruídos altos, repentinos e/ou repetitivos"

    # game/screens.rpy:680
    old "Manipulation / gaslighting"
    new "Manipulação / gaslighting"

    # game/screens.rpy:681
    old "Mental illness"
    new "Doença mental"

    # game/screens.rpy:682
    old "Mind control"
    new "Controle mental"

    # game/screens.rpy:683
    old "Murder"
    new "Assassinato"

    # game/screens.rpy:684
    old "Paranoia"
    new "Paranóia"

    # game/screens.rpy:685
    old "Poison / venom"
    new "Veneno / toxinas"

    # game/screens.rpy:686
    old "Psychological horror"
    new "Horror psicológico"

    # game/screens.rpy:687
    old "Scary / disturbing images & messages"
    new "Imagens e mensagens assustadoras / perturbadoras"

    # game/screens.rpy:688
    old "Scopophobia"
    new "Escopofobia"

    # game/screens.rpy:689
    old "Seizure"
    new "Convulsão"

    # game/screens.rpy:690
    old "Self-harm"
    new "Autolesão"

    # game/screens.rpy:691
    old "Stalking"
    new "Perseguição"

    # game/screens.rpy:692
    old "Suicide / Suicidal ideation"
    new "Suicídio / Ideação suicida"

    # game/screens.rpy:693
    old "Tense situations / gameplay"
    new "Situações / jogabilidade tensas"

    # game/screens.rpy:694
    old "Thalassophobia"
    new "Talassofobia"

    # game/screens.rpy:695
    old "Timed gameplay"
    new "Jogabilidade com limite de tempo"

    # game/screens.rpy:696
    old "Violence"
    new "Violência"

    # game/screens.rpy:697
    old "Vomiting"
    new "Vômito"

    # game/screens.rpy:699
    old "\n{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"
    new "\n{color=#FF0000}{b}_________________________________________________________________________________{/b}{/color}\n"

    # game/screens.rpy:700
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Feito com {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:719
    old "Endings Found: {color=#fff}[persistent.endCounter] / 40{/color}"
    new "Finais Descobertos: {color=#fff}[persistent.endCounter] / 40{/color}"

    # game/screens.rpy:729
    old "Ending 0: It Begins -- {color=#FF0000}Complete{/color}"
    new "Final 0: O Início -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:730
    old "    {i}{size=-3}Something... happened. You {b}think{/b}, anyway. You can't really remember what...{/size}{/i}"
    new "    {i}{size=-3}Algo... aconteceu. Pelo menos é o que você {b}acha{/b}. Você não consegue se lembrar do quê...{/size}{/i}"

    # game/screens.rpy:733
    old "\nEnding 0: It Begins -- {color=#FF0000}Complete{/color}"
    new "\nFinal 0: O Início -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:734
    old "    {i}{size=-3}The first time you took {color=#FF0000}{b}it{/b}{/color} home.{/size}{/i}"
    new "    {i}{size=-3}A primeira vez que você levou {color=#FF0000}{b}isso{/b}{/color} para casa.{/size}{/i}"

    # game/screens.rpy:742
    old "\nEnding 1: A (Not So) Clean Getaway -- {color=#FF0000}Complete{/color}"
    new "\nFinal 1: Uma Fuga (Não Tão) Limpa -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:743
    old "    {i}{size=-3}You tried to clean your apartment but apparently you're not very good at it.{/size}{/i}"
    new "    {i}{size=-3}Você tentou limpar seu apartamento, mas aparentemente você não é tão bom nisso.{/size}{/i}"

    # game/screens.rpy:751
    old "\nEnding 2: Double Trouble -- {color=#FF0000}Complete{/color}"
    new "\nFinal 2: Problema Em Dobro -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:752
    old "    {i}{size=-3}You found the ones responsible for making a mess of your apartment. Haha, those little pranksters...{/size}{/i}"
    new "    {i}{size=-3}Você encontrou os responsáveis pela bagunça no seu apartamento. Haha, essas pestinhas...{/size}{/i}"

    # game/screens.rpy:760
    old "\nEnding 3: Silent Film -- {color=#FF0000}Complete{/color}"
    new "\nFinal 3: O Mal Interior – {color=#FF0000}Completo{/color}"

    # game/screens.rpy:761
    old "    {i}{size=-3}You let the cat sit in your favorite chair and watched a scary movie together. Just an ordinary movie night.{/size}{/i}"
    new "    {i}{size=-3}Você deixou o gato se sentar na sua poltrona favorita e assistiram a um filme de terror juntos. Apenas mais uma noite de filmes.{/size}{/i}"

    # game/screens.rpy:769
    old "\nEnding 4: Real \"Subtle\" -- {color=#FF0000}Complete{/color}"
    new "\nFinal 4: Bem \"Sutil\" -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:770
    old "    {i}{size=-3}You took back the chair from the cat and enjoyed some silly, little jumpscares alone.{/size}{/i}"
    new "    {i}{size=-3}Você tomou de volta a poltrona do gato e curtiu alguns sustinhos sozinho.{/size}{/i}"

    # game/screens.rpy:778
    old "\nEnding 5: Do {i}Nyaa-t{/i} Disturb -- {color=#FF0000}Complete{/color}"
    new "\nFinal 5: Não {i}Mia Corde{/i} -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:779
    old "    {i}{size=-3}You shouldn't bother a cat while it's trying to nap...{/size}{/i}"
    new "    {i}{size=-3}Você não deveria incomodar um gato enquanto ele tenta cochilar...{/size}{/i}"

    # game/screens.rpy:787
    old "\nEnding 6: Just A Cat Nap -- {color=#FF0000}Complete{/color}"
    new "\nFinal 6: Só Um Cochilo -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:788
    old "    {i}{size=-3}Resting's good but you should get up and stretch every now and then... and eat... and {b}drink{/b}...{/size}{/i}"
    new "    {i}{size=-3}Descansar é bom, mas você deveria se levantar e alongar de vez em quando... e comer... e {b}beber{/b}...{/size}{/i}"

    # game/screens.rpy:796
    old "\nEnding 7: Personal Boundaries -- {color=#FF0000}Complete{/color}"
    new "\nFinal 7: Limites Pessoais -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:797
    old "    {i}{size=-3}Knowing how to take \"no\" for an answer is an important life lesson.{/size}{/i}"
    new "    {i}{size=-3}Saber aceitar um \"não\" como resposta é uma lição de vida importante.{/size}{/i}"

    # game/screens.rpy:805
    old "\nEnding 8: Fish Out of Water -- {color=#FF0000}Complete{/color}"
    new "\nFinal 8: Peixe Fora D'Água -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:806
    old "    {i}{size=-3}You fed the cat some tuna. It liked it okay...{/size}{/i}"
    new "    {i}{size=-3}Você deu um pouco de atum para o gato. Até que ele gostou...{/size}{/i}"

    # game/screens.rpy:814
    old "\nEnding 9: Leftovers -- {color=#FF0000}Complete{/color}"
    new "\nFinal 9: Sobras -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:815
    old "    {i}{size=-3}You fed the cat some leftover meatloaf. It liked it okay...{/size}{/i}"
    new "    {i}{size=-3}Você deu um pouco de bolo de carne que sobrou para o gato. Até que ele gostou...{/size}{/i}"

    # game/screens.rpy:823
    old "\nEnding 10: \"You are what you eat...\" -- {color=#FF0000}Complete{/color}"
    new "\nFinal 10: \"Você é o que você come...\" -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:824
    old "    {i}{size=-3}You fed the cat... {b}something{/b}... It really, {b}really{/b} liked it...{/size}{/i}"
    new "    {i}{size=-3}Você deu para o gato... {b}alguma coisa{/b}... Ele gostou muito, {b}muito{/b} mesmo…{/size}{/i}"

    # game/screens.rpy:832
    old "\nEnding 11: At The End of Your Rope -- {color=#FF0000}Complete{/color}"
    new "\nFinal 11: Fim Da Linha -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:833
    old "    {i}{size=-3}What cat doesn't love playing with some yarn?{/size}{/i}"
    new "    {i}{size=-3}Que tipo de gato não ama brincar com um novelo de lã?{/size}{/i}"

    # game/screens.rpy:841
    old "\nEnding 12: Targeted -- {color=#FF0000}Complete{/color}"
    new "\nFinal 12: Alvo -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:842
    old "    {i}{size=-3}The cat loses its mind over a tiny red dot. Hilarious!{/size}{/i}"
    new "    {i}{size=-3}O gato fica louco por causa de um pontinho vermelho. Hilário!{/size}{/i}"

    # game/screens.rpy:850
    old "\nEnding 13: Disappointing Prey -- {color=#FF0000}Complete{/color}"
    new "\nFinal 13: Presa Decepcionante -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:851
    old "    {i}{size=-3}You can't run. Apparently you can't hide either.{/size}{/i}"
    new "    {i}{size=-3}Você não pode correr. Aparentemente também não pode se esconder.{/size}{/i}"

    # game/screens.rpy:859
    old "\nEnding 14: Bath Hater -- {color=#FF0000}Complete{/color}"
    new "\nFinal 14: Anti-Banho -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:860
    old "    {i}{size=-3}Note to self: DO NOT THROW CATS INTO A BATHTUB FULL OF WATER{/size}{/i}"
    new "    {i}{size=-3}Nota pessoal: NÃO JOGAR GATOS EM UMA BANHEIRA CHEIA DE ÁGUA{/size}{/i}"

    # game/screens.rpy:868
    old "\nEnding 15: Self-Care Buddies -- {color=#FF0000}Complete{/color}"
    new "\nFinal 15: Amigões Vaidosos -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:869
    old "    {i}{size=-3}After you give the cat the full spa treatment, it tries its best to return the favor.{/size}{/i}"
    new "    {i}{size=-3}Após dar ao gato um tratamento de spa completo, ele dá o seu melhor para retribuir o favor.{/size}{/i}"

    # game/screens.rpy:877
    old "\nEnding 16: Poor Screening Arrangements -- {color=#FF0000}Complete{/color}"
    new "\nFinal 16: Péssima Administração -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:878
    old "    {i}{size=-3}You go to the old theater and enjoy a film with an interesting stranger.{/size}{/i}"
    new "    {i}{size=-3}Você vai ao velho teatro e assiste um filme com um estranho peculiar.{/size}{/i}"

    # game/screens.rpy:886
    old "\nEnding 17: Black Sheep -- {color=#FF0000}Complete{/color}"
    new "\nFinal 17: Ovelha Negra -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:887
    old "    {i}{size=-3}You weren't a big fan of the movie at the new cinema. The rest of the audience might have opinions about that.{/size}{/i}"
    new "    {i}{size=-3}Você não foi o maior fã do filme no cinema novo. O resto do público pode ter outra opinião sobre isso.{/size}{/i}"

    # game/screens.rpy:895
    old "\nEnding 18: Happy Birthday -- {color=#FF0000}Complete{/color}"
    new "\nFinal 18: Feliz Aniversário -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:896
    old "    {i}{size=-3}You have a front-row seat to the touching reunion of multiple siblings at the new cinema.{/size}{/i}"
    new "    {i}{size=-3}Você tem um assento na primeira fila para a emocionante reunião de vários irmãos no cinema novo.{/size}{/i}"

    # game/screens.rpy:907
    old "\nEnding 19: You beat the maze :D -- {color=#FF0000}Complete{/color}"
    new "\nFinal 19: Você venceu o labirinto :D -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:909
    old "    {i}{size=-3}Whoa, you beat the maze on {b}hard mode?!{/b/} Holy COW! You're a real gamer, ain't ya?{/size}{/i}"
    new "    {i}{size=-3}Uau, você venceu o labirinto no {b}modo difícil?!{/b/} Puxa vida! Você é um verdadeiro gamer, não é mesmo?{/size}{/i}"

    # game/screens.rpy:911
    old "    {i}{size=-3}Congratulations! You beat the maze.{/size}{/i}"
    new "    {i}{size=-3}Parabéns! Você venceu o labirinto.{/size}{/i}"

    # game/screens.rpy:919
    old "\nEnding 20: You failed the maze :( -- {color=#FF0000}Complete{/color}"
    new "\nFinal 20: Você falhou no labirinto :( -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:920
    old "    {i}{size=-3}Better luck next time...{/size}{/i}"
    new "    {i}{size=-3}Mais sorte na próxima...{/size}{/i}"

    # game/screens.rpy:928
    old "\nEnding 21: {color=#FF0000}d o g{/color}  person -- {color=#FF0000}Complete{/color}"
    new "\nFinal 21: prefiro  {color=#FF0000}c a c h o r r o s{/color} -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:929
    old "    {i}{size=-3}...You had a pleasant day at the  {color=#FF0000}{b}d o g{/b}{/color}  park.{/size}{/i}"
    new "    {i}{size=-3}...Você teve um dia agradável no parque para  {color=#FF0000}{b}c a c h o r r o s{/b}{/color} .{/size}{/i}"

    # game/screens.rpy:937
    old "\nEnding 22: Not Alone -- {color=#FF0000}Complete{/color}"
    new "\nFinal 22: Não Estou Sozinho -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:938
    old "    {i}{size=-3}Isn't it nice to feel heard?{/size}{/i}"
    new "    {i}{size=-3}Não é ótimo se sentir ouvido?{/size}{/i}"

    # game/screens.rpy:946
    old "\nEnding 23: Feedback loop -- {color=#FF0000}Complete{/color}"
    new "\nFinal 23: Ciclo sem fim -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:947
    old "    {i}{size=-3}You try to leave the alley. It doesn't work. You try to leave the alley. It doesn't work. You try to leave the alley. It doesn't{/size}{/i}"
    new "    {i}{size=-3}Você tenta sair do beco. Não dá certo. Você tenta sair do beco. Não dá certo. Você tenta sair do beco. Não dá{/size}{/i}"

    # game/screens.rpy:955
    old "\nEnding 24: Fishing for pardon -- {color=#FF0000}Complete{/color}"
    new "\nFinal 24: {i}Pesco{/i} desculpas -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:956
    old "    {i}{size=-3}Silly you! Chocolate is bad for cats! {s}{color=#FF0000}But you knew that, didn't you?{/color}{/s}{/size}{/i}"
    new "    {i}{size=-3}Bobalhão! Chocolate faz mal para gatos! {s}{color=#FF0000}Mas você sabia disso, não sabia?{/color}{/s}{/size}{/i}"

    # game/screens.rpy:964
    old "\nEnding 25: Seafood Sacrifice -- {color=#FF0000}Complete{/color}"
    new "\nFinal 25: Sacrifício de Frutos do Mar -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:965
    old "    {i}{size=-3}You kindly feed some poor, hungry cats a fish. How nice of you!{/size}{/i}"
    new "    {i}{size=-3}Você gentilmente alimentou pobres gatos famintos com peixe. Que bacana da sua parte!{/size}{/i}"

    # game/screens.rpy:973
    old "\nEnding 26: A life spared -- {color=#FF0000}Complete{/color}"
    new "\nFinal 26: Uma vida poupada -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:974
    old "    {i}{size=-3}You decide not to feed the poor, hungry cat a {s}helpless{/s} mouse. Meanie...{/size}{/i}"
    new "    {i}{size=-3}Você decide não alimentar o pobre gato faminto com um rato {s}indefeso{/s}. Maldade...{/size}{/i}"

    # game/screens.rpy:982
    old "\nEnding 27: Well-Fed -- {color=#FF0000}Complete{/color}"
    new "\nFinal 27: Bem Alimentado -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:983
    old "    {i}{size=-3}Cats are supposed to eat mice. Huh, wonder what mice are supposed to eat...{/size}{/i}"
    new "    {i}{size=-3}Gatos costumam comer ratos. Hum, fico imaginando o que os ratos comem…{/size}{/i}"

    # game/screens.rpy:991
    old "\nEnding 28: Personal care package -- {color=#FF0000}Complete{/color}"
    new "\nFinal 28: Pacote de cuidados pessoais -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:992
    old "    {i}{size=-3}You share a nice meal with the cat. A bit high in iron though.{/size}{/i}"
    new "    {i}{size=-3}Você divide uma refeição agradável com o gato. Um pouco alta em ferro, porém.{/size}{/i}"

    # game/screens.rpy:1000
    old "\nEnding 29: All You Can Eat Blood-fey -- {color=#FF0000}Complete{/color}"
    new "\nFinal 29: Rodízio Sangrento -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1001
    old "    {i}{size=-3}You give the cat an endless supply of food. Generous.{/size}{/i}"
    new "    {i}{size=-3}Você dá ao gato um suprimento infinito de comida. Generoso.{/size}{/i}"

    # game/screens.rpy:1009
    old "\nEnding 30: Photo bomber -- {color=#FF0000}Complete{/color}"
    new "\nFinal 30: Fotogênico -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1010
    old "    {i}{size=-3}You really nailed your good side in this one!{/size}{/i}"
    new "    {i}{size=-3}Você arrasou com seu melhor ângulo nessa foto!{/size}{/i}"

    # game/screens.rpy:1018
    old "\nEnding 31: Headshot -- {color=#FF0000}Complete{/color}"
    new "\nFinal 31: Perdendo a cabeça -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1019
    old "    {i}{size=-3}It's okay, we all get a little camera shy sometimes.{/size}{/i}"
    new "    {i}{size=-3}Tudo bem, todos ficamos tímidos na frente das câmeras de vez em quando.{/size}{/i}"

    # game/screens.rpy:1027
    old "\nEnding 32: Fear Quitter -- {color=#FF0000}Complete{/color}"
    new "\nFinal 32: Medroso -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1028
    old "    {i}{size=-3}\"When the going gets tough, just give up.\" That's how the saying goes, right?{/size}{/i}"
    new "    {i}{size=-3}\"Quando as coisas ficarem difíceis, é só desistir.\" É como diz o ditado, né?{/size}{/i}"

    # game/screens.rpy:1036
    old "\nEnding 33: {b}eRRoR{/b} \\ FoUnD -- {color=#FF0000}Complete{/color}"
    new "\nFinal 33: {b}eRRo{/b}  EnCoNtRaDo -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1037
    old "    {i}{size=-3}\"An exception has occurred. Please refrain from going outside of permitted parameters.\"{/size}{/i}"
    new "    {i}{size=-3}\"Ocorreu uma exceção. Por favor, evite sair dos parâmetros permitidos.\"{/size}{/i}"

    # game/screens.rpy:1045
    old "\nEnding 34: Living doll -- {color=#FF0000}Complete{/color}"
    new "\nFinal 34: Brinquedo vivo -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1046
    old "    {i}{size=-3}You end up getting the cat a nice companion!{/size}{/i}"
    new "    {i}{size=-3}Você acabou encontrando uma ótima companhia pro gato!{/size}{/i}"

    # game/screens.rpy:1054
    old "\nEnding 35: Cotton Headed -- {color=#FF0000}Complete{/color}"
    new "\nFinal 35: Bonequinho -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1055
    old "    {i}{size=-3}You're the only friend it needs.{/size}{/i}"
    new "    {i}{size=-3}Você é o único amigo que ele precisa.{/size}{/i}"

    # game/screens.rpy:1063
    old "\nEnding 36: Eight more left -- {color=#FF0000}Complete{/color}"
    new "\nFinal 36: Só mais oito -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1064
    old "    {i}{size=-3}Well that's {b}one{/b} down... Good luck on the rest.{/size}{/i}"
    new "    {i}{size=-3}Bom, {b}uma{/b} já foi... Boa sorte no resto.{/size}{/i}"

    # game/screens.rpy:1072
    old "\nEnding 37: {b}F o r e v e r{/b} -- {color=#FF0000}Complete{/color}"
    new "\nFinal 37: {b}P a r a  S e m p r e{/b} -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1073
    old "    {i}{size=-3}You join the cat. Now you'll always be together. At least... until...{/size}{/i}"
    new "    {i}{size=-3}Você se une ao gato. Agora vocês estarão sempre juntos. Pelo menos... até que...{/size}{/i}"

    # game/screens.rpy:1081
    old "\nEnding 38: Do NOT Take This Cat Home -- {color=#FF0000}Complete{/color}"
    new "\nFinal 38: NÃO Leve Esse Gato Para Casa -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1082
    old "    {i}{size=-3}Bad kitty.{/size}{/i}"
    new "    {i}{size=-3}Gatinho mau.{/size}{/i}"

    # game/screens.rpy:1090
    old "\nEnding N/A: Another day... -- {color=#FF0000}Complete{/color}"
    new "\nFinal N/A: Outro dia… -- {color=#FF0000}Completo{/color}"

    # game/screens.rpy:1091
    old "    {i}{size=-3}You have a nice day off and go home to spend the rest of the evening with your cute, little kitten.{/size}{/i}"
    new "    {i}{size=-3}Você tem um ótimo dia de folga e vai para casa passar o resto da noite com seu adorável gatinho.{/size}{/i}"

    # game/screens.rpy:1131
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:1131
    old "Automatic saves"
    new "Save automático"

    # game/screens.rpy:1131
    old "Quick saves"
    new "Save rápido"

    # game/screens.rpy:1173
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:1173
    old "empty slot"
    new "slot vazio"

    # game/screens.rpy:1190
    old "<"
    new "<"

    # game/screens.rpy:1193
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:1196
    old "{#quick_page}Q"
    new "{#quick_page}R"

    # game/screens.rpy:1202
    old ">"
    new ">"

    # game/screens.rpy:1259
    old "Display"
    new "Exibir"

    # game/screens.rpy:1260
    old "Window"
    new "Janela"

    # game/screens.rpy:1261
    old "Fullscreen"
    new "Tela cheia"

    # game/screens.rpy:1265
    old "Rollback Side"
    new "Lado de reversão"

    # game/screens.rpy:1266
    old "Disable"
    new "Desativar"

    # game/screens.rpy:1267
    old "Left"
    new "Esquerda"

    # game/screens.rpy:1268
    old "Right"
    new "Direita"

    # game/screens.rpy:1273
    old "Unseen Text"
    new "Texto Invisível"

    # game/screens.rpy:1274
    old "After Choices"
    new "Depois das Escolhas"

    # game/screens.rpy:1275
    old "Transitions"
    new "Transições"

    # game/screens.rpy:1282
    old "Language"
    new "Idioma"

    # game/screens.rpy:1294
    old "Text Speed"
    new "Velocidade do texto"

    # game/screens.rpy:1298
    old "Auto-Forward Time"
    new "Tempo de avanço automático"

    # game/screens.rpy:1305
    old "Music Volume"
    new "Volume da música"

    # game/screens.rpy:1312
    old "Sound Volume"
    new "Volume de som"

    # game/screens.rpy:1318
    old "Test"
    new "Teste"

    # game/screens.rpy:1322
    old "Voice Volume"
    new "Volume de voz"

    # game/screens.rpy:1333
    old "Mute All"
    new "Silenciar tudo"

    # game/screens.rpy:1452
    old "The dialogue history is empty."
    new "O histórico de diálogo está vazio."

    # game/screens.rpy:1522
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1523
    old "Mouse"
    new "Mouse"

    # game/screens.rpy:1526
    old "Gamepad"
    new "Controle"

    # game/screens.rpy:1539
    old "Enter"
    new "Enter"

    # game/screens.rpy:1540
    old "Advances dialogue and activates the interface."
    new "Pula o diálogo e ativa a interface."

    # game/screens.rpy:1543
    old "Space"
    new "Espaço"

    # game/screens.rpy:1544
    old "Advances dialogue without selecting choices."
    new "Pula o diálogo sem selecionar escolhas."

    # game/screens.rpy:1547
    old "Arrow Keys"
    new "Setinhas"

    # game/screens.rpy:1548
    old "Navigate the interface."
    new "Navegar pela interface."

    old "*Delete Save"
    new "*Deletar Save"

    # game/screens.rpy:1551
    old "Escape"
    new "Esc"

    # game/screens.rpy:1552
    old "Accesses the game menu."
    new "Acessa o menu do jogo."

    # game/screens.rpy:1555
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1556
    old "Skips dialogue while held down."
    new "Pula o diálogo quando pressionado."

    # game/screens.rpy:1559
    old "Tab"
    new "Tab"

    # game/screens.rpy:1560
    old "Toggles dialogue skipping."
    new "Alterna a opção de pular diálogos."

    # game/screens.rpy:1563
    old "Page Up"
    new "Page Up"

    # game/screens.rpy:1564
    old "Rolls back to earlier dialogue."
    new "Retorna ao diálogo anterior."

    # game/screens.rpy:1567
    old "Page Down"
    new "Page Down"

    # game/screens.rpy:1568
    old "Rolls forward to later dialogue."
    new "Pula para o diálogo posterior."

    # game/screens.rpy:1572
    old "Hides the user interface."
    new "Oculta a interface do usuário."

    # game/screens.rpy:1576
    old "Takes a screenshot."
    new "Faz uma captura de tela."

    # game/screens.rpy:1580
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Alterna a assistência de {a=https://www.renpy.org/l/voicing}voz.{/a}"

    # game/screens.rpy:1584
    old "Select save file with directional pad and press \"delete\" key."
    new "Selecione salvar arquivo com as setinhas e pressione a tecla \"delete\"."

    # game/screens.rpy:1590
    old "Left Click"
    new "Botão esquerdo"

    # game/screens.rpy:1594
    old "Middle Click"
    new "Botão do meio"

    # game/screens.rpy:1598
    old "Right Click"
    new "Botão direito"

    # game/screens.rpy:1602
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Roda do mouse para cima\nBotão lateral"

    # game/screens.rpy:1606
    old "Mouse Wheel Down"
    new "Roda do mouse para baixo"

    # game/screens.rpy:1611
    old "Hover mouse over save file and press \"delete\" key."
    new "Passe o mouse sobre o arquivo salvo e pressione a tecla \"delete\"."

    # game/screens.rpy:1617
    old "Right Trigger\nA/Bottom Button"
    new "Gatilho direito\nA/Botão inferior"

    # game/screens.rpy:1621
    old "Left Trigger\nLeft Shoulder"
    new "Gatilho esquerdo\nSuperior esquerdo"

    # game/screens.rpy:1625
    old "Right Shoulder"
    new "Superior direito"

    # game/screens.rpy:1630
    old "D-Pad, Sticks"
    new "Setinhas, Analógico"

    # game/screens.rpy:1634
    old "Start, Guide"
    new "Start, Guia"

    # game/screens.rpy:1638
    old "Y/Top Button"
    new "Y/Botão superior"

    # game/screens.rpy:1641
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1687
    old "Backgrounds &"
    new "Fundos e Imagens de fundo /"

    # game/screens.rpy:1688
    old "BG/Art References"
    new "Referências de arte"

    # game/screens.rpy:1689
    old "Pexels.com\n"
    new "Pexels.com\n"

    # game/screens.rpy:1690
    old "Sound Effects"
    new "Efeitos sonoros"

    # game/screens.rpy:1691
    old "Pixabay.com\n"
    new "Pixabay.com\n"

    # game/screens.rpy:1692
    old "Programmed with"
    new "Programado com"

    # game/screens.rpy:1693
    old "Ren'Py\n"
    new "Ren'Py\n"

    old "Português-BR Translation"
    new "Tradução Português-BR"

    old "George Ribeiro\n"
    new "George Ribeiro\n"

    # game/screens.rpy:1694
    old "And you..."
    new "E você..."

    # game/screens.rpy:1695
    old "Thank you for playing!\n"
    new "Obrigado por jogar!\n"

    old "{size=+40}Do Not Take{/size}"
    new "{size=+40}Não Leve{/size}"

    old "{size=+40}{color=#FF0000}I T {/color} Home{/size}"
    new "{size=+40}{color=#FF0000}I S S O {/color} Para Casa{/size}"

    old "{size=+40}This Cat Home{/size}"
    new "{size=+40}Esse Gato Para Casa{/size}"

    # game/screens.rpy:1792
    old "Skipping"
    new "Pulando"

    # game/screens.rpy:2015
    old "Menu"
    new "Menu"
