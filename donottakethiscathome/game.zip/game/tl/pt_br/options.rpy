﻿# TODO: Translation updated at 2024-11-02 03:15

translate pt_br strings:

    # game/options.rpy:15
    old "Do NOT Take This Cat Home"
    new "NÃO Leve Esse Gato Para Casa"
