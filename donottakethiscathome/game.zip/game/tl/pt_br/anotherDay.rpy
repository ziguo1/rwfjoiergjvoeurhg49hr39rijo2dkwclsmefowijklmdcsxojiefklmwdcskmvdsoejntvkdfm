﻿# TODO: Translation updated at 2024-11-02 03:15

# game/anotherDay.rpy:9
translate pt_br newDay_8dabefc6:

    # ".."
    ".."

# game/anotherDay.rpy:10
translate pt_br newDay_a20cefa7:

    # "..."
    "..."

# game/anotherDay.rpy:14
translate pt_br newDay_a20cefa7_1:

    # "..."
    "..."

# game/anotherDay.rpy:15
translate pt_br newDay_9ca326b8:

    # "Today's been... {w}surprising..?"
    "Hoje o dia foi... {w}surpreendente..?"

# game/anotherDay.rpy:16
translate pt_br newDay_a20cefa7_2:

    # "..."
    "..."

# game/anotherDay.rpy:18
translate pt_br newDay_f75e011d:

    # "Yeah... {w}{i}Pleasantly{/i} so."
    "É... {w} De um jeito {i}bom{/i}."

# game/anotherDay.rpy:23
translate pt_br newDay_82fa61bd:

    # "A day off that started with admittedly crummy weather led me to the old theater..."
    "Um dia de folga que começou com um tempo bem ruim me levou ao velho teatro..."

# game/anotherDay.rpy:26
translate pt_br newDay_6b209dab:

    # "...where I enjoyed a movie by myself. {w}My laughter filled up the empty theater."
    "...onde curti um filme sozinho. {w}Minha risada preencheu o cinema vazio."

# game/anotherDay.rpy:29
translate pt_br newDay_5d4d31f0:

    # "The rain had stopped by the time the movie was over..."
    "A chuva já tinha parado quando o filme acabou..."

# game/anotherDay.rpy:32
translate pt_br newDay_4e355058:

    # "...and I was in such a good mood, I hopped over to the not-so-new cinema..."
    "...e eu estava tão de bom humor que fui até o cinema não-tão-novo."

# game/anotherDay.rpy:33
translate pt_br newDay_5074d7cd:

    # "Not to watch another movie..."
    "Não para assistir outro filme..."

# game/anotherDay.rpy:36
translate pt_br newDay_112fac01:

    # "...but to play around in the arcade, earning a few high scores."
    "...mas sim para brincar no fliperama e marcar alguns recordes."

# game/anotherDay.rpy:39
translate pt_br newDay_5c2bbf14:

    # "With the gamer in me awakened, I went to the carnival to play some more..."
    "Com o gamer dentro de mim despertado, fui ao festival para jogar mais um pouco..."

# game/anotherDay.rpy:40
translate pt_br newDay_61e5a43c:

    # "...and was humbled fairly quickly."
    "...e logo fui colocado no meu lugar."

# game/anotherDay.rpy:43
translate pt_br newDay_008b7bea:

    # "But I {i}did{/i} manage to win a small stuffed animal at the ring toss booth..."
    "Mas eu {i}consegui{/i} ganhar um pequeno bicho de pelúcia na barraca de arremesso de argolas..."

# game/anotherDay.rpy:44
translate pt_br newDay_1c428f6d:

    # "The design is... {w}questionable..."
    "A aparência é... {w}questionável..."

# game/anotherDay.rpy:45
translate pt_br newDay_8dabefc6_1:

    # ".."
    ".."

# game/anotherDay.rpy:46
translate pt_br newDay_a20cefa7_3:

    # "..."
    "..."

# game/anotherDay.rpy:49
translate pt_br newDay_cf798fa8:

    # "...and I freaking {b}love{/b} it."
    "...e eu simplesmente {b}amo{/b} isso."

# game/anotherDay.rpy:52
translate pt_br newDay_8944ff2f:

    # "The rides weren't so bad either."
    "Os passeios também não foram tão ruins."

# game/anotherDay.rpy:53
translate pt_br newDay_4294899b:

    # "I got inducted into a group for a bit, while waiting in line at the ferris wheel..."
    "Fui integrado a um grupo por um tempo, enquanto esperava na fila da roda-gigante..."

# game/anotherDay.rpy:54
translate pt_br newDay_0c68408c:

    # "...bonding over our shared mistrust of the carnival's game vendors."
    "...unindo forças com nossa desconfiança compartilhada em relação aos vendedores de jogos do festival."

# game/anotherDay.rpy:55
translate pt_br newDay_e9c1e26b:

    # "I even shared a carriage on the ferris wheel with a few of them..."
    "Até compartilhei uma cabine na roda-gigante com alguns deles..."

# game/anotherDay.rpy:56
translate pt_br newDay_2246cb2d:

    # "...and exchanged numbers before we parted ways."
    "...e trocamos números antes de seguirmos caminhos diferentes."

# game/anotherDay.rpy:59
translate pt_br newDay_35f5ea23:

    # "I don't know if I'll ever see them again or if any of them will ever call me..."
    "Não sei se vou vê-los novamente ou se algum deles vai me ligar..."

# game/anotherDay.rpy:60
translate pt_br newDay_df3e5ab9:

    # "...or if I even have it in me to call any of {i}them...{/i}"
    "...ou se eu tenho coragem para ligar para algum {i}deles...{/i}"

# game/anotherDay.rpy:61
translate pt_br newDay_bf0874e3:

    # "But..."
    "Mas..."

# game/anotherDay.rpy:62
translate pt_br newDay_51014aa6:

    # "...having the option to do so is... {w}nice."
    "...ter a opção de fazer isso é... {w}legal."

# game/anotherDay.rpy:63
translate pt_br newDay_5fae18ae:

    # "It feels nice."
    "É legal."

# game/anotherDay.rpy:64
translate pt_br newDay_a20cefa7_4:

    # "..."
    "..."

# game/anotherDay.rpy:65
translate pt_br newDay_75f35366:

    # "Baby steps..."
    "Pequenos passos..."

# game/anotherDay.rpy:66
translate pt_br newDay_3aa81c02:

    # "After all, even that tiny bit of interaction, {w}though fun... {w}exhausted me."
    "Afinal, mesmo aquele pouquinho de interação, {w}embora divertido... {w}me deixou exausto."

# game/anotherDay.rpy:69
translate pt_br newDay_ff72ab2e:

    # "So I went to recharge at the dog park..."
    "Então fui recarregar as energias no parque para cachorros..."

# game/anotherDay.rpy:70
translate pt_br newDay_a0654299:

    # "...feeling rejuvenated at the sight of dogs... {w}old, young, big and small, {w}all running around..."
    "...me sentindo rejuvenescido ao ver os cachorros... {w}velhos, jovens, grandes e pequenos, {w}todos correndo..."

# game/anotherDay.rpy:73
translate pt_br newDay_b8191da0:

    # "...happy and carefree."
    "...alegres e despreocupados."

# game/anotherDay.rpy:77
translate pt_br newDay_26f7c165:

    # "A few of the owners even let me take pictures."
    "Alguns dos donos até me deixaram tirar fotos."

# game/anotherDay.rpy:80
translate pt_br newDay_81757b6b:

    # "...Yeah."
    "...É."

# game/anotherDay.rpy:81
translate pt_br newDay_c8368ac2:

    # "Today was a good day."
    "Hoje foi um bom dia."

# game/anotherDay.rpy:86
translate pt_br newDay_a20cefa7_5:

    # "..."
    "..."

# game/anotherDay.rpy:87
translate pt_br newDay_c70fb4a0:

    # "I don't think about the cat, or \"it\", I guess... all that much these days..."
    "Não penso muito no gato, ou \"isso\", eu acho... ultimamente..."

# game/anotherDay.rpy:88
translate pt_br newDay_79c0fad2:

    # "It was hard at first..."
    "Foi difícil no começo..."

# game/anotherDay.rpy:89
translate pt_br newDay_37f75de5:

    # "In the immediate days and weeks that followed..."
    "Nos dias e semanas seguintes..."

# game/anotherDay.rpy:90
translate pt_br newDay_4a9c65e2:

    # "...what happened to me was all I could think about."
    "...o que aconteceu comigo era tudo o que eu conseguia pensar."

# game/anotherDay.rpy:91
translate pt_br newDay_25500d1f:

    # "There were days I blamed myself..."
    "Houve dias em que me culpei..."

# game/anotherDay.rpy:92
translate pt_br newDay_d712875a:

    # "Days I questioned my choices..."
    "Dias em que questionei minhas escolhas..."

# game/anotherDay.rpy:93
translate pt_br newDay_5d330940:

    # "I went back to the alley more times than I want to admit..."
    "Voltei ao beco mais vezes do que gostaria de admitir..."

# game/anotherDay.rpy:94
translate pt_br newDay_06bc579c:

    # "The feeling that always went through me at the sight of that empty cardboard box..."
    "A sensação que sempre me invadia ao ver aquela caixa de papelão vazia..."

# game/anotherDay.rpy:95
translate pt_br newDay_af9d6393:

    # "...was so indescribable... {w}so {i}{b}overwhelming{/b}...{/i}"
    "...era tão indescritível... {w}tão {i}{b}avassaladora{/b}...{/i}"

# game/anotherDay.rpy:96
translate pt_br newDay_d7e56945:

    # "...I'd sometimes break down and cry right where I stood."
    "...que às vezes eu desabava e chorava bem onde estava."

# game/anotherDay.rpy:97
translate pt_br newDay_1933371e:

    # "It took a while, but eventually that strange emotion became clearer and clearer..."
    "Demorou um pouco, mas eventualmente aquela estranha emoção se tornou cada vez mais clara..."

# game/anotherDay.rpy:98
translate pt_br newDay_28266ef4:

    # "...until I had the courage to recognize it for what it was..."
    "...até que eu tive coragem de reconhecê-la pelo que era..."

# game/anotherDay.rpy:99
translate pt_br newDay_a20cefa7_6:

    # "..."
    "..."

# game/anotherDay.rpy:100
translate pt_br newDay_d38a0dc6:

    # "...\"Relief.\""
    "...\"Alívio.\""

# game/anotherDay.rpy:101
translate pt_br newDay_e22ded33:

    # "I'd been afraid to feel it for so long..."
    "Eu tive medo de sentir isso por tanto tempo..."

# game/anotherDay.rpy:102
translate pt_br newDay_3ed17d31:

    # "...terrified to let my guard down."
    "...apavorado demais para abaixar a guarda."

# game/anotherDay.rpy:103
translate pt_br newDay_a20cefa7_7:

    # "..."
    "..."

# game/anotherDay.rpy:104
translate pt_br newDay_364a8cff:

    # "But that sense of relief finally returned."
    "Mas aquele sentimento de alívio finalmente voltou."

# game/anotherDay.rpy:105
translate pt_br newDay_0e307cdc:

    # "Relief that \"it\" was gone..."
    "Alívio por \"isso\" ter ido embora..."

# game/anotherDay.rpy:106
translate pt_br newDay_c6ae1854:

    # "Relief that I was free to live my life..."
    "Alívio por eu estar livre para viver minha vida..."

# game/anotherDay.rpy:107
translate pt_br newDay_a20cefa7_8:

    # "..."
    "..."

# game/anotherDay.rpy:108
translate pt_br newDay_78dc6ac8:

    # "...however simply or extraordinarily {b}{i}I{/i}{/b} wished."
    "...de um jeito simples ou extraordinário, do jeito que {b}{i}eu{/i}{/b} quisesse."

# game/anotherDay.rpy:109
translate pt_br newDay_5374d191:

    # "The ones \"it\" had imprisoned..."
    "Aqueles que \"isso\" aprisionou..."

# game/anotherDay.rpy:110
translate pt_br newDay_4893c26e:

    # "I never heard their voices again either..."
    "Nunca mais ouvi suas vozes também..."

# game/anotherDay.rpy:111
translate pt_br newDay_1f6ffbc9:

    # "But that's for the best..."
    "Mas é melhor assim..."

# game/anotherDay.rpy:112
translate pt_br newDay_4bc19197:

    # "Living here and now..."
    "Vivendo aqui e agora..."

# game/anotherDay.rpy:113
translate pt_br newDay_9c8d77ec:

    # "Never forgetting what they did for me..."
    "Nunca esquecendo o que fizeram por mim..."

# game/anotherDay.rpy:114
translate pt_br newDay_475a8b7e:

    # "...and what I did for them, too..."
    "...e o que eu fiz por eles também..."

# game/anotherDay.rpy:115
translate pt_br newDay_a20cefa7_9:

    # "..."
    "..."

# game/anotherDay.rpy:116
translate pt_br newDay_b361ea6b:

    # "For now... I think that's enough..."
    "Por enquanto... acho que isso é suficiente..."

# game/anotherDay.rpy:117
translate pt_br newDay_298a3c15:

    # "At least, I hope so..."
    "Pelo menos, espero que sim..."

# game/anotherDay.rpy:118
translate pt_br newDay_0a2444b8:

    # "...and that wherever they are, they're finally at peace."
    "...e que onde quer que estejam, finalmente tenham encontrado paz."

# game/anotherDay.rpy:119
translate pt_br newDay_9e6de573:

    # "I'm fighting for my own peace too..."
    "Eu estou lutando pela minha própria paz também..."

# game/anotherDay.rpy:120
translate pt_br newDay_0f1329f4:

    # "One day at a time..."
    "Um dia após o outro..."

# game/anotherDay.rpy:121
translate pt_br newDay_a1af867c:

    # "One tomorrow after another..."
    "Um amanhã após o outro..."

# game/anotherDay.rpy:139
translate pt_br newDay_5795957d:

    # "Finally... {w}I head home..."
    "Finalmente... {w}Vou para casa..."

# game/anotherDay.rpy:140
translate pt_br newDay_3347a2a8:

    # "...to my little apartment."
    "...para meu pequeno apartamento."

# game/anotherDay.rpy:143
translate pt_br newDay_49ae6019:

    # "One bedroom... {w}one bathroom... {w}and one {i}me{/i} living alone in it."
    "Um quarto... {w}um banheiro... {w}Só {i}eu{/i} vivendo sozinho nele."

# game/anotherDay.rpy:147
translate pt_br newDay_8dabefc6_2:

    # ".."
    ".."

# game/anotherDay.rpy:148
translate pt_br newDay_a20cefa7_10:

    # "..."
    "..."

# game/anotherDay.rpy:149
translate pt_br newDay_bfab167e:

    # "Well..."
    "Bom..."

# game/anotherDay.rpy:150
translate pt_br newDay_f1fea4b8:

    # "{i}Almost{/i} anyway..."
    "{i}Quase{/i} isso..."

# game/anotherDay.rpy:153
translate pt_br newDay_15ad7189:

    # you "I'm home, baby~!"
    you "Tô em casa, benzinho~!"

# game/anotherDay.rpy:155
translate pt_br newDay_f845d69b:

    # who "Miiiiiew!" with hpunch
    who "Miiiiiau!" with hpunch

# game/anotherDay.rpy:159
translate pt_br newDay_426e1e56:

    # "A little kitten flails as it awkwardly runs over and mewls up at me..."
    "Um gatinho se agita enquanto corre desajeitadamente até mim, miando..."

# game/anotherDay.rpy:165
translate pt_br newDay_12ef594f:

    # kitten "Miiiiiew~"
    kitten "Miiiiiau~"

# game/anotherDay.rpy:167
translate pt_br newDay_1c0fd25a:

    # "I kneel down, looking fondly at its hazel-green eye."
    "Me ajoelho, olhando carinhosamente para seu olho verde-avelã."

# game/anotherDay.rpy:168
translate pt_br newDay_c3369978:

    # "The poor thing had been hurt and starving when I found it a few weeks ago..."
    "O coitadinho tinha se machucado e estava faminto quando encontrei ele há algumas semanas..."

# game/anotherDay.rpy:173
translate pt_br newDay_1b8a6de6:

    # "...but it certainly got its energy back after a little food and care."
    "...mas com certeza recuperou suas energias depois de um pouco de comida e cuidado."

# game/anotherDay.rpy:174
translate pt_br newDay_a0beacdc:

    # you "Did you miss me?"
    you "Sentiu saudade?"

# game/anotherDay.rpy:177
translate pt_br newDay_e2c8cb1d:

    # kitten "Miiiiew!" with hpunch
    kitten "Miiiiau!" with hpunch

# game/anotherDay.rpy:179
translate pt_br newDay_2efd6520:

    # you "Hungry, huh?"
    you "Com fome, hã?"

# game/anotherDay.rpy:185
translate pt_br newDay_a27db5c6:

    # kitten "Miii..."
    kitten "Miii..."

# game/anotherDay.rpy:187
translate pt_br newDay_01d545ca:

    # you "Hehe! Me too. It's been a {b}{i}long{/i}{/b} day..."
    you "Hehe! Eu também. Foi um {b}{i}longo{/i}{/b} dia..."

# game/anotherDay.rpy:188
translate pt_br newDay_5a6703df:

    # "I smile helplessly at its cute little face."
    "Eu sorrio todo bobão para seu rostinho fofo."

# game/anotherDay.rpy:189
translate pt_br newDay_24ea3155:

    # you "Let's find something to eat, okay?"
    you "Vamos arrumar algo pra comer, tá bom?"

# game/anotherDay.rpy:192
translate pt_br newDay_bc1c78d9:

    # kitten "Purr..."
    kitten "Purr..."

# game/anotherDay.rpy:197
translate pt_br newDay_c6f7b15a:

    # "Well... I guess there {i}is{/i} one more thing living in my home..."
    "Bem... acho que {i}tem{/i} mais uma coisa vivendo na minha casa..."

# game/anotherDay.rpy:198
translate pt_br newDay_8a9eb749:

    # "And... {w}at least for {i}now{/i}..."
    "E... {w}pelo menos por {i}agora{/i}..."

# game/anotherDay.rpy:199
translate pt_br newDay_a20cefa7_11:

    # "..."
    "..."

# game/anotherDay.rpy:200
translate pt_br newDay_89839a09:

    # "...I wouldn't have it any other way."
    "...Não gostaria que fosse diferente."

# game/anotherDay.rpy:201
translate pt_br newDay_8dabefc6_3:

    # ".."
    ".."

# game/anotherDay.rpy:202
translate pt_br newDay_a20cefa7_12:

    # "..."
    "..."

# game/anotherDay.rpy:203
translate pt_br newDay_f883a887:

    # "Ending N/A: Another day..."
    "Final N/A: Outro dia..."

# game/anotherDay.rpy:242
translate pt_br rollCredits_9ea2f78c:

    # " "
    "\ "

translate pt_br strings:

    old "{color=#FF0000}Backgrounds & BG/Art References{/color}\n\nPexels.com"
    new "{color=#FF0000}Cenários & Referências de Arte/Cenário{/color}\n\nPexels.com"

    old "{color=#FF0000}Sound Effects{/color}\n\nPixabay.com"
    new "{color=#FF0000}Efeitos Sonoros{/color}\n\nPixabay.com"

    old "{color=#FF0000}Programmed With{/color}\n\nRen'Py"
    new "{color=#FF0000}Programado Com{/color}\n\nRen'Py"

    old "{color=#FF0000}Português-BR Translation{/color}\n\nGeorge Ribeiro"
    new "{color=#FF0000}Tradução Português-BR{/color}\n\nGeorge Ribeiro"

    old "{color=#FF0000}And you...{/color}\n\nThank you for playing"
    new "{color=#FF0000}E à você...{/color}\n\nObrigado por jogar"

    old "The End"
    new "Fim"
