﻿# TODO: Translation updated at 2024-11-02 03:15

translate pt_br strings:

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "Auto-voz desabilitado."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "A dublagem da área de transferência está ativada."

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "Auto-voz habilitado."

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "haste"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "escolhido"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "janela de visualização"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "rolagem horizontal"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "rolagem vertical"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "ativar"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "desativar"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "aumentar"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "diminuir"

    # renpy/common/00accessibility.rpy:128
    old "Font Override"
    new "Substituição de fonte"

    # renpy/common/00accessibility.rpy:132
    old "Default"
    new "Padrão"

    # renpy/common/00accessibility.rpy:136
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:140
    old "Opendyslexic"
    new "Opendyslexic"

    # renpy/common/00accessibility.rpy:146
    old "Text Size Scaling"
    new "Dimensionamento do tamanho do texto"

    # renpy/common/00accessibility.rpy:152
    old "Reset"
    new "Reiniciar"

    # renpy/common/00accessibility.rpy:158
    old "Line Spacing Scaling"
    new "Escala de espaçamento de linha"

    # renpy/common/00accessibility.rpy:171
    old "Self-Voicing"
    new "Auto-Voz"

    # renpy/common/00accessibility.rpy:175
    old "Off"
    new "Desligado"

    # renpy/common/00accessibility.rpy:179
    old "Text-to-speech"
    new "Conversão de texto em fala"

    # renpy/common/00accessibility.rpy:183
    old "Clipboard"
    new "Área de transferência"

    # renpy/common/00accessibility.rpy:187
    old "Debug"
    new "Depurar"

    # renpy/common/00accessibility.rpy:193
    old "Self-Voicing Volume Drop"
    new "Queda de volume de auto-voz"

    # renpy/common/00accessibility.rpy:202
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "As opções neste menu têm a intenção de melhorar a acessibilidade. Elas podem não funcionar com todos os jogos, e algumas combinações de opções podem tornar o jogo impossível de jogar. Isso não é um problema com o jogo ou com o mecanismo. Para obter os melhores resultados ao alterar fontes, tente manter o tamanho do texto igual ao original."

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}Segunda-feira"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}Terça-feira"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}Quarta-feira"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}Quinta-feira"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}Sexta-feira"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}Sábado"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}Domingo"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}Seg"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}Ter"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}Qua"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}Qui"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}Sex"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}Sáb"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}Dom"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}Janeiro"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}Fevereiro"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}Março"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}Abril"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}Maio"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}Junho"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}Julho"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}Agosto"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}Setembro"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}Outubro"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}Novembro"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}Dezembro"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}Jan"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}Fev"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}Mar"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}Abr"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}Maio"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}Jun"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}Jul"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}Ago"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}Set"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}Out"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}Nov"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}Dez"

    # renpy/common/00action_file.rpy:250
    old "%b %d, %H:%M"
    new "%b %d, %H:%M"

    # renpy/common/00action_file.rpy:363
    old "Save slot %s: [text]"
    new "Salvar slot %s: [text]"

    # renpy/common/00action_file.rpy:444
    old "Load slot %s: [text]"
    new "Carregar slot %s: [text]"

    # renpy/common/00action_file.rpy:497
    old "Delete slot [text]"
    new "Excluir slot [text]"

    # renpy/common/00action_file.rpy:576
    old "File page auto"
    new "Página de arquivo auto"

    # renpy/common/00action_file.rpy:578
    old "File page quick"
    new "Página de arquivo rápido"

    # renpy/common/00action_file.rpy:580
    old "File page [text]"
    new "Página de arquivo [text]"

    # renpy/common/00action_file.rpy:779
    old "Next file page."
    new "Próxima página do arquivo."

    # renpy/common/00action_file.rpy:851
    old "Previous file page."
    new "Página do arquivo anterior."

    # renpy/common/00action_file.rpy:912
    old "Quick save complete."
    new "Salvamento rápido concluído."

    # renpy/common/00action_file.rpy:930
    old "Quick save."
    new "Salvamento rápido."

    # renpy/common/00action_file.rpy:949
    old "Quick load."
    new "Carregamento rápido."

    # renpy/common/00action_other.rpy:375
    old "Language [text]"
    new "Idioma [text]"

    # renpy/common/00director.rpy:708
    old "The interactive director is not enabled here."
    new "O diretor interativo não está habilitado aqui."

    # renpy/common/00director.rpy:1481
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1487
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1551
    old "Done"
    new "Feito"

    # renpy/common/00director.rpy:1561
    old "(statement)"
    new "(declaração)"

    # renpy/common/00director.rpy:1562
    old "(tag)"
    new "(marcação)"

    # renpy/common/00director.rpy:1563
    old "(attributes)"
    new "(atributos)"

    # renpy/common/00director.rpy:1564
    old "(transform)"
    new "(transformar)"

    # renpy/common/00director.rpy:1589
    old "(transition)"
    new "(transição)"

    # renpy/common/00director.rpy:1601
    old "(channel)"
    new "(canal)"

    # renpy/common/00director.rpy:1602
    old "(filename)"
    new "(nome do arquivo)"

    # renpy/common/00director.rpy:1631
    old "Change"
    new "Mudar"

    # renpy/common/00director.rpy:1633
    old "Add"
    new "Adicionar"

    # renpy/common/00director.rpy:1636
    old "Cancel"
    new "Cancelar"

    # renpy/common/00director.rpy:1639
    old "Remove"
    new "Remover"

    # renpy/common/00director.rpy:1674
    old "Statement:"
    new "Declaração:"

    # renpy/common/00director.rpy:1695
    old "Tag:"
    new "Marcação:"

    # renpy/common/00director.rpy:1711
    old "Attributes:"
    new "Atributos:"

    # renpy/common/00director.rpy:1729
    old "Transforms:"
    new "Transformações:"

    # renpy/common/00director.rpy:1748
    old "Behind:"
    new "Atrás:"

    # renpy/common/00director.rpy:1767
    old "Transition:"
    new "Transição:"

    # renpy/common/00director.rpy:1785
    old "Channel:"
    new "Canal:"

    # renpy/common/00director.rpy:1803
    old "Audio Filename:"
    new "Nome do arquivo de áudio:"

    # renpy/common/00gui.rpy:384
    old "Are you sure?"
    new "Tem certeza?"

    # renpy/common/00gui.rpy:385
    old "Are you sure you want to delete this save?"
    new "Tem certeza de que deseja excluir este salvamento?"

    # renpy/common/00gui.rpy:386
    old "Are you sure you want to overwrite your save?"
    new "Tem certeza de que deseja substituir seu salvamento?"

    # renpy/common/00gui.rpy:387
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "O carregamento perderá o progresso não salvo.\nTem certeza de que deseja fazer isso?"

    # renpy/common/00gui.rpy:388
    old "Are you sure you want to quit?"
    new "Tem certeza de que deseja sair?"

    # renpy/common/00gui.rpy:389
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "Tem certeza de que deseja retornar ao menu principal?\nIsso perderá o progresso não salvo."

    # renpy/common/00gui.rpy:390
    old "Are you sure you want to end the replay?"
    new "Tem certeza de que deseja encerrar o replay?"

    # renpy/common/00gui.rpy:391
    old "Are you sure you want to begin skipping?"
    new "Tem certeza de que deseja começar a pular?"

    # renpy/common/00gui.rpy:392
    old "Are you sure you want to skip to the next choice?"
    new "Tem certeza de que deseja pular para a próxima opção?"

    # renpy/common/00gui.rpy:393
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "Tem certeza de que deseja pular o diálogo não visto para a próxima opção?"

    # renpy/common/00keymap.rpy:306
    old "Failed to save screenshot as %s."
    new "Falha ao salvar a captura de tela como %s."

    # renpy/common/00keymap.rpy:318
    old "Saved screenshot as %s."
    new "Captura de tela salva como %s."

    # renpy/common/00library.rpy:195
    old "Skip Mode"
    new "Modo de pular"

    # renpy/common/00library.rpy:281
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Este programa contém software livre sob uma série de licenças, incluindo a Licença MIT e a Licença Pública Geral Menor GNU. Uma lista completa de software, incluindo links para o código-fonte completo, pode ser encontrada {a=https://www.renpy.org/l/license}aqui{/a}."

    # renpy/common/00preferences.rpy:247
    old "display"
    new "mostrar"

    # renpy/common/00preferences.rpy:259
    old "transitions"
    new "transições"

    # renpy/common/00preferences.rpy:268
    old "skip transitions"
    new "pular transições"

    # renpy/common/00preferences.rpy:270
    old "video sprites"
    new "sprites de vídeo"

    # renpy/common/00preferences.rpy:279
    old "show empty window"
    new "mostrar janela vazia"

    # renpy/common/00preferences.rpy:288
    old "text speed"
    new "velocidade do texto"

    # renpy/common/00preferences.rpy:296
    old "joystick"
    new "joystick"

    # renpy/common/00preferences.rpy:296
    old "joystick..."
    new "joystick..."

    # renpy/common/00preferences.rpy:303
    old "skip"
    new "pular"

    # renpy/common/00preferences.rpy:306
    old "skip unseen [text]"
    new "pular [text] invisível"

    # renpy/common/00preferences.rpy:311
    old "skip unseen text"
    new "pular texto não visto"

    # renpy/common/00preferences.rpy:313
    old "begin skipping"
    new "comece a pular"

    # renpy/common/00preferences.rpy:317
    old "after choices"
    new "depois das escolhas"

    # renpy/common/00preferences.rpy:324
    old "skip after choices"
    new "pular depois das escolhas"

    # renpy/common/00preferences.rpy:326
    old "auto-forward time"
    new "tempo de avanço automático"

    # renpy/common/00preferences.rpy:340
    old "auto-forward"
    new "avanço automático"

    # renpy/common/00preferences.rpy:347
    old "Auto forward"
    new "Avançar automaticamente"

    # renpy/common/00preferences.rpy:350
    old "auto-forward after click"
    new "avanço automático após clique"

    # renpy/common/00preferences.rpy:359
    old "automatic move"
    new "movimento automático"

    # renpy/common/00preferences.rpy:368
    old "wait for voice"
    new "espere pela voz"

    # renpy/common/00preferences.rpy:377
    old "voice sustain"
    new "sustentação da voz"

    # renpy/common/00preferences.rpy:386
    old "self voicing"
    new "auto voz"

    # renpy/common/00preferences.rpy:395
    old "self voicing volume drop"
    new "queda de volume de auto voz"

    # renpy/common/00preferences.rpy:403
    old "clipboard voicing"
    new "voz da área de transferência"

    # renpy/common/00preferences.rpy:412
    old "debug voicing"
    new "depuração de voz"

    # renpy/common/00preferences.rpy:421
    old "emphasize audio"
    new "enfatizar áudio"

    # renpy/common/00preferences.rpy:430
    old "rollback side"
    new "lado de reversão"

    # renpy/common/00preferences.rpy:440
    old "gl powersave"
    new "gl powersave"

    # renpy/common/00preferences.rpy:446
    old "gl framerate"
    new "gl framerate"

    # renpy/common/00preferences.rpy:449
    old "gl tearing"
    new "gl tearing"

    # renpy/common/00preferences.rpy:452
    old "font transform"
    new "transformação de fonte"

    # renpy/common/00preferences.rpy:455
    old "font size"
    new "tamanho da fonte"

    # renpy/common/00preferences.rpy:463
    old "font line spacing"
    new "espaçamento entre linhas da fonte"

    # renpy/common/00preferences.rpy:471
    old "system cursor"
    new "cursor do sistema"

    # renpy/common/00preferences.rpy:480
    old "renderer menu"
    new "menu do renderizador"

    # renpy/common/00preferences.rpy:483
    old "accessibility menu"
    new "menu de acessibilidade"

    # renpy/common/00preferences.rpy:496
    old "music volume"
    new "volume da música"

    # renpy/common/00preferences.rpy:497
    old "sound volume"
    new "volume do som"

    # renpy/common/00preferences.rpy:498
    old "voice volume"
    new "volume de voz"

    # renpy/common/00preferences.rpy:499
    old "mute music"
    new "música muda"

    # renpy/common/00preferences.rpy:500
    old "mute sound"
    new "som mudo"

    # renpy/common/00preferences.rpy:501
    old "mute voice"
    new "voz muda"

    # renpy/common/00preferences.rpy:502
    old "mute all"
    new "silenciar tudo"

    # renpy/common/00preferences.rpy:583
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Voz da área de transferência habilitada. Pressione 'shift+C' para desabilitar."

    # renpy/common/00preferences.rpy:585
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "A autovoz diria \"[renpy.display.tts.last]\". Pressione 'alt+shift+V' para desabilitar."

    # renpy/common/00preferences.rpy:587
    old "Self-voicing enabled. Press 'v' to disable."
    new "Auto-voz habilitado. Pressione 'v' para desabilitar."

    # renpy/common/_compat/gamemenu.rpym:198
    old "Empty Slot."
    new "Espaço vazio."

    # renpy/common/_compat/gamemenu.rpym:355
    old "Previous"
    new "Anterior"

    # renpy/common/_compat/gamemenu.rpym:362
    old "Next"
    new "Próximo"

    # renpy/common/_compat/preferences.rpym:428
    old "Joystick Mapping"
    new "Mapeamento de Joystick"

    # renpy/common/00gallery.rpy:590
    old "Image [index] of [count] locked."
    new "Imagem [index] de [count] bloqueada."

    # renpy/common/00gallery.rpy:610
    old "prev"
    new "anterior"

    # renpy/common/00gallery.rpy:611
    old "next"
    new "próximo"

    # renpy/common/00gallery.rpy:612
    old "slideshow"
    new "apresentação de slides"

    # renpy/common/00gallery.rpy:613
    old "return"
    new "voltar"

    # renpy/common/00gamepad.rpy:32
    old "Select Gamepad to Calibrate"
    new "Selecione o Gamepad para calibrar"

    # renpy/common/00gamepad.rpy:35
    old "No Gamepads Available"
    new "Nenhum controle disponível"

    # renpy/common/00gamepad.rpy:54
    old "Calibrating [name] ([i]/[total])"
    new "Calibrando [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:58
    old "Press or move the '[control!s]' [kind]."
    new "Pressione ou mova o '[control!s]' [kind]."

    # renpy/common/00gamepad.rpy:68
    old "Skip (A)"
    new "Pular (A)"

    # renpy/common/00gamepad.rpy:71
    old "Back (B)"
    new "Voltar (B)"

    # renpy/common/_errorhandling.rpym:542
    old "Open"
    new "Abrir"

    # renpy/common/_errorhandling.rpym:544
    old "Opens the traceback.txt file in a text editor."
    new "Abre o arquivo traceback.txt em um editor de texto."

    # renpy/common/_errorhandling.rpym:546
    old "Copy BBCode"
    new "Copiar BBCode"

    # renpy/common/_errorhandling.rpym:548
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia o arquivo traceback.txt para a área de transferência como BBcode para fóruns como https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:550
    old "Copy Markdown"
    new "Copiar Markdown"

    # renpy/common/_errorhandling.rpym:552
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia o arquivo traceback.txt para a área de transferência como Markdown para Discord."

    # renpy/common/_errorhandling.rpym:581
    old "An exception has occurred."
    new "Ocorreu uma exceção."

    # renpy/common/_errorhandling.rpym:604
    old "Rollback"
    new "Reverter"

    # renpy/common/_errorhandling.rpym:606
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Tenta reverter para um momento anterior, permitindo que você salve ou escolha uma opção diferente."

    # renpy/common/_errorhandling.rpym:613
    old "Ignores the exception, allowing you to continue."
    new "Ignora a exceção, permitindo que você continue."

    # renpy/common/_errorhandling.rpym:615
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora a exceção, permitindo que você continue. Isso frequentemente leva a erros adicionais."

    # renpy/common/_errorhandling.rpym:619
    old "Reload"
    new "Recarregar"

    # renpy/common/_errorhandling.rpym:621
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Recarrega o jogo do disco, salvando e restaurando o estado do jogo, se possível."

    # renpy/common/_errorhandling.rpym:624
    old "Console"
    new "Console"

    # renpy/common/_errorhandling.rpym:626
    old "Opens a console to allow debugging the problem."
    new "Abre um console para permitir a depuração do problema."

    # renpy/common/_errorhandling.rpym:639
    old "Quits the game."
    new "Sai do jogo."

    # renpy/common/_errorhandling.rpym:660
    old "Parsing the script failed."
    new "A análise do script falhou."

    # renpy/common/_errorhandling.rpym:686
    old "Opens the errors.txt file in a text editor."
    new "Abre o arquivo errors.txt em um editor de texto."

    # renpy/common/_errorhandling.rpym:690
    old "Copies the errors.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia o arquivo errors.txt para a área de transferência como BBcode para fóruns como https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:694
    old "Copies the errors.txt file to the clipboard as Markdown for Discord."
    new "Copia o arquivo errors.txt para a área de transferência como Markdown para Discord."
