﻿# TODO: Translation updated at 2024-11-02 03:15

# game/script.rpy:141
translate pt_br afterLanguage_9ea2f78c:

    # " "
    " "

# game/script.rpy:145
translate pt_br afterLanguage_9ea2f78c_1:

    # " "
    " "

# game/script.rpy:223
translate pt_br mainGame_a20cefa7:

    # "..."
    "..."

# game/script.rpy:224
translate pt_br mainGame_fb0939d1:

    # "You've been enjoying yourself, haven't you?"
    "Você se divertiu, não é?"

# game/script.rpy:225
translate pt_br mainGame_5a1fba27:

    # "Yes... {w}{i}I{/i} as well~"
    "Sim... {w}{i}Eu{/i} também~"

# game/script.rpy:226
translate pt_br mainGame_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:227
translate pt_br mainGame_b3e12ea5:

    # "Still..."
    "Mas..."

# game/script.rpy:228
translate pt_br mainGame_8f9c4d0d:

    # "All good things must come to an end..."
    "Tudo que é bom precisa chegar ao fim..."

# game/script.rpy:229
translate pt_br mainGame_d6f62ed1:

    # "...And I believe you are {b}ready.{/b}"
    "...E acredito que você esteja {b}pronto.{/b}"

# game/script.rpy:243
translate pt_br mainGameStart_8dabefc6:

    # ".."
    ".."

# game/script.rpy:244
translate pt_br mainGameStart_a20cefa7:

    # "..."
    "..."

# game/script.rpy:245
translate pt_br mainGameStart_2f052c40:

    # "You're walking..."
    "Você está caminhando..."

# game/script.rpy:246
translate pt_br mainGameStart_da373e99:

    # "Right. Of course."
    "Certo. É claro."

# game/script.rpy:247
translate pt_br mainGameStart_45f04c4f:

    # "It's the first time in a while that you've felt like going out..."
    "É a primeira vez em um bom tempo que te deu vontade de sair..."

# game/script.rpy:248
translate pt_br mainGameStart_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:249
translate pt_br mainGameStart_7039fb77:

    # "And you're..."
    "E você..."

# game/script.rpy:250
translate pt_br mainGameStart_4c74d5a4:

    # "...actually glad that you did."
    "...na verdade, está feliz por ter saído."

# game/script.rpy:255
translate pt_br mainGameStart_78cf1fa7:

    # "weather good today"
    "tempo bom hoje"

# game/script.rpy:256
translate pt_br mainGameStart_5ec9f3bf:

    # "that good thing"
    "essa coisa boa"

# game/script.rpy:257
translate pt_br mainGameStart_f21d0208:

    # "maybe good luck too"
    "talvez boa sorte também"

# game/script.rpy:258
translate pt_br mainGameStart_57725082:

    # "yes lucky"
    "sim sorte"

# game/script.rpy:262
translate pt_br mainGameStart_df511821:

    # "{w=0.6}lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}{nw}"
    "{w=0.6}sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}{nw}"

# game/script.rpy:265
translate pt_br mainGameStart_a3f9f101:

    # "lucky lucky lucky lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}{nw}"
    "sorte sorte sorte sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}sorte {w=0.6}{nw}"

# game/script.rpy:268
translate pt_br mainGameStart_db26c555:

    # "lucky lucky lucky lucky lucky lucky lucky lucky {w=0.3}lucky {w=0.3}lucky {w=0.3}lucky {w=0.3}lucky {w=0.6}{nw}"
    "sorte sorte sorte sorte sorte sorte sorte sorte {w=0.3}sorte {w=0.3}sorte {w=0.3}sorte {w=0.3}sorte {w=0.6}{nw}"

# game/script.rpy:281
translate pt_br mainGameStart_9ea2f78c:

    # " "
    " "

# game/script.rpy:290
translate pt_br mainGameStart_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/script.rpy:291
translate pt_br mainGameStart_dae0ec55:

    # you "..."
    you "..."

# game/script.rpy:295
translate pt_br mainGameStart_c7b678f0:

    # "The weather is absolutely {i}perfect{/i} today."
    "O tempo está absolutamente {i}perfeito{/i} hoje."

# game/script.rpy:296
translate pt_br mainGameStart_dadb738e:

    # "That's a good sign, right?"
    "É um bom sinal, né?"

# game/script.rpy:297
translate pt_br mainGameStart_a0ad31e8:

    # "Maybe your luck is finally starting to turn around."
    "Talvez sua sorte finalmente esteja começando a mudar."

# game/script.rpy:301
translate pt_br mainGameStart_c7b678f0_1:

    # "The weather is absolutely {i}perfect{/i} today."
    "O tempo está absolutamente {i}perfeito{/i} hoje."

# game/script.rpy:302
translate pt_br mainGameStart_dadb738e_1:

    # "That's a good sign, right?"
    "É um bom sinal, né?"

# game/script.rpy:303
translate pt_br mainGameStart_a0ad31e8_1:

    # "Maybe your luck is finally starting to turn around."
    "Talvez sua sorte finalmente esteja começando a mudar."

# game/script.rpy:308
translate pt_br mainGameStart_c8a18d3b:

    # "You tentatively allow yourself to feel excited for the possibilities of where you could go or what you could do..."
    "Você se permite sentir empolgado com cautela pelas possibilidades de onde você poderia ir ou o que poderia fazer..."

# game/script.rpy:309
translate pt_br mainGameStart_3967ef01:

    # "...Maybe even {i}who{/i} you could meet."
    "...Talvez até {i}quem{/i} você poderia encontrar."

# game/script.rpy:310
translate pt_br mainGameStart_1f1bf179:

    # "You're so deep in thought that you almost miss it."
    "Você está tão imerso em seus pensamentos que quase não percebe."

# game/script.rpy:312
translate pt_br mainGameStart_22b1ba98:

    # who "{size=-5}{alpha=0.4}Meow...{/alpha}{/size}"
    who "{size=-5}{alpha=0.4}Miau...{/alpha}{/size}"

# game/script.rpy:313
translate pt_br mainGameStart_d83b2afc:

    # you "{i}Huh? What was that?{/i}"
    you "{i}Hã? O que foi isso?{/i}"

# game/script.rpy:316
translate pt_br mainGameStart_38cc5198:

    # "Curiosity guiding your steps, you follow the sound to the entrance of a lonely alleyway."
    "Com a curiosidade guiando seus passos, você segue o som até a entrada de um beco solitário."

# game/script.rpy:317
translate pt_br mainGameStart_741a7cdd:

    # "The sunlight only {i}just{/i} manages to reach down in between the tall buildings on either side."
    "A luz do sol só consegue alcançar, {i}com dificuldade{/i}, o espaço entre os altos edifícios de cada um dos lados."

# game/script.rpy:318
translate pt_br mainGameStart_d1586eaa:

    # "You timidly enter the alley and walk forward, the loose gravel and scattered debris on the ground softening your steps."
    "Você entra timidamente no beco e segue, com o cascalho solto e o entulho espalhado no chão amortecendo seus passos."

# game/script.rpy:320
translate pt_br mainGameStart_a46fe60b:

    # who "Meow! Meow!"
    who "Miau! Miau!"

# game/script.rpy:321
translate pt_br mainGameStart_1b77a27b:

    # "Finally the sound's source comes into view in the warm, almost ethereal light of the alley..."
    "Finalmente você tem visão da fonte do som na luz quente, quase etérea, do beco..."

# game/script.rpy:324
translate pt_br mainGameStart_1b5c33fc:

    # "At the end of the alley..."
    "No fim do beco..."

# game/script.rpy:325
translate pt_br mainGameStart_f6400e85:

    # "...in a big cardboard box..."
    "...em uma caixa grande de papelão..."

# game/script.rpy:326
translate pt_br mainGameStart_8dabefc6_1:

    # ".."
    ".."

# game/script.rpy:327
translate pt_br mainGameStart_a20cefa7_2:

    # "..."
    "..."

# game/script.rpy:331
translate pt_br mainGameStart_69a9648a:

    # "...is a cat."
    "...tem um gato."

# game/script.rpy:332
translate pt_br mainGameStart_605589a2:

    # you "Huh. Guess that should've been... obvious..?"
    you "Hã. Acho que isso era… óbvio..?"

# game/script.rpy:336
translate pt_br mainGameStart_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/script.rpy:338
translate pt_br mainGameStart_fc6b31f2:

    # "It's an interesting looking cat. Its pretty yellow eyes shine like gold among the dark sea of its black fur."
    "É um gato com uma aparência interessante. Seus lindos olhos amarelos brilham como ouro entre o mar negro de sua pelagem preta."

# game/script.rpy:341
translate pt_br mainGameStart_3b9482ac:

    # "It puts its front paws up on the edge of the box and looks up at you."
    "Ele coloca as patas da frente na borda da caixa e olha para você."

# game/script.rpy:345
translate pt_br mainGameStart_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/script.rpy:347
translate pt_br mainGameStart_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/script.rpy:348
translate pt_br mainGameStart_242bb4ce:

    # you "{i}S-{w}So..!{/i}"
    you "{i}T-{w}Tão..!{/i}"

# game/script.rpy:349
translate pt_br mainGameStart_dae0ec55_1:

    # you "..."
    you "..."

# game/script.rpy:350
translate pt_br mainGameStart_90b68c87:

    # you "..?"
    you "..?"

# game/script.rpy:351
translate pt_br mainGameStart_ea0ef047:

    # you "You look so..."
    you "Você parece tão..."

# game/script.rpy:352
translate pt_br mainGameStart_8dabefc6_2:

    # ".."
    ".."

# game/script.rpy:353
translate pt_br mainGameStart_ab627e54:

    # "...{i}familiar{/i}."
    "...{i}familiar{/i}."

# game/script.rpy:354
translate pt_br mainGameStart_c06dcd96:

    # "...Right?"
    "...Né?"

# game/script.rpy:358
translate pt_br mainGameStart_e5fab8a0_1:

    # cat "Meow!"
    cat "Miau!"

# game/script.rpy:360
translate pt_br mainGameStart_a20cefa7_3:

    # "..."
    "..."

# game/script.rpy:361
translate pt_br mainGameStart_23175e48:

    # "Then again, it {i}is{/i} a cat. Not many different ways for a standard black cat to look, after all."
    "Por outro lado, {i}é{/i} um gato. Afinal, não há muitas formas diferentes para um gato preto normal se parecer."

# game/script.rpy:362
translate pt_br mainGameStart_a20cefa7_4:

    # "..."
    "..."

# game/script.rpy:363
translate pt_br mainGameStart_849caf29:

    # "{i}This{/i} one sure is a cutie, though."
    "Mas {i}esse{/i} aqui é uma fofura, com certeza."

# game/script.rpy:364
translate pt_br mainGameStart_ff38a381:

    # "Just look..."
    "Olhe..."

# game/script.rpy:365
translate pt_br mainGameStart_480ec193:

    # "It's not glaring at you or hissing at you for getting this close like other stray cats have in the past."
    "Ele não está te encarando fixamente ou mostrando os dentes por você ter chegado tão perto, como outros gatos de rua já fizeram."

# game/script.rpy:366
translate pt_br mainGameStart_1d08389c:

    # "It's just sitting there patiently..."
    "Está apenas sentado ali pacientemente..."

# game/script.rpy:367
translate pt_br mainGameStart_85f1774e:

    # "Waiting for you to do something..."
    "Esperando você fazer alguma coisa..."

# game/script.rpy:382
translate pt_br mainChoice1_230edd2e:

    # "Sadly, as cute as the cat is..."
    "Infelizmente, por mais fofo que o gato seja..."

# game/script.rpy:383
translate pt_br mainChoice1_a20cefa7:

    # "..."
    "..."

# game/script.rpy:386
translate pt_br mainChoice1_3313542d:

    # "{size=-10}...you'd {b}never{/b} take this {color=#FF0000}{b}thing{/b}{/color} home with you.{/size}"
    "{size=-10}...você {b}nunca{/b} levaria essa {color=#FF0000}{b}coisa{/b}{/color} para casa.{/size}"

# game/script.rpy:389
translate pt_br mainChoice1_8dabefc6:

    # ".."
    ".."

# game/script.rpy:390
translate pt_br mainChoice1_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:391
translate pt_br mainChoice1_ab96ac00:

    # "...you just {i}can't{/i} take it home with you."
    "...você só {i}não pode{/i} levá-lo para casa com você."

# game/script.rpy:392
translate pt_br mainChoice1_e10d4d87:

    # "You're a responsible adult."
    "Você é um adulto responsável."

# game/script.rpy:399
translate pt_br mainChoice1_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/script.rpy:401
translate pt_br mainChoice1_9c8908c5:

    # "Y-You {i}are!{/i}"
    "V-Você {i}é!{/i}"

# game/script.rpy:402
translate pt_br mainChoice1_473c0e80:

    # "With rent and bills to pay for! Not to mention you need to buy food to survive too!"
    "Com aluguel e contas para pagar! Sem contar que você também precisa comprar comida para sobreviver!"

# game/script.rpy:403
translate pt_br mainChoice1_6783211d:

    # "There's no way {i}you{/i} could care for a cat long term, right?"
    "Não tem como {i}você{/i} cuidar de um gato a longo prazo, né?"

# game/script.rpy:404
translate pt_br mainChoice1_8d3712f3:

    # "You can barely afford this little outing on your day off..."
    "Você mal pode arcar com essa saidinha no seu dia de folga..."

# game/script.rpy:408
translate pt_br mainChoice1_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/script.rpy:410
translate pt_br mainChoice1_dae0ec55:

    # you "..."
    you "..."

# game/script.rpy:411
translate pt_br mainChoice1_af5ee6df:

    # "What to do..."
    "O que fazer..."

# game/script.rpy:415
translate pt_br mainChoice2_7f0ac95c:

    # cat "..."
    cat "..."

# game/script.rpy:416
translate pt_br mainChoice2_dae0ec55:

    # you "..."
    you "..."

# game/script.rpy:423
translate pt_br mainChoice2_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/script.rpy:425
translate pt_br mainChoice2_dae0ec55_1:

    # you "..."
    you "..."

# game/script.rpy:426
translate pt_br mainChoice2_549c54ff:

    # you "Well... Why not?"
    you "Bem... Por que não?"

# game/script.rpy:428
translate pt_br mainChoice2_9979a58c:

    # "Right?"
    "Né?"

# game/script.rpy:432
translate pt_br mainChoice2_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/script.rpy:437
translate pt_br mainChoice2_c97c6224:

    # "You barely reach out your arms before the cat eagerly leaps into them and climbs up onto your shoulders."
    "Você mal estende os braços antes que o gato, ansioso, salte neles e escale até os seus ombros."

# game/script.rpy:438
translate pt_br mainChoice2_6dcf309e:

    # "It butts its head into your temple nuzzling against it."
    "Ele esfrega a cabeça na lateral da sua, acariciando-a."

# game/script.rpy:440
translate pt_br mainChoice2_cc63b22e:

    # cat "Purr... Purr... Purr..."
    cat "Purr... Purr... Purr..."

# game/script.rpy:441
translate pt_br mainChoice2_dae0ec55_2:

    # you "..."
    you "..."

# game/script.rpy:442
translate pt_br mainChoice2_8de35a3a:

    # you "Hehe..."
    you "Hehe..."

# game/script.rpy:443
translate pt_br mainChoice2_b7f6e266:

    # "You can't help but smile at the cat's enthusiasm."
    "Você não consegue deixar de sorrir com o entusiasmo do gato."

# game/script.rpy:446
translate pt_br mainChoice2_c18c153e:

    # you "Let's get you out of here, yeah?"
    you "Vamos sair daqui, tá?"

# game/script.rpy:448
translate pt_br mainChoice2_67107e6c:

    # cat "Purr..."
    cat "Purr..."

# game/script.rpy:452
translate pt_br mainChoice2_0c4dd6d6:

    # "On the way home, you briefly consider getting cat food..."
    "No caminho de volta, você considera por um instante comprar ração para o gato..."

# game/script.rpy:453
translate pt_br mainChoice2_8dabefc6:

    # ".."
    ".."

# game/script.rpy:454
translate pt_br mainChoice2_a20cefa7:

    # "..."
    "..."

# game/script.rpy:456
translate pt_br mainChoice2_ba9adcaf:

    # "{size=-5}But that would be a waste of time.{/size}"
    "{size=-5}Mas isso seria perda de tempo.{/size}"

# game/script.rpy:458
translate pt_br mainChoice2_40d9ca73:

    # "..?"
    "..?"

# game/script.rpy:459
translate pt_br mainChoice2_45eb50c5:

    # "You shrug at the odd feeling and move on."
    "Você ignora a sensação estranha e segue em frente."

# game/script.rpy:462
translate pt_br mainChoice2_df101305:

    # "You live in a modest apartment."
    "Você vive em um apartamento humilde."

# game/script.rpy:465
translate pt_br mainChoice2_247ad3ce:

    # "One bedroom. One bathroom."
    "Um quarto. Um banheiro."

# game/script.rpy:466
translate pt_br mainChoice2_2d3f71e5:

    # "One {i}you{/i} living alone in it..."
    "Apenas {i}você{/i} vivendo sozinho nele..."

# game/script.rpy:469
translate pt_br mainChoice2_f380a402:

    # "So it feels weird having another living being inside it after so long."
    "Então, é estranho ter outro ser vivo aí dentro depois de tanto tempo."

# game/script.rpy:470
translate pt_br mainChoice2_8b0c916e:

    # "Even if it {i}is{/i} just a cat."
    "Mesmo que {i}seja{/i} só um gato."

# game/script.rpy:474
translate pt_br mainChoice2_1c9ee7fd:

    # "After locking the front door and placing the cat on the floor, you wait for it to walk away and explore the new environment."
    "Depois de trancar a porta e colocar o gato no chão, você espera que ele saia andando e explorando o novo ambiente."

# game/script.rpy:475
translate pt_br mainChoice2_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:476
translate pt_br mainChoice2_480ae195:

    # "But it simply sits and looks up at you expectantly..."
    "Mas ele apenas fica sentado e olha para você com expectativa..."

translate pt_br strings:
    old "This game is not suitable for children or the easily disturbed.\n\nIt includes depictions of horror elements, human/animal violence and death,\nabuse/abusive relationship(s), disturbing images, loud noises, flashing images/lights and more.\nIndividuals suffering from anxiety, depression or certain fears/phobias may not have a safe experience playing this game.\n\nFor full list of content/trigger warnings go to 'About' section in the game's main menu."
    new "Este jogo não é adequado para crianças ou para pessoas sensíveis. \n\nInclui representações de elementos de horror, violência animal/humana e morte,\nabuso/relacionamento(s) abusivo(s), imagens perturbadoras, ruídos altos, imagens/luzes piscando e mais.\nIndivíduos que sofrem de ansiedade, depressão ou certos medos/fobias podem não ter uma experiência segura ao jogar este jogo.\n\nPara a lista completa de avisos de conteúdo/gatilho, vá à seção 'Sobre' no menu principal do jogo."

    old "Please take care of yourself."
    new "Por favor, cuide-se."

    old "\ "
    new "\ "

    # game/script.rpy:375
    old "Take cat home!"
    new "Levar o gato para casa!"

    # game/script.rpy:375
    old "Do not take cat home..."
    new "Não levar o gato para casa..."

    old "You"
    new "Você"

    old "Cat"
    new "Gato"

    old "Cat #2"
    new "Gato #2"

    #old "Mouse"
    #new "Rato"

    old "Text"
    new "Texto"

    old "Cat on screen"
    new "Gato na tela"

    old "Audience"
    new "Público"

    old "Dog"
    new "Cachorro"

    old "Cat Doll"
    new "Boneca Gato"

    old "Kitten"
    new "Gatinho"

    old "I T"
    new "I S S O"
