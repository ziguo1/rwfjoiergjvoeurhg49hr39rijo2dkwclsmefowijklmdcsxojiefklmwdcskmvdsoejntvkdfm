﻿# TODO: Translation updated at 2024-11-02 03:15

# game/atHome.rpy:523
translate pt_br atHome_start_dc8d0895:

    # "Like what?"
    "Tipo o quê?"

# game/atHome.rpy:526
translate pt_br atHome_start_dc8d0895_1:

    # "Like what?"
    "Tipo o quê?"

# game/atHome.rpy:554
translate pt_br cleanHome_a2afa525:

    # "You decide that even if it's your day off, that doesn't mean you should be {i}completely{/i} unproductive."
    "Você decide que, mesmo sendo seu dia de folga, isso não quer dizer que você deva ser {i}completamente{/i} improdutivo."

# game/atHome.rpy:555
translate pt_br cleanHome_d5bf1ac2:

    # "You know you have a guest and all, but you really shouldn't put off your chores."
    "Você sabe que tem um convidado e tudo mais, mas não deveria adiar suas tarefas."

# game/atHome.rpy:556
translate pt_br cleanHome_82116c0b:

    # "Best to get them done while you're in the mood to do so..."
    "Melhor terminar logo enquanto está no clima pra isso..."

# game/atHome.rpy:557
translate pt_br cleanHome_38aeb1c1:

    # "So for now, you get dressed, roll up your sleeves and get to work on cleaning the apartment."
    "Então, por agora, você se veste, arregaça as mangas e começa a limpar o apartamento."

# game/atHome.rpy:560
translate pt_br cleanHome_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:561
translate pt_br cleanHome_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:562
translate pt_br cleanHome_0ef3b42c:

    # "At least..."
    "Pelo menos..."

# game/atHome.rpy:563
translate pt_br cleanHome_be509105:

    # "...you {i}try{/i} to?"
    "...você {i}tenta{/i}?"

# game/atHome.rpy:566
translate pt_br cleanHome_251a3003:

    # "You sweep the living room..."
    "Você varre a sala..."

# game/atHome.rpy:569
translate pt_br cleanHome_801add69:

    # "You wipe the kitchen counter..."
    "Você limpa o balcão da cozinha..."

# game/atHome.rpy:572
translate pt_br cleanHome_0f5de544:

    # "You..."
    "Você..."

# game/atHome.rpy:573
translate pt_br cleanHome_94b91bfc:

    # "Okay you don't make your bed, but who actually does that anyway?"
    "Tá, você não arruma a cama, mas quem é que faz isso afinal?"

# game/atHome.rpy:576
translate pt_br cleanHome_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:577
translate pt_br cleanHome_b3e12ea5:

    # "Still..."
    "Ainda assim..."

# game/atHome.rpy:578
translate pt_br cleanHome_e3226b50:

    # "You notice that no matter how much you clean up..."
    "Você nota que, não importa quanto limpe..."

# game/atHome.rpy:579
translate pt_br cleanHome_fe5c443f:

    # "...you keep finding more messes than when you started."
    "...você continua encontrando mais bagunça do que quando começou."

# game/atHome.rpy:580
translate pt_br cleanHome_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:581
translate pt_br cleanHome_6cf4e540:

    # "You peek over at the cat."
    "Você espia o gato."

# game/atHome.rpy:584
translate pt_br cleanHome_9e899f4f:

    # "You suspect that it might be the culprit behind this mystery..."
    "Você suspeita que ele possa ser o culpado por trás desse mistério..."

# game/atHome.rpy:585
translate pt_br cleanHome_ef50fc2a:

    # "But every time you rush to check on it or catch it in the act..."
    "Mas toda vez que você corre para checar ou pegá-lo no pulo..."

# game/atHome.rpy:587
translate pt_br cleanHome_78b6d9cf:

    # cat "Purr.. Purr.."
    cat "Purr.. Purr.."

# game/atHome.rpy:588
translate pt_br cleanHome_e12dcff9:

    # "...You always find it napping in the living room."
    "...Você sempre o encontra cochilando na sala."

# game/atHome.rpy:590
translate pt_br cleanHome_78b6d9cf_1:

    # cat "Purr.. Purr.."
    cat "Purr.. Purr.."

# game/atHome.rpy:591
translate pt_br cleanHome_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:594
translate pt_br cleanHome_70e6e0c9:

    # "You keep cleaning, but the cat..."
    "Você continua limpando, mas o gato..."

# game/atHome.rpy:595
translate pt_br cleanHome_350e9976:

    # "...or {i}something{/i}..."
    "...ou {i}alguma coisa{/i}..."

# game/atHome.rpy:596
translate pt_br cleanHome_3333a159:

    # "...keeps leaving more and more mess in its wake."
    "...continua deixando cada vez mais bagunça pelo caminho."

# game/atHome.rpy:608
translate pt_br keepCleaning_f8527730:

    # "You keep cleaning, but there’s just more mess..."
    "Você continua limpando, mas há cada vez mais bagunça..."

# game/atHome.rpy:609
translate pt_br keepCleaning_2eaedbe8:

    # "And more..."
    "E mais..."

# game/atHome.rpy:610
translate pt_br keepCleaning_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:611
translate pt_br keepCleaning_d9897097:

    # "And {i}more{/i}..."
    "E {i}mais{/i}..."

# game/atHome.rpy:612
translate pt_br keepCleaning_8fe73cbe:

    # "When you finally stop and look around you..."
    "Quando você finalmente para e olha ao seu redor..."

# game/atHome.rpy:613
translate pt_br keepCleaning_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:614
translate pt_br keepCleaning_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:617
translate pt_br keepCleaning_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:618
translate pt_br keepCleaning_df223326:

    # "...you don’t even recognize your home anymore."
    "...você nem reconhece mais sua casa."

# game/atHome.rpy:621
translate pt_br keepCleaning_d37d2b14:

    # "There’s piles of junk everywhere. Do you even {i}own{/i} this much stuff?"
    "Há pilhas de lixo por toda parte. Você {i}tem{/i} mesmo tantas coisas assim?"

# game/atHome.rpy:622
translate pt_br keepCleaning_f12f1103:

    # "You don’t remember ever buying or receiving most of it."
    "Você não se lembra de ter comprado ou ganhado a maior parte disso."

# game/atHome.rpy:623
translate pt_br keepCleaning_6b45c41b:

    # "The piles tower over you."
    "As pilhas se erguem sobre você."

# game/atHome.rpy:624
translate pt_br keepCleaning_1b4957f6:

    # "You feel claustrophobic."
    "Você se sente claustrofóbico."

# game/atHome.rpy:625
translate pt_br keepCleaning_7c04f542:

    # "The stench of garbage is overwhelming, despite your hands feeling raw from all the cleaner fluid you've been using."
    "O fedor de lixo é insuportável, apesar de suas mãos estarem doloridas de tanto líquido de limpeza que você tem usado."

# game/atHome.rpy:626
translate pt_br keepCleaning_9e56909e:

    # "Your eyes still burn from the bleach."
    "Seus olhos ainda ardem por causa do alvejante."

# game/atHome.rpy:627
translate pt_br keepCleaning_1f4f5647:

    # "You need some air."
    "Você precisa de ar."

# game/atHome.rpy:628
translate pt_br keepCleaning_47312e78:

    # "You need to get out of here."
    "Você precisa sair daqui."

# game/atHome.rpy:630
translate pt_br keepCleaning_a46102ae:

    # "Crack!" with hpunch
    "Crack!" with hpunch

# game/atHome.rpy:631
translate pt_br keepCleaning_08ca5ed4:

    # "You hear a crash and see a teacup you're certain you don't own smashed on the floor."
    "Você ouve um barulho e vê uma xícara de chá, que com certeza não é sua, quebrada no chão."

# game/atHome.rpy:634
translate pt_br keepCleaning_2ee0c458:

    # "You look up and see the cat perched on a teetering pile of china and kitchen appliances."
    "Você olha para cima e vê o gato sentado em uma pilha bem instável de louças e utensílios de cozinha."

# game/atHome.rpy:636
translate pt_br keepCleaning_dde8fd86:

    # "It carefully nudges another teacup from the pile, sending it careening to the ground..."
    "Ele empurra cuidadosamente outra xícara de chá da pilha, fazendo-a despencar no chão..."

# game/atHome.rpy:637
translate pt_br keepCleaning_f68c64ac:

    # "...but you don't even flinch as it shatters."
    "...mas você nem pisca quando ela se despedaça."

# game/atHome.rpy:638
translate pt_br keepCleaning_4cb92d86:

    # "Instead..."
    "Em vez disso..."

# game/atHome.rpy:639
translate pt_br keepCleaning_cd64e084:

    # you "Heh..."
    you "Heh..."

# game/atHome.rpy:640
translate pt_br keepCleaning_bc45b6ba:

    # "You start to chuckle."
    "Você começa a rir."

# game/atHome.rpy:641
translate pt_br keepCleaning_0931d500:

    # you "Hehehe!"
    you "Hehehe!"

# game/atHome.rpy:642
translate pt_br keepCleaning_d7e774f2:

    # "Suddenly, you're laughing. It's so hilarious..."
    "De repente, você está gargalhando. É tão hilário..."

# game/atHome.rpy:643
translate pt_br keepCleaning_852190f9:

    # you "HAHAHA!" with hpunch
    you "HAHAHA!" with hpunch

# game/atHome.rpy:644
translate pt_br keepCleaning_a2a51a94:

    # "...that tears start running down your face."
    "...que você começa a lacrimejar."

# game/atHome.rpy:645
translate pt_br keepCleaning_3e62584c:

    # you "I {i}knew{/i} it was you! {i}You{/i} did this, didn't you?"
    you "Eu {i}sabia{/i} foi você! {i}Você{/i} fez isso, não foi?"

# game/atHome.rpy:646
translate pt_br keepCleaning_f6110b17:

    # "You pick up the largest piece of ceramic from the broken teacups..."
    "Você pega o maior pedaço de cerâmica das xícaras quebradas..."

# game/atHome.rpy:647
translate pt_br keepCleaning_ffcea493:

    # you "{size=+5}{b}{i}DIDN'T{/i}{/b} YOU?!{/size}" with hpunch
    you "{size=+5}{b}{i}NÃO{/i}{/b} FOI?!{/size}" with hpunch

# game/atHome.rpy:648
translate pt_br keepCleaning_bcb59dd1:

    # "...and throw it at the cat."
    "...e joga no gato."

# game/atHome.rpy:652
translate pt_br keepCleaning_d9053550:

    # "The cat dodges by leaping off of the pile."
    "O gato desvia pulando da pilha."

# game/atHome.rpy:658
translate pt_br keepCleaning_89623c0d:

    # "The pile... sways."
    "A pilha... balança."

# game/atHome.rpy:664
translate pt_br keepCleaning_6ba05e33:

    # "It sways..."
    "E balança..."

# game/atHome.rpy:667
translate pt_br keepCleaning_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:668
translate pt_br keepCleaning_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:669
translate pt_br keepCleaning_03fd754d:

    # "...It's falling."
    "...Está caindo."

# game/atHome.rpy:675
translate pt_br keepCleaning_28b3ac41:

    # you "!!"
    you "!!"

# game/atHome.rpy:676
translate pt_br keepCleaning_b1a6c334:

    # "...It's falling towards yo--{w=0.8}{nw}"
    "...Está caindo na sua direç--{w=0.8}{nw}"

# game/atHome.rpy:688
translate pt_br keepCleaning_180588a5:

    # "{size=+25}{b}{i}CRASH!!{/i}{/b}{/size}" with vpunch
    "{size=+25}{b}{i}CRASH!!{/i}{/b}{/size}" with vpunch

# game/atHome.rpy:689
translate pt_br keepCleaning_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:690
translate pt_br keepCleaning_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:691
translate pt_br keepCleaning_77a402e9:

    # "...You can't move."
    "...Você não consegue se mexer."

# game/atHome.rpy:692
translate pt_br keepCleaning_23a3bbe5:

    # "You're..."
    "Você está..."

# game/atHome.rpy:693
translate pt_br keepCleaning_19c2b1c0:

    # "You're buried."
    "Você está soterrado."

# game/atHome.rpy:694
translate pt_br keepCleaning_1600c9a3:

    # "The pile fell on top of you."
    "A pilha caiu em cima de você."

# game/atHome.rpy:695
translate pt_br keepCleaning_f5935cf0:

    # "Broken shards of fine china and sharp utensils are piercing your skin..."
    "Cacos de cerâmica fina e talheres afiados estão perfurando sua pele..."

# game/atHome.rpy:696
translate pt_br keepCleaning_2e357ce3:

    # "Your {b}organs{/b}..."
    "Seus {b}órgãos{/b}..."

# game/atHome.rpy:697
translate pt_br keepCleaning_9c53ce22:

    # "Your bones feel loose and limp... crushed under the heavy appliances."
    "Seus ossos parecem soltos e moles... esmagados sob os pesados utensílios."

# game/atHome.rpy:698
translate pt_br keepCleaning_cea9f1b7:

    # "Warm liquid pools under you."
    "Uma poça de líquido morno se forma sob você."

# game/atHome.rpy:699
translate pt_br keepCleaning_7c3e10e7:

    # "With the last of your strength..."
    "Com o que resta das suas forças..."

# game/atHome.rpy:700
translate pt_br keepCleaning_8dd57887:

    # "...you listen as the cat pads over to you before laying down and purring sleepily."
    "...você ouve as patas do gato se aproximando suavemente de você, se deitando e ronronando sonolento."

# game/atHome.rpy:702
translate pt_br keepCleaning_55355e09:

    # cat "Purr... Purr..."
    cat "Purr.. Purr.."

# game/atHome.rpy:703
translate pt_br keepCleaning_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:704
translate pt_br keepCleaning_4914da37:

    # "Yeah..."
    "É..."

# game/atHome.rpy:705
translate pt_br keepCleaning_8ad69668:

    # "A nap sounds..."
    "Um cochilo parece uma ideia..."

# game/atHome.rpy:706
translate pt_br keepCleaning_8a5ba85b:

    # "{size=-5}pretty...{/size}"
    "{size=-5}muito...{/size}"

# game/atHome.rpy:707
translate pt_br keepCleaning_444906a3:

    # "{size=-10}good...{/size}"
    "{size=-10}boa...{/size}"

# game/atHome.rpy:708
translate pt_br keepCleaning_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:709
translate pt_br keepCleaning_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:710
translate pt_br keepCleaning_fdf7d678:

    # "Ending 1: A (Not So) Clean Getaway"
    "Final 1: Uma Fuga (Não Tão) Limpa"

# game/atHome.rpy:723
translate pt_br catchCat_2d0b7d8d:

    # "How are you supposed to finish cleaning up if this little imp is making a menace of itself?"
    "Como você espera terminar de limpar se esse diabinho está fazendo tanta bagunça?"

# game/atHome.rpy:724
translate pt_br catchCat_bcf6dd4d:

    # "No."
    "Não."

# game/atHome.rpy:725
translate pt_br catchCat_eeaa381b:

    # "You {i}know{/i} the cat's the culprit..."
    "Você {i}sabe{/i} que o gato é o culpado..."

# game/atHome.rpy:726
translate pt_br catchCat_f18bba2e:

    # "You consider locking it up in the bathroom, at least until you clean the rest of the apartment..."
    "Você pensa em prendê-lo no banheiro, pelo menos até você ter limpado o resto do apartamento..."

# game/atHome.rpy:727
translate pt_br catchCat_857162a0:

    # "...But it just doesn't seem fair when you don't actually have any proof."
    "...Mas não parece justo, já que você não tem nenhuma prova disso."

# game/atHome.rpy:728
translate pt_br catchCat_23e7b8d0:

    # "You need to investigate this further."
    "Você precisa investigar isso mais a fundo."

# game/atHome.rpy:729
translate pt_br catchCat_7142699f:

    # "You need proof."
    "Você precisa de provas."

# game/atHome.rpy:730
translate pt_br catchCat_5d38d834:

    # "Not just for the sake of your sanity, but more importantly for the sake..."
    "Não apenas para o bem da sua sanidade, mas, mais importante, para o bem..."

# game/atHome.rpy:731
translate pt_br catchCat_d81de3ab:

    # "...of {b}{i}cleanliness!{/i}{/b}" with hpunch
    "...da {b}{i}limpeza!{/i}{/b}" with hpunch

# game/atHome.rpy:732
translate pt_br catchCat_302a1096:

    # "You start to clean again and peek behind you, catching mere glimpses of a paw here or a tail there..."
    "Você começa a limpar de novo e dá uma espiada por trás de você, vendo apenas vislumbres de uma pata aqui ou um rabo ali..."

# game/atHome.rpy:733
translate pt_br catchCat_66dd8df3:

    # "But as with earlier, when you rush back to the living room, the cat is still sleeping."
    "Mas, como antes, quando você corre de volta para a sala, o gato ainda está dormindo."

# game/atHome.rpy:734
translate pt_br catchCat_7c813d85:

    # you "{i}Okay, you wanna play, cat?{/i}"
    you "{i}Beleza, quer brincar, gato?{/i}"

# game/atHome.rpy:735
translate pt_br catchCat_1df4b1f2:

    # you "{i}Then let's play{/i}..."
    you "{i}Então vamos brincar{/i}..."

# game/atHome.rpy:736
translate pt_br catchCat_5264ec6b:

    # "This time, you decide to lay a trap – one your feline friend won’t be able to resist."
    "Desta vez, você decide armar uma armadilha – uma que seu amigo felino não poderá resistir."

# game/atHome.rpy:739
translate pt_br catchCat_e6ab25a3:

    # "You tackle the kitchen island counter and give it the {b}{i}works{/i}{/b}."
    "Você ataca o balcão da ilha da cozinha e o deixa nos {b}{i}trinques{/i}{/b}."

# game/atHome.rpy:740
translate pt_br catchCat_f8c31f4c:

    # "It’s {i}glistening{/i} by the time you’re done."
    "Está {i}brilhando{/i} assim que você termina."

# game/atHome.rpy:741
translate pt_br catchCat_ece57ede:

    # "It’s so clean..."
    "Está tão limpo..."

# game/atHome.rpy:742
translate pt_br catchCat_737ad384:

    # "...you’d drop kick anyone who even {b}{i}thought{/i}{/b} of eating off of it."
    "...que você daria uma voadora em qualquer um que simplesmente {b}{i}pensasse{/i}{/b} em comer nele."

# game/atHome.rpy:743
translate pt_br catchCat_965246c3:

    # "The perfect trap for your little cleaning saboteur."
    "A armadilha perfeita para o seu pequeno sabotador da limpeza."

# game/atHome.rpy:747
translate pt_br catchCat_caf7a734:

    # "You whistle innocently as you exit the room and hide around the corner of the entryway to the hall."
    "Você assobia inocentemente enquanto sai do cômodo e se esconde atrás da esquina da entrada do corredor."

# game/atHome.rpy:748
translate pt_br catchCat_66b634bf:

    # "From the angle you're at, you have a perfect view of the cat and the island counter."
    "Do ângulo em que você está, tem uma visão perfeita do gato e do balcão da ilha."

# game/atHome.rpy:749
translate pt_br catchCat_12e1a084:

    # "There’s no way you won’t catch the culprit in the act now."
    "Impossível não pegar o culpado com a boca na botija agora."

# game/atHome.rpy:750
translate pt_br catchCat_c456968c:

    # "If it really isn’t the cat, maybe you’ll give it a treat as an apology for your suspicions?"
    "Se realmente não for o gato, talvez você lhe dê um petisco como um pedido de desculpas pelas suspeitas?"

# game/atHome.rpy:753
translate pt_br catchCat_0197e62d:

    # "But as you deliberate if you should stop by the grocery store to get some fish... the cat starts to..."
    "Mas enquanto você pensa se deve passar no supermercado para comprar um pouco de peixe... o gato começa a..."

# game/atHome.rpy:763
translate pt_br catchCat_8f5e83db:

    # "...shift?"
    "...mudar?"

# game/atHome.rpy:764
translate pt_br catchCat_80e45c97:

    # "Its back that was rising and falling evenly moments ago..."
    "Suas costas, que estavam subindo e descendo uniformemente pela respiração momentos atrás..."

# game/atHome.rpy:768
translate pt_br catchCat_abeaf9eb:

    # "...is now rippling in small tremors like an agitated wave on a black sea."
    "...agora estão se ondulando em pequenos tremores, como uma onda agitada em um mar negro."

# game/atHome.rpy:772
translate pt_br catchCat_451b684a:

    # "It’s shuddering..."
    "Está tremendo..."

# game/atHome.rpy:776
translate pt_br catchCat_4da3e6b9:

    # "It’s bubbling..."
    "Está borbulhando..."

# game/atHome.rpy:780
translate pt_br catchCat_91204d86:

    # "It’s bulging..."
    "Está inchando..."

# game/atHome.rpy:784
translate pt_br catchCat_51fdb3a7:

    # "It’s {b}{i}bulging--{/i}{/b}{w=0.3}{nw}"
    "Está {b}{i}inchando--{/i}{/b}{w=0.3}{nw}"

# game/atHome.rpy:791
translate pt_br catchCat_7b893834:

    # "{b}{size=+15}POP!{/size}{/b}" with vpunch
    "{b}{size=+15}PLOP!{/size}{/b}" with vpunch

# game/atHome.rpy:792
translate pt_br catchCat_90b68c87:

    # you "..?"
    you "..?"

# game/atHome.rpy:793
translate pt_br catchCat_78ae5d65:

    # you "..?!" with hpunch
    you "..?!" with hpunch

# game/atHome.rpy:794
translate pt_br catchCat_13a4394e:

    # you "{i}What... the {b}hell{/b}..?{/i}"
    you "{i}Mas... que {b}porra{/b}..?{/i}"

# game/atHome.rpy:795
translate pt_br catchCat_0673262a:

    # "You gape in disbelief as {b}another cat{/b} bursts out of the still, {i}still{/i}, sleeping feline you’d taken home with you."
    "Seu queixo cai em descrença ao ver {b}outro gato{/b} explodir para fora do felino que você havia levado para casa, que ainda, {i}ainda{/i}, estava dormindo."

# game/atHome.rpy:798
translate pt_br catchCat_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:799
translate pt_br catchCat_23a3bbe5:

    # "You're..."
    "Você está..."

# game/atHome.rpy:800
translate pt_br catchCat_3b3dcfd1:

    # "You're {i}fairly{/i} certain that's not how cats give birth."
    "Você tem certeza {i}absoluta{/i} de que não é assim que gatos dão à luz."

# game/atHome.rpy:801
translate pt_br catchCat_200e4ba1:

    # "But more importantly..."
    "Mas, mais importante..."

# game/atHome.rpy:804
translate pt_br catchCat_c1255ce3:

    # "You watch cat #2 shake itself off before leaping up onto the counter..."
    "Você observa o gato número 2 se sacudir antes de pular em cima do balcão..."

# game/atHome.rpy:805
translate pt_br catchCat_0f4a0748:

    # "...rolling around on top of it and leaving fur and grime in its wake."
    "...revirando-se em cima dele e deixando pelos e sujeira para trás."

# game/atHome.rpy:806
translate pt_br catchCat_7f180865:

    # you "{i}Hm. Probably should've given it a bath earlier{/i}..."
    you "{i}Hm. Provavelmente deveria ter dado um banho nele mais cedo{/i}..."

# game/atHome.rpy:807
translate pt_br catchCat_cc415aaf:

    # "You feel like your mind is lagging behind the reality of the discovery you've just made..."
    "Você sente que sua mente está demorando a processar a realidade da descoberta que acabou de fazer..."

# game/atHome.rpy:808
translate pt_br catchCat_5624fa4d:

    # "...but you don't seem capable of thinking beyond smaller observations."
    "...mas você parece incapaz de pensar além de observações menores."

# game/atHome.rpy:809
translate pt_br catchCat_b4139f5d:

    # "For example..."
    "Por exemplo..."

# game/atHome.rpy:812
translate pt_br catchCat_c841f0ba:

    # "Though the hows and whys of what you’re witnessing elude you..."
    "Embora os como e porquês do que você está testemunhando lhe escapem..."

# game/atHome.rpy:813
translate pt_br catchCat_7d96eba3:

    # "...the more pertinent question that strikes you is that if the original cat is still sleeping..."
    "...a pergunta mais pertinente que surge é: se o gato original ainda está dormindo..."

# game/atHome.rpy:814
translate pt_br catchCat_8301e7ce:

    # "...and the cloned cat is busy making yet {i}another{/i} mess..."
    "...e o gato clonado está ocupado fazendo {i}mais uma{/i} bagunça..."

# game/atHome.rpy:815
translate pt_br catchCat_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:816
translate pt_br catchCat_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:817
translate pt_br catchCat_031168fd:

    # "{size=-8}...then where are all the {b}other{/b} clones?{/size}"
    "{size=-8}...então onde estão todos os {b}outros{/b} clones?{/size}"

# game/atHome.rpy:825
translate pt_br catchCat_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:826
translate pt_br catchCat_9107a91b:

    # "Suddenly, the two cats look directly at you in perfect unison."
    "De repente, os dois gatos olham diretamente para você em perfeita sincronia."

# game/atHome.rpy:827
translate pt_br catchCat_7f0ac95c:

    # cat "..."
    cat "..."

# game/atHome.rpy:828
translate pt_br catchCat_2849e452:

    # cat2 "..."
    cat2 "..."

# game/atHome.rpy:829
translate pt_br catchCat_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:830
translate pt_br catchCat_5b9cf052:

    # "Their eyes pin you to the spot with their intensity..."
    "Seus olhos prendem você no lugar com sua intensidade..."

# game/atHome.rpy:831
translate pt_br catchCat_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:832
translate pt_br catchCat_bf0874e3:

    # "But..."
    "Mas..."

# game/atHome.rpy:833
translate pt_br catchCat_77335cac:

    # "You realize with the familiar, sinking feeling of being watched from behind..."
    "Você percebe, com a familiar sensação aterradora de estar sendo observado por trás..."

# game/atHome.rpy:834
translate pt_br catchCat_7fe62e1d:

    # "...that they're not the {i}only{/i} ones looking at you."
    "...que eles não são os {i}únicos{/i} olhando para você."

# game/atHome.rpy:835
translate pt_br catchCat_2da9a525:

    # "You slowly turn around..."
    "Você se vira lentamente..."

# game/atHome.rpy:836
translate pt_br catchCat_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/atHome.rpy:854
translate pt_br catchCat_d6b508aa:

    # "Packed in the hall behind you, from the floor to the ceiling..."
    "Empilhados no corredor atrás de você, do chão ao teto..."

# game/atHome.rpy:855
translate pt_br catchCat_8434b31c:

    # "...is a living, breathing, {i}writhing{/i} wall of cats..."
    "...está uma parede viva, respirando e {i}se contorcendo{/i}, feita de gatos..."

# game/atHome.rpy:856
translate pt_br catchCat_2df33dd1:

    # "...of {i}{b}clones{/b}{/i}..."
    "...de {i}{b}clones{/b}{/i}..."

# game/atHome.rpy:857
translate pt_br catchCat_6a0c9ea0:

    # "...all piled on top of each other."
    "...todos empilhados uns sobre os outros."

# game/atHome.rpy:858
translate pt_br catchCat_a9d5e578:

    # "The glowing, golden eyes of every cat in the undulating wall of pure black fur..."
    "Os olhos dourados e brilhantes de cada gato na parede ondulante de puro pelo preto..."

# game/atHome.rpy:859
translate pt_br catchCat_34b528c2:

    # "Every single eye..."
    "Cada olho..."

# game/atHome.rpy:860
translate pt_br catchCat_dff87f71:

    # "...is trained on you."
    "...está fixo em você."

# game/atHome.rpy:861
translate pt_br catchCat_dae0ec55_2:

    # you "..."
    you "..."

# game/atHome.rpy:862
translate pt_br catchCat_5a6e3687:

    # "Out of fear and a sheer, desperate need to distance yourself from this blight on reality and order..."
    "Por medo e uma necessidade desesperada de se afastar desse borrão na realidade e na ordem natural..."

# game/atHome.rpy:863
translate pt_br catchCat_9a5f0b90:

    # "...you take a single step back."
    "...você dá um único passo para trás."

# game/atHome.rpy:867
translate pt_br catchCat_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:868
translate pt_br catchCat_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:870
translate pt_br catchCat_4d3e0545:

    # "...And in response."
    "..E em resposta."

# game/atHome.rpy:871
translate pt_br catchCat_3d2d7818:

    # "The wall just..."
    "A parede simplesmente..."

# game/atHome.rpy:872
translate pt_br catchCat_3c6ffc63:

    # "...{b}breaks{/b}."
    "...{b}se desfaz{/b}."

# game/atHome.rpy:883
translate pt_br catchCat_a3a8c547:

    # "...the cats all stampeding over you."
    "...os gatos todos correndo sobre você."

# game/atHome.rpy:892
translate pt_br catchCat_a7561dac:

    # "It'd be kind of..."
    "Isso seria meio..."

# game/atHome.rpy:893
translate pt_br catchCat_f46b477d:

    # "...cute?"
    "...fofo?"

# game/atHome.rpy:902
translate pt_br catchCat_5af96194:

    # "...If their soft paws weren't hiding claws as sharp as knives."
    "...Se suas patas macias não escondessem garras tão afiadas quanto facas."

# game/atHome.rpy:911
translate pt_br catchCat_7ae94986:

    # "You try to protect yourself... {w}but there's just too many of them."
    "Você tenta se proteger... {w}mas há tantos deles."

# game/atHome.rpy:921
translate pt_br catchCat_cfcc4899:

    # "Blood leaks steadily from your scratches.."
    "O sangue vaza constantemente dos seus arranhões..."

# game/atHome.rpy:922
translate pt_br catchCat_9d23ba22:

    # "You feel dizzy..."
    "Você se sente tonto..."

# game/atHome.rpy:923
translate pt_br catchCat_f52affb8:

    # "With what little strength you have..."
    "Com a pouca força que lhe resta..."

# game/atHome.rpy:924
translate pt_br catchCat_f55aea98:

    # "...you turn your head and watch as the cats tear through carpet and upholstery..."
    "...você vira a cabeça e observa enquanto os gatos rasgam o carpete e o estofado..."

# game/atHome.rpy:925
translate pt_br catchCat_9d8db959:

    # "...knock over vases and dishes and lamps..."
    "...derrubam vasos, pratos e luminárias..."

# game/atHome.rpy:926
translate pt_br catchCat_1a299f19:

    # "...claw at the walls..."
    "...arranham as paredes..."

# game/atHome.rpy:927
translate pt_br catchCat_6f71224c:

    # "It’s going to take forever to clean this up, you think."
    "Vai levar uma eternidade para limpar tudo isso, você pensa."

# game/atHome.rpy:928
translate pt_br catchCat_d44174fd:

    # "Maybe you’ll tackle it all again later..."
    "Talvez você enfrente tudo isso de novo mais tarde..."

# game/atHome.rpy:929
translate pt_br catchCat_9ca1c0cc:

    # "...right after you..."
    "...logo depois de você..."

# game/atHome.rpy:930
translate pt_br catchCat_a6bf102e:

    # "{size=-5}...take a short..{/size}"
    "{size=-5}...tirar um..{/size}"

# game/atHome.rpy:931
translate pt_br catchCat_cac82399:

    # "{size=-8}...nap...{/size}"
    "{size=-8}...cochilo...{/size}"

# game/atHome.rpy:932
translate pt_br catchCat_dae0ec55_3:

    # you "..."
    you "..."

# game/atHome.rpy:933
translate pt_br catchCat_54aa11a1:

    # "With an annoyed sigh..."
    "Com uma inspiração irritada..."

# game/atHome.rpy:934
translate pt_br catchCat_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:935
translate pt_br catchCat_3f89c6a6:

    # "...you breathe your last breath."
    "...você dá seu último suspiro."

# game/atHome.rpy:936
translate pt_br catchCat_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:937
translate pt_br catchCat_6956a6b4:

    # "Ending 2: Double Trouble"
    "Final 2: Problema Em Dobro"

# game/atHome.rpy:950
translate pt_br watchTV_7a132060:

    # "You're not tired enough for a nap, but you're too lazy to get started on any of your chores."
    "Você não está cansado o suficiente para cochilar, mas está com preguiça demais para começar qualquer uma das suas tarefas."

# game/atHome.rpy:951
translate pt_br watchTV_59ecac21:

    # "So you decide to watch a movie."
    "Então você decide assistir a um filme."

# game/atHome.rpy:952
translate pt_br watchTV_e6b3f86f:

    # "You get dressed in your favorite pajamas, make some popcorn with an obscene amount of butter and head over to your armchair..."
    "Você veste seu pijama favorito, faz pipoca com uma quantidade obscena de manteiga e vai até sua poltrona..."

# game/atHome.rpy:955
translate pt_br watchTV_addc29e1:

    # "...only to discover that the cat is already napping in it."
    "...só para descobrir que o gato já está cochilando nela."

# game/atHome.rpy:956
translate pt_br watchTV_c4045cbc:

    # "You frown a little in thought."
    "Você franze um pouco a testa, pensativo."

# game/atHome.rpy:957
translate pt_br watchTV_4f7364cd:

    # "Your couch isn't at the best angle for optimal TV viewing pleasure and you don't feel like pushing it around and having to put it back later."
    "Seu sofá não está no melhor ângulo para uma experiência ideal de assistir TV, e você não está afim de movê-lo e ter que colocá-lo de volta depois."

# game/atHome.rpy:958
translate pt_br watchTV_d1311036:

    # "The only options you have left are to sit on the floor..."
    "As únicas opções que restam são sentar no chão..."

# game/atHome.rpy:959
translate pt_br watchTV_ac7e9daa:

    # "...or move the cat and reclaim your throne."
    "...ou tirar o gato e reivindicar seu trono."

# game/atHome.rpy:969
translate pt_br sitOnFloor_f258c8af:

    # "You decide to sit on the floor. The cat is a guest after all and you pride yourself on being a good host if nothing else."
    "Você decide sentar no chão. Afinal, o gato é um convidado, e você se orgulha pelo menos de ser um bom anfitrião."

# game/atHome.rpy:970
translate pt_br sitOnFloor_94fced8c:

    # "Well... At least you would if you'd ever had any guests over before."
    "Bem... Pelo menos você se orgulharia disso caso já tivesse tido algum convidado antes."

# game/atHome.rpy:971
translate pt_br sitOnFloor_59924bfd:

    # "You grab a blanket and some pillows and make a comfy nest in front of the chair."
    "Você pega um cobertor e algumas almofadas e faz um ninho confortável na frente da poltrona."

# game/atHome.rpy:978
translate pt_br sitOnFloor_c9c06a2d:

    # "You pop in a random movie from your collection and can tell instantly that it's one of your favorite horror films."
    "Coloca um filme aleatório da sua coleção e percebe na hora que é um dos seus filmes de terror favoritos."

# game/atHome.rpy:979
translate pt_br sitOnFloor_178f4f3c:

    # "You've seen it a few times already, but it never fails to get your blood pumping."
    "Você já o viu algumas vezes, mas ele nunca deixa de fazer seu coração disparar."

# game/atHome.rpy:980
translate pt_br sitOnFloor_af009a23:

    # "A few minutes in and you’re already invested, getting reacquainted with the story and characters."
    "Depois de alguns minutos, você já está envolvido, se reconectando com a história e os personagens."

# game/atHome.rpy:981
translate pt_br sitOnFloor_5c1e198e:

    # "The scares won't come until later, but..."
    "Os sustos ainda demoram um pouco para aparecer, mas..."

# game/atHome.rpy:984
translate pt_br sitOnFloor_b30c491a:

    # "...for some reason you feel like something is watching you from behind."
    "...por algum motivo, você sente que algo está te observando por trás."

# game/atHome.rpy:986
translate pt_br sitOnFloor_84c7ae7d:

    # "You know it's probably nothing, but you feel compelled to check anyway."
    "Você sabe que provavelmente não é nada, mas se sente obrigado a checar mesmo assim."

# game/atHome.rpy:987
translate pt_br sitOnFloor_06fb4a58:

    # "You peek over your shoulder..."
    "Você espia por cima do seu ombro..."

# game/atHome.rpy:994
translate pt_br sitOnFloor_ac50ef1c:

    # you "{size=+5}GAH!{/size}" with vpunch
    you "{size=+5}AAH!{/size}" with vpunch

# game/atHome.rpy:995
translate pt_br sitOnFloor_81f1b73f:

    # "...only to jump out of your skin, jostling a few pieces of popcorn out of the bowl in your lap."
    "...só para levar um susto, fazendo algumas pipocas caírem da tigela que está no seu colo."

# game/atHome.rpy:996
translate pt_br sitOnFloor_1f13af02:

    # "The cat is awake and looking right at you."
    "O gato está acordado e olhando bem para você."

# game/atHome.rpy:997
translate pt_br sitOnFloor_7f0ac95c:

    # cat "..."
    cat "..."

# game/atHome.rpy:998
translate pt_br sitOnFloor_143b81e3:

    # you "*SIGH*"
    you "*Suspiro*"

# game/atHome.rpy:999
translate pt_br sitOnFloor_eea23dd1:

    # "You take a calming breath, recovering from your heart nearly lurching out of your chest and immediately feel foolish."
    "Você respira fundo, se recuperando do seu coração quase ter saído pela boca e imediatamente se sente um idiota."

# game/atHome.rpy:1000
translate pt_br sitOnFloor_dfcad786:

    # "It was just the cat, of course. It was so quiet you’d forgotten it was right behind you..."
    "Era só o gato, é claro. Estava tão quieto que você havia esquecido que estava bem atrás de você..."

# game/atHome.rpy:1001
translate pt_br sitOnFloor_f37d47cd:

    # "...even though it’s the whole reason you’re sitting on the floor in the first place."
    "...mesmo sendo a razão pela qual você está sentado no chão pra começo de conversa."

# game/atHome.rpy:1004
translate pt_br sitOnFloor_50a15250:

    # "You shakily pick up the remote, intending to rewind some of the parts you missed."
    "Você pega o controle remoto com a mão trêmula, pretendendo voltar algumas partes que perdeu."

# game/atHome.rpy:1005
translate pt_br sitOnFloor_236c0e1e:

    # "However as soon as you press the rewind button..."
    "No entanto, assim que você aperta o botão de retroceder..."

# game/atHome.rpy:1008
translate pt_br sitOnFloor_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:1009
translate pt_br sitOnFloor_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1013
translate pt_br sitOnFloor_493f0953:

    # "...the TV shuts off."
    "...a TV desliga."

# game/atHome.rpy:1014
translate pt_br sitOnFloor_90b68c87:

    # you "..?"
    you "..?"

# game/atHome.rpy:1015
translate pt_br sitOnFloor_70a6570e:

    # "You blink, confused."
    "Você pisca, confuso."

# game/atHome.rpy:1016
translate pt_br sitOnFloor_78747100:

    # "Nothing else turned off. The kitchen’s dimmed light was still on..."
    "Nada mais desligou. A luz fraca da cozinha ainda estava acesa..."

# game/atHome.rpy:1017
translate pt_br sitOnFloor_af8a226c:

    # "The digital clock was still glowing... and..."
    "O relógio digital ainda piscava... e..."

# game/atHome.rpy:1018
translate pt_br sitOnFloor_78037d5b:

    # "...the movie player was still rewinding..."
    "...o aparelho de DVD ainda estava retrocedendo..."

# game/atHome.rpy:1019
translate pt_br sitOnFloor_3fa5f761:

    # "The power clearly didn't go out... So why...?"
    "Claramente, a energia não caiu... Então, por que...?"

# game/atHome.rpy:1020
translate pt_br sitOnFloor_6a84e27a:

    # "You feel a chill run down your spine as you catch the cat’s reflection in the dark TV screen."
    "Um frio percorre sua espinha ao ver o reflexo do gato na tela escura da TV."

# game/atHome.rpy:1021
translate pt_br sitOnFloor_a74decef:

    # "It's still..."
    "Ele ainda está..."

# game/atHome.rpy:1022
translate pt_br sitOnFloor_29346eda:

    # "...looking at you?"
    "...te olhando?"

# game/atHome.rpy:1023
translate pt_br sitOnFloor_68f3d642:

    # you "{i}Cats stare, silly. It's kind of their thing...{/i}"
    you "{i}Gatos encaram, idiota. É meio que a pira deles...{/i}"

# game/atHome.rpy:1024
translate pt_br sitOnFloor_97996fab:

    # "...right?"
    "...né?"

# game/atHome.rpy:1025
translate pt_br sitOnFloor_c6dea0bf:

    # "And you’re a new addition in its life. Of course it’s going to study you closely to see if you're trustworthy."
    "E você é novo na vida dele. É claro que ele vai te observar de perto para ver se você é confiável."

# game/atHome.rpy:1026
translate pt_br sitOnFloor_22126792:

    # "As you mentally reassure yourself, you turn the TV back on."
    "Você liga a TV de novo, enquanto se tranquiliza mentalmente."

# game/atHome.rpy:1029
translate pt_br sitOnFloor_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:1030
translate pt_br sitOnFloor_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:1031
translate pt_br sitOnFloor_67aaa788:

    # "What?"
    "O quê?"

# game/atHome.rpy:1032
translate pt_br sitOnFloor_4be706f4:

    # "The TV's on, but... the movie isn't what's playing on screen."
    "A TV está ligada, mas... o filme não está passando na tela."

# game/atHome.rpy:1033
translate pt_br sitOnFloor_90b93b6a:

    # "It's..."
    "É..."

# game/atHome.rpy:1037
translate pt_br sitOnFloor_20572e6e:

    # "!!"
    "!!"

# game/atHome.rpy:1038
translate pt_br sitOnFloor_0034943b:

    # "It's you..?"
    "É você..?"

# game/atHome.rpy:1039
translate pt_br sitOnFloor_06079290:

    # "You watch yourself frown onscreen as you feel your brow furrow in tandem."
    "Você se vê franzindo a testa na tela enquanto sente sua sobrancelha contrair junto."

# game/atHome.rpy:1040
translate pt_br sitOnFloor_bc0619d3:

    # "It’s like footage of you in real time, like you’re being recorded..."
    "É como uma filmagem sua em tempo real, como se estivesse sendo gravado..."

# game/atHome.rpy:1041
translate pt_br sitOnFloor_b084c950:

    # "You feel the familiar sensation of your mind focusing on small details to avoid the bigger picture of your current situation."
    "Você sente a sensação familiar de sua mente se concentrando em pequenos detalhes para evitar a visão mais ampla da sua situação atual."

# game/atHome.rpy:1042
translate pt_br sitOnFloor_907a81a6:

    # "Avoiding the questions of how this is happening... of who or what is doing this..."
    "Evitando as perguntas de como isso está acontecendo... de quem ou o que está fazendo isso..."

# game/atHome.rpy:1043
translate pt_br sitOnFloor_4bda7300:

    # "...and why."
    "...e por quê."

# game/atHome.rpy:1046
translate pt_br sitOnFloor_ac593ae3:

    # "Suddenly, your mirrored self smiles and waves at you. All on its own."
    "De repente, sua versão espelhada sorri e acena para você. Por conta própria."

# game/atHome.rpy:1047
translate pt_br sitOnFloor_98f42958:

    # "You don’t wave back, too stunned to move."
    "Você não acena de volta, atordoado demais para se mover."

# game/atHome.rpy:1048
translate pt_br sitOnFloor_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:1049
translate pt_br sitOnFloor_49b81530:

    # "The {b}you{/b} on the screen doesn’t seem to mind though."
    "No entanto, o {b}você{/b} na tela não parece se importar."

# game/atHome.rpy:1052
translate pt_br sitOnFloor_470fca2a:

    # "It then stands up..."
    "Então, ele se levanta..."

# game/atHome.rpy:1053
translate pt_br sitOnFloor_46677075:

    # "It walks out of frame..."
    "Ele sai do enquadramento..."

# game/atHome.rpy:1054
translate pt_br sitOnFloor_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:1055
translate pt_br sitOnFloor_98a9232f:

    # "And-"
    "E-"

# game/atHome.rpy:1056
translate pt_br sitOnFloor_2b614492:

    # you "{b}{i}AAHHH!!{/i}{/b}" with vpunch
    you "{b}{i}AAHHH!!{/i}{/b}" with vpunch

# game/atHome.rpy:1057
translate pt_br sitOnFloor_57aec916:

    # "A terrified yell rips out of your mouth before you can think to stifle it."
    "Um grito aterrorizado escapa da sua boca antes que você consiga pensar em abafar."

# game/atHome.rpy:1058
translate pt_br sitOnFloor_8112b810:

    # "On screen... in the chair..."
    "Na tela... na cadeira..."

# game/atHome.rpy:1059
translate pt_br sitOnFloor_73ca6c0a:

    # "...is the cat."
    "...está o gato."

# game/atHome.rpy:1060
translate pt_br sitOnFloor_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:1061
translate pt_br sitOnFloor_8432e062:

    # "But it’s... {b}wrong{/b}."
    "Mas tem algo... {b}errado{/b}."

# game/atHome.rpy:1066
translate pt_br sitOnFloor_c0555fb1:

    # "It’s become a large swollen mass of black fur..."
    "Ele se tornou uma grande massa inchada de pelo preto..."

# game/atHome.rpy:1067
translate pt_br sitOnFloor_133f90fc:

    # "Its twitching pulse arrhythmical with its slow, almost methodical breaths."
    "Ele pulsa de forma irregular, enquanto suas respirações são lentas, quase metódicas."

# game/atHome.rpy:1068
translate pt_br sitOnFloor_be8a773e:

    # "Its mouth is a yawning entrance to a black abyss, framed by a set of teeth that look very, {i}very{/i} {b}sharp{/b}."
    "Sua boca é uma entrada escancarada para um abismo negro, exibindo um conjunto de dentes que parecem muito, {i}muito{/i} {b}afiados{/b}."

# game/atHome.rpy:1069
translate pt_br sitOnFloor_7a6698ae:

    # "Glowing eyes bulge all over its body..."
    "Olhos brilhantes estão espalhados por todo o seu corpo..."

# game/atHome.rpy:1070
translate pt_br sitOnFloor_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:1071
translate pt_br sitOnFloor_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:1075
translate pt_br sitOnFloor_bc239af5:

    # "{size=-5}It’s... still {b}looking{/b} at you...{/size}"
    "{size=-5}Ele... ainda está {b}olhando{/b} para você...{/size}"

# game/atHome.rpy:1076
translate pt_br sitOnFloor_cbbe5c23:

    # "It doesn’t even acknowledge your onscreen persona as they walk back into frame and pet {b}it{/b} almost lovingly."
    "Ele nem sequer reconhece sua versão na tela enquanto retorna ao enquadramento e acaricia {b}isso{/b} quase carinhosamente."

# game/atHome.rpy:1077
translate pt_br sitOnFloor_f64ee9d8:

    # "Then..."
    "Então..."

# game/atHome.rpy:1078
translate pt_br sitOnFloor_acb34839:

    # "The {b}you{/b} inside the TV touches one of the \"cat's\" fangs..."
    "O {b}você{/b} de dentro da TV toca uma das presas do \"gato\"..."

# game/atHome.rpy:1083
translate pt_br sitOnFloor_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/atHome.rpy:1084
translate pt_br sitOnFloor_2718a9f1:

    # "You flinch at a sudden, sharp pain in your palm."
    "Você se encolhe ao sentir uma dor aguda e repentina na palma da mão."

# game/atHome.rpy:1085
translate pt_br sitOnFloor_78150384:

    # "You look down and sure enough..."
    "Olha para baixo e, com certeza..."

# game/atHome.rpy:1086
translate pt_br sitOnFloor_9b18421a:

    # "...your hand is bleeding."
    "...sua mão está sangrando."

# game/atHome.rpy:1087
translate pt_br sitOnFloor_ba0ef687:

    # "You’re not particularly afraid of blood but..."
    "Você nunca teve medo de ver sangue, mas..."

# game/atHome.rpy:1089
translate pt_br sitOnFloor_1d340c8b:

    # "...for some reason the sight of it leaking out of you sends another chill down your back."
    "...por algum motivo, a visão dele escorrendo de você te faz arrepiar de cima a baixo."

# game/atHome.rpy:1090
translate pt_br sitOnFloor_7c7dcbc3:

    # "A thought... clear and {i}terrible{/i} flashes across your mind..."
    "Um pensamento... claro e {i}terrível{/i} passa pela sua cabeça..."

# game/atHome.rpy:1091
translate pt_br sitOnFloor_2061faa4:

    # "It’s not {i}just{/i} the mutated cat {b}in{/b} the TV that’s watching you..."
    "Não é {i}apenas{/i} o gato mutante {b}dentro{/b} da TV que está te observando..."

# game/atHome.rpy:1092
translate pt_br sitOnFloor_75079696:

    # "{size=-5}...is it?{/size}"
    "{size=-5}...é?{/size}"

# game/atHome.rpy:1093
translate pt_br sitOnFloor_91f03785:

    # "{size=-10}Don't look behind you... Don't look behind you... Don't look behind you... Don't look behind you... Don't look behind you... {/size}"
    "{size=-10}Não olha para trás... Não olha para trás... Não olha para trás... Não olha para trás... Não olha para trás... Não olha para trás... {/size}"

# game/atHome.rpy:1100
translate pt_br sitOnFloor_e1698794:

    # "You watch helplessly as your onscreen self smiles and nods at you, almost {i}encouragingly{/i}..."
    "Você observa, impotente, enquanto sua versão da tela sorri e acena com a cabeça para você, quase como se quisesse te {i}encorajar{/i}..."

# game/atHome.rpy:1101
translate pt_br sitOnFloor_ceaf9390:

    # "They stand in front of the cat’s gaping jaws..."
    "Ele fica em pé diante das mandíbulas escancaradas do gato..."

# game/atHome.rpy:1102
translate pt_br sitOnFloor_a76a9c6a:

    # "They look into the dark depths..."
    "Olha para as profundezas escuras..."

# game/atHome.rpy:1103
translate pt_br sitOnFloor_5cdba61f:

    # "...and as you’re torn between the horrifying realization of what’s about to happen..."
    "...e, enquanto a concepção horripilante do que está prestes a acontecer te atormenta..."

# game/atHome.rpy:1104
translate pt_br sitOnFloor_82ccfc29:

    # "...and the gripping wonder of what they see looking back at them from that deep, deep darkness..."
    "...e a inquietante curiosidade sobre o que ele vê olhando de volta daquele abismo profundo se apodera de você..."

# game/atHome.rpy:1105
translate pt_br sitOnFloor_8dabefc6_3:

    # ".."
    ".."

# game/atHome.rpy:1106
translate pt_br sitOnFloor_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:1107
translate pt_br sitOnFloor_91fe1774:

    # "...they jump {i}in{/i}."
    "...ele se joga lá {i}dentro{/i}."

# game/atHome.rpy:1110
translate pt_br sitOnFloor_8dabefc6_4:

    # ".."
    ".."

# game/atHome.rpy:1111
translate pt_br sitOnFloor_a20cefa7_6:

    # "..."
    "..."

# game/atHome.rpy:1112
translate pt_br sitOnFloor_d88e36d3:

    # "Darkness is a sudden presence all around you."
    "A escuridão subitamente se torna uma presença em toda a sua volta."

# game/atHome.rpy:1113
translate pt_br sitOnFloor_c6d24f52:

    # "Pressing in, holding you down..."
    "Pressionando, te segurando..."

# game/atHome.rpy:1114
translate pt_br sitOnFloor_a6895774:

    # "...and yet you somehow also feel.. weightless."
    "...e, ainda assim, você se sente de alguma forma... sem peso."

# game/atHome.rpy:1115
translate pt_br sitOnFloor_d861ceaf:

    # "You can’t tell if you’re falling but it doesn’t feel like you're laying down or standing either."
    "Você não sabe dizer se está caindo, mas não parece que está deitado ou em pé também."

# game/atHome.rpy:1116
translate pt_br sitOnFloor_156d0dbf:

    # "You feel warm..."
    "Você sente calor..."

# game/atHome.rpy:1117
translate pt_br sitOnFloor_3a06e0dd:

    # "You feel cold..."
    "Você sente frio..."

# game/atHome.rpy:1118
translate pt_br sitOnFloor_bcd3d129:

    # "You feel everything..."
    "Você sente tudo..."

# game/atHome.rpy:1119
translate pt_br sitOnFloor_2b49bb86:

    # "You feel nothing..."
    "Você sente nada..."

# game/atHome.rpy:1120
translate pt_br sitOnFloor_a20cefa7_7:

    # "..."
    "..."

# game/atHome.rpy:1121
translate pt_br sitOnFloor_1ef9b933:

    # "You feel {b}nothing.{/b}"
    "Você não sente {b}nada.{/b}"

# game/atHome.rpy:1122
translate pt_br sitOnFloor_a20cefa7_8:

    # "..."
    "..."

# game/atHome.rpy:1123
translate pt_br sitOnFloor_e8846d70:

    # "Ending 3: Silent Film"
    "Final 3: O Mal Interior"

# game/atHome.rpy:1136
translate pt_br sitInChair_b3119c57:

    # "You square your shoulders."
    "Você arruma a postura."

# game/atHome.rpy:1137
translate pt_br sitInChair_0a269556:

    # you "Sorry, kitty. But that's my spot."
    you "Desculpa, gatinho. Mas esse lugar é meu."

# game/atHome.rpy:1140
translate pt_br sitInChair_f57f352f:

    # "You pick up the cat and place it on the floor."
    "Você pega o gato e o coloca no chão."

# game/atHome.rpy:1142
translate pt_br sitInChair_12dc27c4:

    # cat "Mreow!!" with hpunch
    cat "Miaau!!" with hpunch

# game/atHome.rpy:1143
translate pt_br sitInChair_3a47415e:

    # "It's clearly upset with you. When you try to pet it as an apology, it dodges your hand and scampers away."
    "Ele está claramente chateado com você. Quando você tenta fazer um carinho como pedido de desculpas, ele evita a sua mão e foge."

# game/atHome.rpy:1144
translate pt_br sitInChair_590b209f:

    # "You shrug and put on a random movie before nestling into your chair."
    "Você dá de ombros e coloca um filme aleatório antes de se aconchegar na sua cadeira."

# game/atHome.rpy:1148
translate pt_br sitInChair_761b0c81:

    # "It's some horror film that you love to heckle from beginning to end."
    "É algum filme de terror que você adora criticar do início ao fim."

# game/atHome.rpy:1149
translate pt_br sitInChair_c1831989:

    # "Nothing but an endless string of pointless jumpscares."
    "Nada além de uma sequência interminável de sustos sem sentido."

# game/atHome.rpy:1150
translate pt_br sitInChair_02d4fb14:

    # "Did the writers not know the meaning of the word \"subtle\"?"
    "Os roteiristas não sabiam o que significava a palavra \"sutil\"?"

# game/atHome.rpy:1152
translate pt_br sitInChair_0420a8db:

    # "{size=+15}{b}CRASH!{/b}{/size}" with vpunch
    "{size=+15}{b}CRASH!{/b}{/size}" with vpunch

# game/atHome.rpy:1153
translate pt_br sitInChair_28b3ac41:

    # you "!!"
    you "!!"

# game/atHome.rpy:1154
translate pt_br sitInChair_a9188f84:

    # you "What was that?! Was that the bathroom..?"
    you "O que foi isso?! Foi no banheiro..?"

# game/atHome.rpy:1155
translate pt_br sitInChair_f3f4fb49:

    # "The cat must've gotten into the medicine cabinet or knocked something over."
    "O gato deve ter entrado no armário de remédios ou derrubado alguma coisa."

# game/atHome.rpy:1156
translate pt_br sitInChair_d150cda1:

    # "Calming your thundering heart with a deep breath, you pause the movie and get up to investigate."
    "Acalmando seu coração acelerado com uma respiração profunda, você pausa o filme e se levanta para investigar."

# game/atHome.rpy:1160
translate pt_br sitInChair_ec1974d4:

    # cat "Meow!" with hpunch
    cat "Miau!" with hpunch

# game/atHome.rpy:1161
translate pt_br sitInChair_fc460430:

    # you "Whoa!" with vpunch
    you "Ei!" with vpunch

# game/atHome.rpy:1162
translate pt_br sitInChair_4f08c65a:

    # "The cat dashes between your legs from the hall."
    "O gato corre entre suas pernas vindo do corredor."

# game/atHome.rpy:1163
translate pt_br sitInChair_071d97e8:

    # you "Fleeing the scene only makes you look guiltier, you know..."
    you "Fugir da cena só te faz parecer mais culpado, sabia?"

# game/atHome.rpy:1164
translate pt_br sitInChair_c4cc6ce8:

    # "You're even more reluctant to see the damage now. You just want to relax and watch your bad horror movie..."
    "Você está ainda mais relutante em ver o estrago agora. Você só quer relaxar e assistir seu filme de terror ruim..."

# game/atHome.rpy:1167
translate pt_br sitInChair_eb15eef1:

    # "You go into the bathroom and turn on the light."
    "Você entra no banheiro e acende a luz."

# game/atHome.rpy:1168
translate pt_br sitInChair_2a6c7408:

    # "Just as you thought, all the stuff in your medicine cabinet is scattered on the tiles."
    "Como você suspeitava, todas as coisas do seu armário de remédios estão espalhadas pelo piso."

# game/atHome.rpy:1169
translate pt_br sitInChair_8b19c490:

    # "You sigh. At least none of it looks broken or damaged."
    "Você suspira. Pelo menos nada parece quebrado ou danificado."

# game/atHome.rpy:1170
translate pt_br sitInChair_dc4e84a5:

    # "You crouch down to pick everything up."
    "Você se agacha para recolher tudo."

# game/atHome.rpy:1173
translate pt_br sitInChair_84499443:

    # "{size=-8}click...{/size}"
    "{size=-8}bam...{/size}"

# game/atHome.rpy:1174
translate pt_br sitInChair_90b68c87:

    # you "..?"
    you "..?"

# game/atHome.rpy:1175
translate pt_br sitInChair_3c037f7a:

    # "Did the door just... close? Did you bump it when you crouched down or..?"
    "A porta... fechou? Você a bateu quando agachou ou..?"

# game/atHome.rpy:1176
translate pt_br sitInChair_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1177
translate pt_br sitInChair_4f5638e2:

    # "W-Well... At least the cat can't come in and make more of a mess this way-"
    "B-Bom... Pelo menos assim o gato não pode entrar pra fazer mais bagunça-"

# game/atHome.rpy:1183
translate pt_br sitInChair_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:1184
translate pt_br sitInChair_cdedc7c0:

    # "The lights?"
    "As luzes?"

# game/atHome.rpy:1185
translate pt_br sitInChair_2bfd08b2:

    # "Didn't you just replace the bulbs? They weren't faulty, were they?"
    "Você não acabou de trocar as lâmpadas? Elas não estavam com defeito, estavam?"

# game/atHome.rpy:1186
translate pt_br sitInChair_f920211f:

    # "You never remember to hold on to your receipts for situations like these."
    "Você nunca se lembra de guardar os recibos para situações como essa."

# game/atHome.rpy:1187
translate pt_br sitInChair_0249ee11:

    # "You doubt you'll be able to get your money back..."
    "E duvida que vá conseguir reembolso..."

# game/atHome.rpy:1193
translate pt_br sitInChair_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:1194
translate pt_br sitInChair_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:1195
translate pt_br sitInChair_3a64e1bd:

    # "You stand up."
    "Você se levanta."

# game/atHome.rpy:1198
translate pt_br sitInChair_c3acc1e2:

    # "You shake out the pain in your knees from crouching and open your medicine cabinet."
    "Após se esticar, aliviando a dor na coluna por ter agachado, você abre o armário de remédios."

# game/atHome.rpy:1201
translate pt_br sitInChair_29a4c348:

    # "Carefully, you place everything back where they belong, making sure nothing is missing."
    "Cuidadosamente, você coloca tudo de volta em seu devido lugar, certificando-se de que nada está faltando."

# game/atHome.rpy:1204
translate pt_br sitInChair_3cbf6fbc:

    # "You close the cabinet door--{w=0.60}{nw}"
    "Você fecha a porta do armário--{w=0.60}{nw}"

# game/atHome.rpy:1215
translate pt_br sitInChair_24c68cb1:

    # you "{size=+30}AAAAAHHH!!{/size}" with vpunch
    you "{size=+30}AAAAAHHH!!{/size}" with vpunch

# game/atHome.rpy:1216
translate pt_br sitInChair_77935352:

    # "You jump back, slamming against the wall, covering your mouth."
    "Você salta para trás, batendo contra a parede e cobrindo a boca."

# game/atHome.rpy:1217
translate pt_br sitInChair_51841170:

    # "You look back up at the mirror on the medicine cabinet door to see..."
    "Você olha para o espelho da porta do armário de remédios e vê..."

# game/atHome.rpy:1218
translate pt_br sitInChair_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:1219
translate pt_br sitInChair_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:1222
translate pt_br sitInChair_e9a3c807:

    # "...nothing."
    "...nada."

# game/atHome.rpy:1223
translate pt_br sitInChair_3a9199d1:

    # "Nothing?"
    "Nada?"

# game/atHome.rpy:1225
translate pt_br sitInChair_dc92f804:

    # you "What... What the hell..? Something... Something was..."
    you "Mas... Mas que porra..? Alguma coisa... Tinha alguma coisa..."

# game/atHome.rpy:1226
translate pt_br sitInChair_312bb316:

    # "You know you saw something just now."
    "Você sabe que viu algo agora há pouco."

# game/atHome.rpy:1227
translate pt_br sitInChair_963cfd9b:

    # "You {i}know{/i} you did."
    "Você {i}sabe{/i} que viu."

# game/atHome.rpy:1228
translate pt_br sitInChair_9979a58c:

    # "Right?"
    "Certo?"

# game/atHome.rpy:1237
translate pt_br movieBathroomJumpscare1_2144dee4:

    # "Yeah, definitely. You're not sticking around for--{w=0.4}{nw}"
    "É, com certeza. Você não vai ficar para--{w=0.4}{nw}"

# game/atHome.rpy:1248
translate pt_br movieBathroomJumpscare1_9998cb84:

    # you "{size=+35}{b}AAAAAAAAHHHHH!!{/b}{/size}" with hpunch
    you "{size=+35}{b}AAAAAAAAHHHHH!!{/b}{/size}" with hpunch

# game/atHome.rpy:1249
translate pt_br movieBathroomJumpscare1_9a70f959:

    # "You rush out of the bathroom and slam the door behind you without looking."
    "Você corre para fora do banheiro e bate a porta com força sem olhar."

# game/atHome.rpy:1253
translate pt_br movieBathroomJumpscare1_4482999d:

    # "You enter the hall and-"
    "Você entra no corredor e-"

# game/atHome.rpy:1262
translate pt_br movieBathroomJumpscare1_8105eadd:

    # you "No..."
    you "Não..."

# game/atHome.rpy:1286
translate pt_br movieBathroomJumpscare1_b3556bea:

    # you "No no no no no!!" with hpunch
    you "Não não não não não!!" with hpunch

# game/atHome.rpy:1287
translate pt_br movieBathroomJumpscare1_40feb4d7:

    # "You shield yourself with your arms and..."
    "Você se protege usando os braços e..."

# game/atHome.rpy:1288
translate pt_br movieBathroomJumpscare1_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:1289
translate pt_br movieBathroomJumpscare1_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1290
translate pt_br movieBathroomJumpscare1_e9a3c807:

    # "...nothing."
    "...nada."

# game/atHome.rpy:1291
translate pt_br movieBathroomJumpscare1_4b236e0a:

    # "Nothing. Again."
    "Nada. De novo."

# game/atHome.rpy:1292
translate pt_br movieBathroomJumpscare1_7af0a5e1:

    # "You peek through your fingers and see..."
    "Você espia através dos dedos e vê..."

# game/atHome.rpy:1297
translate pt_br movieBathroomJumpscare1_9949aa1e:

    # "...just your usual hallway."
    "...apenas o seu corredor de sempre."

# game/atHome.rpy:1298
translate pt_br movieBathroomJumpscare1_0f5de544:

    # "You..."
    "Você..."

# game/atHome.rpy:1303
translate pt_br movieBathroomJumpscare1_6c66c891:

    # "You don't feel very good."
    "Você não se sente muito bem."

# game/atHome.rpy:1304
translate pt_br movieBathroomJumpscare1_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:1305
translate pt_br movieBathroomJumpscare1_63883ba3:

    # "You need to sit down."
    "Precisa se sentar."

# game/atHome.rpy:1308
translate pt_br movieBathroomJumpscare1_3d95bb71:

    # "You carefully make your way back to the dark living room..."
    "Você segue cuidadosamente de volta para a sala escura..."

# game/atHome.rpy:1309
translate pt_br movieBathroomJumpscare1_20b300df:

    # "...trying not to overwhelm your senses anymore than you already have."
    "...tentando não sobrecarregar seus sentidos mais do que já fez."

# game/atHome.rpy:1310
translate pt_br movieBathroomJumpscare1_394dfa11:

    # "Maybe you should watch something a little more lighthearted..."
    "Talvez você devesse assistir algo um pouco mais tranquilo..."

# game/atHome.rpy:1311
translate pt_br movieBathroomJumpscare1_038385fd:

    # "...or just lie down instead?"
    "...ou simplesmente ir se deitar?"

# game/atHome.rpy:1312
translate pt_br movieBathroomJumpscare1_2f6db9fa:

    # "You don't know."
    "Você não sabe."

# game/atHome.rpy:1313
translate pt_br movieBathroomJumpscare1_6866aca7:

    # "It's a little hard to think..."
    "Está meio difícil de pensar..."

# game/atHome.rpy:1314
translate pt_br movieBathroomJumpscare1_d42b8f2e:

    # "You just... need to sit {b}down.{/b}"
    "Você só... precisa se {b}sentar.{/b}"

# game/atHome.rpy:1315
translate pt_br movieBathroomJumpscare1_5ec868b4:

    # "Stumbling forward, you reach your chair..."
    "Cambaleando para frente, você alcança sua poltrona..."

# game/atHome.rpy:1316
translate pt_br movieBathroomJumpscare1_2cdad339:

    # "{color=#FF0000}But-{/color}"
    "{color=#FF0000}Mas-{/color}"

# game/atHome.rpy:1320
translate pt_br movieBathroomJumpscare1_a110fb02:

    # you "{size=+15}!!!!!{/size}" with vpunch
    you "{size=+15}!!!!!{/size}" with vpunch

# game/atHome.rpy:1324
translate pt_br movieBathroomJumpscare1_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:1325
translate pt_br movieBathroomJumpscare1_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:1326
translate pt_br movieBathroomJumpscare1_a4cfcb7e:

    # "It's nothing."
    "Não é nada."

# game/atHome.rpy:1327
translate pt_br movieBathroomJumpscare1_d10408f3:

    # "It's nothing at all."
    "Absolutamente nada."

# game/atHome.rpy:1328
translate pt_br movieBathroomJumpscare1_650a1380:

    # "Just the cat... sitting back in your chair again. Looking up at you curiously."
    "Só o gato... sentado na sua poltrona de novo. Olhando para você com curiosidade."

# game/atHome.rpy:1330
translate pt_br movieBathroomJumpscare1_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/atHome.rpy:1333
translate pt_br movieBathroomJumpscare1_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:1337
translate pt_br movieBathroomJumpscare1_8dabefc6_3:

    # ".."
    "..."

# game/atHome.rpy:1338
translate pt_br movieBathroomJumpscare1_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:1339
translate pt_br movieBathroomJumpscare1_30fe06e7:

    # "...but it's enough."
    "...mas isso é o suficiente."

# game/atHome.rpy:1340
translate pt_br movieBathroomJumpscare1_b8391155:

    # "Your heart lurched so harshly out of a mixture of fear and anticipation..."
    "Seu coração disparou tão intensamente, numa mistura de medo e ansiedade..."

# game/atHome.rpy:1342
translate pt_br movieBathroomJumpscare1_ee49c0d1:

    # "...that it completely gives out."
    "...que ele simplesmente parou."

# game/atHome.rpy:1343
translate pt_br movieBathroomJumpscare1_217ef2ff:

    # "Your eyes roll up into your skull."
    "Seus olhos rolam para trás."

# game/atHome.rpy:1344
translate pt_br movieBathroomJumpscare1_ab3f5fb1:

    # "You feel yourself falling back."
    "Você sente que está caindo para trás."

# game/atHome.rpy:1349
translate pt_br movieBathroomJumpscare1_8dabefc6_4:

    # ".."
    ".."

# game/atHome.rpy:1350
translate pt_br movieBathroomJumpscare1_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:1351
translate pt_br movieBathroomJumpscare1_43180df7:

    # "...You're dead before you even hit the ground."
    "...Você morre antes mesmo de tocar o chão."

# game/atHome.rpy:1352
translate pt_br movieBathroomJumpscare1_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:1353
translate pt_br movieBathroomJumpscare1_15eac906:

    # "Ending 4--{w=0.3}{nw}"
    "Final 4--{w=0.3}{nw}"

# game/atHome.rpy:1372
translate pt_br movieBathroomJumpscare1_a20cefa7_6:

    # "..."
    "..."

# game/atHome.rpy:1373
translate pt_br movieBathroomJumpscare1_ca055f36:

    # "Ending 4: Real \"Subtle\""
    "Final 4: Bem \"Sutil\""

# game/atHome.rpy:1385
translate pt_br napAlone_8f615c2b:

    # "You're a little tired from the events of the day."
    "Você está um pouco cansado dos acontecimentos do dia."

# game/atHome.rpy:1386
translate pt_br napAlone_dcbf1da5:

    # "Making life-changing choices like committing to the responsibility of caring for another living creature..."
    "Tomar decisões que mudam sua vida, como se comprometer com a responsabilidade de cuidar de outro ser vivo..."

# game/atHome.rpy:1387
translate pt_br napAlone_d9c98972:

    # "...really wears you out."
    "...realmente te esgota."

# game/atHome.rpy:1388
translate pt_br napAlone_4505fdc0:

    # "You could definitely use a nap."
    "Você definitivamente poderia tirar um cochilo."

# game/atHome.rpy:1391
translate pt_br napAlone_c3e294a3:

    # "You head to your room and get dressed in your pajamas, before you decide to grab a glass of water from the kitchen."
    "Você vai para o seu quarto e coloca seu pijama, antes de decidir pegar um copo d'água na cozinha."

# game/atHome.rpy:1394
translate pt_br napAlone_0fed84ed:

    # "You head back to your bedroom, ready for a much-needed nap..."
    "Você volta para o seu quarto, pronto para o tão esperado cochilo..."

# game/atHome.rpy:1396
translate pt_br napAlone_ec1974d4:

    # cat "Meow!" with hpunch
    cat "Miau!" with hpunch

# game/atHome.rpy:1397
translate pt_br napAlone_fc460430:

    # you "Whoa!" with vpunch
    you "Ei!" with vpunch

# game/atHome.rpy:1398
translate pt_br napAlone_a5249354:

    # "...only for the cat to race past you through the open door and jump on the middle of the bed."
    "...mas o gato passa correndo por você pela porta aberta e pula no meio da cama."

# game/atHome.rpy:1401
translate pt_br napAlone_919b944d:

    # "It takes its time kneading at the sheets before settling down and closing its eyes."
    "Ele toma seu tempo, amassando os lençóis com as patinhas antes de se acomodar e fechar os olhos."

# game/atHome.rpy:1403
translate pt_br napAlone_cc63b22e:

    # cat "Purr... Purr... Purr..."
    cat "Purr... Purr... Purr..."

# game/atHome.rpy:1404
translate pt_br napAlone_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:1405
translate pt_br napAlone_13af021f:

    # you "{i}Well, that was fast...{/i}"
    you "{i}Rapaz, isso foi rápido...{/i}"

# game/atHome.rpy:1406
translate pt_br napAlone_5068475e:

    # "You frown thoughtfully."
    "Você franze a testa, pensativo."

# game/atHome.rpy:1407
translate pt_br napAlone_3bd08dfd:

    # "Now that your mind's on it, you find yourself {i}really{/i} craving a nap in your own bed."
    "Agora que isso passou pela sua cabeça, você se pega querendo {i}muito{/i} tirar uma soneca na sua própria cama."

# game/atHome.rpy:1408
translate pt_br napAlone_661e2716:

    # "There's no way you're settling for sleeping on the couch. {i}Certainly{/i} not the armchair..."
    "De jeito nenhum você vai se contentar em dormir no sofá. {i}Com certeza{/i} não na poltrona..."

# game/atHome.rpy:1409
translate pt_br napAlone_91480ce3:

    # "Which means you should..."
    "O que significa que você deve..."

# game/atHome.rpy:1418
translate pt_br napMenu_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:1419
translate pt_br napMenu_b4e0a60e:

    # "Maybe you can try napping {i}later...{/i}"
    "Talvez você possa tentar cochilar {i}mais tarde...{/i}"

# game/atHome.rpy:1420
translate pt_br napMenu_f2c5d8d3:

    # "You decide to do something else with your time."
    "Você decide fazer outra coisa com o seu tempo."

# game/atHome.rpy:1426
translate pt_br napMoveCat_c4777c85:

    # "You tentatively nudge the cat in an attempt to make it move on its own."
    "Você dá um empurrãozinho no gato, tentando fazê-lo se mover por conta própria."

# game/atHome.rpy:1427
translate pt_br napMoveCat_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:1428
translate pt_br napMoveCat_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1429
translate pt_br napMoveCat_01382361:

    # "It doesn't budge in the slightest."
    "Ele não se mexe nem um centímetro."

# game/atHome.rpy:1439
translate pt_br napMoveCat2_60058abd:

    # "You push a little more firmly this time."
    "Você empurra um pouquinho mais forte desta vez."

# game/atHome.rpy:1444
translate pt_br napMoveCat2_3af2f912:

    # cat "Mreow..."
    cat "Miaau..."

# game/atHome.rpy:1445
translate pt_br napMoveCat2_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:1446
translate pt_br napMoveCat2_35168c1b:

    # "The cat sounds annoyed with you..."
    "O gato parece irritado com você..."

# game/atHome.rpy:1453
translate pt_br napMoveCat2_7f0ac95c:

    # cat "..."
    cat "..."

# game/atHome.rpy:1463
translate pt_br napMoveCat3_a5040b05:

    # "The cat opens one yellow eye and slides it up to look at you."
    "O gato abre um de seus olhos amarelos e arrasta o olhar para você."

# game/atHome.rpy:1465
translate pt_br napMoveCat3_f07f0105:

    # cat "{b}Mreowww...{/b}"
    cat "{b}Miaaaau...{/b}"

# game/atHome.rpy:1466
translate pt_br napMoveCat3_38a2a096:

    # you "..!" with vpunch
    you "..!" with vpunch

# game/atHome.rpy:1467
translate pt_br napMoveCat3_24137500:

    # "Is its voice a little... deeper? Than before?"
    "A miado dele está um pouco... mais grave? Do que antes?"

# game/atHome.rpy:1468
translate pt_br napMoveCat3_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1477
translate pt_br napMoveCat3_7f0ac95c:

    # cat "..."
    cat "..."

# game/atHome.rpy:1485
translate pt_br napMoveCat4_98c26b25:

    # "You move forward. {w}Ready to shove the cat with all your might--{w=1.5}{nw}"
    "Você avança. {w}Pronto para empurrar o gato com toda a sua força--{w=1.5}{nw}"

# game/atHome.rpy:1490
translate pt_br napMoveCat4_87d1e4e3:

    # "{size=+25}CRASH!{/size}" with vpunch
    "{size=+25}CRASH!{/size}" with vpunch

# game/atHome.rpy:1491
translate pt_br napMoveCat4_35bc070f:

    # you "{size=+10}GAH!{/size}" with hpunch
    you "{size=+10}GAH!{/size}" with hpunch

# game/atHome.rpy:1494
translate pt_br napMoveCat4_267670c2:

    # "You're thrown back by some invisible force and crash into the dresser, before falling to the ground."
    "Você é arremessado para trás por uma força invisível e bate na cômoda, antes de cair no chão."

# game/atHome.rpy:1495
translate pt_br napMoveCat4_e16be8b8:

    # you "Unhh..."
    you "Unhh..."

# game/atHome.rpy:1496
translate pt_br napMoveCat4_f2025eea:

    # "Wind knocked out of you, you look up in a daze..."
    "Sem ar, você olha para cima atordoado..."

# game/atHome.rpy:1497
translate pt_br napMoveCat4_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:1498
translate pt_br napMoveCat4_0f5de544:

    # "You..."
    "Você..."

# game/atHome.rpy:1499
translate pt_br napMoveCat4_c335fc02:

    # "You don't quite comprehend what it is you're seeing."
    "Você não consegue compreender bem o que está vendo."

# game/atHome.rpy:1500
translate pt_br napMoveCat4_1edf14ea:

    # "A strong, swirling wind has picked up, throwing items all over the place..."
    "Um vento forte em espiral se levantou, jogando objetos por toda parte..."

# game/atHome.rpy:1501
translate pt_br napMoveCat4_2e084285:

    # "...as if a miniature hurricane had just taken form in your room."
    "...como se um mini furacão tivesse se formado em seu quarto."

# game/atHome.rpy:1502
translate pt_br napMoveCat4_d7c2d390:

    # "And right there in the center of it all..."
    "E bem no centro disso tudo..."

# game/atHome.rpy:1505
translate pt_br napMoveCat4_73ca6c0a:

    # "...is the cat."
    "...está o gato."

# game/atHome.rpy:1506
translate pt_br napMoveCat4_b37f5c41:

    # "Hovering in the air above the bed..."
    "Pairando no ar acima da cama..."

# game/atHome.rpy:1507
translate pt_br napMoveCat4_f02e91e8:

    # "Its eyes open, glowing like molten lava..."
    "Seus olhos abertos, brilhando como lava derretida..."

# game/atHome.rpy:1509
translate pt_br napMoveCat4_3e04d2ff:

    # cat "Mreowww..."
    cat "Miauuuu..."

# game/atHome.rpy:1511
translate pt_br napMoveCat4_c2cbf478:

    # cat "{size=+5}Mreowww...{/size}" with vpunch
    cat "{size=+5}Miauuuu...{/size}" with vpunch

# game/atHome.rpy:1516
translate pt_br napMoveCat4_c64e3fd2:

    # cat "{size=+10}{b}M r e o w w w...!{/b}{/size}" with vpunch
    cat "{size=+10}{b}M i a u u u u...!{/b}{/size}" with vpunch

# game/atHome.rpy:1520
translate pt_br napMoveCat4_28b3ac41:

    # you "!!"
    you "!!"

# game/atHome.rpy:1521
translate pt_br napMoveCat4_3db840b4:

    # "You watch as a vortex rips open in the center of your bed..."
    "Você assiste enquanto um vórtice se abre no centro da sua cama..."

# game/atHome.rpy:1522
translate pt_br napMoveCat4_9c4942bc:

    # "...and panic as the swirling wind turns into a {i}vaccuum.{/i}"
    "...e entra em pânico quando o vento em espiral se transforma em um {i}vácuo.{/i}"

# game/atHome.rpy:1523
translate pt_br napMoveCat4_4351a428:

    # "{b}Dragging{/b} you towards the bed..."
    "{b}Arrastando{/b} você em direção à cama..."

# game/atHome.rpy:1527
translate pt_br napMoveCat4_67c9c705:

    # you "Ghh!" with hpunch
    you "Ghh!" with hpunch

# game/atHome.rpy:1528
translate pt_br napMoveCat4_410731bd:

    # "Your nails catch and {b}{i}tear{/i}{/b} as you desperately try to cling to the carpet... {w}the floor boards..."
    "Suas unhas prendem e se {b}{i}quebram{/i}{/b} enquanto você tenta desesperadamente se segurar no carpete... {w}as tábuas do chão..."

# game/atHome.rpy:1529
translate pt_br napMoveCat4_20ed66fb:

    # "...any and {i}every{/i} piece of furniture within your reach..."
    "...toda e {i}qualquer{/i} mobília ao seu alcance..."

# game/atHome.rpy:1530
translate pt_br napMoveCat4_c8ef0095:

    # "...bloody fingers slipping clumsily on every surface..."
    "...seus dedos ensanguentados escorregam desajeitadamente em cada superfície..."

# game/atHome.rpy:1531
translate pt_br napMoveCat4_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:1532
translate pt_br napMoveCat4_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1533
translate pt_br napMoveCat4_fe111813:

    # "...but there's nothing you can do."
    "...mas não há nada que você possa fazer."

# game/atHome.rpy:1535
translate pt_br napMoveCat4_92ab24b3:

    # "As you touch the vortex... your body starts to..."
    "Quando você toca o vórtice... seu corpo começa a..."

# game/atHome.rpy:1536
translate pt_br napMoveCat4_cb8978e7:

    # "...{i}disintegrate.{/i}"
    "...{i}desintegrar.{/i}"

# game/atHome.rpy:1537
translate pt_br napMoveCat4_70bd56a0:

    # "Tiny particles of your body separating and floating into nothing..."
    "Minúsculas partículas do seu corpo se separando e flutuando para o nada..."

# game/atHome.rpy:1541
translate pt_br napMoveCat4_9d7d7459:

    # "The last thing you see is the cat landing nimbly on the bed and kneading at your sheets..."
    "A última coisa que você vê é o gato caindo agilmente na cama e amassando os seus lençóis..."

# game/atHome.rpy:1542
translate pt_br napMoveCat4_3bbf7816:

    # "...before it curls up and falls back asleep."
    "...antes de se enroscar e voltar a dormir."

# game/atHome.rpy:1544
translate pt_br napMoveCat4_67107e6c:

    # cat "Purr..."
    cat "Purr..."

# game/atHome.rpy:1545
translate pt_br napMoveCat4_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:1546
translate pt_br napMoveCat4_575b36ec:

    # "Ending 5: Do Nyaa-t Disturb"
    "Final 5: Não Mia Corde"

# game/atHome.rpy:1558
translate pt_br napTogether_4e7a8b32:

    # "You shrug. What's the harm in sharing the bed, right?"
    "Qual o problema em dividir a cama, certo?"

# game/atHome.rpy:1559
translate pt_br napTogether_426f3adb:

    # "You both have had a long day, after all."
    "Afinal, vocês dois tiveram um longo dia."

# game/atHome.rpy:1561
translate pt_br napTogether_a3583f06:

    # "You try to carefully avoid jostling the cat as you lay down, but it immediately scoots over and curls up against you anyway."
    "Você tenta deitar com cuidado para não incomodar o gato, mas ele imediatamente se aproxima e se enrosca em você de qualquer maneira."

# game/atHome.rpy:1563
translate pt_br napTogether_cc63b22e:

    # cat "Purr... Purr... Purr..."
    cat "Purr... Purr... Purr..."

# game/atHome.rpy:1564
translate pt_br napTogether_0ff74098:

    # "You smile."
    "Você sorri."

# game/atHome.rpy:1567
translate pt_br napTogether_416e2125:

    # you "Sweet dreams..."
    you "Sonhe com os anjos..."

# game/atHome.rpy:1568
translate pt_br napTogether_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:1569
translate pt_br napTogether_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1570
translate pt_br napTogether_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:1574
translate pt_br napTogether_37d6d699:

    # you "Mmph..?"
    you "Mmph..?"

# game/atHome.rpy:1575
translate pt_br napTogether_80a5c3e8:

    # "You feel like you slept for a long time."
    "Você sente que dormiu por um bom tempo."

# game/atHome.rpy:1576
translate pt_br napTogether_40d9ca73_1:

    # "..?"
    "..?"

# game/atHome.rpy:1577
translate pt_br napTogether_1a1908b3:

    # "You feel a warm weight on your back..."
    "Também sente um peso quente nas costas..."

# game/atHome.rpy:1578
translate pt_br napTogether_f1efd4f0:

    # "But you don't see the-{w=0.6}{nw}"
    "Mas você não vê o-{w=0.6}{nw}"

# game/atHome.rpy:1580
translate pt_br napTogether_57f9ada2:

    # cat "Purr... Purr... Purrr..."
    cat "Purr... Purr... Purr..."

# game/atHome.rpy:1581
translate pt_br napTogether_28052c77:

    # "...Oh. Mystery solved, then."
    "...Ah. Mistério resolvido, então."

# game/atHome.rpy:1582
translate pt_br napTogether_3ab0f315:

    # "You feel... comfortable..?"
    "Você se sente... confortável..?"

# game/atHome.rpy:1583
translate pt_br napTogether_6a292af6:

    # "You consider getting up..."
    "Você pensa em se levantar..."

# game/atHome.rpy:1585
translate pt_br napTogether_5bdd7954:

    # "...but as soon as the thought enters your head, your mind fills with static and a deep sense of..."
    "...mas assim que essa ideia passa pela sua cabeça, sua mente se enche com um ruído e um senso profundo de..."

# game/atHome.rpy:1586
translate pt_br napTogether_ef2259f2:

    # "...disapproval?"
    "...desaprovação?"

# game/atHome.rpy:1587
translate pt_br napTogether_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:1591
translate pt_br napTogether_0ef6194c:

    # you "{i}Not yet, then? Okay...{/i}"
    you "{i}Então, ainda não? Ok...{/i}"

# game/atHome.rpy:1592
translate pt_br napTogether_614a2e6c:

    # "The cat, jostled by your attempts at movement, kneads painfully at your back before settling down again and falling back asleep."
    "O gato, incomodado com suas tentativas de se mexer, amassa suas costas dolorosamente antes de se acomodar novamente e voltar a dormir."

# game/atHome.rpy:1593
translate pt_br napTogether_2145b389:

    # "You fall back into slumber too."
    "Você também volta a adormecer."

# game/atHome.rpy:1594
translate pt_br napTogether_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:1595
translate pt_br napTogether_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:1600
translate pt_br napTogether_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:1601
translate pt_br napTogether_3e8cc2f1:

    # "It's night."
    "Está de noite."

# game/atHome.rpy:1602
translate pt_br napTogether_b5717b9e:

    # "You want to get up."
    "Você quer se levantar."

# game/atHome.rpy:1606
translate pt_br napTogether_d13d6302:

    # you "Nnnh!" with vpunch
    you "Nnnh!" with vpunch

# game/atHome.rpy:1607
translate pt_br napTogether_45f5f5bd:

    # "Claws dig into your back like a warning."
    "As garras se cravam em suas costas, como um aviso."

# game/atHome.rpy:1609
translate pt_br napTogether_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:1612
translate pt_br napTogether_4c13fdd1:

    # "...Tomorrow then, right?"
    "...Amanhã então, certo?"

# game/atHome.rpy:1614
translate pt_br napTogether_55355e09:

    # cat "Purr... Purr..."
    cat "Purr... Purr..."

# game/atHome.rpy:1615
translate pt_br napTogether_dae0ec55_2:

    # you "..."
    you "..."

# game/atHome.rpy:1616
translate pt_br napTogether_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:1618
translate pt_br napTogether_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:1622
translate pt_br napTogether_e1a3bb11:

    # "...It's morning. You'll be late for work..."
    "...Já é de manhã. Você vai se atrasar para o trabalho..."

# game/atHome.rpy:1623
translate pt_br napTogether_ccb83206:

    # "...but the cat doesn't budge."
    "...mas o gato não se mexe."

# game/atHome.rpy:1624
translate pt_br napTogether_6faab910:

    # "You don't even try to get up this time."
    "Desta vez, você nem tenta se levantar."

# game/atHome.rpy:1628
translate pt_br napTogether_da0c099f:

    # "You just close your eyes and drift off again."
    "Apenas fecha os olhos e volta a dormir."

# game/atHome.rpy:1629
translate pt_br napTogether_8dabefc6_3:

    # ".."
    ".."

# game/atHome.rpy:1630
translate pt_br napTogether_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:1636
translate pt_br napTogether_90b93b6a:

    # "It's..."
    "É..."

# game/atHome.rpy:1637
translate pt_br napTogether_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:1638
translate pt_br napTogether_7e35a8e3:

    # "It's the next day..."
    "Já faz um dia..."

# game/atHome.rpy:1639
translate pt_br napTogether_a20cefa7_6:

    # "..."
    "..."

# game/atHome.rpy:1640
translate pt_br napTogether_432cfea9:

    # "...since the last {b}several{/b} days..."
    "...desde que você começou a se perder nos últimos {b}vários{/b} dias..."

# game/atHome.rpy:1641
translate pt_br napTogether_b3d9c927:

    # "...Or has it been weeks?"
    "...Ou foram semanas?"

# game/atHome.rpy:1642
translate pt_br napTogether_a20cefa7_7:

    # "..."
    "..."

# game/atHome.rpy:1643
translate pt_br napTogether_8a135021:

    # "{size=-8}Or longer...?{/size}"
    "{size=-8}Ou mais...?{/size}"

# game/atHome.rpy:1644
translate pt_br napTogether_a20cefa7_8:

    # "..."
    "..."

# game/atHome.rpy:1645
translate pt_br napTogether_4c91bf15:

    # "You're not quite sure."
    "Você não tem certeza."

# game/atHome.rpy:1647
translate pt_br napTogether_dae0ec55_3:

    # you "..."
    you "..."

# game/atHome.rpy:1648
translate pt_br napTogether_421780e5:

    # "You're hungry."
    "Você está com fome."

# game/atHome.rpy:1649
translate pt_br napTogether_f631369d:

    # "You don’t know how long you’ve been lying down."
    "Você não sabe por quanto tempo esteve deitado."

# game/atHome.rpy:1650
translate pt_br napTogether_097a8871:

    # "You feel sore on your back, but also on your stomach, your arms, your face..."
    "Você sente as costas doloridas, mas também o estômago, os braços, o rosto..."

# game/atHome.rpy:1651
translate pt_br napTogether_d6e6ac76:

    # "Everywhere..."
    "Todo lugar..."

# game/atHome.rpy:1652
translate pt_br napTogether_6ebedf14:

    # "You can't remember your last meal... {w}The last time you drank anything..."
    "Você não consegue se lembrar da sua última refeição... {w}Da última vez que bebeu algo..."

# game/atHome.rpy:1653
translate pt_br napTogether_151a082b:

    # "You've been sleeping all this time..."
    "Você esteve dormindo todo esse tempo..."

# game/atHome.rpy:1654
translate pt_br napTogether_5255f5a0:

    # "...but you feel {b}exhausted{/b}. More tired than you think you've ever felt in your life."
    "...mas se sente {b}exausto{/b}. Mais cansado do que jamais se lembra de ter ficado."

# game/atHome.rpy:1655
translate pt_br napTogether_e3a05912:

    # "It feels like a giant hand is {i}pressing{/i} you into the bed."
    "É como se uma mão gigante estivesse {i}pressionando{/i} você contra a cama."

# game/atHome.rpy:1656
translate pt_br napTogether_0fa6935c:

    # "You can't remember the last time you even considered moving..."
    "Você não consegue se lembrar da última vez que sequer considerou se mover..."

# game/atHome.rpy:1659
translate pt_br napTogether_4c459194:

    # "But somehow you know..."
    "Mas, de alguma forma, você sabe..."

# game/atHome.rpy:1660
translate pt_br napTogether_2c153c83:

    # "{size=-8}...that you need to go back to sleep {b}anyway{/b}.{/size}"
    "{size=-8}......que precisa voltar a dormir {b}de qualquer jeito{/b}.{/size}"

# game/atHome.rpy:1661
translate pt_br napTogether_f31145ff:

    # "Everything will be fine if you just go back to sleep."
    "Tudo vai ficar bem se você só voltar a dormir."

# game/atHome.rpy:1663
translate pt_br napTogether_8dabefc6_4:

    # ".."
    ".."

# game/atHome.rpy:1664
translate pt_br napTogether_a20cefa7_9:

    # "..."
    "..."

# game/atHome.rpy:1665
translate pt_br napTogether_b59d962a:

    # "..?" with vpunch
    "..?" with vpunch

# game/atHome.rpy:1666
translate pt_br napTogether_e82e813a:

    # "You think you're hallucinating when the cat finally stirs..."
    "Você pensa estar alucinando quando o gato finalmente se mexe..."

# game/atHome.rpy:1668
translate pt_br napTogether_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/atHome.rpy:1669
translate pt_br napTogether_c3e31538:

    # "It stretches languidly before hopping off your back."
    "Ele se estica preguiçosamente antes de pular das suas costas."

# game/atHome.rpy:1670
translate pt_br napTogether_2f0da195:

    # "You hear its feet padding through your still open bedroom door, its steps fading down the hall."
    "Você ouve suas patinhas passando pela porta do seu quarto ainda aberta, seus passos desaparecendo pelo corredor."

# game/atHome.rpy:1671
translate pt_br napTogether_8dabefc6_5:

    # ".."
    ".."

# game/atHome.rpy:1672
translate pt_br napTogether_a20cefa7_10:

    # "..."
    "..."

# game/atHome.rpy:1673
translate pt_br napTogether_c45998b5:

    # "You don't open your eyes."
    "Você não abre os olhos."

# game/atHome.rpy:1674
translate pt_br napTogether_9e3127bc:

    # "You don't {i}move.{/i}"
    "Você não {i}se move.{/i}"

# game/atHome.rpy:1675
translate pt_br napTogether_a20cefa7_11:

    # "..."
    "..."

# game/atHome.rpy:1676
translate pt_br napTogether_40b03495:

    # "You’re afraid you don’t remember {b}how.{/b}"
    "Você tem medo de não se lembrar {b}como.{/b}"

# game/atHome.rpy:1677
translate pt_br napTogether_7362ca19:

    # "You’re afraid that the static will return if you try..."
    "Tem medo de que o ruído volte se você tentar..."

# game/atHome.rpy:1678
translate pt_br napTogether_a20cefa7_12:

    # "..."
    "..."

# game/atHome.rpy:1679
translate pt_br napTogether_3c068b44:

    # "But you eventually {i}do{/i} try."
    "Mas eventualmente você {i}tenta{/i}."

# game/atHome.rpy:1683
translate pt_br napTogether_cedc9e87:

    # "You try to prop yourself up on your arm."
    "Você tenta se apoiar no braço."

# game/atHome.rpy:1684
translate pt_br napTogether_9728d600:

    # "It’s thinner than you’ve ever seen it..."
    "Ele está mais fino do que você já o viu..."

# game/atHome.rpy:1685
translate pt_br napTogether_7accebe2:

    # "Thinner than you think should be {i}possible-{/i}"
    "Mais fino do que você acha que deveria ser {i}possível-{/i}"

# game/atHome.rpy:1689
translate pt_br napTogether_f877cb8f:

    # "{size=+10}CRACK!{/size}" with vpunch
    "{size=+10}CRACK!{/size}" with vpunch

# game/atHome.rpy:1691
translate pt_br napTogether_dae0ec55_4:

    # you "..."
    you "..."

# game/atHome.rpy:1692
translate pt_br napTogether_bf2e0dee:

    # "The arm snaps under the weight of your body and crumbles to dust on the bedsheets."
    "O braço se quebra sob o peso do seu corpo e se desfaz em pó sobre os lençóis."

# game/atHome.rpy:1693
translate pt_br napTogether_a20cefa7_13:

    # "..."
    "..."

# game/atHome.rpy:1694
translate pt_br napTogether_205af2fa:

    # "It doesn’t hurt in the slightest..."
    "Não dói nem um pouco..."

# game/atHome.rpy:1695
translate pt_br napTogether_72a91789:

    # "As if even your nerves have dried up and become as useless as..."
    "Como se até seus nervos tivessem secado e se tornado tão inúteis quanto..."

# game/atHome.rpy:1696
translate pt_br napTogether_e7fd628a:

    # "...well, as useless as you feel in {i}general.{/i}"
    "...bem, tão inútil quanto você se sente, {i}de maneira geral.{/i}"

# game/atHome.rpy:1697
translate pt_br napTogether_afc8d8b5:

    # "{size=-8}Just how {b}long{/b} have you been laying in bed..?{/size}"
    "{size=-8}Há quanto {b}tempo{/b} você está deitado nessa cama..?{/size}"

# game/atHome.rpy:1698
translate pt_br napTogether_a20cefa7_14:

    # "..."
    "..."

# game/atHome.rpy:1699
translate pt_br napTogether_ac9494ba:

    # "You don't have much time to think about it."
    "Você não tem muito tempo para pensar nisso."

# game/atHome.rpy:1700
translate pt_br napTogether_ea722524:

    # "Your failed attempt at sitting up sends you tumbling over the side of the bed like a rag doll..."
    "Sua tentativa frustrada de se sentar faz com que você despenque do lado da cama como um boneco de pano..."

# game/atHome.rpy:1702
translate pt_br napTogether_39ee23ef:

    # "{size=+5}CRACK!{/size}" with vpunch
    "{size=+5}CRACK!{/size}" with vpunch

# game/atHome.rpy:1704
translate pt_br napTogether_f877cb8f_1:

    # "{size=+10}CRACK!{/size}" with vpunch
    "{size=+10}CRACK!{/size}" with vpunch

# game/atHome.rpy:1706
translate pt_br napTogether_047fc669:

    # "{size=+25}CRACK!{/size}" with vpunch
    "{size=+25}CRACK!{/size}" with vpunch

# game/atHome.rpy:1707
translate pt_br napTogether_1407836e:

    # "But you think you’re probably closer to being a {i}ceramic{/i} doll..."
    "Mas você pensa que está mais para um boneco de {i}cerâmica{/i}..."

# game/atHome.rpy:1708
translate pt_br napTogether_394bdc78:

    # "...as your body shatters {i}instantly{/i} upon impact with the floor."
    "...pois seu corpo se despedaça {i}instantâneamente{/i} ao cair no chão."

# game/atHome.rpy:1711
translate pt_br napTogether_d48b6485:

    # "Your head rolls towards the door..."
    "Sua cabeça rola em direção à porta..."

# game/atHome.rpy:1712
translate pt_br napTogether_118dceca:

    # "...letting you watch as the rest of your strewn body parts crack..."
    "...fazendo você observar o restante dos seus membros espalhados se quebrarem..."

# game/atHome.rpy:1713
translate pt_br napTogether_fdee14d8:

    # "...and {i}crumble{/i}..."
    "...e {i}se desfazerem{/i}..."

# game/atHome.rpy:1714
translate pt_br napTogether_77f0a0e9:

    # "...and turn to broken {b}ruin{/b} as your consciousness begins to fade."
    "...transformando-se em {b}entulho{/b} à medida que sua consciência começa a se dissipar."

# game/atHome.rpy:1720
translate pt_br napTogether_1d86a44d:

    # "The cat strolls into view then... poking and prodding at the remains of your brittle limbs."
    "O gato então aparece... cutucando e tocando os restos dos seus membros quebradiços."

# game/atHome.rpy:1721
translate pt_br napTogether_59882995:

    # "\"Bad kitty.\" {w}You try to say..."
    "\"Gatinho mau.\" {w}Você tenta dizer..."

# game/atHome.rpy:1722
translate pt_br napTogether_a20cefa7_15:

    # "..."
    "..."

# game/atHome.rpy:1723
translate pt_br napTogether_c7e0166e:

    # "But you think your jaw might've snapped off earlier as well."
    "Mas você pensa que sua mandíbula pode já ter se quebrado."

# game/atHome.rpy:1724
translate pt_br napTogether_58a56e4d:

    # "Almost as if sensing your attention, the cat walks over to you..."
    "Quase como se sentisse sua atenção, o gato caminha até você..."

# game/atHome.rpy:1725
translate pt_br napTogether_ebb54fa1:

    # "Well... your {i}head{/i} at least..."
    "Bem... pelo menos até sua {i}cabeça{/i}..."

# game/atHome.rpy:1726
translate pt_br napTogether_3639e1f8:

    # "...and you watch with your final conscious seconds as it lays down, curling its body around you."
    "...e você observa, nos seus últimos segundos de consciência, enquanto ele se deita, se enroscando ao seu redor."

# game/atHome.rpy:1730
translate pt_br napTogether_55355e09_1:

    # cat "Purr... Purr..."
    cat "Purr... Purr..."

# game/atHome.rpy:1731
translate pt_br napTogether_8dabefc6_6:

    # ".."
    ".."

# game/atHome.rpy:1732
translate pt_br napTogether_a20cefa7_16:

    # "..."
    "..."

# game/atHome.rpy:1733
translate pt_br napTogether_807ca19c:

    # "It feels warm."
    "É quentinho."

# game/atHome.rpy:1734
translate pt_br napTogether_a20cefa7_17:

    # "..."
    "..."

# game/atHome.rpy:1735
translate pt_br napTogether_221cbb22:

    # "Well."
    "Bom..."

# game/atHome.rpy:1736
translate pt_br napTogether_a20cefa7_18:

    # "..."
    "..."

# game/atHome.rpy:1737
translate pt_br napTogether_ba93f838:

    # "{size=-8}Maybe another nap couldn't hurt...{/size}"
    "{size=-8}Talvez outro cochilo não fizesse mal...{/size}"

# game/atHome.rpy:1738
translate pt_br napTogether_8dabefc6_7:

    # ".."
    ".."

# game/atHome.rpy:1739
translate pt_br napTogether_a20cefa7_19:

    # "..."
    "..."

# game/atHome.rpy:1740
translate pt_br napTogether_f7b8427a:

    # "Ending 6: Just A Cat Nap"
    "Final 6: Só Um Cochilo"

# game/atHome.rpy:1752
translate pt_br petCat_52bd3edf:

    # "It's not everyday you have access to a cute fluffy animal."
    "Não é todo dia que você tem acesso a um bichinho fofo e peludo."

# game/atHome.rpy:1753
translate pt_br petCat_f910595b:

    # "What else is there to do but pet it to your heart's content?"
    "O que mais você poderia fazer além de fazer carinho nele até se sentir satisfeito?"

# game/atHome.rpy:1754
translate pt_br petCat_59866bfa:

    # "You sit on the floor in your living room and click your tongue to call the cat over."
    "Você se senta no chão da sala e estala a língua para chamar o gato."

# game/atHome.rpy:1756
translate pt_br petCat_9542a4b9:

    # cat "Mrrp!!" with hpunch
    cat "Mrrp!!" with hpunch

# game/atHome.rpy:1759
translate pt_br petCat_59da5396:

    # "The cat dashes over to you, immediately climbing into your lap."
    "O gato corre até você, subindo no seu colo imediatamente."

# game/atHome.rpy:1760
translate pt_br petCat_c59a408d:

    # you "Poor thing~ You just want some attention, don't you?"
    you "Pobrezinho~ Só quer um pouco de atenção, não é?"

# game/atHome.rpy:1762
translate pt_br petCat_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/atHome.rpy:1763
translate pt_br petCat_cef992d7:

    # you "Hehe, alright, alright!"
    you "Hehe, tá bom, tá bom!"

# game/atHome.rpy:1764
translate pt_br petCat_99ba38b9:

    # "You carefully pet the cat. {w}A rub behind an ear. {w}A scratch under the chin. {w}A smooth sweep along the back."
    "Você o acaricia com cuidado. {w}Coça atrás da orelha. {w}Esfrega em baixo do queixo. {w}Desliza a mão suavemente pelas costas."

# game/atHome.rpy:1766
translate pt_br petCat_cc63b22e:

    # cat "Purr... Purr... Purr..."
    cat "Purr... Purr... Purr..."

# game/atHome.rpy:1767
translate pt_br petCat_4d2c742f:

    # you "Heh, good?"
    you "Heh, tá gostando?"

# game/atHome.rpy:1769
translate pt_br petCat_67107e6c:

    # cat "Purr..."
    cat "Purr..."

# game/atHome.rpy:1770
translate pt_br petCat_79e12018:

    # "You keep petting the cat in your lap, enjoying this bonding time together..."
    "Você continua acariciando o gato no seu colo, aproveitando esse momento juntos..."

# game/atHome.rpy:1774
translate pt_br petCat_f5145a26:

    # "...but the cat starts to get restless after a while."
    "...mas o gato começa a ficar inquieto depois de um tempo."

# game/atHome.rpy:1788
translate pt_br keepPetting_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1789
translate pt_br keepPetting_e01ca199:

    # "You're not quite ready to stop."
    "Você não está pronto para parar."

# game/atHome.rpy:1790
translate pt_br keepPetting_7107d5ed:

    # "You feel so {i}calm{/i}... The repetitive action soothing your usually overworking mind..."
    "Você se sente tão {i}calmo{/i}... Essa ação repetitiva acalma sua mente sobrecarregada..."

# game/atHome.rpy:1791
translate pt_br keepPetting_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:1792
translate pt_br keepPetting_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:1793
translate pt_br keepPetting_afeb9142:

    # "You keep petting."
    "Você continua fazendo carinho."

# game/atHome.rpy:1798
translate pt_br keepPetting_3af2f912:

    # cat "Mreow..."
    cat "Miau..."

# game/atHome.rpy:1799
translate pt_br keepPetting_a3f235fe:

    # "The cat leans away from your next head pat."
    "O gato se afasta da sua próxima tentativa de fazer carinho na cabeça."

# game/atHome.rpy:1800
translate pt_br keepPetting_1e8aea73:

    # "It's trying to get out of your lap."
    "Está tentando sair do seu colo."

# game/atHome.rpy:1816
translate pt_br keepPetting2_972c75fa:

    # "When you scratch under the cat's chin, it bites at your fingers."
    "Quando você faz um carinho em baixo do queixo do gato, ele morde seus dedos."

# game/atHome.rpy:1817
translate pt_br keepPetting2_ae0c2b21:

    # "You might be bleeding, but really it barely hurts."
    "Você pode estar sangrando, mas, na verdade, mal dói."

# game/atHome.rpy:1818
translate pt_br keepPetting2_b3d3cd04:

    # "More of a warning than anything."
    "Mais um aviso do que qualquer outra coisa."

# game/atHome.rpy:1823
translate pt_br keepPetting2_ceceaf01:

    # cat "Mreow!" with hpunch
    cat "Miaau!" with hpunch

# game/atHome.rpy:1824
translate pt_br keepPetting2_746fba6a:

    # "The cat struggles in your hold."
    "O gato se debate em seus braços."

# game/atHome.rpy:1825
translate pt_br keepPetting2_59092dab:

    # "It's watching you closely."
    "Está te observando atentamente."

# game/atHome.rpy:1826
translate pt_br keepPetting2_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:1838
translate pt_br keepPetting3_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:1839
translate pt_br keepPetting3_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:1840
translate pt_br keepPetting3_1ffa03f8:

    # "You keep petting the cat-"
    "Você continua fazendo carinho no gato-"

# game/atHome.rpy:1842
translate pt_br keepPetting3_df1f0434:

    # cat "{b}{size=+5}MREOW!{/size}{/b}" with hpunch
    cat "{b}{size=+5}MIAAU!{/size}{/b}" with hpunch

# game/atHome.rpy:1845
translate pt_br keepPetting3_d51d0b13:

    # "{size=+15}{b}CHOMP!{/b}{/size}" with vpunch
    "{size=+15}{b}CHOMP!{/b}{/size}" with vpunch

# game/atHome.rpy:1846
translate pt_br keepPetting3_28b3ac41:

    # you "!!"
    you "!!"

# game/atHome.rpy:1863
translate pt_br keepPetting3_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:1864
translate pt_br keepPetting3_a513413e:

    # "..!"
    "..!"

# game/atHome.rpy:1865
translate pt_br keepPetting3_f5b70ae2:

    # "The cat..."
    "O gato..."

# game/atHome.rpy:1866
translate pt_br keepPetting3_439e3871:

    # "...bites {b}off{/b} your finger."
    "...morde seu dedo e o arranca {b}fora{/b}."

# game/atHome.rpy:1867
translate pt_br keepPetting3_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:1868
translate pt_br keepPetting3_62c0c671:

    # "It hurts..."
    "Dói..."

# game/atHome.rpy:1871
translate pt_br keepPetting3_505e1acd:

    # "You're {i}definitely{/i} bleeding now..."
    "Você {i}definitivamente{/i} está sangrando agora..."

# game/atHome.rpy:1872
translate pt_br keepPetting3_bf0874e3:

    # "But..."
    "Mas..."

# game/atHome.rpy:1873
translate pt_br keepPetting3_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:1874
translate pt_br keepPetting3_a4bb9dbd:

    # "...for some reason..."
    "...por alguma razão..."

# game/atHome.rpy:1875
translate pt_br keepPetting3_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:1876
translate pt_br keepPetting3_92e28b8f:

    # "{size=-8}...you just can't {b}stop.{/b}{/size}"
    "{size=-8}...você simplesmente não consegue {b}parar.{/b}{/size}"

# game/atHome.rpy:1877
translate pt_br keepPetting3_0ecc6b91:

    # "You don't know what it is..."
    "Você não sabe o que é..."

# game/atHome.rpy:1878
translate pt_br keepPetting3_f43d701c:

    # "Its fur is so much {b}{i}softer{/i}{/b} than you realized..."
    "Seu pelo é muito mais {b}{i}macio{/i}{/b} do que você imaginava..."

# game/atHome.rpy:1879
translate pt_br keepPetting3_99249dc1:

    # "You’d think that it would be shining in the faint light of your living room, but..."
    "É de se pensar que ele brilharia sob a luz fraca da sala, mas..."

# game/atHome.rpy:1880
translate pt_br keepPetting3_4b10ed10:

    # "...it's as if the darkness of the cat’s black coat is {i}sucking{/i} in all the illumination around it..."
    "...é como se a escuridão do pelo preto do gato estivesse {i}absorvendo{/i} toda a iluminação ao redor dele..."

# game/atHome.rpy:1881
translate pt_br keepPetting3_d09fbed4:

    # "...rendering it completely {i}null.{/i}"
    "...tornando-o completamente {i}nulo.{/i}"

# game/atHome.rpy:1882
translate pt_br keepPetting3_21d4057c:

    # "You're drawn to it. {w}Like you're somehow holding a deep dark {b}abyss{/b} right in your lap."
    "Você é atraído para ele. {w}Como se, de alguma forma, estivesse segurando um profundo e sombrio {b}abyss{/b} bem no seu colo."

# game/atHome.rpy:1884
translate pt_br keepPetting3_8c8267dd:

    # cat "Purr... Purrr.."
    cat "Purr... Purr..."

# game/atHome.rpy:1885
translate pt_br keepPetting3_2ba9ab53:

    # "It seems calmer now, munching on your severed finger."
    "Parece mais calmo agora, mastigando seu dedo arrancado."

# game/atHome.rpy:1886
translate pt_br keepPetting3_03d25c7d:

    # "The stump between your thumb and middle finger is leaking..."
    "O toco entre o polegar e o dedo médio está sangrando..."

# game/atHome.rpy:1887
translate pt_br keepPetting3_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:1888
translate pt_br keepPetting3_396fb77c:

    # "...but you keep petting."
    "...mas você continua acariciando."

# game/atHome.rpy:1889
translate pt_br keepPetting3_c18819d8:

    # "You fret that your blood will ruin its fur, but the cat no longer seems to mind."
    "Você não quer que seu sangue manche o pelo dele, mas o gato parece não se importar mais."

# game/atHome.rpy:1890
translate pt_br keepPetting3_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:1891
translate pt_br keepPetting3_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:1894
translate pt_br keepPetting3_4d9e273d:

    # "Time passes. {w}It's dark out now."
    "O tempo passa. {w}Já está escuro lá fora."

# game/atHome.rpy:1895
translate pt_br keepPetting3_7ff6d061:

    # "Soft as the fur is, your palm has started to feel raw and damp under the constant friction from your petting."
    "Por mais macio que seja o pelo, sua palma começou a ficar áspera e úmida com a fricção constante dos carinhos."

# game/atHome.rpy:1896
translate pt_br keepPetting3_a20cefa7_6:

    # "..."
    "..."

# game/atHome.rpy:1897
translate pt_br keepPetting3_005a0a26:

    # "{size=-7}You think faintly that maybe you’ve had enough.{/size}"
    "{size=-7}Surge um pensamento vago de que talvez já tenha sido o suficiente.{/size}"

# game/atHome.rpy:1900
translate pt_br keepPetting3_0d6d2a66:

    # "You start to lift your hand from the cat..."
    "Você começa a levantar a mão do gato..."

# game/atHome.rpy:1901
translate pt_br keepPetting3_0f665b3a:

    # "...when in a flash--{w=0.5}{nw}"
    "...quando, num piscar de olhos--{w=0.5}{nw}"

# game/atHome.rpy:1913
translate pt_br keepPetting3_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:1914
translate pt_br keepPetting3_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:1915
translate pt_br keepPetting3_a20cefa7_7:

    # "..."
    "..."

# game/atHome.rpy:1920
translate pt_br keepPetting3_8dabefc6_3:

    # ".."
    ".."

# game/atHome.rpy:1921
translate pt_br keepPetting3_a20cefa7_8:

    # "..."
    "..."

# game/atHome.rpy:1922
translate pt_br keepPetting3_cb08e821:

    # "...your entire {b}hand{/b} is separated from your wrist."
    "...sua {b}mão{/b} inteira é separada do seu pulso."

# game/atHome.rpy:1923
translate pt_br keepPetting3_28e9e838:

    # "It flops onto your lap beside the cat."
    "Ela cai no seu colo, ao lado do gato."

# game/atHome.rpy:1924
translate pt_br keepPetting3_9ab57abe:

    # "The cat's claws on its front right paw glisten with crimson liquid."
    "As garras da pata dianteira direita do gato brilham com um líquido carmesim."

# game/atHome.rpy:1925
translate pt_br keepPetting3_c40b465b:

    # "You don’t feel it for a moment but your body tenses..."
    "Você não sente nada na hora, mas seu corpo se tenciona..."

# game/atHome.rpy:1926
translate pt_br keepPetting3_f432849a:

    # "...anticipating the pain as you blankly watch the cat lick at the bloody palm of your severed hand."
    "...antecipando a dor enquanto observa, atônito, o gato lamber a palma ensanguentada da sua mão decepada."

# game/atHome.rpy:1928
translate pt_br keepPetting3_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/atHome.rpy:1929
translate pt_br keepPetting3_4a4e0688:

    # you "H-hah..! It... hurts..."
    you "H-hah..! Isso... dói..."

# game/atHome.rpy:1930
translate pt_br keepPetting3_3476012a:

    # "It really, {i}really{/i} hurts.."
    "Dói muito, {i}muito{/i} mesmo.."

# game/atHome.rpy:1931
translate pt_br keepPetting3_a268e071:

    # "Then... {w}the cat looks up at you and you... {w}feel compelled..."
    "Então... {w}o gato te olha e você... {w}se sente forçado..."

# game/atHome.rpy:1932
translate pt_br keepPetting3_a20cefa7_9:

    # "..."
    "..."

# game/atHome.rpy:1935
translate pt_br keepPetting3_c070fd95:

    # "{size=-8}...to keep {b}petting.{/b}{/size}"
    "{size=-8}...a continuar {b}acariciando.{/b}{/size}"

# game/atHome.rpy:1936
translate pt_br keepPetting3_6bbf2111:

    # "You’re reluctant... but you’re also afraid of what will happen if you don’t heed the call."
    "Você está relutante... mas também com medo do que acontecerá se não atender ao chamado."

# game/atHome.rpy:1937
translate pt_br keepPetting3_a3553d39:

    # "What will you lose {i}next{/i} if you try to resist again?"
    "O que você perderá da {i}próxima vez{/i} se tentar resistir novamente?"

# game/atHome.rpy:1938
translate pt_br keepPetting3_a20cefa7_10:

    # "..."
    "..."

# game/atHome.rpy:1939
translate pt_br keepPetting3_0b8e27c7:

    # "You were hurt for your insistent petting earlier..."
    "Você se machucou por insistir em acariciar antes..."

# game/atHome.rpy:1940
translate pt_br keepPetting3_2f39be7c:

    # "...yet now you’ve been hurt for trying to stop?"
    "...e agora foi ferido por tentar parar?"

# game/atHome.rpy:1941
translate pt_br keepPetting3_85303526:

    # "...It defies all logic, but that’s what scares you."
    "...Isso desafia toda a lógica, mas é isso que te assusta."

# game/atHome.rpy:1942
translate pt_br keepPetting3_9d61d6e2:

    # "There’s no reasoning with such fickle whims..."
    "Não há como argumentar com caprichos tão volúveis..."

# game/atHome.rpy:1946
translate pt_br keepPetting3_3feec0d7:

    # "You feebly try to raise your {b}{i}uninjured{/i}{/b} hand to pet the cat..."
    "Você tenta, hesitante, levantar sua mão {b}{i}não ferida{/i}{/b} para acariciar o gato..."

# game/atHome.rpy:1947
translate pt_br keepPetting3_e419ea53:

    # "...but it stiffens, golden eyes glinting dangerously."
    "...mas ele se enrijece, com os olhos dourados brilhando perigosamente."

# game/atHome.rpy:1948
translate pt_br keepPetting3_8dabefc6_4:

    # ".."
    ".."

# game/atHome.rpy:1949
translate pt_br keepPetting3_a20cefa7_11:

    # "..."
    "..."

# game/atHome.rpy:1950
translate pt_br keepPetting3_221cbb22:

    # "Well."
    "Bom..."

# game/atHome.rpy:1951
translate pt_br keepPetting3_a20cefa7_12:

    # "..."
    "..."

# game/atHome.rpy:1952
translate pt_br keepPetting3_7d2ae1e5:

    # "{size=-10}Alright then.{/size}"
    "{size=-10}Tá bom então.{/size}"

# game/atHome.rpy:1953
translate pt_br keepPetting3_fa304b76:

    # "You raise your bleeding stump and resume your petting to the best of your ability."
    "Você levanta seu braço sem mão ensanguentado e retoma o carinho da melhor maneira possível."

# game/atHome.rpy:1955
translate pt_br keepPetting3_57f9ada2:

    # cat "Purr... Purr... Purrr..."
    cat "Purr... Purr... Purr..."

# game/atHome.rpy:1956
translate pt_br keepPetting3_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:1957
translate pt_br keepPetting3_b9a42afa:

    # "You pet..."
    "Você faz carinho..."

# game/atHome.rpy:1965
translate pt_br keepPetting3_70d03ba5:

    # "...and you bleed."
    "...e sangra."

# game/atHome.rpy:1966
translate pt_br keepPetting3_b9a42afa_1:

    # "You pet..."
    "Você faz carinho..."

# game/atHome.rpy:1974
translate pt_br keepPetting3_70d03ba5_1:

    # "...and you bleed."
    "...e sangra."

# game/atHome.rpy:1975
translate pt_br keepPetting3_b9a42afa_2:

    # "You pet..."
    "Você faz carinho..."

# game/atHome.rpy:1983
translate pt_br keepPetting3_70d03ba5_2:

    # "...and you bleed."
    "...e sangra."

# game/atHome.rpy:1984
translate pt_br keepPetting3_15f14ac5:

    # "You pet and..."
    "Você faz carinho e..."

# game/atHome.rpy:1985
translate pt_br keepPetting3_a20cefa7_13:

    # "..."
    "..."

# game/atHome.rpy:1986
translate pt_br keepPetting3_73e94448:

    # "...you..."
    "...você..."

# game/atHome.rpy:1987
translate pt_br keepPetting3_dae0ec55_2:

    # you "..."
    you "..."

# game/atHome.rpy:1988
translate pt_br keepPetting3_a20cefa7_14:

    # "..."
    "..."

# game/atHome.rpy:1989
translate pt_br keepPetting3_31baff1c:

    # "Ending 7: Personal Boundaries"
    "Final 7: Limites Pessoais"

# game/atHome.rpy:2002
translate pt_br feedHome_87825912:

    # "The cat looks hungry so you decide to feed it."
    "O gato parece estar com fome, então você decide alimentá-lo."

# game/atHome.rpy:2003
translate pt_br feedHome_e8e76bb4:

    # "You’re regretting not stopping for food earlier as you don’t have much left. Grocery shopping day is tomorrow after all..."
    "Você se arrepende de não ter parado para comer antes, pois não tem muito em casa. Afinal, o dia de compras no supermercado é amanhã..."

# game/atHome.rpy:2006
translate pt_br feedHome_5c57afc5:

    # "You head to the kitchen and click your tongue, ensuring the cat follows after you."
    "Você vai até a cozinha e estala a língua, fazendo com que o gato te siga."

# game/atHome.rpy:2007
translate pt_br feedHome_393fa72b:

    # "It leaps nimbly onto the kitchen counter and watches as you search for meal options."
    "Ele salta agilmente para o balcão da cozinha e observa enquanto você procura opções de refeição."

# game/atHome.rpy:2008
translate pt_br feedHome_a873ea07:

    # you "Hmm, let's see..."
    you "Hmm, vejamos..."

# game/atHome.rpy:2009
translate pt_br feedHome_72d43a37:

    # "You find some things you expect:"
    "Você encontra algumas coisas que já esperava:"

# game/atHome.rpy:2012
translate pt_br feedHome_aa2b7420:

    # "A can of tuna in the pantry..."
    "Uma lata de atum na despensa..."

# game/atHome.rpy:2015
translate pt_br feedHome_8b7aae08:

    # "Some leftover meatloaf in the fridge..."
    "Um pouco de bolo de carne na geladeira..."

# game/atHome.rpy:2019
translate pt_br feedHome_cb64e404:

    # "And..."
    "E..."

# game/atHome.rpy:2020
translate pt_br feedHome_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:2021
translate pt_br feedHome_8e2c51bf:

    # you "Huh? What's {i}that{/i}..?"
    you "Hã? O que é {i}isso{/i}..?"

# game/atHome.rpy:2031
translate pt_br feedHome_af12342d:

    # "You realize there's a tightly sealed tupperware on the bottom shelf of the fridge."
    "Você percebe que há um tapuer bem fechado na prateleira de baixo da geladeira."

# game/atHome.rpy:2032
translate pt_br feedHome_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:2033
translate pt_br feedHome_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:2034
translate pt_br feedHome_24225f61:

    # "You {b}don't{/b} recognize it."
    "Você {b}não faz ideia{/b} do que seja."

# game/atHome.rpy:2035
translate pt_br feedHome_36681b88:

    # "A foul odor is leaking from the container..."
    "Um odor fétido está vazando do recipiente..."

# game/atHome.rpy:2036
translate pt_br feedHome_ea57ce22:

    # "Whatever's inside {i}can’t{/i} be safe for human consumption..."
    "O que quer que esteja dentro {i}não pode{/i} ser seguro para consumo humano..."

# game/atHome.rpy:2038
translate pt_br feedHome_022b9bff:

    # cat "Meow! Meoww!"
    cat "Miau! Miauu!"

# game/atHome.rpy:2039
translate pt_br feedHome_f909cf5f:

    # you "Uhh..."
    you "Ãhn..."

# game/atHome.rpy:2040
translate pt_br feedHome_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:2041
translate pt_br feedHome_1350b083:

    # "...but the {i}cat{/i} seems excited about it. Practically {i}salivating{/i} over it..."
    "...mas o {i}gato{/i} parece estar empolgado. Praticamente {i}salivando{/i} por causa disso..."

# game/atHome.rpy:2042
translate pt_br feedHome_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:2050
translate pt_br feedHome_24b8e350:

    # "Still, {i}you're{/i} the caretaker here."
    "Ainda assim, {i}você{/i} é o responsável aqui."

# game/atHome.rpy:2051
translate pt_br feedHome_2e4a58b3:

    # "{i}You're{/i} the one who needs to decide what's best to feed a hungry cat."
    "{i}Você{/i} é quem precisa decidir o que é melhor para alimentar um gato faminto."

# game/atHome.rpy:2052
translate pt_br feedHome_cf9ca97b:

    # "So you'll feed it..."
    "Então, você vai alimentá-lo com..."

# game/atHome.rpy:2067
translate pt_br feedHomeMenu_f4bfafde:

    # you "Eh, not too hungry right now..."
    you "Eh, não estou com muita fome agora..."

# game/atHome.rpy:2068
translate pt_br feedHomeMenu_8b418ade:

    # "You decide to hold off on food and do something else."
    "Você decide deixar a comida de lado e fazer outra coisa."

# game/atHome.rpy:2076
translate pt_br feedTuna_d786e656:

    # you "Cats like fish, right?"
    you "Gatos gostam de peixe, né?"

# game/atHome.rpy:2077
translate pt_br feedTuna_96364a0d:

    # "Shrugging, you take out the tuna for the cat and the meatloaf for yourself."
    "Você dá de ombros e tira o atum para o gato e o bolo de carne para você."

# game/atHome.rpy:2078
translate pt_br feedTuna_1712c85a:

    # "You put the frankly {i}ominous{/i} container back in the fridge."
    "Você coloca o recipiente francamente {i}sinistro{/i} de volta na geladeira."

# game/atHome.rpy:2079
translate pt_br feedTuna_1a9c9560:

    # "The cat looks a little disappointed."
    "O gato parece um pouco desapontado."

# game/atHome.rpy:2080
translate pt_br feedTuna_a1a28824:

    # "Tough."
    "Dureza."

# game/atHome.rpy:2081
translate pt_br feedTuna_ee9eb500:

    # "You'll need to dispose of that weird... {b}{i}whatever-it-is{/i}{/b} later."
    "Você vai precisar se desfazer daquela coisa estranha... {b}{i}seja lá o que for{/i}{/b} mais tarde."

# game/atHome.rpy:2082
translate pt_br feedTuna_e074c087:

    # "You open the tuna and spoon it onto a small saucer. You put the saucer on the kitchen counter next to the cat."
    "Você abre a lata de atum e coloca em um pratinho. Coloca o prato na bancada da cozinha ao lado do gato."

# game/atHome.rpy:2083
translate pt_br feedTuna_a1f2544f:

    # "You don't think you should be encouraging it to eat up there..."
    "Você não acha que deveria incentivá-lo a comer ali em cima..."

# game/atHome.rpy:2084
translate pt_br feedTuna_a98d3823:

    # "...but you figure it'll make up for electing not to feed it the toxic goop it wanted."
    "...mas você acha que isso compensará por não o ter alimentado com aquela gosma tóxica que ele queria."

# game/atHome.rpy:2086
translate pt_br feedTuna_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/atHome.rpy:2087
translate pt_br feedTuna_6769c6cb:

    # "The cat looks like it finds the tuna..."
    "O gato parece achar o atum..."

# game/atHome.rpy:2088
translate pt_br feedTuna_164d6921:

    # "...acceptable."
    "...aceitável."

# game/atHome.rpy:2089
translate pt_br feedTuna_6aad42ef:

    # "You'll take it."
    "Você acha que é o suficiente."

# game/atHome.rpy:2090
translate pt_br feedTuna_3b189997:

    # you "Eat up, kitty."
    you "Bom apetite, gatinho."

# game/atHome.rpy:2092
translate pt_br feedTuna_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/atHome.rpy:2093
translate pt_br feedTuna_38b50666:

    # "As the cat digs into its meal, you go about heating up the meatloaf in the microwave."
    "Enquanto o gato aproveita a sua refeição, você vai aquecendo o bolo de carne no micro-ondas."

# game/atHome.rpy:2094
translate pt_br feedTuna_c294db5c:

    # "While setting the time, you hear-"
    "Enquanto ajusta o tempo, você ouve-"

# game/atHome.rpy:2096
translate pt_br feedTuna_2699cbe6:

    # cat "{size=-7}*hiccup*...{/size}"
    cat "{size=-7}*soluço*...{/size}"

# game/atHome.rpy:2097
translate pt_br feedTuna_5d06f92b:

    # you "Hm?"
    you "Hm?"

# game/atHome.rpy:2098
translate pt_br feedTuna_70f82d13:

    # "You turn and see that the plate is completely empty."
    "Você se vira e vê que o prato está completamente vazio."

# game/atHome.rpy:2099
translate pt_br feedTuna_14924412:

    # you "Whoa, that was quick... You need to pace yourself-"
    you "Opa, isso foi rápido... Você precisa se controlar-"

# game/atHome.rpy:2101
translate pt_br feedTuna_5c31b794:

    # cat "*hiccup*..." with hpunch
    cat "*soluço*..." with hpunch

# game/atHome.rpy:2103
translate pt_br feedTuna_829d2012:

    # cat "*hiccup*... *hiccup*..." with hpunch
    cat "*soluço*... *soluço*..." with hpunch

# game/atHome.rpy:2105
translate pt_br feedTuna_75a36584:

    # cat "{size=+5}*HICCUP*{/size}" with hpunch
    cat "{size=+5}*SOLUÇO*{/size}" with hpunch

# game/atHome.rpy:2106
translate pt_br feedTuna_0e9b573c:

    # you "!?"
    you "!?"

# game/atHome.rpy:2107
translate pt_br feedTuna_b52ace45:

    # you "What the..?"
    you "Mas que..?"

# game/atHome.rpy:2110
translate pt_br feedTuna_8871fae2:

    # "You watch, baffled, as the cat continues to hiccup, causing..."
    "Você observa, perplexo, enquanto o gato continua soluçando, fazendo..."

# game/atHome.rpy:2111
translate pt_br feedTuna_56982b7d:

    # "...little bubbles to float out of its mouth..?"
    "...pequenas bolhas flutuarem da boca dele..?"

# game/atHome.rpy:2112
translate pt_br feedTuna_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:2113
translate pt_br feedTuna_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:2114
translate pt_br feedTuna_f0657274:

    # "Okay."
    "Beleza."

# game/atHome.rpy:2115
translate pt_br feedTuna_a4c0df6c:

    # "That's okay."
    "Tudo bem."

# game/atHome.rpy:2116
translate pt_br feedTuna_6dfd9fc3:

    # "You can... You can process this. It's not {i}completely{/i} out of the realm of what's possible, right?"
    "Você pode... Você pode processar isso. Não algo {i}completamente{/i} fora de cogitação, certo?"

# game/atHome.rpy:2117
translate pt_br feedTuna_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:2118
translate pt_br feedTuna_ff5f4bbc:

    # "Right."
    "Certo."

# game/atHome.rpy:2119
translate pt_br feedTuna_d1b6b37d:

    # "Best not to think too hard about it."
    "Melhor não pensar muito sobre isso."

# game/atHome.rpy:2124
translate pt_br feedTuna_3e1feb83:

    # "Soon enough, the room is full of the floating bubbles."
    "Em pouco tempo, o quarto está cheio de bolhas flutuando."

# game/atHome.rpy:2126
translate pt_br feedTuna_20d20ae4:

    # cat "h.. h... {size=-5}*hiccup*{/size}..."
    cat "s.. s... {size=-5}*soluço*{/size}..."

# game/atHome.rpy:2127
translate pt_br feedTuna_544efc67:

    # "The cat releases a final, tiny bubble before yawning and laying down right there on the counter."
    "O gato solta uma última bolhinha antes de bocejar e se deitar ali mesmo no balcão."

# game/atHome.rpy:2129
translate pt_br feedTuna_cc63b22e:

    # cat "Purr... Purr... Purr..."
    cat "Purr... Purr... Purr..."

# game/atHome.rpy:2130
translate pt_br feedTuna_13093fc6:

    # you "Well... Glad you enjoyed it..."
    you "Bem... Que bom que você gostou..."

# game/atHome.rpy:2131
translate pt_br feedTuna_2c4ee3ec:

    # "The bubbles haven't left the room or popped. They seem to be pretty resilient..."
    "As bolhas não saíram do quarto nem estouraram. Elas parecem ser bastante resistentes..."

# game/atHome.rpy:2132
translate pt_br feedTuna_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:2133
translate pt_br feedTuna_5a83a2b4:

    # "Wait... What..?"
    "Espera... O que..?"

# game/atHome.rpy:2134
translate pt_br feedTuna_112822b7:

    # you "What's that..?"
    you "O que é aquilo..?"

# game/atHome.rpy:2135
translate pt_br feedTuna_f0eb37c9:

    # "As one of the bubbles floats closer to you..."
    "À medida que uma das bolhas flutua mais perto de você..."

# game/atHome.rpy:2138
translate pt_br feedTuna_b6cf5b97:

    # "...you see that there's actually something inside it."
    "...você vê que, na verdade, há algo dentro dela."

# game/atHome.rpy:2139
translate pt_br feedTuna_7a06a1b0:

    # "A tiny... {i}furry{/i}..."
    "Um pequeno... e {i}peludo{/i}..."

# game/atHome.rpy:2140
translate pt_br feedTuna_40d9ca73_1:

    # "..?"
    "..?"

# game/atHome.rpy:2141
translate pt_br feedTuna_4208ab4d:

    # "...fish?"
    "...peixe?"

# game/atHome.rpy:2142
translate pt_br feedTuna_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:2143
translate pt_br feedTuna_a99e5490:

    # you "This is just getting weirder and weirder..."
    you "Isso tá ficando cada vez mais estranho..."

# game/atHome.rpy:2144
translate pt_br feedTuna_b3e12ea5:

    # "Still..."
    "Ainda assim..."

# game/atHome.rpy:2145
translate pt_br feedTuna_f2728bdd:

    # "You can't help but marvel at the impossible wonder in front of you..."
    "Você não consegue deixar de se maravilhar com o milagre impossível à sua frente..."

# game/atHome.rpy:2148
translate pt_br feedTuna_8d18fd6d:

    # "You lift a hand..."
    "Você levanta uma mão..."

# game/atHome.rpy:2149
translate pt_br feedTuna_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:2152
translate pt_br feedTuna_09b77d88:

    # "You extend a finger towards a bubble..."
    "Estende um dedo em direção a uma bolha..."

# game/atHome.rpy:2153
translate pt_br feedTuna_69d6aee8:

    # "...Carefully press it against the surface-"
    "...Pressiona cuidadosamente contra a superfície-"

# game/atHome.rpy:2164
translate pt_br feedTuna_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:2165
translate pt_br feedTuna_b9de8c3d:

    # "The little fish inside lashes out, viciously sinking tiny fangs into your finger."
    "O peixinho dentro ataca, ferozmente cravando dentes minúsculos em seu dedo."

# game/atHome.rpy:2166
translate pt_br feedTuna_ba997575:

    # "It doesn't really hurt that much at first but then..."
    "Inicialmente não dói tanto, mas então..."

# game/atHome.rpy:2172
translate pt_br feedTuna_2da11494:

    # you "AHH! O-Ow! What..?" with vpunch
    you "AHH! A-Ai! O que..?" with vpunch

# game/atHome.rpy:2173
translate pt_br feedTuna_c7a75804:

    # "Pain starts to climb from your finger to the rest of your hand..."
    "A dor começa a subir do seu dedo para o resto da mão..."

# game/atHome.rpy:2174
translate pt_br feedTuna_77c0c910:

    # "Past your wrist..."
    "Passando pelo pulso..."

# game/atHome.rpy:2175
translate pt_br feedTuna_06c8ab12:

    # "Could it be... some kind of {b}venom{/b}..?"
    "Poderia ser... algum tipo de {b}veneno{/b}..?"

# game/atHome.rpy:2176
translate pt_br feedTuna_32fa58b5:

    # "You fling your arm around in an attempt to dislodge the fish, but..."
    "Você balança o braço na tentativa de fazer o peixe soltar, mas..."

# game/atHome.rpy:2191
translate pt_br feedTuna_8ca8510a_1:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:2192
translate pt_br feedTuna_321fb0c5:

    # you "{size=+15}{b}{i}GAH!{/i}{/b}{/size}" with hpunch
    you "{size=+15}{b}{i}GAH!{/i}{/b}{/size}" with hpunch

# game/atHome.rpy:2193
translate pt_br feedTuna_af541737:

    # "...you accidentally knock your arm into several of the bubbles floating around."
    "...você acaba batendo o braço em várias das bolhas flutuando ao redor."

# game/atHome.rpy:2194
translate pt_br feedTuna_48cade3b:

    # "More tiny, ravenous fish latch onto your flesh..."
    "Mais peixinhos famintos se agarram à sua pele..."

# game/atHome.rpy:2200
translate pt_br feedTuna_d89404a4:

    # "You stumble back out of pain and a sudden bout of dizziness, only to bump into more bubbles..."
    "Você tropeça para trás devido à dor e a uma súbita tontura, te fazendo esbarrar em mais bolhas..."

# game/atHome.rpy:2201
translate pt_br feedTuna_6ae60f96:

    # "...more fish digging their teeth into your back."
    "...mais peixes cravam os dentes em suas costas."

# game/atHome.rpy:2203
translate pt_br feedTuna_4cf68681:

    # you "Ghh..! Uhnn..."
    you "Ghh..! Uhnn..."

# game/atHome.rpy:2204
translate pt_br feedTuna_62c0c671:

    # "It hurts..."
    "Dói..."

# game/atHome.rpy:2205
translate pt_br feedTuna_33314499:

    # "You're getting dizzy..."
    "Você está ficando tonto..."

# game/atHome.rpy:2206
translate pt_br feedTuna_4a51b22e:

    # "You've got to... get out..."
    "Você tem que... sair..."

# game/atHome.rpy:2207
translate pt_br feedTuna_246f5c25:

    # "You deliriously try to stumble out of the kitchen..."
    "Você tenta, delirante, cambalear para fora da cozinha..."

# game/atHome.rpy:2215
translate pt_br feedTuna_eec393f2:

    # "...but the entire room is {i}filled{/i} with the deadly bubbles."
    "...mas o quarto inteiro está {i}cheio{/i} de bolhas mortais."

# game/atHome.rpy:2216
translate pt_br feedTuna_aa72ff49:

    # "By the time you collapse to the ground, you're absolutely covered in tiny, angry, {b}biting{/b} fish..."
    "Quando você desaba no chão, está absolutamente coberto de peixinhos raivosos e {b}famintos{/b}..."

# game/atHome.rpy:2217
translate pt_br feedTuna_39a7b474:

    # "Your legs... {w}Your torso... {w}Your arms... {w}Your {i}face{/i}..."
    "Suas pernas... {w}Seu tronco... {w}Seus braços... {w}Seu {i}rosto{/i}..."

# game/atHome.rpy:2218
translate pt_br feedTuna_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:2219
translate pt_br feedTuna_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:2220
translate pt_br feedTuna_9b33ef77:

    # "...The pain is {b}unbearable.{/b}"
    "...A dor é {b}insuportável.{/b}"

# game/atHome.rpy:2221
translate pt_br feedTuna_74c927c6:

    # "You can feel it in your skin and your teeth and your eyes and your hair and..."
    "Você pode sentir isso em sua pele, nos seus dentes, nos seus olhos, no seu cabelo e..."

# game/atHome.rpy:2222
translate pt_br feedTuna_ee1fb69a:

    # "...and it's so {i}consuming{/i} you can't even feel yourself convulsing."
    "...e é tão {i}desgastante{/i} que você não consegue nem sentir seu corpo se contorcendo."

# game/atHome.rpy:2223
translate pt_br feedTuna_514dcaf6:

    # "...Or crying."
    "...Ou chorando."

# game/atHome.rpy:2224
translate pt_br feedTuna_01f15502:

    # "You don't black out."
    "Você não desmaia."

# game/atHome.rpy:2225
translate pt_br feedTuna_ca0edb73:

    # "Your eyes are still rolling up into your skull when you gasp out your last breath."
    "Seus olhos ainda estão se revirando quando você solta o seu último suspiro."

# game/atHome.rpy:2226
translate pt_br feedTuna_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:2227
translate pt_br feedTuna_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:2228
translate pt_br feedTuna_b311580a:

    # "Ending 8: Fish Out of Water"
    "Final 8: Peixe Fora D'Água"

# game/atHome.rpy:2242
translate pt_br feedMeatloaf_38761e59:

    # "You get the feeling the cat won't be too impressed with anything that comes out of a can."
    "Você sente de que o gato não vai ficar muito impressionado com qualquer coisa que saia de uma lata."

# game/atHome.rpy:2243
translate pt_br feedMeatloaf_b3808f59:

    # "And you're {i}not{/i} about to feed it whatever the heck that toxic-looking sludge is..."
    "E você com certeza {i}não{/i} vai alimentá-lo com aquela coisa tóxica que parece um lodo..."

# game/atHome.rpy:2244
translate pt_br feedMeatloaf_4217e4a0:

    # "So it's settled..."
    "Então está decidido..."

# game/atHome.rpy:2245
translate pt_br feedMeatloaf_6b525050:

    # "A tuna sandwich for you and leftover meatloaf for your feline guest."
    "Um sanduíche de atum para você e as sobras de bolo de carne para o seu convidado felino."

# game/atHome.rpy:2246
translate pt_br feedMeatloaf_47300799:

    # "You ignore the cat's disappointed meows as you put the weird container back in the fridge to dispose of later."
    "Você ignora os miados decepcionados do gato enquanto coloca o estranho recipiente de volta na geladeira, para descartá-lo depois."

# game/atHome.rpy:2247
translate pt_br feedMeatloaf_f17edea9:

    # "You warm up the meatloaf in the microwave."
    "Você esquenta o bolo de carne no micro-ondas."

# game/atHome.rpy:2248
translate pt_br feedMeatloaf_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:2249
translate pt_br feedMeatloaf_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:2251
translate pt_br feedMeatloaf_6a13ca1e:

    # "{size=+5}{i}BEEP! BEEP! BEEP! BEEP!{/i}{/size}" with hpunch
    "{size=+5}{i}BIP! BIP! BIP! BIP!{/i}{/size}" with hpunch

# game/atHome.rpy:2252
translate pt_br feedMeatloaf_187e6671:

    # "You place the now warm meatloaf on a saucer next to the cat on the counter."
    "Você coloca o bolo de carne agora quente em um pratinho ao lado do gato no balcão."

# game/atHome.rpy:2253
translate pt_br feedMeatloaf_a1f2544f:

    # "You don't think you should be encouraging it to eat up there..."
    "Você não acha que deveria incentivá-lo a comer ali em cima..."

# game/atHome.rpy:2254
translate pt_br feedMeatloaf_a98d3823:

    # "...but you figure it'll make up for electing not to feed it the toxic goop it wanted."
    "...mas você acha que isso compensará por não o ter alimentado com aquela gosma tóxica que ele queria."

# game/atHome.rpy:2256
translate pt_br feedMeatloaf_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/atHome.rpy:2257
translate pt_br feedMeatloaf_6f042a3e:

    # "The cat looks like it finds the meatloaf..."
    "O gato parece achar o bolo de carne..."

# game/atHome.rpy:2258
translate pt_br feedMeatloaf_c595ac61:

    # "...interesting."
    "...interessante."

# game/atHome.rpy:2259
translate pt_br feedMeatloaf_5291b869:

    # "Works for you."
    "Já serve."

# game/atHome.rpy:2260
translate pt_br feedMeatloaf_3b189997:

    # you "Eat up, kitty."
    you "Bom apetite, gatinho."

# game/atHome.rpy:2262
translate pt_br feedMeatloaf_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/atHome.rpy:2263
translate pt_br feedMeatloaf_e2cec0db:

    # "As the cat digs into its meal, you go about searching for some bread for your tuna sandwich."
    "Enquanto o gato devora sua refeição, você começa a procurar por um pão para seu sanduíche de atum."

# game/atHome.rpy:2264
translate pt_br feedMeatloaf_abbef2a5:

    # "You're so distracted by your search that you only just barely hear-"
    "Você está tão distraído na busca que mal ouve-"

# game/atHome.rpy:2266
translate pt_br feedMeatloaf_92aab58b:

    # "{size=-10}*splat*{/size}"
    "{size=-10}*splat*{/size}"

# game/atHome.rpy:2267
translate pt_br feedMeatloaf_5d06f92b:

    # you "Hm?"
    you "Hm?"

# game/atHome.rpy:2270
translate pt_br feedMeatloaf_c6afd330:

    # "You turn around and see that the meatloaf has only one, {i}maybe{/i} two bites taken out of it..."
    "Você se vira e vê que o bolo de carne tem marcas de apenas uma, {i}talvez{/i} duas mordidas..."

# game/atHome.rpy:2271
translate pt_br feedMeatloaf_e41d47bd:

    # "But more alarmingly..."
    "Mas, mais alarmante..."

# game/atHome.rpy:2272
translate pt_br feedMeatloaf_074c7320:

    # "There seems to be a red trail of..."
    "Parece ter um rastro vermelho de..."

# game/atHome.rpy:2273
translate pt_br feedMeatloaf_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:2274
translate pt_br feedMeatloaf_8dea9007:

    # "...{i}something{/i}"
    "...{i}algo{/i}"

# game/atHome.rpy:2275
translate pt_br feedMeatloaf_a38b893d:

    # "...leading away from where the cat had been sitting..."
    "...levando de onde o gato estava sentado..."

# game/atHome.rpy:2276
translate pt_br feedMeatloaf_c0b392d7:

    # "...and off the edge of the counter towards the living room."
    "...e caindo da borda do balcão em direção à sala de estar."

# game/atHome.rpy:2277
translate pt_br feedMeatloaf_bebfdc57:

    # you "{i}Is...{/i}"
    you "{i}Isso...{/i}"

# game/atHome.rpy:2278
translate pt_br feedMeatloaf_8de83a4b:

    # you "{i}{size=-5}Is that blood..?{/size}{/i}"
    you "{i}{size=-5}Isso é sangue..?{/size}{/i}"

# game/atHome.rpy:2282
translate pt_br feedMeatloaf_a406bb9a:

    # who "*gurgle*... *gurgle*... *grk*... Uhhnn..."
    who "*gurgle*... *gurgle*... *grk*... Uhhnn..."

# game/atHome.rpy:2283
translate pt_br feedMeatloaf_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/atHome.rpy:2284
translate pt_br feedMeatloaf_29b1ab2e:

    # "You jump at the strange sound coming from around the corner."
    "Você pula de sousto por causa do som estranho vindo de algum canto."

# game/atHome.rpy:2285
translate pt_br feedMeatloaf_d5fe7a57:

    # "Further into your apartment."
    "Mais ao fundo do seu apartamento."

# game/atHome.rpy:2286
translate pt_br feedMeatloaf_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:2287
translate pt_br feedMeatloaf_b94adebc:

    # "You... attempt to steel your nerves."
    "Você... tenta acalmar seus nervos."

# game/atHome.rpy:2290
translate pt_br feedMeatloaf_4ef1545a:

    # "Taking a breath, you walk around the counter to head into the living room-"
    "Respirando fundo, você contorna o balcão e caminha em direção à sala-"

# game/atHome.rpy:2294
translate pt_br feedMeatloaf_9a14f254:

    # "*Splat*..."
    "*Splat*..."

# game/atHome.rpy:2295
translate pt_br feedMeatloaf_90b68c87:

    # you "..?"
    you "..?"

# game/atHome.rpy:2296
translate pt_br feedMeatloaf_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:2297
translate pt_br feedMeatloaf_56add764:

    # "You stepped in something warm and wet..."
    "Você pisou em algo quente e úmido..."

# game/atHome.rpy:2298
translate pt_br feedMeatloaf_e7fb65f3:

    # "...and {color=#FF0000}red.{/color}"
    "...e {color=#FF0000}vermelho.{/color}"

# game/atHome.rpy:2299
translate pt_br feedMeatloaf_6aee484c:

    # "You resist the urge to vomit and step away from the trail of..."
    "Você resiste ao impulso de vomitar e tira o pé da trilha de..."

# game/atHome.rpy:2300
translate pt_br feedMeatloaf_aa46a15a:

    # "Of..."
    "De..."

# game/atHome.rpy:2301
translate pt_br feedMeatloaf_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:2302
translate pt_br feedMeatloaf_cb348c3a:

    # "You follow the trail into the living room and see that it leads into the hall."
    "Você segue a trilha até a sala de estar e vê que ela vai em direção ao corredor."

# game/atHome.rpy:2306
translate pt_br feedMeatloaf_2f827865:

    # who "{size=+5}*gurgle*... *grk*... *kurrgh*... Uhhhgh...{/size}"
    who "{size=+5}*gurgle*... *grk*... *kurrgh*... Uhhhgh...{/size}"

# game/atHome.rpy:2307
translate pt_br feedMeatloaf_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:2308
translate pt_br feedMeatloaf_98bfcf24:

    # "It's getting louder."
    "Está ficando mais alto."

# game/atHome.rpy:2309
translate pt_br feedMeatloaf_e71a3743:

    # "It's {i}definitely{/i} in the hall."
    "Está {i}definitivamente{/i} no corredor."

# game/atHome.rpy:2313
translate pt_br feedMeatloaf_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:2314
translate pt_br feedMeatloaf_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:2315
translate pt_br feedMeatloaf_1853155d:

    # "You feel like you can hear your heartbeat."
    "Você sente como se pudesse ouvir seu próprio coração batendo."

# game/atHome.rpy:2316
translate pt_br feedMeatloaf_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:2317
translate pt_br feedMeatloaf_de85b765:

    # "You hope whatever is in the hall {i}can't{/i}."
    "Você torce para que o que quer que esteja no corredor {i}não possa{/i}."

# game/atHome.rpy:2318
translate pt_br feedMeatloaf_e0863d49:

    # "Your body shakes as you feel yourself step forward."
    "Seu corpo treme enquanto você dá mais um passo à frente."

# game/atHome.rpy:2319
translate pt_br feedMeatloaf_a20cefa7_6:

    # "..."
    "..."

# game/atHome.rpy:2320
translate pt_br feedMeatloaf_28a75bbb:

    # "...And forward."
    "...E mais um."

# game/atHome.rpy:2321
translate pt_br feedMeatloaf_a20cefa7_7:

    # "..."
    "..."

# game/atHome.rpy:2322
translate pt_br feedMeatloaf_28a75bbb_1:

    # "...And forward."
    "...E mais um."

# game/atHome.rpy:2323
translate pt_br feedMeatloaf_a20cefa7_8:

    # "..."
    "..."

# game/atHome.rpy:2324
translate pt_br feedMeatloaf_8ffd6bf2:

    # "...And {i}{b}forward.{/b}{/i}"
    "...E {i}{b}mais um.{/b}{/i}"

# game/atHome.rpy:2325
translate pt_br feedMeatloaf_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:2326
translate pt_br feedMeatloaf_3b66688a:

    # "You peek..."
    "Você espia..."

# game/atHome.rpy:2327
translate pt_br feedMeatloaf_e4196020:

    # "around the corner..."
    "por trás do canto..."

# game/atHome.rpy:2328
translate pt_br feedMeatloaf_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:2329
translate pt_br feedMeatloaf_a20cefa7_9:

    # "..."
    "..."

# game/atHome.rpy:2330
translate pt_br feedMeatloaf_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:2334
translate pt_br feedMeatloaf_9850f53c:

    # "Nothing."
    "Nada."

# game/atHome.rpy:2335
translate pt_br feedMeatloaf_4367dae0:

    # "There's nothing there."
    "Não há nada lá."

# game/atHome.rpy:2336
translate pt_br feedMeatloaf_74be92cd:

    # you "What..?"
    you "O que..?"

# game/atHome.rpy:2337
translate pt_br feedMeatloaf_dc6f132f:

    # "You walk further into the hall and see that the trail leads all the way down the end of it."
    "Você avança mais pelo corredor e vê que a trilha se estende até o final dele."

# game/atHome.rpy:2338
translate pt_br feedMeatloaf_b35a0aab:

    # "But there's nothing there..."
    "Mas não há nada lá..."

# game/atHome.rpy:2339
translate pt_br feedMeatloaf_a20cefa7_10:

    # "..."
    "..."

# game/atHome.rpy:2340
translate pt_br feedMeatloaf_b02be747:

    # "You don't... quite feel relief. But at least-"
    "Você não... sente alívio, exatamente. Mas pelo menos-"

# game/atHome.rpy:2344
translate pt_br feedMeatloaf_d22643f9:

    # "{size=-10}*plop*{/size}"
    "{size=-10}*plop*{/size}"

# game/atHome.rpy:2345
translate pt_br feedMeatloaf_28b3ac41:

    # you "!!"
    you "!!"

# game/atHome.rpy:2346
translate pt_br feedMeatloaf_887daca8:

    # "You feel something wet and warm drip onto your cheek."
    "Você sente algo quente e molhado pingar na sua bochecha."

# game/atHome.rpy:2347
translate pt_br feedMeatloaf_e8998afe:

    # "Something... {i}very{/i} warm..."
    "Algo... {i}muito{/i} quente..."

# game/atHome.rpy:2348
translate pt_br feedMeatloaf_a56c59b7:

    # "You swipe your shaking hand across it and pull it back to see your fingers covered... in {color=#FF0000}something-{/color}"
    "Você passa a mão trêmula sobre isso e a tira para ver seus dedos cobertos... de {color=#FF0000}alguma coisa-{/color}"

# game/atHome.rpy:2353
translate pt_br feedMeatloaf_60bcdd54:

    # who "{size=+15}*gurgle*... *gurgle*...{/size}"
    who "{size=+15}*gurgle*... *gurgle*...{/size}"

# game/atHome.rpy:2360
translate pt_br feedMeatloaf_ded5babf:

    # who "{size=+25}MREooUuhgh!!{/size}" with hpunch
    who "{size=+25}MIAooUuhgh!!{/size}" with hpunch

# game/atHome.rpy:2363
translate pt_br feedMeatloaf_dae0ec55_2:

    # you "..."
    you "..."

# game/atHome.rpy:2364
translate pt_br feedMeatloaf_81bc8fbe:

    # "You look up."
    "Você olha para cima."

# game/atHome.rpy:2365
translate pt_br feedMeatloaf_415d7b3f:

    # "And see what can only be described as..."
    "E vê o que só pode ser descrito como..."

# game/atHome.rpy:2366
translate pt_br feedMeatloaf_bb123be3:

    # "...{b}meat{/b}."
    "...{b}carne{/b}."

# game/atHome.rpy:2371
translate pt_br feedMeatloaf_c009ecbe:

    # "The entire ceiling of the hallway is covered in a thick, undulating, writhing layer of pulsing {b}meat{/b}..."
    "O teto inteiro do corredor está coberto por uma camada espessa, ondulante,retorcida e pulsante de {b}carne{/b}..."

# game/atHome.rpy:2372
translate pt_br feedMeatloaf_eb3595a3:

    # "...at its center is a single glowing eyeball, frantically rolling around in every direction..."
    "...no meio, há um único olho brilhante, girando freneticamente em todas as direções..."

# game/atHome.rpy:2373
translate pt_br feedMeatloaf_8dabefc6_3:

    # ".."
    ".."

# game/atHome.rpy:2374
translate pt_br feedMeatloaf_a20cefa7_11:

    # "..."
    "..."

# game/atHome.rpy:2381
translate pt_br feedMeatloaf_f82e914d:

    # "...until it lands squarely on you."
    "...até seu olhar pousar diretamente em você."

# game/atHome.rpy:2382
translate pt_br feedMeatloaf_dc6af6ff:

    # you "{size=-8}Ah... ah..!{/size}"
    you "{size=-8}Ah... ah..!{/size}"

# game/atHome.rpy:2383
translate pt_br feedMeatloaf_ca526b52:

    # "You try to take a step back, desperate to escape the hallway..."
    "Você tenta dar um passo para trás, desesperado para fugir do corredor..."

# game/atHome.rpy:2384
translate pt_br feedMeatloaf_6d8938bf:

    # "To escape this {b}thing{/b}..."
    "Fugir dessa {b}coisa{/b}..."

# game/atHome.rpy:2385
translate pt_br feedMeatloaf_b3f43ac7:

    # "But-"
    "Mas-"

# game/atHome.rpy:2391
translate pt_br feedMeatloaf_56ebb028:

    # you "!!!"
    you "!!!"

# game/atHome.rpy:2392
translate pt_br feedMeatloaf_20d52c76:

    # "Before you can even scream, meaty tendrils shoot out and grab you."
    "Antes que você possa sequer gritar, tentáculos de carne disparam e te agarram."

# game/atHome.rpy:2393
translate pt_br feedMeatloaf_2982ba17:

    # you "{size=+15}NNNOOO!!{/size}" with hpunch
    you "{size=+15}NNNÃOO!!{/size}" with hpunch

# game/atHome.rpy:2394
translate pt_br feedMeatloaf_3137a039:

    # you "{size=+25}{i}LET ME GO!!{/i}{/size}" with hpunch
    you "{size=+25}{i}ME SOLTA!!{/i}{/size}" with hpunch

# game/atHome.rpy:2397
translate pt_br feedMeatloaf_f3b9e9bf:

    # "They pull you up."
    "Eles te levantam."

# game/atHome.rpy:2398
translate pt_br feedMeatloaf_435dd3ca:

    # "And up..."
    "E levantam..."

# game/atHome.rpy:2401
translate pt_br feedMeatloaf_25c927be:

    # "...into a pair of slowly opening jaws."
    "...até um par de mandíbulas que se abrem lentamente."

# game/atHome.rpy:2404
translate pt_br feedMeatloaf_b2782038:

    # "...And then-"
    "...E então-"

# game/atHome.rpy:2412
translate pt_br feedMeatloaf_82893c2b:

    # "{b}{size=+30}CHOMP!!{/size}{/b}" with vpunch
    "{b}{size=+30}CHOMP!!{/size}{/b}" with vpunch

# game/atHome.rpy:2413
translate pt_br feedMeatloaf_8dabefc6_4:

    # ".."
    ".."

# game/atHome.rpy:2414
translate pt_br feedMeatloaf_a20cefa7_12:

    # "..."
    "..."

# game/atHome.rpy:2415
translate pt_br feedMeatloaf_34c3a0cf:

    # "Ending 9: Leftovers"
    "Final 9: Sobras"

# game/atHome.rpy:2430
translate pt_br feedMysteryFood_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:2431
translate pt_br feedMysteryFood_e19f8a1e:

    # you "{i}Is this really a good idea?{/i}"
    you "{i}Será que isso uma boa ideia?{/i}"

# game/atHome.rpy:2433
translate pt_br feedMysteryFood_36cb4eaa:

    # cat "Meow! Meowww!" with hpunch
    cat "Miau! Miauuuu!" with hpunch

# game/atHome.rpy:2434
translate pt_br feedMysteryFood_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:2435
translate pt_br feedMysteryFood_c3369009:

    # you "Ugh... Fine, I guess if this is what you want..?"
    you "Uhg... Tá bom, se você faz questão..?"

# game/atHome.rpy:2436
translate pt_br feedMysteryFood_36a3d8dc:

    # "You open the container and..."
    "Você abre o recipiente e..."

# game/atHome.rpy:2445
translate pt_br feedMysteryFood_f5cdd629:

    # you "UGH! Hrk..!" with hpunch
    you "UGH! Hrk..!" with hpunch

# game/atHome.rpy:2446
translate pt_br feedMysteryFood_7b89e96c:

    # "You just barely manage to keep from throwing up."
    "Você quase não consegue evitar de vomitar."

# game/atHome.rpy:2447
translate pt_br feedMysteryFood_4f6fda05:

    # "But just {b}barely.{/b}"
    "Mas foi {b}por pouco.{/b}"

# game/atHome.rpy:2448
translate pt_br feedMysteryFood_bfa15d09:

    # "The stench is {b}{i}overwhelming.{/i}{/b}"
    "O fedor é {b}{i}insuportável.{/i}{/b}"

# game/atHome.rpy:2449
translate pt_br feedMysteryFood_df33334e:

    # you "*cough*! *gulp*..."
    you "*cof*! *gulp*..."

# game/atHome.rpy:2451
translate pt_br feedMysteryFood_ec1974d4:

    # cat "Meow!" with hpunch
    cat "Miau!" with hpunch

# game/atHome.rpy:2452
translate pt_br feedMysteryFood_d652c8bc:

    # you "Yeah, yeah... G-Give me a minute..."
    you "É, é... C-Calma aí um segundinho..."

# game/atHome.rpy:2453
translate pt_br feedMysteryFood_dae0ec55_2:

    # you "..."
    you "..."

# game/atHome.rpy:2454
translate pt_br feedMysteryFood_fd67a9c4:

    # "You hazard a look at the contents of the container but..."
    "Você arrisca olhar para o conteúdo do recipiente, mas..."

# game/atHome.rpy:2457
translate pt_br feedMysteryFood_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:2458
translate pt_br feedMysteryFood_7fb4ab6c:

    # "You honestly can't understand what you're supposed to be {i}looking{/i} at."
    "Você honestamente não consegue entender o que era para estar {i}vendo{/i}."

# game/atHome.rpy:2459
translate pt_br feedMysteryFood_0d3260cd:

    # "Everything is just... {w}{b}mashed{/b} together."
    "Está tudo apenas... {w}{b}amontoado{/b}."

# game/atHome.rpy:2460
translate pt_br feedMysteryFood_d0e4106b:

    # "What exactly \"everything\" consists of is a mystery you're {i}more{/i} than happy to keep unsolved."
    "O que exatamente compõe esse \"tudo\" é um mistério que você está {i}mais{/i} do que feliz em deixar sem solução."

# game/atHome.rpy:2463
translate pt_br feedMysteryFood_e5b4174b:

    # "Different shapes... {w}Different sizes... {w}Different {i}textures{/i}..."
    "Formas diferentes... {w}Tamanhos diferentes... {w}{i}Texturas{/i} diferentes..."

# game/atHome.rpy:2464
translate pt_br feedMysteryFood_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:2465
translate pt_br feedMysteryFood_1f632afd:

    # "Not the color though..."
    "Mas a cor não..."

# game/atHome.rpy:2466
translate pt_br feedMysteryFood_0499b762:

    # "{i}All{/i} of it is the same color..."
    "{i}Tudo{/i} tem a mesma cor..."

# game/atHome.rpy:2467
translate pt_br feedMysteryFood_e5aaee76:

    # "The most {b}unfortunate{/b} looking shade of gray you've ever seen..."
    "O tom de cinza mais {b}desgraçado{/b} que você já viu..."

# game/atHome.rpy:2468
translate pt_br feedMysteryFood_abfd3e68:

    # "...tinted with a nauseatingly {i}wet{/i} {b}green{/b} film over the top..."
    "...com uma nauseante camada {i}úmida{/i} e {b}verde{/b} por cima..."

# game/atHome.rpy:2471
translate pt_br feedMysteryFood_6251ddbe:

    # you "Hrk..."
    you "Hrk..."

# game/atHome.rpy:2472
translate pt_br feedMysteryFood_eebacd3d:

    # you "Am... Am I supposed to {i}warm{/i} it up or..?"
    you "Eu... Eu deveria {i}esquentar{/i} isso ou..?"

# game/atHome.rpy:2473
translate pt_br feedMysteryFood_6c91135f:

    # "You don't really know how to serve it."
    "Você realmente não sabe como servir."

# game/atHome.rpy:2474
translate pt_br feedMysteryFood_6dadf976:

    # "Any utensil or plate that touches it is getting thrown out {i}immediately.{/i}"
    "Qualquer talher ou prato que tocar nisso vai ser jogado fora {i}imediatamente.{/i}"

# game/atHome.rpy:2475
translate pt_br feedMysteryFood_a1ab8862:

    # "{b}No{/b} exceptions."
    "{b}Sem{/b} exceções."

# game/atHome.rpy:2476
translate pt_br feedMysteryFood_ce04a664:

    # "Your hands are going to be scrubbed with soap and hot water to within an inch of their lives after this..."
    "Suas mãos vão ser esfregadas com água e sabão até não aguentar mais depois disso..."

# game/atHome.rpy:2477
translate pt_br feedMysteryFood_1c5ca3cc:

    # "You decide against putting this crap in your microwave."
    "Você decide não colocar essa porcaria no micro-ondas."

# game/atHome.rpy:2478
translate pt_br feedMysteryFood_e60b4396:

    # "You doubt it would taste or smell any better warm."
    "Você duvida que iria cheirar ou ter um gosto melhor depois de esquentar."

# game/atHome.rpy:2479
translate pt_br feedMysteryFood_00b711bd:

    # "Not wanting to hold it anymore, you shake your head and practically toss the container next to the cat on the counter."
    "Não querendo mais segurar isso, você balança a cabeça e praticamente joga o recipiente ao lado do gato no balcão."

# game/atHome.rpy:2481
translate pt_br feedMysteryFood_4303c63e:

    # cat "{size=+5}MEOW!!{/size}" with hpunch
    cat "{size=+5}MIAU!!{/size}" with hpunch

# game/atHome.rpy:2482
translate pt_br feedMysteryFood_dd9d08f5:

    # "The cat enthusiastically dives for the toxic looking sludge, sniffing it as if savoring the scent."
    "O gato voa entusiasmado para a gosma aparentemente tóxica, cheirando-a como se estivesse saboreando o aroma."

# game/atHome.rpy:2483
translate pt_br feedMysteryFood_7692df1d:

    # "You turn to the fridge and close it."
    "Você se vira para a geladeira e a fecha."

# game/atHome.rpy:2484
translate pt_br feedMysteryFood_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:2485
translate pt_br feedMysteryFood_6895d8e7:

    # "You've lost your appetite."
    "Você perdeu o apetite."

# game/atHome.rpy:2486
translate pt_br feedMysteryFood_7f974e2b:

    # "You're about to head to the bathroom to wash your hands for the next hour or so when-"
    "Está prestes a ir ao banheiro lavar as mãos pelas próximas horas quando..."

# game/atHome.rpy:2490
translate pt_br feedMysteryFood_767bfdd5:

    # cat "*munch*!"
    cat "*munch*!"

# game/atHome.rpy:2492
translate pt_br feedMysteryFood_b82c7bcd:

    # "{size=-5}*crunch*!{/size}" with vpunch
    "{size=-5}*crunch*!{/size}" with vpunch

# game/atHome.rpy:2499
translate pt_br feedMysteryFood_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:2500
translate pt_br feedMysteryFood_9b89e7c0:

    # you "OW!!" with hpunch
    you "AI!!" with hpunch

# game/atHome.rpy:2501
translate pt_br feedMysteryFood_529cb8ee:

    # "A sharp pain on your foot causes you to stumble."
    "Uma dor aguda no pé faz você tropeçar."

# game/atHome.rpy:2502
translate pt_br feedMysteryFood_d7056fb1:

    # "You catch yourself on the kitchen sink and look down to see that the tip of your sock is..."
    "Você se apoia na pia da cozinha e olha para baixo, vendo que a ponta da sua meia está..."

# game/atHome.rpy:2505
translate pt_br feedMysteryFood_2d02d511:

    # "{color=#FF0000}...red.{/color}"
    "{color=#FF0000}...vermelha.{/color}"

# game/atHome.rpy:2506
translate pt_br feedMysteryFood_645b7424:

    # "..?!"
    "..?!"

# game/atHome.rpy:2507
translate pt_br feedMysteryFood_5b076aa4:

    # "And the red is still slowly spreading to the rest of your sock."
    "E o vermelho está lentamente se espalhando para o resto da sua meia."

# game/atHome.rpy:2508
translate pt_br feedMysteryFood_54172303:

    # "Are you {b}{i}bleeding?{/i}{/b}"
    "Você está {b}{i}sangrando?{/i}{/b}"

# game/atHome.rpy:2509
translate pt_br feedMysteryFood_eaef5df7:

    # "You quickly reach down and pull off your sock to see the damage."
    "Você rapidamente se inclina e tira a meia para ver o estrago."

# game/atHome.rpy:2510
translate pt_br feedMysteryFood_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:2511
translate pt_br feedMysteryFood_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/atHome.rpy:2516
translate pt_br feedMysteryFood_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:2517
translate pt_br feedMysteryFood_40b6614a:

    # "Your middle toe is..."
    "Seu dedo do meio..."

# game/atHome.rpy:2518
translate pt_br feedMysteryFood_9342fc41:

    # "...{b}gone.{/b}"
    "...{b}sumiu.{/b}"

# game/atHome.rpy:2519
translate pt_br feedMysteryFood_9117d01a:

    # "It's just {i}gone{/i}... {w}Just a stump is left in its place... {w}steadily leaking blood onto the floor."
    "Simplesmente {i}sumiu{/i}... {w}Há apenas um toco no lugar... {w}vazando sangue no chão."

# game/atHome.rpy:2522
translate pt_br feedMysteryFood_6558b781:

    # you "Ah... Ah..."
    you "Ah... Ah..."

# game/atHome.rpy:2523
translate pt_br feedMysteryFood_f42c7e0f:

    # "You clumsily step back as if it would help you get away from what you were seeing. The blood trail simply follows your movements."
    "Você recua desajeitado, como se pudesse se afastar do que estava vendo. A trilha de sangue simplesmente acompanha seus movimentos."

# game/atHome.rpy:2524
translate pt_br feedMysteryFood_b3c55428:

    # "9-1-1..."
    "1-9-0..."

# game/atHome.rpy:2525
translate pt_br feedMysteryFood_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:2526
translate pt_br feedMysteryFood_5355e62d:

    # "You have to... call 9-1-1..."
    "Você precisa... ligar para o 1-9-0..."

# game/atHome.rpy:2527
translate pt_br feedMysteryFood_a378dc9c:

    # you "P-Phone... Where's the-"
    you "C-Celular... Cadê o-"

# game/atHome.rpy:2535
translate pt_br feedMysteryFood_33af87d5:

    # you "{b}!!!{/b}" with vpunch
    you "{b}!!!{/b}" with vpunch

# game/atHome.rpy:2536
translate pt_br feedMysteryFood_40d95a03:

    # you "*COUGH!* *COUGH!* {b}*COUGH!*{/b}" with vpunch
    you "*COF!* *COF!* {b}*COF!*{/b}" with vpunch

# game/atHome.rpy:2537
translate pt_br feedMysteryFood_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:2538
translate pt_br feedMysteryFood_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:2539
translate pt_br feedMysteryFood_cb722153:

    # you "*gurgle* W... Wahs..."
    you "*gurgle* O... Ouê..."

# game/atHome.rpy:2540
translate pt_br feedMysteryFood_78617435:

    # "Your..."
    "A sua..."

# game/atHome.rpy:2541
translate pt_br feedMysteryFood_6e8b8ede:

    # "Your {i}tongue{/i} is...!"
    "A sua {i}língua{/i}...!"

# game/atHome.rpy:2542
translate pt_br feedMysteryFood_067d0202:

    # you "Wahs... {w}ahbehh...nnn?!"
    you "Ouê... {w}aoonn...nnn?!"

# game/atHome.rpy:2543
translate pt_br feedMysteryFood_dea300f2:

    # you "{i}What's happening to me..?!{/i}"
    you "{i}O que tá acontecendo comigo..?!{/i}"

# game/atHome.rpy:2545
translate pt_br feedMysteryFood_2f81467a:

    # cat "*munch*... *munch*... *munch*..."
    cat "*munch*... *munch*... *munch*..."

# game/atHome.rpy:2546
translate pt_br feedMysteryFood_a20cefa7_6:

    # "..."
    "..."

# game/atHome.rpy:2549
translate pt_br feedMysteryFood_db9cba4a:

    # "You slowly look over to find the cat still eating."
    "Você lentamente olha para o lado e vê o gato ainda comendo."

# game/atHome.rpy:2550
translate pt_br feedMysteryFood_f044b2af:

    # "Completely unbothered by your suffering."
    "Completamente indiferente ao seu sofrimento."

# game/atHome.rpy:2551
translate pt_br feedMysteryFood_2f81467a_1:

    # cat "*munch*... *munch*... *munch*..."
    cat "*munch*... *munch*... *munch*..."

# game/atHome.rpy:2552
translate pt_br feedMysteryFood_a0ae4816:

    # "Not bothering to try and stop the blood from dribbling out of your mouth..."
    "Sem sequer tentar impedir o sangue de escorrer de sua boca..."

# game/atHome.rpy:2553
translate pt_br feedMysteryFood_3b0a657b:

    # "...you keep watching in a daze as the cat happily chews at a gross piece of..."
    "...você continua observando, atordoado, enquanto o gato mastiga feliz um pedaço asqueroso de..."

# game/atHome.rpy:2554
translate pt_br feedMysteryFood_40d9ca73_1:

    # "..?"
    "..?"

# game/atHome.rpy:2555
translate pt_br feedMysteryFood_e81efaa7:

    # "Wait..."
    "Espera..."

# game/atHome.rpy:2556
translate pt_br feedMysteryFood_dde83c31:

    # "That's..."
    "Isso é..."

# game/atHome.rpy:2557
translate pt_br feedMysteryFood_90087fb1:

    # "You look more closely at the mystery food in the cat's jaws."
    "Você olha mais de perto para a comida misteriosa na boca do gato."

# game/atHome.rpy:2558
translate pt_br feedMysteryFood_433e4a84:

    # "It looks vaguely familiar..."
    "Parece vagamente familiar..."

# game/atHome.rpy:2559
translate pt_br feedMysteryFood_ed0337aa:

    # "It... {w}looks... {w}like..."
    "Está... {w}parecendo... {w}uma..."

# game/atHome.rpy:2560
translate pt_br feedMysteryFood_55d4f761:

    # "{size=-10}...a tongue?{/size}"
    "{size=-10}...língua?{/size}"

# game/atHome.rpy:2561
translate pt_br feedMysteryFood_ed5ea61e:

    # you "Ah..."
    you "Ah..."

# game/atHome.rpy:2562
translate pt_br feedMysteryFood_4f325bce:

    # cat "*munch*... *gulp*..."
    cat "*munch*... *gulp*..."

# game/atHome.rpy:2564
translate pt_br feedMysteryFood_0e994b53:

    # cat "Meowww!" with hpunch
    cat "Miauuu!" with hpunch

# game/atHome.rpy:2565
translate pt_br feedMysteryFood_0ffcdb7b:

    # "Before you can even think to do anything to stop it, the cat dives into the container again..."
    "Antes que você consiga pensar em fazer algo para parar o gato, ele novamente enfia a cara no recipiente..."

# game/atHome.rpy:2566
translate pt_br feedMysteryFood_1ccdd916:

    # "...and bites into a piece that looks kind of like a--{w=1.5}{nw}"
    "...e morde um pedaço que parece ser um--{w=1.5}{nw}"

# game/atHome.rpy:2575
translate pt_br feedMysteryFood_60602550:

    # you "{size=+10}AAHHH!!{/size}" with vpunch
    you "{size=+10}AAHHH!!{/size}" with vpunch

# game/atHome.rpy:2576
translate pt_br feedMysteryFood_b2b51942:

    # you "GHH..!!" with vpunch
    you "GHH..!!" with vpunch

# game/atHome.rpy:2577
translate pt_br feedMysteryFood_d6477e05:

    # "You collapse to the floor, clutching your torso."
    "Você desaba no chão, com a mão no peito."

# game/atHome.rpy:2578
translate pt_br feedMysteryFood_4ba5d8f7:

    # "You writhe around on the blood-streaked tiles, crying..."
    "Você se contorce no piso manchado de sangue, chorando..."

# game/atHome.rpy:2579
translate pt_br feedMysteryFood_f422db3b:

    # "Something... {w}Something {i}inside{/i} you just..."
    "Algo... {w}Algo {i}dentro{/i} de você..."

# game/atHome.rpy:2585
translate pt_br feedMysteryFood_d69064ca:

    # you "Blurgh!!" with vpunch
    you "Blurgh!!" with vpunch

# game/atHome.rpy:2586
translate pt_br feedMysteryFood_668a5876:

    # "Blood pours out from deep within you..."
    "Sangue jorra de dentro de você..."

# game/atHome.rpy:2587
translate pt_br feedMysteryFood_2c70abae:

    # "Whatever that was... {w}felt important..."
    "O que quer que tenha sido... {w}parecia importante..."

# game/atHome.rpy:2588
translate pt_br feedMysteryFood_a20cefa7_7:

    # "..."
    "..."

# game/atHome.rpy:2589
translate pt_br feedMysteryFood_0b43b634:

    # "...and now it's probably gone too."
    "...e agora provavelmente também sumiu."

# game/atHome.rpy:2590
translate pt_br feedMysteryFood_a20cefa7_8:

    # "..."
    "..."

# game/atHome.rpy:2591
translate pt_br feedMysteryFood_62c0c671:

    # "It hurts..."
    "Dói..."

# game/atHome.rpy:2594
translate pt_br feedMysteryFood_30734567:

    # "It hurts so {i}much...{/i}"
    "Dói {i}tanto...{/i}"

# game/atHome.rpy:2595
translate pt_br feedMysteryFood_5aa5bc57:

    # you "S... Staaub... Puh... eese..."
    you "P... PaA... Pu... aavor..."

# game/atHome.rpy:2596
translate pt_br feedMysteryFood_211a3f4c:

    # "You weakly try to reach up to the cat on the counter above you..."
    "Você tenta, sem forças, alcançar o gato no balcão acima de você..."

# game/atHome.rpy:2597
translate pt_br feedMysteryFood_84b8f508:

    # "Your vision blurs. From the effort... From the pain... From your tears... From-"
    "Sua visão começa a embaçar. Pelo esforço... Pela dor... Pelas lágrimas... Pelo-"

# game/atHome.rpy:2607
translate pt_br feedMysteryFood_822363a9:

    # you "UUHHgh!!" with vpunch
    you "UUHHgh!!" with vpunch

# game/atHome.rpy:2608
translate pt_br feedMysteryFood_a20cefa7_9:

    # "..."
    "..."

# game/atHome.rpy:2609
translate pt_br feedMysteryFood_cc9a5909:

    # "!!!"
    "!!!"

# game/atHome.rpy:2610
translate pt_br feedMysteryFood_0858d46d:

    # you "Uhhnn..."
    you "Uhhnn..."

# game/atHome.rpy:2611
translate pt_br feedMysteryFood_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:2612
translate pt_br feedMysteryFood_a20cefa7_10:

    # "..."
    "..."

# game/atHome.rpy:2613
translate pt_br feedMysteryFood_75d1a549:

    # "Your eyes..."
    "Seus olhos..."

# game/atHome.rpy:2614
translate pt_br feedMysteryFood_15ada053:

    # "Your {b}{i}eyes{/i}{/b}..!"
    "Seus {b}{i}olhos{/i}{/b}..!"

# game/atHome.rpy:2615
translate pt_br feedMysteryFood_a20cefa7_11:

    # "..."
    "..."

# game/atHome.rpy:2616
translate pt_br feedMysteryFood_bd9ff9f5:

    # "You fall limply back to the floor."
    "Você, fraco, cai no chão."

# game/atHome.rpy:2617
translate pt_br feedMysteryFood_ac841cd1:

    # "You're leaking blood all over... {w}{i}from{/i} all over..."
    "Você está sangrando por todo o lugar... {w}{i}de{/i} todo lugar..."

# game/atHome.rpy:2618
translate pt_br feedMysteryFood_e55d866a:

    # "Your foot... Your mouth... Your insides... Your eyesockets..."
    "Seu pé... Sua boca... Suas entranhas... Onde ficavam seus olhos..."

# game/atHome.rpy:2619
translate pt_br feedMysteryFood_a20cefa7_12:

    # "..."
    "..."

# game/atHome.rpy:2620
translate pt_br feedMysteryFood_8ecf8642:

    # "You can feel your {i}life{/i} fading away too..."
    "Você tembém pode sentir sua {i}vida{/i} esvaindo..."

# game/atHome.rpy:2621
translate pt_br feedMysteryFood_a20cefa7_13:

    # "..."
    "..."

# game/atHome.rpy:2622
translate pt_br feedMysteryFood_caccfbd8:

    # "That's fine..."
    "Tá tudo bem..."

# game/atHome.rpy:2623
translate pt_br feedMysteryFood_e46ce5d0:

    # "If it means not feeling the pain of losing another part of you, then..."
    "Se isso significa não sentir a dor de perder mais uma parte de você, então..."

# game/atHome.rpy:2624
translate pt_br feedMysteryFood_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:2625
translate pt_br feedMysteryFood_a20cefa7_14:

    # "..."
    "..."

# game/atHome.rpy:2626
translate pt_br feedMysteryFood_69d0c3bc:

    # "Hopefully the cat will take its time eating your eyeballs..."
    "Tomara que o gato esteja ocupado comendo seus olhos..."

# game/atHome.rpy:2627
translate pt_br feedMysteryFood_1a12115a:

    # "...and give {i}you{/i} time... {w}{alpha=0.5}to just...{/alpha} {w}{alpha=0.3}just...{/alpha}"
    "...e {i}te{/i} dê tempo... {w}{alpha=0.5}para...{/alpha} {w}{alpha=0.3}para...{/alpha}"

# game/atHome.rpy:2628
translate pt_br feedMysteryFood_dae0ec55_3:

    # you "..."
    you "..."

# game/atHome.rpy:2629
translate pt_br feedMysteryFood_8dabefc6_3:

    # ".."
    ".."

# game/atHome.rpy:2630
translate pt_br feedMysteryFood_a20cefa7_15:

    # "..."
    "..."

# game/atHome.rpy:2631
translate pt_br feedMysteryFood_71436a3d:

    # "Ending 10: \"You are what you eat...\""
    "Final 10: \"Você é o que você come...\""

# game/atHome.rpy:2644
translate pt_br playHome_8b57cab4:

    # cat "Meowww?"
    cat "Miauuu?"

# game/atHome.rpy:2645
translate pt_br playHome_e1260fe5:

    # "Poor thing was probably bored stiff sitting in that old box all day..."
    "O coitadinho devia estar entediado de ficar só sentado naquela caixa velha o dia todo..."

# game/atHome.rpy:2646
translate pt_br playHome_aa8c252a:

    # "Just watching crowds of people walking by them..."
    "Só assistindo a multidão passar por ele..."

# game/atHome.rpy:2647
translate pt_br playHome_84679d02:

    # "{i}Ignoring{/i} them..."
    "{i}Ignorando-o{/i}..."

# game/atHome.rpy:2648
translate pt_br playHome_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:2649
translate pt_br playHome_d87c1b74:

    # "You can't just leave them alone as soon you're home!"
    "Já que está em casa, você não pode deixá-lo sozinho!"

# game/atHome.rpy:2650
translate pt_br playHome_af11a585:

    # "A little interspecies socializing won't kill you, right?"
    "Um pouco de socialização com outras espécies não vai te matar, certo?"

# game/atHome.rpy:2652
translate pt_br playHome_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/atHome.rpy:2653
translate pt_br playHome_3b415eb0:

    # you "Aww... You just want some attention, don't you? You wanna play, huh?"
    you "Awn... Você só quer um pouco de atenção, não é? Quer brincar?"

# game/atHome.rpy:2655
translate pt_br playHome_ec1974d4:

    # cat "Meow!" with hpunch
    cat "Miau!" with hpunch

# game/atHome.rpy:2656
translate pt_br playHome_cbd9fef6:

    # you "Hehe, okay then!"
    you "Hehe, beleza então!"

# game/atHome.rpy:2657
translate pt_br playHome_30cd7cf3:

    # "What to play though?"
    "Mas, brincar de quê?"

# game/atHome.rpy:2675
translate pt_br playYarn_dd1cf4bc:

    # "If every movie and cartoon involving cats that you've watched since childhood is to be believed..."
    "Se todos os filmes e desenhos com gatos que você assistiu desde a infância estiverem certos..."

# game/atHome.rpy:2676
translate pt_br playYarn_e8f945eb:

    # "...then you can deduce with almost {i}absolute{/i} certainty..."
    "...então você pode deduzir com quase {i}absoluta{/i} certeza..."

# game/atHome.rpy:2677
translate pt_br playYarn_cf283aac:

    # "...that cats freaking {b}love{/b} yarn."
    "...que os gatos realmente {b}amam{/b} lã."

# game/atHome.rpy:2678
translate pt_br playYarn_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:2679
translate pt_br playYarn_83c46a64:

    # "...Probably."
    "...Provavelmente."

# game/atHome.rpy:2691
translate pt_br playYarn_f53e5eed:

    # "You unearth some from an old box in the hallway closet that's filled with knick-knacks from various abandoned hobbies."
    "Você desenterra algumas de uma caixa velha no armário do corredor, cheia de quinquilharias de vários hobbies abandonados."

# game/atHome.rpy:2692
translate pt_br playYarn_9882b599:

    # "You consider just handing the ball of bright red yarn over to the cat and supervising from the side..."
    "Você considera simplesmente entregar a bola de lã vermelha brilhante para o gato e supervisionar de longe..."

# game/atHome.rpy:2693
translate pt_br playYarn_447f557d:

    # "...but that would defeat the idea of playing {i}together{/i}, wouldn't it?"
    "...mas isso acabaria com a ideia de brincar {i}juntos{/i}, não é?"

# game/atHome.rpy:2694
translate pt_br playYarn_0c8da5b7:

    # "You cut off a decent length of string from the ball of yarn and go back to the living room."
    "Você corta um bom pedaço de linha da bola de lã e volta para a sala de estar."

# game/atHome.rpy:2700
translate pt_br playYarn_143b5340:

    # "The cat is resting on the floor."
    "O gato está descansando no chão."

# game/atHome.rpy:2701
translate pt_br playYarn_b46f2b82:

    # "It's not asleep, but when it looks up as you enter the living room, you feel like it could doze off right then and there."
    "Ele não está dormindo, mas quando ele olha para cima, vendo você entrar na sala, você sente que ele poderia cochilar ali mesmo."

# game/atHome.rpy:2702
translate pt_br playYarn_e2043592:

    # "You'll fix that~"
    "Você vai dar um jeito nisso~"

# game/atHome.rpy:2703
translate pt_br playYarn_1f142b99:

    # "You smirk a little, confident with your surprise..."
    "Você dá uma risadinha, confiante com sua surpresa..."

# game/atHome.rpy:2709
translate pt_br playYarn_5a92a679:

    # "...and let the piece of yarn dangle just above the floor, pinched between your thumb and index finger."
    "...e deixa o pedaço de lã pendurado logo acima do chão, preso entre o polegar e o indicador."

# game/atHome.rpy:2716
translate pt_br playYarn_7f0ac95c:

    # cat "..."
    cat "..."

# game/atHome.rpy:2717
translate pt_br playYarn_e4612ec1:

    # you "..!"
    you "..!"

# game/atHome.rpy:2718
translate pt_br playYarn_7f0ac95c_1:

    # cat "..."
    cat "..."

# game/atHome.rpy:2721
translate pt_br playYarn_082fc8f9:

    # "The sudden shift in the cat's demeanor makes your heart start to beat a little faster."
    "A mudança repentina no comportamento do gato faz seu coração começar a bater um pouco mais rápido."

# game/atHome.rpy:2722
translate pt_br playYarn_47f12df9:

    # "Its posture has barely changed at all."
    "A postura dele mal mudou."

# game/atHome.rpy:2723
translate pt_br playYarn_693f240f:

    # "Just a subtle shift of the head and ears..."
    "Apenas uma inclinação sutil da cabeça e das orelhas..."

# game/atHome.rpy:2724
translate pt_br playYarn_c99bf353:

    # "A slight tension in the shoulders..."
    "Uma leve tensão nos ombros..."

# game/atHome.rpy:2725
translate pt_br playYarn_e3dd092d:

    # "A sharpness in the gaze as it locks onto the yarn dangling an inch above the floor."
    "Um olhar cortante ao focar na lã pendurada a um centímetro do chão."

# game/atHome.rpy:2726
translate pt_br playYarn_bc8cebd1:

    # "The cat could still pass as being almost... relaxed."
    "O gato ainda poderia se passar por quase... relaxado."

# game/atHome.rpy:2727
translate pt_br playYarn_c57d0fe0:

    # "Calm."
    "Calmo."

# game/atHome.rpy:2731
translate pt_br playYarn_09c01095:

    # "And yet the air is thick with its eagerness to lunge forward..."
    "E ainda assim, o ar está denso com sua ânsia de se lançar à frente..."

# game/atHome.rpy:2734
translate pt_br playYarn_9d4bad95:

    # "...waiting for the right moment to strike."
    "...esperando o momento certo para atacar."

# game/atHome.rpy:2735
translate pt_br playYarn_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:2736
translate pt_br playYarn_ea936df6:

    # "You feel like you've just witnessed the awakening of the perfect predator."
    "Você sente que acabou de testemunhar o despertar do predador perfeito."

# game/atHome.rpy:2737
translate pt_br playYarn_c0a501b2:

    # "You're... almost afraid of what will happen once you make the first move..."
    "Você... quase teme o que vai acontecer assim que fizer o primeiro movimento..."

# game/atHome.rpy:2738
translate pt_br playYarn_7f0ac95c_2:

    # cat "..."
    cat "..."

# game/atHome.rpy:2739
translate pt_br playYarn_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:2740
translate pt_br playYarn_a046cf90:

    # "...But it {i}will{/i} be {i}you{/i} who makes the first move."
    "...Mas {i}será{/i} só {i}você{/i} quem fará o primeiro movimento."

# game/atHome.rpy:2743
translate pt_br playYarn_75c8055f:

    # "You take a deep breath..."
    "Você respira fundo..."

# game/atHome.rpy:2744
translate pt_br playYarn_7f0ac95c_3:

    # cat "..."
    cat "..."

# game/atHome.rpy:2745
translate pt_br playYarn_6b7d4985:

    # "Relax your shoulders..."
    "Relaxa os ombros..."

# game/atHome.rpy:2746
translate pt_br playYarn_7f0ac95c_4:

    # cat "..."
    cat "..."

# game/atHome.rpy:2747
translate pt_br playYarn_cb64e404:

    # "And..."
    "E..."

# game/atHome.rpy:2748
translate pt_br playYarn_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:2770
translate pt_br playYarn_eaa3eb7d:

    # cat "{b}MEOW!!{/b}" with hpunch
    cat "{b}MIAU!!{/b}" with hpunch

# game/atHome.rpy:2771
translate pt_br playYarn_80bfc06c:

    # you "Yoink~!"
    you "Vapt~!"

# game/atHome.rpy:2773
translate pt_br playYarn_ece07a96:

    # "The cat had lunged the instant you wiggled the yarn."
    "O gato saltou assim que você balançou a lã."

# game/atHome.rpy:2774
translate pt_br playYarn_1ec8f382:

    # "But you're faster."
    "Mas você é mais rápido."

# game/atHome.rpy:2775
translate pt_br playYarn_f1e3bd8f:

    # "It completely misses as you flick your wrist, making the yarn recoil out of its reach like a terrified snake."
    "Ele erra completamente ao você girar o pulso, fazendo a lã sair do seu alcance como uma cobra assustada."

# game/atHome.rpy:2776
translate pt_br playYarn_0a015919:

    # "Having overshot the landing in its eagerness, the cat stumbles and looks around as if shocked at its failed attack."
    "Tendo exagerado ao pousar por causa da sua ânsia, o gato tropeça e olha em volta como se estivesse chocado com seu ataque fracassado."

# game/atHome.rpy:2777
translate pt_br playYarn_6c8a9bcc:

    # "You generously click your tongue to help reorient it. The cat whips its head around at the sound."
    "Você generosamente estala a língua para ajudá-lo a se reorientar. O gato vira a cabeça ao ouvir o som."

# game/atHome.rpy:2778
translate pt_br playYarn_9111e7f0:

    # "You're slightly taken aback at the intensity of its stare on the yarn."
    "Você fica um pouco surpreso com a intensidade do seu olhar na lã."

# game/atHome.rpy:2779
translate pt_br playYarn_dc3f454b:

    # "But you persist."
    "Mas você persiste."

# game/atHome.rpy:2780
translate pt_br playYarn_0d970e5b:

    # "You wiggle the yarn again, encouragingly... {w}and yes, maybe a {i}little{/i} tauntingly."
    "Você mexe na lã novamente, o encorajando... {w}e sim, talvez provocando {i}um pouco{/i}."

# game/atHome.rpy:2781
translate pt_br playYarn_28d461a7:

    # "This time, the cat anticipates the yarn's upward dodge and leaps up to swipe at it..."
    "Desta vez, o gato antecipa o movimento de subida da lã e salta para alcançá-la..."

# game/atHome.rpy:2782
translate pt_br playYarn_1e32b6e1:

    # "But you're already one step ahead, puppeting the yarn to dance gracefully out of reach once more."
    "Mas você já está um passo à frente, manipulando a lã para dançar graciosamente fora de alcance mais uma vez."

# game/atHome.rpy:2784
translate pt_br playYarn_ceceaf01:

    # cat "Mreow!" with hpunch
    cat "Miau!" with hpunch

# game/atHome.rpy:2785
translate pt_br playYarn_046c475d:

    # you "Hehe, come on. You can do it~"
    you "Hehe, vambora. Você consegue~"

# game/atHome.rpy:2786
translate pt_br playYarn_00cf3674:

    # "It's a little condescending, but you can't seem to help it."
    "É um pouco condescendente, mas você não consegue evitar."

# game/atHome.rpy:2787
translate pt_br playYarn_defd1036:

    # "For some reason, it feels a little good knocking the feline down a peg or two."
    "Por algum motivo, é um pouco satisfatório colocar o gato em seu lugar."

# game/atHome.rpy:2789
translate pt_br playYarn_74d03aa0:

    # cat "Mreow! Mreow!"
    cat "Miaau! Miaau!"

# game/atHome.rpy:2790
translate pt_br playYarn_9f124326:

    # "At least it seems to be enjoying itself?"
    "Pelo menos parece estar se divertindo?"

# game/atHome.rpy:2791
translate pt_br playYarn_79f40d3e:

    # "You {i}hope{/i} anyway..."
    "Você {i}espera{/i} que sim..."

# game/atHome.rpy:2792
translate pt_br playYarn_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:2793
translate pt_br playYarn_5d2e14ac:

    # "You keep going."
    "Você continua."

# game/atHome.rpy:2796
translate pt_br playYarn_82c37b27:

    # cat "Mreow!{w=0.7}{nw}" with vpunch
    cat "Miaau!{w=0.7}{nw}" with vpunch

# game/atHome.rpy:2799
translate pt_br playYarn_c2d58782:

    # cat "{size=+5}Mreow!!{/size}{w=0.7}{nw}" with vpunch
    cat "{size=+5}Miaau!!{/size}{w=0.7}{nw}" with vpunch

# game/atHome.rpy:2802
translate pt_br playYarn_ddbf4218:

    # cat "{size=+10}Mreow!!!{/size}{w=0.7}{nw}" with vpunch
    cat "{size=+10}Miaau!!!{/size}{w=0.7}{nw}" with vpunch

# game/atHome.rpy:2803
translate pt_br playYarn_238eca43:

    # "The cat's movements have gotten more... aggressive."
    "Os movimentos do gato começaram a ficar mais... agressivos."

# game/atHome.rpy:2804
translate pt_br playYarn_b85635f2:

    # "It must be getting frustrated."
    "Deve estar ficando frustrado."

# game/atHome.rpy:2805
translate pt_br playYarn_15e0cfc4:

    # "You could {i}swear{/i} it nearly took a shot at your eye that last time, it had jumped so high and erratically..."
    "Você poderia {i}jurar{/i} que na última vez quase atacou seu olho, pulou tão alto e de forma imprevisível..."

# game/atHome.rpy:2806
translate pt_br playYarn_b6240bec:

    # "You've been keeping the yarn in constant motion, afraid to slow down."
    "Você tem mantido a lã em constante movimento, com medo de desacelerar."

# game/atHome.rpy:2807
translate pt_br playYarn_7c40740c:

    # "Your wrist is starting to get tired..."
    "Seu pulso está começando a ficar cansado..."

# game/atHome.rpy:2808
translate pt_br playYarn_f8a8c5e7:

    # "The cat doesn't seem to be losing any energy though."
    "Mas o gato não parece estar perdendo energia alguma."

# game/atHome.rpy:2809
translate pt_br playYarn_abbf9704:

    # "It's like..."
    "É como se..."

# game/atHome.rpy:2810
translate pt_br playYarn_f401f029:

    # "...it's getting faster and faster."
    "...estivesse ficando cada vez mais rápido."

# game/atHome.rpy:2812
translate pt_br playYarn_9416f814:

    # cat "{b}Mreow!{/b}" with vpunch
    cat "{b}Miaau!{/b}" with vpunch

# game/atHome.rpy:2813
translate pt_br playYarn_f2676f04:

    # "*Flick*"
    "*Vush*"

# game/atHome.rpy:2815
translate pt_br playYarn_d1bee282:

    # cat "{size=+5}{b}Mreow!{/b}{/size}" with vpunch
    cat "{size=+5}{b}Miaau!{/b}{/size}" with vpunch

# game/atHome.rpy:2816
translate pt_br playYarn_f2676f04_1:

    # "*Flick*"
    "*Vush*"

# game/atHome.rpy:2818
translate pt_br playYarn_06cf9fb4:

    # cat "{size=+10}{b}Mreow!{/b}{/size}" with vpunch
    cat "{size=+10}{b}Miaau!{/b}{/size}" with vpunch

# game/atHome.rpy:2819
translate pt_br playYarn_6c59984d:

    # "*Flick*-"
    "*Vush*-"

# game/atHome.rpy:2823
translate pt_br playYarn_0174bdad:

    # you "Nhh!"
    you "Nhh!"

# game/atHome.rpy:2824
translate pt_br playYarn_363b732f:

    # "Your wrist finally cramps sharply..."
    "Seu pulso finalmente começa a doer agudamente..."

# game/atHome.rpy:2825
translate pt_br playYarn_91e83780:

    # "...making you lose control of the yarn's motion as the tip of it brushes lightly against your stomach-"
    "...fazendo você perder o controle do movimento da lã enquanto a ponta dela toca levemente seu estômago-"

# game/atHome.rpy:2836
translate pt_br playYarn_9e69e751:

    # "{size=+25}{i}SLASH!!!{/i}{/size}" with hpunch
    "{size=+25}{i}SLASH!!!{/i}{/size}" with hpunch

# game/atHome.rpy:2841
translate pt_br playYarn_88a29bc2:

    # you "..!!! GHH!!" with vpunch
    you "..!!! GHH!!" with vpunch

# game/atHome.rpy:2842
translate pt_br playYarn_fa719f0e:

    # "Pain rips low across your torso..."
    "A dor rasga sua barriga..."

# game/atHome.rpy:2843
translate pt_br playYarn_9d6f51b9:

    # "...{i}into{/i} your torso."
    "...{i}dentro{/i} da sua barriga."

# game/atHome.rpy:2848
translate pt_br playYarn_0670ea4a:

    # you "B-Blurgh!" with vpunch
    you "B-Blurgh!" with vpunch

# game/atHome.rpy:2849
translate pt_br playYarn_3fa6ed31:

    # "Blood pours out of your mouth..."
    "Sangue derrama da sua boca..."

# game/atHome.rpy:2852
translate pt_br playYarn_93c8a750:

    # "In a daze, you look down and see red blooming slowly along the bottom of your shirt... around the tears in the fabric..."
    "Atordoado, você olha para baixo e vê o vermelho aumentando lentamente na parte de baixo da sua camisa... ao redor dos rasgos no tecido..."

# game/atHome.rpy:2853
translate pt_br playYarn_28f0d5c3:

    # you "*cough* *cough*-"
    you "*cof* *cof*-"

# game/atHome.rpy:2860
translate pt_br playYarn_b11bba49:

    # "{size=+10}{b}PLOP!{/b}{/size}" with vpunch
    "{size=+10}{b}PLOP!{/b}{/size}" with vpunch

# game/atHome.rpy:2861
translate pt_br playYarn_56ebb028:

    # you "!!!"
    you "!!!"

# game/atHome.rpy:2862
translate pt_br playYarn_cfd9f7c0:

    # you "A-Ah..!"
    you "A-Ah..!"

# game/atHome.rpy:2865
translate pt_br playYarn_a3378925:

    # "You watch as long thick ropes of..."
    "Você assiste enquanto longas e grossas linhas de..."

# game/atHome.rpy:2866
translate pt_br playYarn_083f1354:

    # "{i}...something...{/i}"
    "{i}...alguma coisa...{/i}"

# game/atHome.rpy:2867
translate pt_br playYarn_c9be29f0:

    # "...pour out from under your shirt into a bloody heap on the floor at your feet."
    "...despejam-se debaixo da sua camisa, em um monte de sangue no chão aos seus pés."

# game/atHome.rpy:2868
translate pt_br playYarn_36f9ea20:

    # "A single red streaked rope still hangs from you... {w}{i}connecting{/i} you to all that... {b}mess{/b}."
    "Uma única linha vermelha ainda se prende a você... {w}{i}conectando{/i} você a toda aquela... {b}bagunça{/b}."

# game/atHome.rpy:2869
translate pt_br playYarn_98fb658f:

    # "Are... {w}Are those your...?"
    "Esses... {w}Esses são seus...?"

# game/atHome.rpy:2870
translate pt_br playYarn_afbea56b:

    # "You crumble to the ground and topple over onto your side."
    "Você desmorona no chão e cai de lado."

# game/atHome.rpy:2871
translate pt_br playYarn_101de09f:

    # "Your vision has gone blurry..."
    "Sua visão ficou embaçada..."

# game/atHome.rpy:2873
translate pt_br playYarn_bf0874e3:

    # "But..."
    "Mas..."

# game/atHome.rpy:2879
translate pt_br playYarn_a49bee6a:

    # "...you can just make out the shape of something small and a deep, inky black as it walks over and inspects your..."
    "...você consegue distinguir a forma de algo pequeno e de um preto profundo se aproximando e conferindo seus..."

# game/atHome.rpy:2880
translate pt_br playYarn_a5942a18:

    # "{size=-10}Oh god, they're your {i}intestines{/i}...{/size}"
    "{size=-10}Meu Deus, são seus {i}intestinos{/i}...{/size}"

# game/atHome.rpy:2881
translate pt_br playYarn_59d3b133:

    # "...before it starts to giddily roll around in the mass of your bloody insides next to you."
    "...antes de começar a rolar, animado, na massa de suas entranhas ensanguentadas ao seu lado."

# game/atHome.rpy:2883
translate pt_br playYarn_5e84b463:

    # cat "Meow! Meow!"
    cat "Miau! Miau!"

# game/atHome.rpy:2886
translate pt_br playYarn_a0096ee8:

    # "Darkness falls over you..."
    "Escuridão recai sobre você..."

# game/atHome.rpy:2888
translate pt_br playYarn_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/atHome.rpy:2889
translate pt_br playYarn_dae0ec55_2:

    # you "..."
    you "..."

# game/atHome.rpy:2890
translate pt_br playYarn_99e0e8b8:

    # "The cat... {w}sounds happy."
    "O gato... {w}parece feliz."

# game/atHome.rpy:2891
translate pt_br playYarn_6d107ba2:

    # "Nonsensically you wonder where the yarn has gone but... {w}there's really no need to worry about it."
    "Ilogicamente, você se pergunta onde foi parar a lã, mas... {w}não há porque se preocupar com isso."

# game/atHome.rpy:2892
translate pt_br playYarn_2773433b:

    # "The cat seems content with the next best thing."
    "O gato parece satisfeito com a segunda melhor opção."

# game/atHome.rpy:2893
translate pt_br playYarn_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:2894
translate pt_br playYarn_472f27e0:

    # "Ending 11: At The End of Your Rope"
    "Final 11: Fim da Linha"

# game/atHome.rpy:2907
translate pt_br playLaser_fb5ad6dc:

    # "Cats are curious creatures by nature..."
    "Gatos são criaturas curiosas por natureza..."

# game/atHome.rpy:2908
translate pt_br playLaser_c4ace2d3:

    # "They're also natural hunters... Sort of."
    "Eles também são caçadores natos... De certa forma."

# game/atHome.rpy:2909
translate pt_br playLaser_80e551db:

    # "Why not pass the time by letting the cat hunt after something it'll never quite understand?"
    "Por que não passar tempo fazendo o gato caçar algo que ele nunca vai entender direito?"

# game/atHome.rpy:2910
translate pt_br playLaser_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:2911
translate pt_br playLaser_75f82259:

    # "That sounds a little mean when you think of it like that..."
    "Pensando bem, isso soa um pouco maldoso..."

# game/atHome.rpy:2912
translate pt_br playLaser_914e4419:

    # "But it's not like the cat will know anyway."
    "Mas não é como se o gato fosse perceber, de qualquer forma."

# game/atHome.rpy:2913
translate pt_br playLaser_1a75f885:

    # "\"Ignorance is bliss\", or so they say."
    "\"A ignorância é uma benção\", é o que dizem, pelo menos."

# game/atHome.rpy:2914
translate pt_br playLaser_9007c0d7:

    # "So you dig out your old laser pointer from your long gone dreaded days of group presentations in school."
    "Então você desenterra seu laser velho dos tempos amaldiçoados de apresentações em grupo na escola."

# game/atHome.rpy:2915
translate pt_br playLaser_c3d8ff06:

    # "You flip it on and see that even after all this time, the batteries still work."
    "Você o liga e vê que mesmo após todo esse tempo, a bateria ainda funciona."

# game/atHome.rpy:2916
translate pt_br playLaser_9c176f96:

    # "You get a little kick out of aiming it at a mirror hanging in the living room, so it reflects off the glass..."
    "Você se diverte um pouco mirando o laser em um espelho pendurado na sala, fazendo-o refletir no vidro..."

# game/atHome.rpy:2917
translate pt_br playLaser_679296d6:

    # "...Making a little red dot appear on your knee."
    "...E fazendo um ponto vermelho aparecer no seu joelho."

# game/atHome.rpy:2919
translate pt_br playLaser_751f71d9:

    # cat "...Meow?"
    cat "...Miau?"

# game/atHome.rpy:2920
translate pt_br playLaser_ebec2255:

    # "The cat cautiously walks over, stopping every few steps to cast a look of suspicion at you."
    "O gato cuidadosamente se aproxima, parando a cada poucos passos para lançar um olhar desconfiado em sua direção."

# game/atHome.rpy:2921
translate pt_br playLaser_1f6e99f2:

    # "When it finally reaches you, it lightly presses a paw to your knee..."
    "Quando ele finalmente chega perto, pressiona suavemente a patinha no seu joelho..."

# game/atHome.rpy:2922
translate pt_br playLaser_7afb7281:

    # "...like it's trying to catch the dot of red light as casually as possible."
    "...como se estivesse tentando pegar o pontinho vermelho, como se fosse possível."

# game/atHome.rpy:2923
translate pt_br playLaser_6e2311a9:

    # you "Hm!" with vpunch
    you "Hm!" with vpunch

# game/atHome.rpy:2924
translate pt_br playLaser_e7427e1b:

    # "You manage to hold back a chuckle. Not that it really matters."
    "Você consegue segurar um riso. Não que isso importe muito."

# game/atHome.rpy:2925
translate pt_br playLaser_51f4c068:

    # "The cat isn't paying attention to you at all, entirely focused on the light now resting on top of its paw."
    "O gato não está nem prestando atenção em você, totalmente focado na luz que agora está em sua pata."

# game/atHome.rpy:2926
translate pt_br playLaser_c6366437:

    # you "Hehe~"
    you "Hehe~"

# game/atHome.rpy:2927
translate pt_br playLaser_a1c9ebec:

    # "You move the light a little higher above your knee."
    "Você move a luz para um pouco acima do seu joelho."

# game/atHome.rpy:2928
translate pt_br playLaser_bdf0b7fa:

    # "The cat reacts immediately, trying to pin the light down..."
    "O gato reage na hora, tentando prender o ponto de luz..."

# game/atHome.rpy:2929
translate pt_br playLaser_1e13c86f:

    # "...but in the next second, you've already moved it to the floor."
    "...mas no segundo seguinte, você já o moveu para o chão."

# game/atHome.rpy:2932
translate pt_br playLaser_e51a55ad:

    # "The cat jerkily follows, attempting a more energetic pounce when you shift the red dot..."
    "O gato acompanha bruscamente, tentando um ataque mais enérgico quando você move o ponto vermelho......"

# game/atHome.rpy:2933
translate pt_br playLaser_27fb2bef:

    # "Over here..."
    "Aqui..."

# game/atHome.rpy:2936
translate pt_br playLaser_99bbe8fa:

    # "Over there..."
    "Ali..."

# game/atHome.rpy:2939
translate pt_br playLaser_c2405716:

    # "And over there..."
    "E ali..."

# game/atHome.rpy:2942
translate pt_br playLaser_a4dbb992:

    # "By the couch..."
    "Perto do..."

# game/atHome.rpy:2951
translate pt_br playLaser_7b4b553d:

    # "{i}On{/i} the couch..."
    "Em cima {i}do{/i} sofá..."

# game/atHome.rpy:2955
translate pt_br playLaser_555c0370:

    # cat "Mreow! Mreow!!" with hpunch
    cat "Miaau! Miaau!!" with hpunch

# game/atHome.rpy:2956
translate pt_br playLaser_0931d500:

    # you "Hehehe!"
    you "Hehehe!"

# game/atHome.rpy:2957
translate pt_br playLaser_33d860e3:

    # "The cat might be ignoring you, but you're certainly enjoying yourself."
    "O gato pode estar te ignorando, mas, com certeza, você está se divertindo."

# game/atHome.rpy:2958
translate pt_br playLaser_98b699aa:

    # "It's been a while since you've laughed this much."
    "Já faz um bom tempo que você não ri tanto assim."

# game/atHome.rpy:2959
translate pt_br playLaser_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:2960
translate pt_br playLaser_2ca4176f:

    # "You're laughing {i}so{/i} much in fact..."
    "Na verdade, você ri {i}tanto{/i}..."

# game/atHome.rpy:2961
translate pt_br playLaser_0f656f12:

    # "...that you accidentally shift the red dot onto a lamp beside the couch."
    "...que acidentamente coloca o ponto vermelho sobre o abajur ao lado do sofá."

# game/atHome.rpy:2963
translate pt_br playLaser_a4314429:

    # cat "{size=+10}Mreow!{/size}" with hpunch
    cat "{size=+10}Miaau!{/size}" with hpunch

# game/atHome.rpy:2964
translate pt_br playLaser_c80ec7e6:

    # "In its haste to get the light, the cat leaps onto the lamp, sending them both to the ground."
    "Na pressa de pegar a luz, o gato pula no abajur, e os dois vão ao chão."

# game/atHome.rpy:2968
translate pt_br playLaser_c9873f7d:

    # "{size=+20}CRASH!!{/size}" with vpunch
    "{size=+20}CRASH!!{/size}" with vpunch

# game/atHome.rpy:2969
translate pt_br playLaser_2cb154e5:

    # you "*Gasp* Oh my gosh!"
    you "*Gasp* Meu Deus!"

# game/atHome.rpy:2972
translate pt_br playLaser_4cd0c099:

    # "The cat is sitting in the middle of the former lamp's broken shards..."
    "O gato está sentado no meio dos cacos quebrados do que um dia foi o abajur..."

# game/atHome.rpy:2973
translate pt_br playLaser_4e66e4b9:

    # "...back hunched, its head whipping around back and forth as if in a panic."
    "...costas curvadas, a cabeça se virando para lá e para cá, como se estivesse em pânico."

# game/atHome.rpy:2974
translate pt_br playLaser_68f4b17b:

    # "You quickly turn off the laser pointer and rush over."
    "Você rapidamente desliga o laser e corre até ele."

# game/atHome.rpy:2975
translate pt_br playLaser_d789f24b:

    # you "I'm so sorry! A-Are you okay? Are you hurt?"
    you "Me desculpa! V-Você tá bem? Se machucou?"

# game/atHome.rpy:2976
translate pt_br playLaser_d4abd66b:

    # "You reach down to pick up the cat and check it for any injuries when-"
    "Você se abaixa para pegar o gato e ver se ele se machucou, quando-"

# game/atHome.rpy:2978
translate pt_br playLaser_8fdc8cf1:

    # cat "{size=+5}MREOWR!!{/size}" with vpunch
    cat "{size=+5}MIAAUU!!{/size}" with vpunch

# game/atHome.rpy:2983
translate pt_br playLaser_ec457ab1:

    # "{size=+20}{i}SLASH!{/i}{/size}" with hpunch
    "{size=+20}{i}SLASH!{/i}{/size}" with hpunch

# game/atHome.rpy:2984
translate pt_br playLaser_327933f5:

    # you "OW! Hey!"
    you "AI! Ei!"

# game/atHome.rpy:2985
translate pt_br playLaser_a708b99f:

    # "The cat swipes at you, claws extended."
    "O gato te ataca, com as garras estendidas."

# game/atHome.rpy:2986
translate pt_br playLaser_da2387c2:

    # "It backs up and twitches away, making frantic half turns in various directions as if looking for something..."
    "Ele recua e se contorce, girando freneticamente em várias direções, como se estivesse procurando por algo..."

# game/atHome.rpy:2987
translate pt_br playLaser_663f6b23:

    # "...or {i}waiting{/i} for something to appear."
    "...ou {i}esperando{/i} que algo apareça."

# game/atHome.rpy:2988
translate pt_br playLaser_290f624d:

    # you "Ow, geez... That really hurt, you know..."
    you "Ai, caralho... Isso machuca, sabia?"

# game/atHome.rpy:2989
translate pt_br playLaser_38b4ee56:

    # "You hold the hand with the scratch close to your chest."
    "Você segura a mão arranhada próxima ao peito."

# game/atHome.rpy:2990
translate pt_br playLaser_eee45712:

    # "It's bleeding, but it's not too big. You're more annoyed than anything but..."
    "Está sangrando, mas não está tão ruim. É mais irritação que tudo, mas..."

# game/atHome.rpy:2992
translate pt_br playLaser_e78aaa6d:

    # cat "Mreowr!{w=0.75}{nw}" with hpunch
    cat "Miaauu!{w=0.75}{nw}" with hpunch

# game/atHome.rpy:2994
translate pt_br playLaser_1bb5166d:

    # cat "Mreowr! Mreowr!{w=1}{nw}" with hpunch
    cat "Miaauu! Miaauu!{w=1}{nw}" with hpunch

# game/atHome.rpy:2995
translate pt_br playLaser_ab09fb6c:

    # "...immediately your annoyance starts to bleed into concern."
    "...imediatamente sua irritação começa a dar lugar à preocupação."

# game/atHome.rpy:2997
translate pt_br playLaser_e92b7d98:

    # cat "{i}MREOWR!{/i}" with vpunch
    cat "{i}MIAAUU!{/i}" with vpunch

# game/atHome.rpy:2998
translate pt_br playLaser_539c898a:

    # "You watch in shock as the cat starts to run around tearing at the carpet, the sofa, your armchair..."
    "Você observa em choque, enquanto o gato começa a correr pela sala, rasgando o carpete, o sofá, sua poltrona..."

# game/atHome.rpy:2999
translate pt_br playLaser_f45e7675:

    # "You want to stop it, but you're afraid of getting in the middle of its rampage."
    "Você quer pará-lo, mas está com medo de se enfiar no meio do seu surto."

# game/atHome.rpy:3000
translate pt_br playLaser_8920b0ca:

    # "You consider calling a vet for advice on how to calm it down, but for some reason..."
    "Você pensa em ligar para um veterinário para saber como acalmar ele, mas por algum motivo..."

# game/atHome.rpy:3001
translate pt_br playLaser_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:3003
translate pt_br playLaser_12cd3024:

    # "{size=-10}...you feel like that wouldn't be a good idea.{/size}"
    "{size=-10}...você sente que não é uma boa ideia.{/size}"

# game/atHome.rpy:3005
translate pt_br playLaser_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:3006
translate pt_br playLaser_5fb40629:

    # you "What happened to you...? Is it...?"
    you "O que aconteceu com você...? Será que...?"

# game/atHome.rpy:3007
translate pt_br playLaser_38a2a096:

    # you "..!" with vpunch
    you "..!" with vpunch

# game/atHome.rpy:3008
translate pt_br playLaser_d478bf3d:

    # "An idea comes to you. Or rather, a realization?"
    "Uma ideia passa pela sua cabeça. Ou melhor, uma epifania?"

# game/atHome.rpy:3009
translate pt_br playLaser_688dec48:

    # "You grasp the laser pointer, aiming it safely away towards the floor in the middle of the living room..."
    "Você segura o laser, cuidadosamente apontando-o para o chão no meio da sala..."

# game/atHome.rpy:3010
translate pt_br playLaser_3ab47bcb:

    # "Thinking... {w}{i}hoping{/i}... {w}that the cat would calm down if it found what it was looking for..."
    "Pensando... {w}{i}esperando{/i}... {w}que o gato pudesse se acalmar caso encontrasse o que estava procurando..."

# game/atHome.rpy:3011
translate pt_br playLaser_74fa8018:

    # "...you turn on the laser pointer."
    "...você liga o laser."

# game/atHome.rpy:3012
translate pt_br playLaser_ab6d5659:

    # cat "!!!" with hpunch
    cat "!!!" with hpunch

# game/atHome.rpy:3015
translate pt_br playLaser_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:3016
translate pt_br playLaser_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:3017
translate pt_br playLaser_10394fe2:

    # "The cat's reaction is {b}immediate.{/b}"
    "A reação do gato é {b}imediata.{/b}"

# game/atHome.rpy:3021
translate pt_br playLaser_e362f7cd:

    # cat "Mreowr!" with hpunch
    cat "Miaauu!" with hpunch

# game/atHome.rpy:3023
translate pt_br playLaser_d6063309:

    # cat "{size=+15}MREOWR!! {/size}" with hpunch
    cat "{size=+15}MIAAUU!! {/size}" with hpunch

# game/atHome.rpy:3025
translate pt_br playLaser_e47b681a:

    # cat "{size=+25}{b}MROARRRR!!!{/b}{/size}" with hpunch
    cat "{size=+25}{b}MROOARRR!!!{/b}{/size}" with hpunch

# game/atHome.rpy:3026
translate pt_br playLaser_56ebb028:

    # you "!!!"
    you "!!!"

# game/atHome.rpy:3027
translate pt_br playLaser_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:3028
translate pt_br playLaser_02bcbf4d:

    # "{size=-8}...You screwed up.{/size}"
    "{size=-8}...Você fudeu tudo.{/size}"

# game/atHome.rpy:3031
translate pt_br playLaser_ff446bcf:

    # "In the span of mere seconds, you watch as the cat spies the red dot from its perch on the shredded armchair..."
    "Em questão de segundos, você vê o gato avistar o ponto vermelho do alto da poltrona destroçada..."

# game/atHome.rpy:3034
translate pt_br playLaser_bcb1443f:

    # "...leaps high into the air..."
    "...dar um salto muito alto no ar..."

# game/atHome.rpy:3037
translate pt_br playLaser_ce89eeea:

    # "...{i}{b}changes{/b}{/i} in the air..."
    "...{i}{b}mudar{/b}{/i} no ar..."

# game/atHome.rpy:3042
translate pt_br playLaser_b7ce2ec0:

    # "{size=+35}{b}CRASH!!{/b}{/size}{w=0.2}{nw}" with hpunch
    "{size=+35}{b}CRASH!!{/b}{/size}{w=0.2}{nw}" with hpunch

# game/atHome.rpy:3043
translate pt_br playLaser_3aae9beb:

    # "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch
    "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch

# game/atHome.rpy:3044
translate pt_br playLaser_56ebb028_1:

    # you "!!!"
    you "!!!"

# game/atHome.rpy:3046
translate pt_br playLaser_cd394c54:

    # "...and slams down upon the dot on the floor, with a weight and force that {i}shakes{/i} the whole apartment."
    "...e desabar sobre o ponto no chão, com um peso e força que faz {i}tremer{/i} todo o apartamento."

# game/atHome.rpy:3047
translate pt_br playLaser_41d12d34:

    # "Maybe even the whole building."
    "Talvez até o prédio inteiro."

# game/atHome.rpy:3048
translate pt_br playLaser_f7f341a9:

    # "You wonder dazedly how none of the other tenants have rushed over to complain about the noise..."
    "Você se pergunta, atordoado, como nenhum dos outros moradores correu para reclamar do barulho..."

# game/atHome.rpy:3049
translate pt_br playLaser_a1efdf2a:

    # "Yet as you stare at the sight in front of you..."
    "Mas, enquanto você encara a cena à sua frente..."

# game/atHome.rpy:3053
translate pt_br playLaser_189e50c9:

    # "The cat has somehow {i}grown{/i} in size..."
    "O gato de alguma forma {i}cresceu{/i}..."

# game/atHome.rpy:3054
translate pt_br playLaser_0d1c6dcc:

    # "...eyes bulging and glowing... {w}tail thrashing... {w}teeth enlarged, bared and covered alarmingly in a bubbling froth..."
    "...os olhos saltados e brilhando... {w}a cauda chicoteando... {w}os dentes crescidos, à mostra e alarmantemente cobertos por uma espuma borbulhante..."

# game/atHome.rpy:3057
translate pt_br playLaser_b78125ff:

    # "Its giant claws rip and shred through the carpet, through the floor tiles and even {b}below{/b} them..."
    "Suas garras gigantes rasgam e destroem o carpete, os azulejos do chão e vão ainda {b}mais fundo{/b}..."

# game/atHome.rpy:3058
translate pt_br playLaser_29b85512:

    # "...ravenously trying to get at the red dot."
    "...tentando vorazmente alcançar o ponto vermelho."

# game/atHome.rpy:3059
translate pt_br playLaser_3917623e:

    # "Your hands are shaking."
    "Suas mãos estão tremendo."

# game/atHome.rpy:3060
translate pt_br playLaser_a225310b:

    # "You don't know what to do. You feel trapped. You have to get away."
    "Você não sabe o que fazer. Se sente encurralado. Precisa se afastar."

# game/atHome.rpy:3061
translate pt_br playLaser_82568cc9:

    # "...Get {i}it{/i} away from you."
    "...Precisa se afastar {i}disso{/i}."

# game/atHome.rpy:3062
translate pt_br playLaser_28b3ac41:

    # you "!!"
    you "!!"

# game/atHome.rpy:3063
translate pt_br playLaser_94047747:

    # "You slowly back up towards the door."
    "Você lentamente recua em direção à porta."

# game/atHome.rpy:3064
translate pt_br playLaser_76076a2d:

    # "The light moves with you."
    "A luz se move com você."

# game/atHome.rpy:3065
translate pt_br playLaser_f2573342:

    # cat "{size=+10}!!!{/size}" with hpunch
    cat "{size=+10}!!!{/size}" with hpunch

# game/atHome.rpy:3066
translate pt_br playLaser_56ebb028_2:

    # you "!!!"
    you "!!!"

# game/atHome.rpy:3067
translate pt_br playLaser_4d205848:

    # "Instinctively you flick the light away, this way and that, the cat stampeding after it..."
    "Instintivamente você mexe a luz, de um lado para o outro, enquanto o gato corre atrás dela..."

# game/atHome.rpy:3069
translate pt_br playLaser_cb465f82:

    # "{size=+30}{b}CRASH!!{/b}{/size}" with vpunch
    "{size=+30}{b}CRASH!!{/b}{/size}" with vpunch

# game/atHome.rpy:3070
translate pt_br playLaser_69d96002:

    # you "{i}So fast...{/i}"
    you "{i}Rápido demais...{/i}"

# game/atHome.rpy:3071
translate pt_br playLaser_195b9941:

    # "...smashing through the TV ...breaking the couch in the half..."
    "...esmagando a TV... partindo o sofá ao meio..."

# game/atHome.rpy:3073
translate pt_br playLaser_17efb246:

    # "{size=+30}{b}CRASH!!{/b}{/size}{w=0.2}{nw}" with vpunch
    "{size=+30}{b}CRASH!!{/b}{/size}{w=0.2}{nw}" with vpunch

# game/atHome.rpy:3075
translate pt_br playLaser_5fdd654f:

    # "{size=+30}{b}CRASH!! CRASH!!{/b}{/size}" with vpunch
    "{size=+30}{b}CRASH!! CRASH!!{/b}{/size}" with vpunch

# game/atHome.rpy:3076
translate pt_br playLaser_adef04a7:

    # you "{i}Too fast...{/i}"
    you "{i}Rápido demais...{/i}"

# game/atHome.rpy:3077
translate pt_br playLaser_555778c7:

    # "...bulldozing through the wall into the hallway."
    "...atravessando a parede, indo para corredor."

# game/atHome.rpy:3079
translate pt_br playLaser_3aae9beb_1:

    # "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch
    "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch

# game/atHome.rpy:3080
translate pt_br playLaser_28b3ac41_1:

    # you "!!"
    you "!!"

# game/atHome.rpy:3081
translate pt_br playLaser_7984bc3e:

    # "A chance!"
    "Uma chance!"

# game/atHome.rpy:3082
translate pt_br playLaser_67119f3b:

    # "You turn, intending to bolt out of the door and never come back..."
    "Você se vira, decidido a sair pela porta e nunca mais voltar..."

# game/atHome.rpy:3083
translate pt_br playLaser_a741a67f:

    # "...but in your haste, you {b}forget{/b} something."
    "...mas, na pressa, você {b}esquece{/b} de algo."

# game/atHome.rpy:3084
translate pt_br playLaser_4dfa2f4a:

    # "You forget {i}several{/i} somethings."
    "Você esquece de {i}vários{/i} algos."

# game/atHome.rpy:3085
translate pt_br playLaser_3ef81c43:

    # "You forget the laser pointer, gripped like a lifeline in your hand..."
    "Você esquece o laser, segurando-o como se fosse um recurso vital..."

# game/atHome.rpy:3086
translate pt_br playLaser_e94069c8:

    # cat "!!!"
    cat "!!!"

# game/atHome.rpy:3087
translate pt_br playLaser_6d278a4f:

    # "You forget the mirror, still miraculously hanging on the wall next to the hallway..."
    "Se esquece do espelho, ainda milagrosamente pendurado na parede ao lado do corredor..."

# game/atHome.rpy:3088
translate pt_br playLaser_aa8d0cf9:

    # "...the laser reflecting off of it..."
    "...com o laser refletindo nele..."

# game/atHome.rpy:3089
translate pt_br playLaser_e6c0f1f9:

    # "...putting a small, glowing red dot..."
    "...projetando um pequeno ponto vermelho brilhante..."

# game/atHome.rpy:3090
translate pt_br playLaser_a20cefa7_6:

    # "..."
    "..."

# game/atHome.rpy:3091
translate pt_br playLaser_69603a8b:

    # "...on the back of your head..."
    "...atrás da sua cabeça..."

# game/atHome.rpy:3092
translate pt_br playLaser_7f0ac95c:

    # cat "..."
    cat "..."

# game/atHome.rpy:3096
translate pt_br playLaser_80207668:

    # "And as you reach the door..."
    "E assim que você alcança a porta......"

# game/atHome.rpy:3098
translate pt_br playLaser_9b41848f:

    # cat "{b}*GROWL*{/b}"
    cat "{b}*RUGIDO*{/b}"

# game/atHome.rpy:3099
translate pt_br playLaser_a20cefa7_7:

    # "..."
    "..."

# game/atHome.rpy:3100
translate pt_br playLaser_35fdb28d:

    # "...you forget that it's locked."
    "...você esqueceu que está trancada."

# game/atHome.rpy:3129
translate pt_br playLaser_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:3130
translate pt_br playLaser_a20cefa7_8:

    # "..."
    "..."

# game/atHome.rpy:3131
translate pt_br playLaser_8b4b67e6:

    # "You don't even have the chance to turn around before the cat lunges all the way across the room at you."
    "Você nem tem a chance de se virar antes que o gato salte do outro lado da sala em sua direção."

# game/atHome.rpy:3175
translate pt_br playLaser_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:3176
translate pt_br playLaser_f57c18d4:

    # "You're torn to shreds before you can even blink."
    "Você é dilacerado antes mesmo de conseguir piscar."

# game/atHome.rpy:3177
translate pt_br playLaser_a20cefa7_9:

    # "..."
    "..."

# game/atHome.rpy:3178
translate pt_br playLaser_fa28c27c:

    # "Ending 12: Targeted"
    "Final 12: Alvo"

# game/atHome.rpy:3191
translate pt_br playHideSeek_4bd0d419:

    # you "What about hide and seek..?"
    you "Que tal esconde-esconde..?"

# game/atHome.rpy:3193
translate pt_br playHideSeek_16879ce5:

    # cat "Meow?"
    cat "Miau?"

# game/atHome.rpy:3194
translate pt_br playHideSeek_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:3195
translate pt_br playHideSeek_7f0ac95c:

    # cat "..."
    cat "..."

# game/atHome.rpy:3196
translate pt_br playHideSeek_501b5875:

    # "You're... not quite sure how this is going to work."
    "Você... não tem muita certeza de como isso vai funcionar."

# game/atHome.rpy:3197
translate pt_br playHideSeek_2dd47eb6:

    # "Can a cat even understand the concept of a {i}game...{/i} {w}let alone one with rules like hide and seek?"
    "Será que um gato conseguiria entender o conceito de um {i}jogo...{/i} {w}ainda mais um com regras, como esconde-esconde?"

# game/atHome.rpy:3198
translate pt_br playHideSeek_990e7450:

    # you "Hmm... Here, just..."
    you "Hmm... Aqui, ó..."

# game/atHome.rpy:3199
translate pt_br playHideSeek_d9b6c5b2:

    # "You pick up the cat and turn them away from you before hiding behind the armchair."
    "Você pega o gato e coloca ele virado, longe de você, antes de se esconder atrás da poltrona."

# game/atHome.rpy:3202
translate pt_br playHideSeek_0b37453e:

    # "You're almost certain the cat must've turned and looked while you were hiding... {w}out of confusion at least, if nothing else..."
    "Você tem quase certeza de que o gato deve ter se virado e olhado enquanto você se escondia... {w}por estar confuso, ou outro motivo..."

# game/atHome.rpy:3211
translate pt_br playHideSeek_16879ce5_1:

    # cat "Meow?"
    cat "Miau?"

# game/atHome.rpy:3212
translate pt_br playHideSeek_caa03df3:

    # "Regardless, a few moments later, the cat cautiously peeks around the armchair at you, eyes curious."
    "De qualquer forma, depois de um momento, o gato cuidadosamente te espia pela poltrona, com os olhos curiosos."

# game/atHome.rpy:3215
translate pt_br playHideSeek_bfd68843:

    # "You smile and scoop it up, holding it out in front of you."
    "Você sorri e o pega no colo, segurando-o à sua frente."

# game/atHome.rpy:3216
translate pt_br playHideSeek_bf4f65f9:

    # you "You found me! You win!!"
    you "Você me achou! Você ganhou!!"

# game/atHome.rpy:3218
translate pt_br playHideSeek_321f01a1:

    # cat "Meow! Meow!" with hpunch
    cat "Miau! Miau!" with hpunch

# game/atHome.rpy:3219
translate pt_br playHideSeek_3b87374e:

    # "The cat looks confused, but pleased at your praise."
    "O gato parece confuso, mas contente com sua empolgação."

# game/atHome.rpy:3220
translate pt_br playHideSeek_ef6ad04d:

    # "This time, you put it on the armchair so it can't see your hiding spot as easily."
    "Dessa vez, você o coloca na poltrona para que ele não veja seu esconderijo tão facilmente."

# game/atHome.rpy:3223
translate pt_br playHideSeek_1f14505c:

    # "You dash over to the kitchen, hiding behind the counter."
    "Você corre até a cozinha, escondendo-se atrás do balcão."

# game/atHome.rpy:3224
translate pt_br playHideSeek_dd4584c0:

    # "It takes a little longer this time for the cat to find you."
    "Demora um pouco mais dessa vez para o gato te encontrar."

# game/atHome.rpy:3225
translate pt_br playHideSeek_8fa4c58e:

    # "This time, when it does, it startles you by hopping down into your lap from the countertop above."
    "Dessa vez, quando encontra, ele te assusta pulando de cima do balcão direto no seu colo."

# game/atHome.rpy:3226
translate pt_br playHideSeek_fc460430:

    # you "Whoa!" with vpunch
    you "Ei!" with vpunch

# game/atHome.rpy:3228
translate pt_br playHideSeek_fbbaa7ef:

    # cat "Meow! Meoww!" with hpunch
    cat "Miau! Miaau!" with hpunch

# game/atHome.rpy:3229
translate pt_br playHideSeek_5afcd17c:

    # you "You found me again!"
    you "Você me achou de novo!"

# game/atHome.rpy:3231
translate pt_br playHideSeek_b003a621:

    # cat "Meoww!"
    cat "Miau!"

# game/atHome.rpy:3232
translate pt_br playHideSeek_fc37ae68:

    # you "Hehe, okay okay, you win!"
    you "Hehe, tá, tá, você ganhou!"

# game/atHome.rpy:3233
translate pt_br playHideSeek_044aa542:

    # "You reward it with little scratches behind the ear and under the chin when it leans into your touch."
    "Você o recompensa esfregando atrás de sua orelha e abaixo do queixo, fazendo-o se inclinar na sua mão."

# game/atHome.rpy:3235
translate pt_br playHideSeek_78b6d9cf:

    # cat "Purr.. Purr.."
    cat "Purr.. Purr.."

# game/atHome.rpy:3236
translate pt_br playHideSeek_6e23df72:

    # you "Hehe~ Okay, why don't you give it a try?"
    you "Hehe~ Tá bom, que tal você tentar agora?"

# game/atHome.rpy:3238
translate pt_br playHideSeek_16879ce5_2:

    # cat "Meow?"
    cat "Miau?"

# game/atHome.rpy:3241
translate pt_br playHideSeek_4b3553e2:

    # "You go and stand in the middle of the living room..."
    "Você vai até o meio da sala e fica lá parado..."

# game/atHome.rpy:3244
translate pt_br playHideSeek_ab912efe:

    # "...the cat following you."
    "...com o gato te seguindo, logo atrás."

# game/atHome.rpy:3255
translate pt_br playHideSeek_13e57d68:

    # "You make a show of covering your eyes and turning around."
    "Você faz um showzinho cobrindo os olhos e se virando."

# game/atHome.rpy:3256
translate pt_br playHideSeek_3d4baad1:

    # you "Okay~"
    you "Ok~"

# game/atHome.rpy:3257
translate pt_br playHideSeek_d05e788f:

    # you "5... 4... 3... 2... 1... Go!"
    you "5... 4... 3... 2... 1... Vai!"

# game/atHome.rpy:3269
translate pt_br playHideSeek_43176d29:

    # "You turn around and see that the cat is gone."
    "Você se vira e vê que o gato sumiu."

# game/atHome.rpy:3272
translate pt_br playHideSeek_a96ff075:

    # you "Huh, you sure catch on quick..."
    you "Hmm, você pega o jeito rápido..."

# game/atHome.rpy:3273
translate pt_br playHideSeek_659c41b9:

    # "There aren't that many places available in your apartment for someone your size to hide..."
    "Não há muitos lugares no seu apartamento para que alguém do seu tamanho possa se esconder..."

# game/atHome.rpy:3274
translate pt_br playHideSeek_138bf664:

    # "...but without the opposable thumbs needed to open the closed doors in the hall, the cat will have its limits too."
    "...mas, sem polegares opositores necessários para abrir as portas fechadas do corredor, o gato também terá seus limites."

# game/atHome.rpy:3275
translate pt_br playHideSeek_46edf521:

    # "Fair game."
    "É justo."

# game/atHome.rpy:3276
translate pt_br playHideSeek_e97341d6:

    # you "Okay, now where to look~"
    you "Beleza, agora onde procurar~"

# game/atHome.rpy:3295
translate pt_br seekLivingRoom_b174d0b4:

    # "You look behind the couch and the armchair... {w}Then under the coffee table..."
    "Você olha atrás do sofá e da poltrona... {w}Depois embaixo da mesa de centro..."

# game/atHome.rpy:3296
translate pt_br seekLivingRoom_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3297
translate pt_br seekLivingRoom_3f311f83:

    # "Nothing. The living room is pretty sparse when it comes to furniture, after all."
    "Nada. A sala é bem simples quando se trata de mobília, afinal."

# game/atHome.rpy:3306
translate pt_br seekKitchen_8e951d9b:

    # "You peek around the counter... {w}Grab a chair and check on top of the fridge..."
    "Você espia ao redor do balcão... {w}Pega uma cadeira e dá uma olhada em cima da geladeira..."

# game/atHome.rpy:3307
translate pt_br seekKitchen_b35ddd37:

    # "You even open the cupboards along the floor, just in case the cat managed to squeeze inside..."
    "Você até abre os armários baixos, só para garantir que o gato não tenha conseguido se enfiar lá dentro..."

# game/atHome.rpy:3308
translate pt_br seekKitchen_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3309
translate pt_br seekKitchen_67b7b559:

    # "Nothing. You decide that's for the best."
    "Nada. Você decide que é até melhor assim."

# game/atHome.rpy:3310
translate pt_br seekKitchen_6e50a758:

    # "The kitchen is for making food, not playing games."
    "A cozinha é para preparar comida, não para brincadeiras."

# game/atHome.rpy:3321
translate pt_br seekHallway_7248db28:

    # "You peek around the corner into the hall..."
    "Você olha pelos cantos em direção ao corredor..."

# game/atHome.rpy:3322
translate pt_br seekHallway_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3323
translate pt_br seekHallway_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:3324
translate pt_br seekHallway_4e973a05:

    # "Nothing. You're not sure what you were expecting."
    "Nada. Você não tem certeza do que estava esperando."

# game/atHome.rpy:3325
translate pt_br seekHallway_957bcdee:

    # "With all the doors closed..."
    "Com todas as portas fechadas..."

# game/atHome.rpy:3326
translate pt_br seekHallway_148b7481:

    # "There's nowhere in the hall for the cat to hide."
    "Não há onde se esconder no corredor"

# game/atHome.rpy:3336
translate pt_br seekingDone_2b449ce4:

    # "You couldn't find the cat anywhere..."
    "Você não consegue achar o gato em lugar algum..."

# game/atHome.rpy:3337
translate pt_br seekingDone_e2a5632e:

    # "You start to get a little worried when you hear a soft sound coming from... the hall..?"
    "Você começa a ficar um pouco preocupado ao ouvir um som bem baixinho vindo do... corredor..?"

# game/atHome.rpy:3340
translate pt_br seekingDone_dc5e6416:

    # "You head to the hall and listen again."
    "Você vai até o corredor e ouve de novo."

# game/atHome.rpy:3341
translate pt_br seekingDone_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:3342
translate pt_br seekingDone_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3344
translate pt_br seekingDone_d5aac1e5:

    # "{size=-5}*scratch* *scratch*{/size}"
    "{size=-5}*scratch* *scratch*{/size}"

# game/atHome.rpy:3345
translate pt_br seekingDone_90425976:

    # "That sounded like it was coming from... your bedroom... but..."
    "Parece ter vindo do... seu quarto... mas..."

# game/atHome.rpy:3346
translate pt_br seekingDone_4902eb0a:

    # "You walk down the hall to your room and gingerly open the door-"
    "Você caminha pelo corredor até seu quarto e abre a porta com cuidado-"

# game/atHome.rpy:3348
translate pt_br seekingDone_ec1974d4:

    # cat "Meow!" with hpunch
    cat "Miau!" with hpunch

# game/atHome.rpy:3349
translate pt_br seekingDone_e74ed2e1:

    # you "Gah!" with vpunch
    you "Gah!" with vpunch

# game/atHome.rpy:3350
translate pt_br seekingDone_a479bdf3:

    # "The cat trots out and runs around your legs, and meowing insistently."
    "O gato sai em passinhos rápidos e corre ao redor das suas pernas, miando insistentemente."

# game/atHome.rpy:3352
translate pt_br seekingDone_5e84b463:

    # cat "Meow! Meow!"
    cat "Miau! Miau!"

# game/atHome.rpy:3353
translate pt_br seekingDone_5e30cc7e:

    # "It looks... {w}disappointed somehow? {w}Perhaps in your apparently subpar seeking skills..."
    "Ele parece.... {w}decepcionado com você, de alguma forma? {w}Talvez com suas habilidades de caça aparentemente medíocres..."

# game/atHome.rpy:3354
translate pt_br seekingDone_bf0874e3:

    # "But..."
    "Mas..."

# game/atHome.rpy:3355
translate pt_br seekingDone_edd5757f:

    # "You lift the cat into your arms and look at your bedroom door."
    "Você o pega nos braços e olha para a porta do seu quarto."

# game/atHome.rpy:3356
translate pt_br seekingDone_ba8a4d17:

    # you "How did you... get in my room?"
    you "Como você... entrou no meu quarto?"

# game/atHome.rpy:3358
translate pt_br seekingDone_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/atHome.rpy:3359
translate pt_br seekingDone_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:3360
translate pt_br seekingDone_93d1adf7:

    # "You... {w}You {i}know{/i} the door was closed."
    "Você... {w}Você {i}sabe{/i} que a porta estava fechada."

# game/atHome.rpy:3361
translate pt_br seekingDone_31c44218:

    # "{size=-5}Right..?{/size}"
    "{size=-5}Né..?{/size}"

# game/atHome.rpy:3362
translate pt_br seekingDone_be5113cc:

    # "The cat wiggles out of your hold and runs out of the hall."
    "O gato se solta dos seus braços e corre para fora do corredor."

# game/atHome.rpy:3363
translate pt_br seekingDone_dae0ec55_1:

    # you "..."
    you "..."

# game/atHome.rpy:3369
translate pt_br seekingDone_c00c8735:

    # "You follow to see it sitting in the middle of the living room."
    "Você o segue e encontra ele sentado bem no meio da sala."

# game/atHome.rpy:3371
translate pt_br seekingDone_e5fab8a0_1:

    # cat "Meow!"
    cat "Miau!"

# game/atHome.rpy:3374
translate pt_br seekingDone_e131e1c8:

    # "Upon seeing you, the cat promptly turns around."
    "Assim que vê você, ele rapidamente se vira de costas."

# game/atHome.rpy:3375
translate pt_br seekingDone_63775626:

    # "Guess it wants to take its turn seeking?"
    "Acho que agora é a vez dele de procurar, não é?"

# game/atHome.rpy:3376
translate pt_br seekingDone_cc17d7e1:

    # "You're about to indulge it by hiding around the counter again when-"
    "Você está prestes a agradá-lo se escondendo atrás do balcão novamente, quando-"

# game/atHome.rpy:3379
translate pt_br seekingDone_28b3ac41:

    # you "!!"
    you "!!"

# game/atHome.rpy:3380
translate pt_br seekingDone_0cea138b:

    # "The lights... Did the power go out?"
    "As luzes... Será que a energia acabou?"

# game/atHome.rpy:3381
translate pt_br seekingDone_1a77e248:

    # you "Darn it..."
    you "Droga..."

# game/atHome.rpy:3384
translate pt_br seekingDone_5c8a1500:

    # "As you wait for your eyes to adjust to the darkness..."
    "Enquanto espera que seus olhos se ajustem à escuridão..."

# game/atHome.rpy:3388
translate pt_br seekingDone_88a23747:

    # "...you notice that the cat hasn't moved an inch."
    "...você percebe que o gato não se mexeu nem um centímetro."

# game/atHome.rpy:3389
translate pt_br seekingDone_3bb63b1d:

    # "Was it scared?"
    "Ficou assustado?"

# game/atHome.rpy:3390
translate pt_br seekingDone_60b30750:

    # you "Hey, are you-"
    you "Ei, você tá-"

# game/atHome.rpy:3392
translate pt_br seekingDone_b48bd826:

    # "*Badum* *Badum* *Badum*"
    "*Badum* *Badum* *Badum*"

# game/atHome.rpy:3393
translate pt_br seekingDone_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:3394
translate pt_br seekingDone_67aaa788:

    # "What?"
    "O quê?"

# game/atHome.rpy:3395
translate pt_br seekingDone_8e3bedbd:

    # "For some reason..."
    "Por algum motivo..."

# game/atHome.rpy:3396
translate pt_br seekingDone_ecdba21d:

    # "...your heart starts beating faster."
    "...seu coração começa a bater mais rápido."

# game/atHome.rpy:3397
translate pt_br seekingDone_0f5de544:

    # "You..."
    "Você..."

# game/atHome.rpy:3401
translate pt_br seekingDone_ae699357:

    # "You consider going to over to the cat..."
    "Você pensa em ir até o gato..."

# game/atHome.rpy:3402
translate pt_br seekingDone_26358dc1:

    # "But when you do..."
    "Mas, ao fazer isso..."

# game/atHome.rpy:3405
translate pt_br seekingDone_bcc0f247:

    # "...the thought makes you feel..."
    "...a ideia faz você sentir..."

# game/atHome.rpy:3409
translate pt_br seekingDone_84220bdf:

    # you ".."
    you ".."

# game/atHome.rpy:3410
translate pt_br seekingDone_dae0ec55_2:

    # you "..."
    you "..."

# game/atHome.rpy:3411
translate pt_br seekingDone_796928f5:

    # "...You feel like your life is in danger."
    "...Você sente que sua vida está em perigo."

# game/atHome.rpy:3412
translate pt_br seekingDone_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:3413
translate pt_br seekingDone_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:3414
translate pt_br seekingDone_c73db94c:

    # "You need to hide."
    "Você precisa se esconder."

# game/atHome.rpy:3416
translate pt_br seekingDone_e42d7264:

    # "{b}Now.{/b}"
    "{b}Agora.{/b}"

# game/atHome.rpy:3459
translate pt_br time_out_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3468
translate pt_br time_out_ff2c9b51:

    # "You failed."
    "Você falhou."

# game/atHome.rpy:3469
translate pt_br time_out_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:3470
translate pt_br time_out_d4b5152a:

    # "Try again?"
    "Tentar novamente?"

# game/atHome.rpy:3489
translate pt_br hidingArmchair_dfc43610:

    # "No, that's too close. It would find you immediately."
    "Não, é muito perto. Ele te encontraria imediatamente."

# game/atHome.rpy:3494
translate pt_br hidingKitchen_9e1fc511:

    # "You've hidden there before and it found you almost instantly. That won't work."
    "Você já se escondeu lá antes e ele te encontrou quase instantaneamente. Não vai funcionar."

# game/atHome.rpy:3499
translate pt_br hidingHall_6093fc0a:

    # "Just... In the hall?"
    "Apenas... No corredor?"

# game/atHome.rpy:3500
translate pt_br hidingHall_3fe08047:

    # "{size=-5}{b}There's nowhere to {i}hide{/i} in the hall.{/b}{/size}"
    "{size=-5}{b}Não há onde se {i}esconder{/i} no corredor.{/b}{/size}"

# game/atHome.rpy:3510
translate pt_br hidingHallCloset_35447e61:

    # "You quietly slip into the hallway closet..."
    "Você entra silenciosamente para dentro do armário do corredor..."

# game/atHome.rpy:3511
translate pt_br hidingHallCloset_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3512
translate pt_br hidingHallCloset_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/atHome.rpy:3513
translate pt_br hidingHallCloset_3d6395df:

    # "The door won't close because a heavy box is now blocking it after you squeezed inside."
    "A porta não fecha porque uma caixa pesada a está bloqueando depois de você entrar."

# game/atHome.rpy:3514
translate pt_br hidingHallCloset_50bac2df:

    # "If you try to move it further, the cat might hear it."
    "Se você tentar tirá-la do caminho, o gato pode ouvir."

# game/atHome.rpy:3515
translate pt_br hidingHallCloset_19a963ab:

    # "That is, if it hasn't heard you already."
    "Isso é, se ele já não tiver te ouvido."

# game/atHome.rpy:3516
translate pt_br hidingHallCloset_a067a470:

    # "This won't work. You need to hide somewhere else."
    "Isso não vai funcionar. Você precisa se esconder em outro lugar."

# game/atHome.rpy:3517
translate pt_br hidingHallCloset_0c125b36:

    # "Hurry!"
    "Rápido!"

# game/atHome.rpy:3526
translate pt_br hidingBathroom_ee79f861:

    # "You quietly rush to the bathroom and-"
    "Você corre silenciosamente até o banheiro e-"

# game/atHome.rpy:3528
translate pt_br hidingBathroom_823cbce9:

    # "*clink!* *clink!* *clink!*" with hpunch
    "*clink!* *clink!* *clink!*" with hpunch

# game/atHome.rpy:3529
translate pt_br hidingBathroom_24bdca17:

    # you "{i}What?! Why is the door {b}locked?!{/b}{/i}"
    you "{i}O quê?! Por que a porta está {b}trancada?!{/b}{/i}"

# game/atHome.rpy:3530
translate pt_br hidingBathroom_96a60aa2:

    # "You freeze upon realizing how much noise you just made jostling the doorknob and hold your breath."
    "Você congela ao perceber quanto barulho fez mexendo na maçaneta e prende a respiração."

# game/atHome.rpy:3531
translate pt_br hidingBathroom_5650ad03:

    # "Listening..."
    "Ouvindo..."

# game/atHome.rpy:3532
translate pt_br hidingBathroom_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:3533
translate pt_br hidingBathroom_1e37664c:

    # "The silence coming from the living room feels heavier than before. More restless."
    "O silêncio vindo da sala parece mais pesado do que antes. Mais inquieto."

# game/atHome.rpy:3534
translate pt_br hidingBathroom_0df09957:

    # "Even if some miracle opened the door now, it would know exactly where you were. No good."
    "Mesmo se algum milagre abrisse a porta agora, ele saberia exatamente onde você está. Não adianta."

# game/atHome.rpy:3546
translate pt_br hidingBedroom_1ff5c45d:

    # "You quietly rush into the bedroom, carefully closing the door behind you."
    "Você corre silenciosamente para o quarto, fechando a porta atrás de você com cuidado."

# game/atHome.rpy:3547
translate pt_br hidingBedroom_8fc59726:

    # "The only place to hide in your bedroom is your closet."
    "O único lugar para se esconder no seu quarto é o seu armário."

# game/atHome.rpy:3572
translate pt_br hideAndSeekEnd_7a6998e3:

    # "You lock the door as quietly as you can before lunging into the closet and sliding the door shut."
    "Você tranca a porta o mais silenciosamente possível antes de pular para dentro armário e fechá-lo."

# game/atHome.rpy:3573
translate pt_br hideAndSeekEnd_04f7409b:

    # "As soon as you've secured yourself inside the closet..."
    "Assim que você se protege dentro do armário..."

# game/atHome.rpy:3574
translate pt_br hideAndSeekEnd_2aeed70c:

    # "...there's a sudden shift throughout the entire apartment."
    "...há uma súbita mudança em todo o apartamento."

# game/atHome.rpy:3575
translate pt_br hideAndSeekEnd_7dfa20bb:

    # "As if something can sense that you're as ready as you'll ever be..."
    "Como se algo pudesse sentir que você está mais pronto do que nunca..."

# game/atHome.rpy:3576
translate pt_br hideAndSeekEnd_8d5830fc:

    # "As if it can sense..."
    "Como se pudesse sentir..."

# game/atHome.rpy:3577
translate pt_br hideAndSeekEnd_18e07b28:

    # "...that you're ready to be hunted."
    "...que você está pronto para ser caçado."

# game/atHome.rpy:3578
translate pt_br hideAndSeekEnd_c4340c4a:

    # "A horrible chill runs down your spine as you realize that's what this game has become."
    "Um horrível arrepio percorre sua espinha ao perceber que é isso que essa brincadeira se tornou."

# game/atHome.rpy:3579
translate pt_br hideAndSeekEnd_dec1d69c:

    # "This isn't a simple game of hide and seek anymore."
    "Isso não é mais uma simples brincadeira de esconde-esconde."

# game/atHome.rpy:3580
translate pt_br hideAndSeekEnd_db025406:

    # "This is being {i}hunted{/i} by a predator... as prey."
    "É ser {i}caçado{/i} por um predador... como presa."

# game/atHome.rpy:3581
translate pt_br hideAndSeekEnd_90116c90:

    # "It..."
    "Nunca..."

# game/atHome.rpy:3582
translate pt_br hideAndSeekEnd_008b199b:

    # "{size=-10}It never really mattered where you chose to hide, did it?{/size}"
    "{size=-10}Nunca importou onde você escolheu se esconder, importou?{/size}"

# game/atHome.rpy:3584
translate pt_br hideAndSeekEnd_e993f131:

    # "{size=+15}*BAM!!*{/size}" with hpunch
    "{size=+15}*BAM!!*{/size}" with hpunch

# game/atHome.rpy:3585
translate pt_br hideAndSeekEnd_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:3586
translate pt_br hideAndSeekEnd_006cf29b:

    # "As if in answer to your question, you hear a loud slam on the bedroom door."
    "Como se estivesse respondendo a sua pergunta, você ouve uma batida forte na porta do quarto."

# game/atHome.rpy:3587
translate pt_br hideAndSeekEnd_1d63d4b0:

    # "You {i}just{/i} manage to hold back from making a startled noise at the sound."
    "Você {i}mal{/i} consegue segurar um som de susto diante do barulho."

# game/atHome.rpy:3589
translate pt_br hideAndSeekEnd_3523c074:

    # "{size=+20}*BAM!! BAM!!*{/size}" with hpunch
    "{size=+20}*BAM!! BAM!!*{/size}" with hpunch

# game/atHome.rpy:3591
translate pt_br hideAndSeekEnd_981dfd0d:

    # "Your heart rate kicks up again, making it feel hard to breathe quietly. Hard to breathe in general..."
    "Seu coração dispara novamente, dificultando respirar em silêncio. Dificultando respirar em geral..."

# game/atHome.rpy:3593
translate pt_br hideAndSeekEnd_f29fbbed:

    # "{size=+25}*BAM!! BAM!! BAM!!*{/size}" with hpunch
    "{size=+25}*BAM!! BAM!! BAM!!*{/size}" with hpunch

# game/atHome.rpy:3594
translate pt_br hideAndSeekEnd_4331beee:

    # "Tears fill your eyes as you cover your panting mouth with your shaking hands."
    "Lágrimas enchem seus olhos enquanto você cobre a boca ofegante com as mãos trêmulas."

# game/atHome.rpy:3595
translate pt_br hideAndSeekEnd_bc2b365b:

    # "It knows."
    "Ele sabe."

# game/atHome.rpy:3596
translate pt_br hideAndSeekEnd_aa5ace4f:

    # "It {i}{b}knows{/b}{/i}."
    "Ele {i}{b}sabe{/b}{/i}."

# game/atHome.rpy:3597
translate pt_br hideAndSeekEnd_7507be91:

    # "Crying with your hands over your mouth, trying to smother the choked sounds leaking out of you..."
    "Chorando com as mãos sobre a boca, tentando abafar os sons sufocados que escapam de você..."

# game/atHome.rpy:3598
translate pt_br hideAndSeekEnd_30c5f04c:

    # "...you slide down the wall at the back of your closet into a heap on the floor."
    "...você desliza pela parede no fundo do armário até cair em um monte de roupas."

# game/atHome.rpy:3600
translate pt_br hideAndSeekEnd_a785ec8d:

    # "{size=+30}*BAM!! BAM!! BAM!! BAM!! BAM!! BAM!! BAM!!*{/size}" with vpunch
    "{size=+30}*BAM!! BAM!! BAM!! BAM!! BAM!! BAM!! BAM!!*{/size}" with vpunch

# game/atHome.rpy:3602
translate pt_br hideAndSeekEnd_64e5c3aa:

    # "{size=+35}{i}{b}*CRACK!! CRASH!!*{/b}{/i}{/size}" with hpunch
    "{size=+35}{i}{b}*CRACK!! CRASH!!*{/b}{/i}{/size}" with hpunch

# game/atHome.rpy:3603
translate pt_br hideAndSeekEnd_510fa47c:

    # "You flinch harshly at the sound of the door being ripped off its hinges... {w}followed by a loud crash against the wall on the other side of the room..."
    "Você se encolhe bruscamente ao som da porta sendo arrancada das dobradiças... {w}seguido por um estrondo alto contra a parede do outro lado do quarto..."

# game/atHome.rpy:3604
translate pt_br hideAndSeekEnd_d11501ae:

    # "Like the door had been {b}blown{/b} away..."
    "Como se a porta tivesse sido {b}explodida{/b}..."

# game/atHome.rpy:3605
translate pt_br hideAndSeekEnd_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:3606
translate pt_br hideAndSeekEnd_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3607
translate pt_br hideAndSeekEnd_0adc35ae:

    # "The silence that follows... is almost too much to bear."
    "O silêncio que se segue... é quase insuportável."

# game/atHome.rpy:3608
translate pt_br hideAndSeekEnd_40c73218:

    # "You... You can't..."
    "Você... Você não consegue..."

# game/atHome.rpy:3609
translate pt_br hideAndSeekEnd_a822f67c:

    # you "{size=-8}*sob*{/size}" with vpunch
    you "{size=-8}*soluço*{/size}" with vpunch

# game/atHome.rpy:3610
translate pt_br hideAndSeekEnd_48cca663:

    # "A single sob escapes through your nose."
    "Um único soluço escapa pelo seu nariz."

# game/atHome.rpy:3611
translate pt_br hideAndSeekEnd_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:3612
translate pt_br hideAndSeekEnd_a56b7772:

    # "You squeeze your eyes shut in defeat at how loud it sounds in the quiet of the room."
    "Você aperta os olhos, derrotado, consciente do quão alto soou na quietude do quarto."

# game/atHome.rpy:3613
translate pt_br hideAndSeekEnd_944d62b1:

    # "Not much point in hiding it anymore anyway, is there?"
    "De qualquer forma, não há muito sentido em tentar esconder isso agora, não é?"

# game/atHome.rpy:3614
translate pt_br hideAndSeekEnd_54d98921:

    # "You instinctively put whatever energy you have left into listening for footsteps.."
    "Instintivamente, você junta o resto da sua energia para ouvir os passos..."

# game/atHome.rpy:3615
translate pt_br hideAndSeekEnd_f054e4f2:

    # "...even as you emotionally shut down."
    "...mesmo enquanto se desliga emocionalmente."

# game/atHome.rpy:3616
translate pt_br hideAndSeekEnd_ba5567da:

    # "But you hear nothing."
    "Mas você não ouve nada."

# game/atHome.rpy:3617
translate pt_br hideAndSeekEnd_97d7e1ff:

    # "...Nothing."
    "...Nada."

# game/atHome.rpy:3618
translate pt_br hideAndSeekEnd_b1eedee3:

    # "... {w}...Nothing."
    "... {w}...Nada."

# game/atHome.rpy:3619
translate pt_br hideAndSeekEnd_f64ee9d8:

    # "Then..."
    "Então..."

# game/atHome.rpy:3620
translate pt_br hideAndSeekEnd_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:3622
translate pt_br hideAndSeekEnd_1ae26af9:

    # "{size=-10}*Shhhheeee*{/size}"
    "{size=-10}*Shhhheeee*{/size}"

# game/atHome.rpy:3623
translate pt_br hideAndSeekEnd_56ebb028:

    # you "!!!"
    you "!!!"

# game/atHome.rpy:3624
translate pt_br hideAndSeekEnd_973413d4:

    # "Something..."
    "Algo..."

# game/atHome.rpy:3625
translate pt_br hideAndSeekEnd_cc2670ce:

    # "...slides open the closet door."
    "...abre a porta do armário."

# game/atHome.rpy:3628
translate pt_br hideAndSeekEnd_d3ef84de:

    # "You've curled in on yourself."
    "Você se encolhe."

# game/atHome.rpy:3629
translate pt_br hideAndSeekEnd_37dac42d:

    # "Knees up... {w}Back curved forward... {w}Head down... {w}Mouth covered... {w}Eyes shut tight, so tight it hurts."
    "Joelhos levantados... {w}Costas curvadas para frente... {w}Cabeça baixa... {w}Boca coberta... {w}Olhos tão apertados que chegam a doer."

# game/atHome.rpy:3630
translate pt_br hideAndSeekEnd_169ad8da:

    # "You don't want to look."
    "Você não quer olhar."

# game/atHome.rpy:3631
translate pt_br hideAndSeekEnd_9be26059:

    # "You don't want to {i}{b}look{/b}{/i}."
    "Você não quer {i}{b}olhar{/b}{/i}."

# game/atHome.rpy:3632
translate pt_br hideAndSeekEnd_9288147d:

    # "But that's what it's waiting for."
    "Mas é isso que ele está esperando."

# game/atHome.rpy:3633
translate pt_br hideAndSeekEnd_b4897419:

    # "It won't end you without this final act of cruelty."
    "Não vai acabar com você sem esse último ato de crueldade."

# game/atHome.rpy:3634
translate pt_br hideAndSeekEnd_38e8ce5b:

    # "Of making you {b}look{/b} at it before it takes your life."
    "De fazer você {b}olhar{/b} para ele, antes de tomar sua vida."

# game/atHome.rpy:3635
translate pt_br hideAndSeekEnd_f6781194:

    # "So... {i}so{/i} cruel."
    "Tão... {i}tão{/i} cruel."

# game/atHome.rpy:3636
translate pt_br hideAndSeekEnd_3964a50d:

    # "You just want this to be over..."
    "Você só quer que isso acabe..."

# game/atHome.rpy:3637
translate pt_br hideAndSeekEnd_42b896f8:

    # "So..."
    "Então..."

# game/atHome.rpy:3638
translate pt_br hideAndSeekEnd_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:3639
translate pt_br hideAndSeekEnd_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:3641
translate pt_br hideAndSeekEnd_07ae2bce:

    # "...you open your eyes."
    "...você abre os olhos."

# game/atHome.rpy:3660
translate pt_br hideAndSeekEnd_05f9ce7c:

    # "You see... {w}{i}something...{/i} {w}glaring in at you from the darkness beyond the closet door."
    "Você vê... {w}{i}alguma coisa...{/i} {w}encarando você da escuridão além da porta do armário."

# game/atHome.rpy:3661
translate pt_br hideAndSeekEnd_532712c0:

    # "It looks..."
    "Ele parece..."

# game/atHome.rpy:3662
translate pt_br hideAndSeekEnd_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:3663
translate pt_br hideAndSeekEnd_c5599256:

    # "...disappointed."
    "...decepcionado."

# game/atHome.rpy:3666
translate pt_br hideAndSeekEnd_e501a69b:

    # "In the moment before you draw your last breath, you almost consider apologizing for being such unworthy prey."
    "No momento antes de você dar seu último suspiro, quase considera se desculpar por ser uma presa tão indigna."

# game/atHome.rpy:3667
translate pt_br hideAndSeekEnd_fdce8679:

    # "Guess your hiding skills were just as subpar as your seeking skills."
    "Pelo visto suas habilidades de esconder eram tão medíocres quanto as suas habilidades de caça."

# game/atHome.rpy:3668
translate pt_br hideAndSeekEnd_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:3669
translate pt_br hideAndSeekEnd_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:3670
translate pt_br hideAndSeekEnd_bebf47e2:

    # "Ending 13: Disappointing Prey"
    "Final 13: Presa Decepcionante"

# game/atHome.rpy:3684
translate pt_br hidingGetOut_d6bdd900:

    # "You're halfway to the front door when-{w=0.75}{nw}"
    "Você está no meio do caminho até a porta da frente, quando-{w=0.75}{nw}"

# game/atHome.rpy:3698
translate pt_br hidingGetOut_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:3699
translate pt_br hidingGetOut_dec8c6c7:

    # "You look at the door and see several more locks over it than you {i}know{/i} you have."
    "Você olha para a porta e vê vários trincos a mais do que {i}sabe{/i} que tem."

# game/atHome.rpy:3700
translate pt_br hidingGetOut_3df65a5c:

    # "You peek over at the cat. It's not looking at you but..."
    "Você dá uma espiada no gato. Ele não está olhando para você, mas..."

# game/atHome.rpy:3701
translate pt_br hidingGetOut_5b6ca7ca:

    # "...You feel a wave of disappointment practically pouring from it into you."
    "...Você sente uma onda de decepção quase transbordar dele para você."

# game/atHome.rpy:3702
translate pt_br hidingGetOut_298892a1:

    # "It feels almost..."
    "Parece quase..."

# game/atHome.rpy:3703
translate pt_br hidingGetOut_050be7e5:

    # "...like a warning."
    "...como um aviso."

# game/atHome.rpy:3704
translate pt_br hidingGetOut_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:3705
translate pt_br hidingGetOut_b0ee1743:

    # "You back away from the door and the feeling slowly subsides, letting you breathe again."
    "Você se afasta da porta, e a sensação lentamente se dissipa, permitindo que você respire novamente."

# game/atHome.rpy:3706
translate pt_br hidingGetOut_d9de9905:

    # "There's no getting out then."
    "Não tem saída então."

# game/atHome.rpy:3707
translate pt_br hidingGetOut_c73db94c:

    # "You need to hide."
    "Você precisa se esconder."

# game/atHome.rpy:3714
translate pt_br hidingSitOnCouch_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3715
translate pt_br hidingSitOnCouch_e26ed14e:

    # "Are you joking?"
    "Tá de sacanagem?"

# game/atHome.rpy:3716
translate pt_br hidingSitOnCouch_85ef84c7:

    # "You get the feeling the cat won't appreciate your lack of effort, and anyway..."
    "Você tem a impressão de que o gato não vai gostar da sua falta de empenho, e de qualquer forma..."

# game/atHome.rpy:3717
translate pt_br hidingSitOnCouch_aa165348:

    # "{size=-8}...like {b}hell{/b} are you getting any closer to it.{/size}"
    "{size=-8}...nem {b}fudendo{/b} você vai chegar mais perto dele.{/size}"

# game/atHome.rpy:3718
translate pt_br hidingSitOnCouch_8d4b014b:

    # "Stop messing around and find a place to hide."
    "Pare de enrolar e encontre um lugar para se esconder."

# game/atHome.rpy:3725
translate pt_br cleanCat_1f0122ea:

    # "Upon giving it a second look..."
    "Reparando bem..."

# game/atHome.rpy:3726
translate pt_br cleanCat_73bbf6e8:

    # "...you realize that the cat isn't exactly clean."
    "...você percebe que o gato não está muito limpo."

# game/atHome.rpy:3727
translate pt_br cleanCat_2dad982f:

    # "Not surprising since up until you brought it home, it's been sitting in a dirty, old box..."
    "O que não é surpresa, já que, até você trazê-lo para casa, ele estava em uma caixa velha e suja..."

# game/atHome.rpy:3728
translate pt_br cleanCat_3e60fb93:

    # "...in an alley full of scattered garbage... {w}for who knows how long..."
    "...em um beco cheio de lixo espalhado... {w}por sabe-se lá quanto tempo..."

# game/atHome.rpy:3729
translate pt_br cleanCat_b2b50516:

    # "You've heard that cats can keep themselves clean..."
    "Você já ouviu dizer que gatos conseguem se limpar sozinhos..."

# game/atHome.rpy:3730
translate pt_br cleanCat_8a02a14f:

    # "...but maybe this is one of those times that a little human help couldn't hurt?"
    "...mas talvez essa seja uma daquelas vezes em que um pouco de ajuda humana não faria mal?"

# game/atHome.rpy:3736
translate pt_br cleanCat_e97a3dc8:

    # "You head into the bathroom and set things up, trying to remember how to wash a cat."
    "Você vai até o banheiro e arruma tudo, tentando se lembrar de como dar banho em um gato."

# game/atHome.rpy:3737
translate pt_br cleanCat_e263c12b:

    # "You're definitely no expert but you think the best way to get a cat clean would be..."
    "Você definitivamente não é nenhum especialista, mas acha que a melhor maneira de limpar um gato seria..."

# game/atHome.rpy:3746
translate pt_br cleanQuick_78d7a181:

    # "Cats don't like water, you think..."
    "Gatos não gostam de água, você pensa..."

# game/atHome.rpy:3747
translate pt_br cleanQuick_4e407771:

    # "So a quick wash would be the way to go, right?"
    "Então, o ideal seria um banho rápido, certo?"

# game/atHome.rpy:3748
translate pt_br cleanQuick_7f064cd9:

    # "You decide to do everything at once, filling the tub deep with soapy, bubbly warm water."
    "Você decide fazer tudo de uma vez, enchendo a banheira com água morna e espumante."

# game/atHome.rpy:3749
translate pt_br cleanQuick_c39a4c6e:

    # "A quick dunk here, a short scrubbing there, then rinse and dry."
    "Um mergulho rápido aqui, uma esfregada ali, depois enxaguar e secar."

# game/atHome.rpy:3750
translate pt_br cleanQuick_9e8e5dea:

    # "The cat won't even know what hit it before everything's over."
    "O gato nem vai entender o que aconteceu antes de tudo terminar."

# game/atHome.rpy:3751
translate pt_br cleanQuick_71d98443:

    # "You open the door and click your tongue, beckoning the cat inside."
    "Você abre a porta e estala a língua, chamando o gato para entrar."

# game/atHome.rpy:3752
translate pt_br cleanQuick_85ffbc84:

    # "It quickly scampers in, curious of the newly available setting."
    "Ele rapidamente corre para dentro, curioso com o novo ambiente acessível."

# game/atHome.rpy:3756
translate pt_br cleanQuick_03c62019:

    # "You close the door so it won't be able to run out and make a mess of the apartment..."
    "Você fecha a porta para evitar que ele fuja e bagunce o apartamento..."

# game/atHome.rpy:3757
translate pt_br cleanQuick_9f0ef82a:

    # "Steeling yourself, you roll up your sleeves."
    "Respirando fundo, você arregaça as mangas."

# game/atHome.rpy:3760
translate pt_br cleanQuick_f62bf066:

    # "You lift up the cat and carry it over to the tub."
    "Levanta o gato e o leva até a banheira."

# game/atHome.rpy:3761
translate pt_br cleanQuick_4b2a2198:

    # "Your plan's already compromised as the cat starts to struggle in your hold."
    "Seu plano começa a ser comprometido quando o gato começa a se debater nos seus braços."

# game/atHome.rpy:3762
translate pt_br cleanQuick_83e9b6c8:

    # "You probably should've held it so it couldn't see the water?"
    "Você provavelmente deveria tê-lo segurado de forma que ele não visse a água?"

# game/atHome.rpy:3767
translate pt_br cleanQuick_1422090a:

    # you "Ow! Ow, hey!"
    you "Ai! Ai, ei!"

# game/atHome.rpy:3768
translate pt_br cleanQuick_26e1e230:

    # "It scratches at your arms. {w}You knew it wouldn't be happy about the water..."
    "Ele arranha seus braços. {w}Você já esperava que ele não fosse gostar da água..."

# game/atHome.rpy:3769
translate pt_br cleanQuick_5f15c75c:

    # "...but you didn't think it'd be {i}this{/i} irate."
    "...mas não imaginava que ficaria {i}tão{/i} furioso."

# game/atHome.rpy:3770
translate pt_br cleanQuick_2b5c1bb2:

    # "Still, as mad as it will be at you for a little while... {w}you know this is for the best."
    "Ainda assim, por mais irritado que ele fique por um tempo... {w}você sabe que isso é para o bem dele."

# game/atHome.rpy:3776
translate pt_br cleanQuick_5bf8a6d7:

    # "A deep scratch to your bicep startles you..."
    "Você se assusta com um arranhão profundo no seu bíceps..."

# game/atHome.rpy:3780
translate pt_br cleanQuick_b7d98ebe:

    # "...making you drop the cat into the tub."
    "...fazendo você largar o gato na banheira."

# game/atHome.rpy:3786
translate pt_br cleanQuick_0e4fefa1:

    # cat "{size=+10}MREAWWRRR!!!{/size}" with hpunch
    cat "{size=+10}MIIAAAAAUUU!!!{/size}" with hpunch

# game/atHome.rpy:3788
translate pt_br cleanQuick_53f96c50:

    # "{size=+20}{b}SPLASH!!{/b}{/size}" with vpunch
    "{size=+20}{b}SPLASH!!{/b}{/size}" with vpunch

# game/atHome.rpy:3789
translate pt_br cleanQuick_4ab5e1b8:

    # you "!! Shoot! Kitty?!"
    you "!! Merda! Gatinho?!"

# game/atHome.rpy:3790
translate pt_br cleanQuick_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3793
translate pt_br cleanQuick_9755cc74:

    # "The cat doesn't reemerge hissing and yowling like you thought it would."
    "O gato não emerge chiando e miando como você pensou que faria."

# game/atHome.rpy:3794
translate pt_br cleanQuick_56ebb028:

    # you "!!!"
    you "!!!"

# game/atHome.rpy:3795
translate pt_br cleanQuick_d3c199bb:

    # "You rush over and dunk your arms beneath the soapy surface, searching for the cat."
    "Você corre até a banheira e enfia os braços na superfície espumosa, procurando pelo gato."

# game/atHome.rpy:3796
translate pt_br cleanQuick_28c52c35:

    # "What if it bumped its head and blacked out?! It would drown!"
    "E se ele bateu a cabeça e desmaiou?! Ele pode se afogar!"

# game/atHome.rpy:3797
translate pt_br cleanQuick_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:3798
translate pt_br cleanQuick_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:3799
translate pt_br cleanQuick_da164869:

    # "But you don't find the cat."
    "Mas você não encontra o gato."

# game/atHome.rpy:3800
translate pt_br cleanQuick_4cb92d86:

    # "Instead..."
    "Em vez disso..."

# game/atHome.rpy:3805
translate pt_br cleanQuick_6d15e014:

    # you "..?! What the..?"
    you "..?! Mas que..?"

# game/atHome.rpy:3806
translate pt_br cleanQuick_37bc76a0:

    # "...you watch as the water starts to darken."
    "...você observa enquanto a água começa a escurecer."

# game/atHome.rpy:3807
translate pt_br cleanQuick_bbf488b7:

    # "At first, you think it's just dirt from the cat and feel a little vindicated about your decision, but..."
    "A princípio, você acha que é apenas sujeira do gato e sente que sua decisão foi justificada, mas..."

# game/atHome.rpy:3813
translate pt_br cleanQuick_1cd5e3cc:

    # "...the water darkens further and further..."
    "...a água escurece cada vez mais..."

# game/atHome.rpy:3816
translate pt_br cleanQuick_0d858457:

    # "...until it looks like you've filled your tub with {i}black ink{/i}, rather than water."
    "...até parecer que você encheu a banheira com {i}tinta preta{/i}, em vez de água."

# game/atHome.rpy:3817
translate pt_br cleanQuick_b024b629:

    # "Even the soap bubbles are a transculent obsidian now..."
    " Até as bolhas de sabão agora têm uma tonalidade obsidiana translúcida..."

# game/atHome.rpy:3818
translate pt_br cleanQuick_5d31ed33:

    # you "This is..."
    you "Isso é..."

# game/atHome.rpy:3819
translate pt_br cleanQuick_0667ddd5:

    # "Something's... not right."
    "Alguma coisa... não está certa."

# game/atHome.rpy:3820
translate pt_br cleanQuick_28ef0d48:

    # "But as soon as you have this thought-"
    "Mas assim que você pensa nisso-"

# game/atHome.rpy:3821
translate pt_br cleanQuick_c27265ab:

    # "!!!" with vpunch
    "!!!" with vpunch

# game/atHome.rpy:3822
translate pt_br cleanQuick_8825e5a8:

    # you "W-Whoa!"
    you "O-Opa!"

# game/atHome.rpy:3823
translate pt_br cleanQuick_8dabefc6_1:

    # ".."
    ".."

# game/atHome.rpy:3824
translate pt_br cleanQuick_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:3825
translate pt_br cleanQuick_f51b5d50:

    # "You just..."
    "Você acabou de..."

# game/atHome.rpy:3826
translate pt_br cleanQuick_2703b498:

    # "You just felt something tugging you from under the water."
    "Você acabou de sentir algo puxando você debaixo da água."

# game/atHome.rpy:3827
translate pt_br cleanQuick_04ac177f:

    # "You try to pull away... but your arm won't budge."
    "Você tenta se afastar... mas seu braço não se mexe."

# game/atHome.rpy:3828
translate pt_br cleanQuick_1e1011d4:

    # "Whatever it is, it pulls you closer toward the water."
    "Seja lá o que for, te puxa em direção à água."

# game/atHome.rpy:3829
translate pt_br cleanQuick_ea4d65f2:

    # "You try to use your free hand to release the drain plug..."
    "Você tenta usar a mão livre para soltar a tampa do ralo..."

# game/atHome.rpy:3830
translate pt_br cleanQuick_49f8d758:

    # "...but when you dunk your other arm in the water without thinking..."
    "...mas, ao mergulhar o outro braço na água sem pensar..."

# game/atHome.rpy:3831
translate pt_br cleanQuick_af07684a:

    # "...it's grabbed {i}too.{/i}"
    "...ele {i}também{/i} é agarrado."

# game/atHome.rpy:3832
translate pt_br cleanQuick_7bc9d3d3:

    # "Both hands restrained, you can't get any leverage to force yourself free."
    "Com as duas mãos imobilizadas, você não consegue encontrar um jeito de se soltar."

# game/atHome.rpy:3833
translate pt_br cleanQuick_9b4985ab:

    # you "H-HEL-"
    you "S-SOCOR-"

# game/atHome.rpy:3837
translate pt_br cleanQuick_959e6733:

    # "{size=+30}{b}{i}SPLASH!!{/i}{/b}{/size}" with vpunch
    "{size=+30}{b}{i}SPLASH!!{/i}{/b}{/size}" with vpunch

# game/atHome.rpy:3839
translate pt_br cleanQuick_8dabefc6_2:

    # ".."
    ".."

# game/atHome.rpy:3840
translate pt_br cleanQuick_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:3841
translate pt_br cleanQuick_9920ee06:

    # "You're dragged into the murky waters of the tub."
    "Você é arrastado para as águas turvas da banheira."

# game/atHome.rpy:3842
translate pt_br cleanQuick_d4cb78f0:

    # "You're dragged down..."
    "Você é puxado para baixo..."

# game/atHome.rpy:3843
translate pt_br cleanQuick_803774b5:

    # "And down..."
    "E para baixo..."

# game/atHome.rpy:3844
translate pt_br cleanQuick_292fd1e4:

    # "And down further still..."
    "E ainda mais para baixo..."

# game/atHome.rpy:3845
translate pt_br cleanQuick_effa8a23:

    # "Much farther than it should be possible for your bathtub..."
    "Muito mais do que deveria ser possível para a sua banheira..."

# game/atHome.rpy:3846
translate pt_br cleanQuick_0f5de544:

    # "You..."
    "Você..."

# game/atHome.rpy:3847
translate pt_br cleanQuick_89ffaa13:

    # "You can't breathe."
    "Você não consegue respirar."

# game/atHome.rpy:3848
translate pt_br cleanQuick_6ff0ecd8:

    # "You think you can't see either but..."
    "Você pensa que também não consegue ver, mas..."

# game/atHome.rpy:3849
translate pt_br cleanQuick_c4107513:

    # "...as you draw your final breath..."
    "...à medida que suspira pela última vez..."

# game/atHome.rpy:3853
translate pt_br cleanQuick_19e72cc3:

    # "...you think you see what has been pulling you down."
    "...você acha que vê o que está te puxando para baixo."

# game/atHome.rpy:3854
translate pt_br cleanQuick_3be28426:

    # "Something resting deep, deep down below..."
    "Algo repousando bem, bem lá no fundo..."

# game/atHome.rpy:3855
translate pt_br cleanQuick_117208a3:

    # "Something waiting..."
    "Algo esperando..."

# game/atHome.rpy:3856
translate pt_br cleanQuick_a20cefa7_4:

    # "..."
    "..."

# game/atHome.rpy:3857
translate pt_br cleanQuick_3c2769fc:

    # "...for {i}you.{/i}"
    "...por {i}você.{/i}"

# game/atHome.rpy:3860
translate pt_br cleanQuick_a20cefa7_5:

    # "..."
    "..."

# game/atHome.rpy:3861
translate pt_br cleanQuick_e75202ef:

    # "Ending 14: Bath Hater"
    "Final 14: Anti-Banho"

# game/atHome.rpy:3873
translate pt_br cleanCareful_76034b76:

    # "You think careful is the way to go."
    "Você acha que ser cuidadoso é a melhor opção."

# game/atHome.rpy:3874
translate pt_br cleanCareful_753310b5:

    # "Cats aren't always fond of water, so you doubt it'll be a fan of an excessive amount of it."
    "Gatos nem sempre gostam de água, então você duvida que ele vá gostar de uma quantidade exagerada."

# game/atHome.rpy:3875
translate pt_br cleanCareful_1e17f067:

    # "So you pick the cat up and place it gently in the sink, before turning on the water."
    "Assim, você pega o gato e o coloca gentilmente na pia, antes de abrir a torneira."

# game/atHome.rpy:3877
translate pt_br cleanCareful_ec1974d4:

    # cat "Meow!" with hpunch
    cat "Miau!" with hpunch

# game/atHome.rpy:3878
translate pt_br cleanCareful_0e8202cd:

    # "The cat is startled but ultimately..."
    "O gato fica assustado, mas no fim das contas..."

# game/atHome.rpy:3879
translate pt_br cleanCareful_0a111937:

    # "...doesn't try to run away!"
    "...não tenta fugir!"

# game/atHome.rpy:3880
translate pt_br cleanCareful_52edc0ce:

    # "Nice."
    "Que bom."

# game/atHome.rpy:3891
translate pt_br cleanCareful_8897c5e8:

    # "You lather your hands with some soap and carefully give the cat a thorough half-scrub, half-massage."
    "Você ensaboa as mãos e cuidadosamente alterna entre esfregar e massagear o gato."

# game/atHome.rpy:3893
translate pt_br cleanCareful_f506c017:

    # "After a few minutes, you rinse the cat completely and gather it up in a blanket, drying it."
    "Depois de alguns minutos, você enxágua o gato por completo e o envolve em um cobertor, secando-o."

# game/atHome.rpy:3894
translate pt_br cleanCareful_0d9cd6eb:

    # "Then you take a brush and carefully run it through the cat's fur."
    "Então você pega uma escova e cuidadosamente penteia o pelo do gato."

# game/atHome.rpy:3896
translate pt_br cleanCareful_57f9ada2:

    # cat "Purr... Purr... Purrr..."
    cat "Purr... Purr... Purr..."

# game/atHome.rpy:3897
translate pt_br cleanCareful_1d903d7d:

    # "The cat seems like it's in heaven as you brush it."
    "O gato parece estar no paraíso enquanto você o escova."

# game/atHome.rpy:3898
translate pt_br cleanCareful_079980a1:

    # "Some hairs are sticking to you, but you don't... mind..."
    "Alguns pelos ficam grudados em você, mas você não... se importa..."

# game/atHome.rpy:3900
translate pt_br cleanCareful_40d9ca73:

    # "..?"
    "..?"

# game/atHome.rpy:3903
translate pt_br cleanCareful_c3f6a165:

    # "In fact..."
    "Na verdade..."

# game/atHome.rpy:3906
translate pt_br cleanCareful_c94a020a:

    # "...quite a {i}lot{/i} of fur is sticking on you."
    "...grudou {i}muito{/i} pelo em você."

# game/atHome.rpy:3909
translate pt_br cleanCareful_65471dfb:

    # "You try to brush it away but it won’t come off."
    "Você tenta tirar usando a escova, mas não quer sair."

# game/atHome.rpy:3910
translate pt_br cleanCareful_5b936bac:

    # "Guess you're up next for a bath yourself..."
    "Parece que você também vai precisar de um banho..."

# game/atHome.rpy:3912
translate pt_br cleanCareful_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/atHome.rpy:3913
translate pt_br cleanCareful_dae0ec55:

    # you "..."
    you "..."

# game/atHome.rpy:3916
translate pt_br cleanCareful_da765a9f:

    # "You try to ignore the fur and finish with the cat quickly, but more hair keeps sticking to you."
    "Você tenta ignorar os pelos e terminar rápido com o gato, mas cada vez mais continuam grudando em você."

# game/atHome.rpy:3917
translate pt_br cleanCareful_ffccba96:

    # "Your hands, your arms.."
    "Suas mãos, seus braços.."

# game/atHome.rpy:3918
translate pt_br cleanCareful_711ff096:

    # "Before you realize it, they’re covered in fur that won’t come off."
    "Antes que perceba, está cobertos de pelos que não saem."

# game/atHome.rpy:3919
translate pt_br cleanCareful_52386fff:

    # "It’s thick enough that you try to just yank it off but-"
    "Está tão denso que você tenta simplesmente puxar, mas-"

# game/atHome.rpy:3923
translate pt_br cleanCareful_c4b43d4e:

    # you "Ow! What..?"
    you "Ai! O quê...?"

# game/atHome.rpy:3924
translate pt_br cleanCareful_22aea2b6:

    # "Pain lances through the spot you tugged at."
    "Uma dor aguda atravessa o ponto onde você puxou."

# game/atHome.rpy:3925
translate pt_br cleanCareful_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/atHome.rpy:3926
translate pt_br cleanCareful_197758f7:

    # "Upon closer inspection... {w}you see that the hair is..."
    "Olhando mais de perto... {w}você vê que os pelos estão..."

# game/atHome.rpy:3927
translate pt_br cleanCareful_68e96464:

    # "...{i}growing{/i}..."
    "...{i}crescendo{/i}..."

# game/atHome.rpy:3928
translate pt_br cleanCareful_a20cefa7:

    # "..."
    "..."

# game/atHome.rpy:3929
translate pt_br cleanCareful_80ea14b2:

    # "{size=-5}{b}...growing {i}out{/i} of you.{/b}{/size}"
    "{size=-5}{b}...crescendo {i}de{/i} você.{/b}{/size}"

# game/atHome.rpy:3930
translate pt_br cleanCareful_01e37002:

    # you "Ah... Ah..!"
    you "Ah... Ah..!"

# game/atHome.rpy:3934
translate pt_br cleanCareful_1ce5a910:

    # "You can actually {b}feel{/b} it now."
    "Você consegue {b}sentir{/b} agora."

# game/atHome.rpy:3937
translate pt_br cleanCareful_b86f7ef8:

    # "Fur {i}growing{/i} out of your back, your neck..."
    "Pelo {i}crescendo{/i} de suas costas, seu pescoço..."

# game/atHome.rpy:3940
translate pt_br cleanCareful_12fc6531:

    # "your face..."
    "seu rosto..."

# game/atHome.rpy:3943
translate pt_br cleanCareful_f9ae2b18:

    # "your eyes..."
    "seus olhos..."

# game/atHome.rpy:3946
translate pt_br cleanCareful_3489b447:

    # "your tongue..."
    "sua língua..."

# game/atHome.rpy:3949
translate pt_br cleanCareful_eeaf3b6e:

    # "It's even growing inside your {i}throat-{/i}"
    "Está crescendo até mesmo dentro da sua {i}garganta-{/i}"

# game/atHome.rpy:3952
translate pt_br cleanCareful_06b758f9:

    # you "*Gasp!* *Cough!* *Cough!*" with vpunch
    you "*Gasp!* *Cof!* *Cof!*" with vpunch

# game/atHome.rpy:3962
translate pt_br cleanCareful_8dabefc6:

    # ".."
    ".."

# game/atHome.rpy:3963
translate pt_br cleanCareful_a20cefa7_1:

    # "..."
    "..."

# game/atHome.rpy:3964
translate pt_br cleanCareful_1d671d77:

    # "As you collapse and start to choke on the thickening fur in your esophagus..."
    "Enquanto você cai no cão e começa a sufocar com os pelos que engrossam em seu esôfago..."

# game/atHome.rpy:3965
translate pt_br cleanCareful_dae75121:

    # "...the cat leans up to lap at the fur growing on your forehead..."
    "...o gato se inclina e começa a lamber o pelo que cresce em sua testa..."

# game/atHome.rpy:3966
translate pt_br cleanCareful_cb7d4fad:

    # "...grooming your hair as thoroughly as you did for it earlier."
    "...limpando seus pelos tão cuidadosamente quanto você fez por ele mais cedo."

# game/atHome.rpy:3968
translate pt_br cleanCareful_b53c4107:

    # cat "Purr... Purrr..."
    cat "Purr... Purrr..."

# game/atHome.rpy:3969
translate pt_br cleanCareful_96b21532:

    # "You think it’d be sweet... {w}if you weren’t currently losing air."
    "Você pensa que seria até adorável... {w}se não estivesse ficando sem ar."

# game/atHome.rpy:3970
translate pt_br cleanCareful_ba1d39d4:

    # "Still."
    "Ainda assim."

# game/atHome.rpy:3971
translate pt_br cleanCareful_ebb0a00f:

    # "Feels nice at least... {w}to be looked after and cared for in some way."
    "É reconfortante, pelo menos... {w}ser cuidado e mimado de alguma forma."

# game/atHome.rpy:3972
translate pt_br cleanCareful_c9790759:

    # "Even if it's just for a little while longer."
    "Mesmo que seja só por mais um breve momento."

# game/atHome.rpy:3973
translate pt_br cleanCareful_4d45e938:

    # "The cat’s careful grooming is the last thing you feel..."
    "A cuidadosa limpeza do gato é a última coisa que você sente..."

# game/atHome.rpy:3974
translate pt_br cleanCareful_a20cefa7_2:

    # "..."
    "..."

# game/atHome.rpy:3975
translate pt_br cleanCareful_2ed36266:

    # "...before you’re no longer able to breath."
    "...antes de não conseguir mais respirar."

# game/atHome.rpy:3976
translate pt_br cleanCareful_a20cefa7_3:

    # "..."
    "..."

# game/atHome.rpy:3977
translate pt_br cleanCareful_dc678fac:

    # "Ending 15: Self-Care Buddies"
    "Final 15: Amigões Vaidosos"

translate pt_br strings:

    # game/atHome.rpy:521
    old "Do something alone."
    new "Fazer algo sozinho."

    # game/atHome.rpy:521
    old "Do something with cat."
    new "Fazer algo com o gato."

    # game/atHome.rpy:530
    old "Clean apartment"
    new "Limpar o apartamento"

    # game/atHome.rpy:530
    old "Watch a movie"
    new "Assistir um filme"

    # game/atHome.rpy:530
    old "Take a nap"
    new "Tirar uma soneca"

    # game/atHome.rpy:530
    old "On second thought..."
    new "Pensando bem..."

    # game/atHome.rpy:541
    old "Pet cat"
    new "Acariciar o gato"

    # game/atHome.rpy:541
    old "Feed cat"
    new "Alimentar o gato"

    # game/atHome.rpy:541
    old "Play with cat"
    new "Brincar com o gato"

    # game/atHome.rpy:541
    old "Clean cat"
    new "Limpar o gato"

    # game/atHome.rpy:598
    old "Keep cleaning"
    new "Continuar limpando"

    # game/atHome.rpy:598
    old "Catch cat in the act"
    new "Pegar o gato no flagra"

    # game/atHome.rpy:961
    old "Sit on the floor."
    new "Sentar no chão."

    # game/atHome.rpy:961
    old "Reclaim your throne."
    new "Reivindicar seu trono."

    # game/atHome.rpy:1230
    old "You saw something."
    new "Você viu algo."

    # game/atHome.rpy:1230
    old "You {i}definitely{/i} saw something"
    new "Você {i}definitivamente{/i} viu algo"

    # game/atHome.rpy:1412
    old "Move the cat."
    new "Tirar o gato."

    # game/atHome.rpy:1412
    old "Sleep next to cat"
    new "Dormir ao lado do gato"

    # game/atHome.rpy:1412
    old "Do something else"
    new "Ir fazer outra coisa"

    # game/atHome.rpy:1431
    old "Move the cat?"
    new "Tirar o gato?"

    # game/atHome.rpy:1431
    old "Keep trying. This is {i}your{/i} bed."
    new "Continuar tentando. Essa cama é {i}sua{/i}."

    # game/atHome.rpy:1448
    old "Again. You WILL sleep in your own bed."
    new "De novo. Você VAI dormir na sua cama."

    # game/atHome.rpy:1448
    old "I don't know. It sounds mad..."
    new "Não sei não. Ele parece bravo..."

    # game/atHome.rpy:1470
    old "{size=-5}Move the cat?{/size}"
    new "{size=-5}Tirar o gato?{/size}"

    # game/atHome.rpy:1470
    old "Move. The. Cat."
    new "Tirar. O. Gato."

    # game/atHome.rpy:1470
    old "Seriously last chance. You {i}really{/i} want to do this?"
    new "Sério, última chance. Você quer fazer isso {i}mesmo{/i}?"

    # game/atHome.rpy:1776
    old "Keep petting"
    new "Continuar acariciando"

    # game/atHome.rpy:1776
    old "Let's do something else..."
    new "Vamos fazer outra coisa..."

    # game/atHome.rpy:1802
    old "Keep petting..."
    new "Continuar acariciando..."

    # game/atHome.rpy:1802
    old "That's enough. Let's do something else."
    new "Já chega. Vamos fazer outra coisa."

    # game/atHome.rpy:1828
    old "...{i}Keep{/i} petting."
    new "...{i}Continuar{/i} acariciando."

    # game/atHome.rpy:1828
    old "{b}Seriously...{/b} Let's do something else."
    new "{b}Sério...{/b} Vamos fazer outra coisa."

    # game/atHome.rpy:2056
    old "Tuna"
    new "Atum"

    # game/atHome.rpy:2056
    old "Meatloaf"
    new "Bolo de carne"

    # game/atHome.rpy:2056
    old "Mystery food"
    new "Comida misteriosa"

    # game/atHome.rpy:2056
    old "Actually, let's eat later."
    new "Na verdade, vamos comer mais tarde."

    # game/atHome.rpy:2663
    old "Let's play with the cat!"
    new "Vamos brincar com o gato!"

    # game/atHome.rpy:2663
    old "Look for some yarn?"
    new "Procurar um pouco de lã?"

    # game/atHome.rpy:2663
    old "I think my laser pointer still works..."
    new "Acho que meu laser ainda funciona..."

    # game/atHome.rpy:2663
    old "Hide and seek: A classic!"
    new "Esconde-esconde: Um clássico!"

    # game/atHome.rpy:3286
    old "Living Room"
    new "Sala"

    # game/atHome.rpy:3286
    old "Kitchen"
    new "Cozinha"

    # game/atHome.rpy:3286
    old "Hallway"
    new "Corredor"

    # game/atHome.rpy:3428
    old "Hide behind the armchair."
    new "Esconder atrás da poltrona."

    # game/atHome.rpy:3428
    old "Hide behind kitchen counter."
    new "Esconder atrás do balcão da cozinha."

    # game/atHome.rpy:3428
    old "Hide in the hall."
    new "Esconder no corredor."

    # game/atHome.rpy:3428
    old "Hide in the hallway closet."
    new "Esconder no armário do corredor."

    # game/atHome.rpy:3428
    old "Hide in the bathroom."
    new "Esconder no banheiro."

    # game/atHome.rpy:3428
    old "Hide in your bedroom..."
    new "Esconder no seu quarto..."

    # game/atHome.rpy:3428
    old "Get out of the apartment."
    new "Sair do apartamento."

    # game/atHome.rpy:3428
    old "Sit on the couch."
    new "Sentar no sofá."

    # game/atHome.rpy:3549
    old "Hide in the closet."
    new "Esconder no armário."

    # game/atHome.rpy:3549
    old "Risk another hiding spot."
    new "Arriscar outro esconderijo."

    # game/atHome.rpy:3739
    old "Quickly"
    new "Rápido"

    # game/atHome.rpy:3739
    old "Carefully"
    new "Com cuidado"

    old "Yes"
    new "Sim"

    old "No"
    new "Não"

    old "Don't look behind you..."
    new "Não olha para trás..."

    old "{alpha=0.2}How disappointing...{/alpha}"
    new "{alpha=0.2}Que decepcionante...{/alpha}"
