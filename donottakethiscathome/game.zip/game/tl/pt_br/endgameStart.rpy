﻿# TODO: Translation updated at 2024-11-02 03:15

# game/endgameStart.rpy:43
translate pt_br endCat_6022b618:

    # "Really? Are you sure?"
    "Sério? Tem certeza?"

# game/endgameStart.rpy:51
translate pt_br endCat_a20cefa7:

    # "..."
    "..."

# game/endgameStart.rpy:61
translate pt_br endCat1_a20cefa7:

    # "..."
    "..."

# game/endgameStart.rpy:62
translate pt_br endCat1_ee69ed58:

    # "Once you do this..."
    "Uma vez que fizer isso..."

# game/endgameStart.rpy:65
translate pt_br endCat1_5376e166:

    # "...you WON'T be able to turn back."
    "...você NÃO PODERÁ voltar atrás."

# game/endgameStart.rpy:73
translate pt_br endCat1_8dabefc6:

    # ".."
    ".."

# game/endgameStart.rpy:74
translate pt_br endCat1_a20cefa7_1:

    # "..."
    "..."

# game/endgameStart.rpy:84
translate pt_br endCat2_a20cefa7:

    # "..."
    "..."

# game/endgameStart.rpy:85
translate pt_br endCat2_18858365:

    # "Last chance."
    "Última chance."

# game/endgameStart.rpy:86
translate pt_br endCat2_f66a6910:

    # "Are you really, {b}really{/b} sure about this?"
    "Você tem certeza {b}absoluta{/b} disso?"

# game/endgameStart.rpy:96
translate pt_br endCat2_a20cefa7_1:

    # "..."
    "..."

# game/endgameStart.rpy:97
translate pt_br endCat2_0a4bf479:

    # "...We will."
    "...Nós iremos."

# game/endgameStart.rpy:98
translate pt_br endCat2_d56150af:

    # "Forever and ever..."
    "Para sempre e sempre..."

# game/endgameStart.rpy:112
translate pt_br endCatFinal_a20cefa7:

    # "..."
    "..."

# game/endgameStart.rpy:113
translate pt_br endCatFinal_dae0ec55:

    # you "..."
    you "..."

# game/endgameStart.rpy:114
translate pt_br endCatFinal_7f0ac95c:

    # cat "..."
    cat "..."

# game/endgameStart.rpy:156
translate pt_br endCatFinal_8dabefc6:

    # ".."
    ".."

# game/endgameStart.rpy:157
translate pt_br endCatFinal_a20cefa7_1:

    # "..."
    "..."

# game/endgameStart.rpy:158
translate pt_br endCatFinal_0b3e6813:

    # "You kill the cat."
    "Você mata o gato."

# game/endgameStart.rpy:163
translate pt_br endCatFinal_99b6c530:

    # "Its corpse lays limp and lifeless in its now bloodstained cardboard box."
    "O seu corpo jaz inérte e sem vida em sua caixa de papelão agora manchada de sangue."

# game/endgameStart.rpy:164
translate pt_br endCatFinal_8dabefc6_1:

    # ".."
    ".."

# game/endgameStart.rpy:165
translate pt_br endCatFinal_a20cefa7_2:

    # "..."
    "..."

# game/endgameStart.rpy:168
translate pt_br endCatMenu_20873599:

    # "What would you like to do?"
    "O que você gostaria de fazer?"

# game/endgameStart.rpy:179
translate pt_br endPockets_5308f154:

    # "There's no point."
    "Não tem porque."

# game/endgameStart.rpy:180
translate pt_br endPockets_edd17d2d:

    # "The cat is dead."
    "O gato está morto."

# game/endgameStart.rpy:181
translate pt_br endPockets_bcb34bfb:

    # "You dig in your pockets anyway..."
    "Você enfia a mão nos bolsos mesmo assim..."

# game/endgameStart.rpy:182
translate pt_br endPockets_a89eb7de:

    # "Left pocket..."
    "Bolso esquerdo..."

# game/endgameStart.rpy:185
translate pt_br endPockets_600502e3:

    # "...String. {w}Useless."
    "...Linha. {w}Inútil."

# game/endgameStart.rpy:188
translate pt_br endPockets_197df679:

    # "Right pocket..."
    "Bolso direito..."

# game/endgameStart.rpy:191
translate pt_br endPockets_a20cefa7:

    # "..."
    "..."

# game/endgameStart.rpy:192
translate pt_br endPockets_2bcc0dba:

    # "{color=#FF0000}{b}...Chocolate.{/b}{/color}"
    "{color=#FF0000}{b}...Chocolate.{/b}{/color}"

# game/endgameStart.rpy:195
translate pt_br endPockets_8eb9bd2b:

    # "You eat the chocolate."
    "Você come o chocolate."

# game/endgameStart.rpy:200
translate pt_br endPockets_559496a2:

    # "You have your phone."
    "Você está com seu celular."

# game/endgameStart.rpy:202
translate pt_br endPockets_1a0c66b1:

    # "Take a picture?"
    "Tirar uma foto?"

# game/endgameStart.rpy:203
translate pt_br endPockets_a20cefa7_1:

    # "..."
    "..."

# game/endgameStart.rpy:204
translate pt_br endPockets_c8d556cd:

    # "No point."
    "Não tem motivo."

# game/endgameStart.rpy:207
translate pt_br endPockets_edd17d2d_1:

    # "The cat is dead."
    "O gato está morto."

# game/endgameStart.rpy:212
translate pt_br endLook_2e60e8b3:

    # "What are you looking for?"
    "O que você está procurando?"

# game/endgameStart.rpy:213
translate pt_br endLook_edd17d2d:

    # "The cat is dead."
    "O gato está morto."

# game/endgameStart.rpy:214
translate pt_br endLook_30561a58:

    # "You look anyway..."
    "Você olha mesmo assim..."

# game/endgameStart.rpy:217
translate pt_br endLook_2af5fa5c:

    # "You look to your left and right..."
    "Você olha para a esquerda e para a direita..."

# game/endgameStart.rpy:218
translate pt_br endLook_e8093ee2:

    # "...Nothing but trash."
    "...Nada além de lixo."

# game/endgameStart.rpy:219
translate pt_br endLook_c96ce435:

    # "You look up..."
    "Você olha para cima..."

# game/endgameStart.rpy:220
translate pt_br endLook_52bbc94a:

    # "...The sun never reaches in here well enough."
    "...O sol mal alcança aqui dentro."

# game/endgameStart.rpy:221
translate pt_br endLook_29e137bf:

    # "But you can tell that it's a beautiful day today."
    "Mas você pode notar que hoje é um belo dia."

# game/endgameStart.rpy:222
translate pt_br endLook_35f3a46a:

    # "You look behind you..."
    "Você olha para trás..."

# game/endgameStart.rpy:223
translate pt_br endLook_8dabefc6:

    # ".."
    ".."

# game/endgameStart.rpy:224
translate pt_br endLook_a20cefa7:

    # "..."
    "..."

# game/endgameStart.rpy:226
translate pt_br endLook_1dc79289:

    # "{size=-10}{b}nobody saw.{/b}{/size}"
    "{size=-10}{b}ninguém viu.{/b}{/size}"

# game/endgameStart.rpy:228
translate pt_br endLook_a4cef966:

    # "You look down in front of you..."
    "Você olha bem embaixo de você..."

# game/endgameStart.rpy:230
translate pt_br endLook_8dabefc6_1:

    # ".."
    ".."

# game/endgameStart.rpy:231
translate pt_br endLook_a20cefa7_1:

    # "..."
    "..."

# game/endgameStart.rpy:232
translate pt_br endLook_49dade07:

    # "Oh yeah..."
    "Ah é..."

# game/endgameStart.rpy:233
translate pt_br endLook_edd17d2d_1:

    # "The cat is dead."
    "O gato está morto."

# game/endgameStart.rpy:242
translate pt_br endLeave_b5a44804:

    # "You're done here."
    "Você acabou por aqui."

# game/endgameStart.rpy:245
translate pt_br endLeave_a40ffd19:

    # "You turn around and leave the alley..."
    "Você se vira para sair do beco..."

# game/endgameStart.rpy:246
translate pt_br endLeave_8dabefc6:

    # ".."
    ".."

# game/endgameStart.rpy:247
translate pt_br endLeave_a20cefa7:

    # "..."
    "..."

# game/endgameStart.rpy:248
translate pt_br endLeave_40d9ca73:

    # "..?"
    "..?"

# game/endgameStart.rpy:249
translate pt_br endLeave_ec199ff2:

    # "At least... {w}You {i}try{/i} to..."
    "Pelo menos... {w}Você {i}tenta{/i}..."

# game/endgameStart.rpy:252
translate pt_br endLeave_74fbacaf:

    # "As you stand at the edge of the alley's entrance..."
    "Enquanto está parado na entrada do beco..."

# game/endgameStart.rpy:253
translate pt_br endLeave_d9a60d33:

    # "...you see that nothing exists beyond it."
    "...você vê que não existe nada além dele."

# game/endgameStart.rpy:254
translate pt_br endLeave_16e07799:

    # "Just an empty black void."
    "Só um completo vazio."

# game/endgameStart.rpy:255
translate pt_br endLeave_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/endgameStart.rpy:256
translate pt_br endLeave_252552a2:

    # "You turn back..."
    "Você dá meia volta..."

# game/endgameStart.rpy:260
translate pt_br endLeave_88047473:

    # "...and see that the back of the alley has become shrouded in darkness."
    "...e vê que o fundo do beco está envolto em escuridão."

# game/endgameStart.rpy:261
translate pt_br endLeave_d8c18e4f:

    # "You can't see a thing."
    "Você não consegue ver nada."

# game/endgameStart.rpy:268
translate pt_br endLeave2_cfb03abe:

    # "{size=-5}But there's nothing there.{/size}"
    "{size=-5}Mas não há nada por lá.{/size}"

# game/endgameStart.rpy:275
translate pt_br endLeave3_ca0588d8:

    # "With no other options, you step towards the darkness..."
    "Sem opções, você avança em direção à escuridão..."

# game/endgameStart.rpy:276
translate pt_br endLeave3_624b526a:

    # "Closer..."
    "Cada vez..."

# game/endgameStart.rpy:277
translate pt_br endLeave3_a20cefa7:

    # "..."
    "..."

# game/endgameStart.rpy:278
translate pt_br endLeave3_57fba23d:

    # "And closer..."
    "Mais perto..."

# game/endgameStart.rpy:279
translate pt_br endLeave3_6faf07b3:

    # "And clo-{w=0.3}{nw}"
    "E mais per-{w=0.3}{nw}"

# game/endgameStart.rpy:305
translate pt_br endLeave3_50da432c:

    # "{size=+10}{b}SLASH!!{/b}{/size}" with hpunch
    "{size=+10}{b}SLASH!!{/b}{/size}" with hpunch

# game/endgameStart.rpy:306
translate pt_br endLeave3_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/endgameStart.rpy:311
translate pt_br endLeave3_8dabefc6:

    # ".."
    ".."

# game/endgameStart.rpy:312
translate pt_br endLeave3_a20cefa7_1:

    # "..."
    "..."

# game/endgameStart.rpy:313
translate pt_br endLeave3_23a3bbe5:

    # "You're..."
    "Você tá..."

# game/endgameStart.rpy:314
translate pt_br endLeave3_13ee741d:

    # "You're blee-{w=0.2}{nw}"
    "Você tá sangr-{w=0.2}{nw}"

# game/endgameStart.rpy:322
translate pt_br endLeave3_ea937b79:

    # "{size=+15}{b}{i}SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    "{size=+15}{b}{i}SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch

# game/endgameStart.rpy:334
translate pt_br endLeave3_9a0232ef:

    # "{size=+20}{b}{i}SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    "{size=+20}{b}{i}SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch

# game/endgameStart.rpy:346
translate pt_br endLeave3_e1d010df:

    # "{size=+25}{b}{i}SLASH!! SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    "{size=+25}{b}{i}SLASH!! SLASH!!{/i}{/b}{/size}{w=0.3}{nw}" with hpunch

# game/endgameStart.rpy:358
translate pt_br endLeave3_c6e79053:

    # "{size=+30}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with vpunch
    "{size=+30}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with vpunch

# game/endgameStart.rpy:362
translate pt_br endLeave3_cc9a5909:

    # "!!!"
    "!!!"

# game/endgameStart.rpy:363
translate pt_br endLeave3_a20cefa7_2:

    # "..."
    "..."

# game/endgameStart.rpy:376
translate pt_br endLeave3_8dabefc6_1:

    # ".."
    ".."

# game/endgameStart.rpy:377
translate pt_br endLeave3_a20cefa7_3:

    # "..."
    "..."

# game/endgameStart.rpy:378
translate pt_br endLeave3_c6478448:

    # "You collapse to your knees..."
    "Você cai de joelhos..."

# game/endgameStart.rpy:380
translate pt_br endLeave3_c760ebc8:

    # "The front of your body is slashed open, leaking blood and guts and organs down your torso and over your lap."
    "A parte da frente do seu corpo está dilacerada, vazando sangue, tripas e órgãos pelo seu tronco e sobre seu colo."

# game/endgameStart.rpy:383
translate pt_br endLeave3_27a9cba3:

    # who "don't... {w}you... {w}know..."
    who "você... {w}nao... {w}sabe..."

# game/endgameStart.rpy:384
translate pt_br endLeave3_cfc77429:

    # who "{size=-10}...that cats have \ {b}{color=#FF0000}N I N E{/color}{/b} \ lives~?{/size}"
    who "{size=-10}...que gatos têm  {b}{color=#FF0000}N O V E{/color}{/b}  vidas~?{/size}"

# game/endgameStart.rpy:385
translate pt_br endLeave3_a79a5fec:

    # you "Wai-{w=0.3}{nw}"
    you "Esper-{w=0.3}{nw}"

# game/endgameStart.rpy:394
translate pt_br endLeave3_b363dab3:

    # "{size=+30}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    "{size=+30}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch

# game/endgameStart.rpy:406
translate pt_br endLeave3_a40c3115:

    # "{size=+35}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    "{size=+35}{b}{i}{color=#FF0000}SLASH!!{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch

# game/endgameStart.rpy:418
translate pt_br endLeave3_13c80e81:

    # "{size=+40}{b}{i}{color=#FF0000}S L A S H ! !{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch
    "{size=+40}{b}{i}{color=#FF0000}S L A S H ! !{/color}{/i}{/b}{/size}{w=0.3}{nw}" with hpunch

# game/endgameStart.rpy:424
translate pt_br endLeave3_8dabefc6_2:

    # ".."
    ".."

# game/endgameStart.rpy:425
translate pt_br endLeave3_a20cefa7_4:

    # "..."
    "..."

# game/endgameStart.rpy:426
translate pt_br endLeave3_66ecbb19:

    # "Ending 36: Eight more left"
    "Final 36: Só mais oito"

# game/endgameStart.rpy:427
translate pt_br endLeave3_a20cefa7_5:

    # "..."
    "..."

translate pt_br strings:

    # game/endgameStart.rpy:45
    old "Maybe not..."
    new "Talvez não..."

    old "Yes."
    new "Sim."

    # game/endgameStart.rpy:67
    old "I've changed my mind, let's go back!"
    new "Mudei de ideia, vamos voltar!"

    # game/endgameStart.rpy:67
    old "...Do it."
    new "...Vá em frente."

    # game/endgameStart.rpy:88
    old "This is the point of NO return. Are you sure there's nothing else you wish to do?"
    new "Esse é um ponto SEM volta. Tem certeza de que não há mais nada que queira fazer?"

    # game/endgameStart.rpy:88
    old "Take me back, I want us to play forever."
    new "Me leve de volta, quero que a gente brinque para sempre."

    old "...and ever."
    new "...e sempre."

    # game/endgameStart.rpy:88
    old "{b}{color=#FF0000}k i l l... t h e... c a t...{/color}{/b}"
    new "{b}{color=#FF0000}m a t a r... o... g a t o...{/color}{/b}"

    # game/endgameStart.rpy:170
    old "...Check pockets."
    new "...Checar os bolsos."

    # game/endgameStart.rpy:170
    old "...Look around the area."
    new "...Olhar em volta da área."

    # game/endgameStart.rpy:170
    old "leave."
    new "ir embora."

    # game/endgameStart.rpy:264
    old "Leave the alley."
    new "Sair do beco."

    # game/endgameStart.rpy:264
    old "Approach the darkness"
    new "Se aproximar da escuridão."
