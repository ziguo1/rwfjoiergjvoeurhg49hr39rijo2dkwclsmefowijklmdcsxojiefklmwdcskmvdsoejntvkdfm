﻿# TODO: Translation updated at 2024-11-02 03:15

# game/prologue.rpy:76
translate pt_br prologue_start_984bc6cc:

    # "You're not having a great day, as usual."
    "Você não está tendo um dia bom, como sempre."

# game/prologue.rpy:80
translate pt_br prologue_start_1481783e:

    # you "Oh great..."
    you "Ah, ótimo..."

# game/prologue.rpy:81
translate pt_br prologue_start_45f04c4f:

    # "It's the first time in a while that you've felt like going out..."
    "É a primeira vez em um bom tempo que você sentiu vontade de sair..."

# game/prologue.rpy:82
translate pt_br prologue_start_8a152280:

    # "But in the middle of your walk, it starts to rain."
    "Mas no meio da caminhada, começa a chover."

# game/prologue.rpy:83
translate pt_br prologue_start_11943181:

    # "Typical. But..."
    "Típico. Mas..."

# game/prologue.rpy:84
translate pt_br prologue_start_be9a673a:

    # "...maybe this is just a sign that you should've stayed home today?"
    "...talvez isso seja só um sinal de que você deveria ter ficado em casa hoje?"

# game/prologue.rpy:85
translate pt_br prologue_start_aba41a33:

    # "Yeah. You can always try again tomorrow... {w}right?"
    "É. Você sempre pode tentar de novo amanhã... {w}né?"

# game/prologue.rpy:86
translate pt_br prologue_start_f93e972d:

    # "You turn to head home when--"
    "Você se vira para voltar para casa quando--"

# game/prologue.rpy:88
translate pt_br prologue_start_a1100951:

    # who "{size=-5}{alpha=0.25}Meow...{/alpha}{/size}"
    who "{size=-5}{alpha=0.25}Miau...{/alpha}{/size}"

# game/prologue.rpy:89
translate pt_br prologue_start_4d2575f7:

    # you "{i}Huh? What was that..?{/i}"
    you "{i}Hã? O que foi isso..?{/i}"

# game/prologue.rpy:90
translate pt_br prologue_start_6b2b7353:

    # "There are only a few people around on the street..."
    "Tem só algumas poucas pessoas na rua..."

# game/prologue.rpy:91
translate pt_br prologue_start_dd4ef7b8:

    # "Makes sense due to the increase of missing persons around the area recently..."
    "Faz sentido, devido ao aumento nas pessoas desaparecidas na área recentemente..."

# game/prologue.rpy:92
translate pt_br prologue_start_edacd6a8:

    # "Well {i}that{/i} and the weather..."
    "Bom, {i}isso{/i} e a chuva..."

# game/prologue.rpy:93
translate pt_br prologue_start_8dabefc6:

    # ".."
    ".."

# game/prologue.rpy:94
translate pt_br prologue_start_a20cefa7:

    # "..."
    "..."

# game/prologue.rpy:95
translate pt_br prologue_start_bf8c3d80:

    # "But none of them react to the sound at {i}all.{/i}"
    "Mas {i}nenhuma{/i} delas reage ao som."

# game/prologue.rpy:102
translate pt_br prologue_start_01f2bb72:

    # "Curiosity guiding your steps, you follow the sound to the entrance of a dark, dingy alleyway."
    "Com a curiosidade guiando seus passos, você segue o som até a entrada de um beco sujo e escuro."

# game/prologue.rpy:103
translate pt_br prologue_start_c0632003:

    # "You timidly enter the alley and walk forward..."
    "Você entra timidamente no beco e segue em frente..."

# game/prologue.rpy:104
translate pt_br prologue_start_ee1644f5:

    # "The ground dampened by the rain makes your steps sound louder and more confident than you actually feel."
    "O chão molhado da chuva faz com que seus passos soem mais altos e confiantes do que você realmente se sente."

# game/prologue.rpy:106
translate pt_br prologue_start_a46fe60b:

    # who "Meow! Meow!"
    who "Miau! Miau!"

# game/prologue.rpy:107
translate pt_br prologue_start_0141658f:

    # "Finally, the sound's source comes into view in the cold, dim light of the alley..."
    "Finalmente, a fonte do som aparece na luz fria e tênue do beco..."

# game/prologue.rpy:108
translate pt_br prologue_start_7845feba:

    # "At the end of the alley, in a big cardboard box..."
    "No fundo do beco, numa caixa grande de papelão..."

# game/prologue.rpy:111
translate pt_br prologue_start_69a9648a:

    # "...is a cat."
    "...está um gato."

# game/prologue.rpy:112
translate pt_br prologue_start_e4ece72d:

    # you "Huh. Guess that should've been obvious..."
    you "Hã. Acho que isso era óbvio..."

# game/prologue.rpy:113
translate pt_br prologue_start_fc6b31f2:

    # "It's an interesting looking cat. Its pretty yellow eyes shine like gold among the dark sea of its black fur."
    "É um gato com uma aparência interessante. Seus lindos olhos amarelos brilham como ouro entre o mar negro de sua pelagem preta."

# game/prologue.rpy:116
translate pt_br prologue_start_3b9482ac:

    # "It puts its front paws up on the edge of the box and looks up at you."
    "Ele coloca as patas da frente na borda da caixa e olha para você."

# game/prologue.rpy:118
translate pt_br prologue_start_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/prologue.rpy:119
translate pt_br prologue_start_632d1a35:

    # you "!!!" with hpunch
    you "!!!" with hpunch

# game/prologue.rpy:120
translate pt_br prologue_start_8adec91e:

    # you "{i}S-{w}So cute..!{/i}"
    you "{i}T-{w}Tão fofo..!{/i}"

# game/prologue.rpy:121
translate pt_br prologue_start_443266e6:

    # "And it definitely {i}knows{/i} it..."
    "E ele definitivamente {i}sabe{/i} disso..."

# game/prologue.rpy:122
translate pt_br prologue_start_51df6142:

    # "You've never had much of an opinion one way or another about cats before..."
    "Você nunca teve uma opinião formada sobre gatos antes..."

# game/prologue.rpy:123
translate pt_br prologue_start_6d340fc5:

    # "But if they're all like this one..."
    "Mas se todos forem como esse aqui..."

# game/prologue.rpy:124
translate pt_br prologue_start_1074677c:

    # "...it's a shock they haven't already found a way to rule the world."
    "...é chocante que eles ainda não tenham achado um jeito de dominar o mundo."

# game/prologue.rpy:125
translate pt_br prologue_start_1eb5cc4a:

    # "You don't think you'd mind bowing down to a feline overlord."
    "Você não acha que se importaria em se curvar a um lorde soberano felino."

# game/prologue.rpy:126
translate pt_br prologue_start_dae0ec55:

    # you "..."
    you "..."

# game/prologue.rpy:127
translate pt_br prologue_start_1ca0cd0e:

    # "You look around the alley with a small frown."
    "Você olha descontente ao redor do beco."

# game/prologue.rpy:128
translate pt_br prologue_start_1d578264:

    # you "Who leaves cats in cardboard boxes these days anyway? Wouldn't they just jump out and leave the box eventually?"
    you "Quem deixa gatos em caixas de papelão hoje em dia, afinal? Eles não acabariam pulando pra fora da caixa eventualmente?"

# game/prologue.rpy:129
translate pt_br prologue_start_7f0ac95c:

    # cat "..."
    cat "..."

# game/prologue.rpy:130
translate pt_br prologue_start_1325c2b8:

    # "The cat doesn't answer you. {w}Obviously."
    "O gato não te responde. {w}Obviamente."

# game/prologue.rpy:131
translate pt_br prologue_start_926d62e7:

    # "It also doesn't do as you suggest and leave the box."
    "Ele também não sai da caixa como você sugeriu."

# game/prologue.rpy:132
translate pt_br prologue_start_c6acd156:

    # "It's just... looking at you?"
    "Ele fica só... olhando para você?"

# game/prologue.rpy:133
translate pt_br prologue_start_67f65235:

    # "As if waiting for you to make the next move..."
    "Como se esperasse você dar o próximo passo..."

# game/prologue.rpy:147
translate pt_br prologueChoice1_c86cf436:

    # "With a sigh, you take a decisive step back."
    "Com um suspiro, você dá um passo decisivo para trás."

# game/prologue.rpy:148
translate pt_br prologueChoice1_e66a2c52:

    # "As cute as the cat is, you really can't afford to be taking in a pet on a whim."
    "Por mais fofo que o gato seja, você não pode se dar ao luxo de adotar um animal por impulso."

# game/prologue.rpy:149
translate pt_br prologueChoice1_76b01b01:

    # "Rent's coming up soon. And your job doesn't exactly leave you rolling in dough..."
    "O aluguel está chegando. E seu trabalho não exatamente te deixa nadando em dinheiro..."

# game/prologue.rpy:150
translate pt_br prologueChoice1_ecf3c1ab:

    # "You give the cat a sad nod."
    "Você acena triste para o gato."

# game/prologue.rpy:151
translate pt_br prologueChoice1_8199e4d6:

    # you "Sorry... Good luck out here, okay?"
    you "Foi mal... Boa sorte por aí, tá?"

# game/prologue.rpy:152
translate pt_br prologueChoice1_7f0ac95c:

    # cat "..."
    cat "..."

# game/prologue.rpy:158
translate pt_br prologueChoice1_4b339222:

    # "You turn around and leave the cat and the alley behind."
    "Você se vira, deixando o gato e o beco para trás."

# game/prologue.rpy:160
translate pt_br prologueChoice1_93d0f774:

    # "Rain's picking up."
    "A chuva está piorando."

# game/prologue.rpy:165
translate pt_br prologueChoice1_a20cefa7:

    # "..."
    "..."

# game/prologue.rpy:166
translate pt_br prologueChoice1_dd6fc7c7:

    # "Time to head home."
    "Tá na hora de ir para casa."

# game/prologue.rpy:170
translate pt_br prologueChoice2_8dabefc6:

    # ".."
    ".."

# game/prologue.rpy:171
translate pt_br prologueChoice2_a20cefa7:

    # "..."
    "..."

# game/prologue.rpy:172
translate pt_br prologueChoice2_4122aacf:

    # you "You know what..?"
    you "Quer saber..?"

# game/prologue.rpy:175
translate pt_br prologueChoice2_5743aa48:

    # "You reach into the box and pick the cat up, holding it out in front of you."
    "Você alcança a caixa e pega o gato, o segurando na sua frente."

# game/prologue.rpy:176
translate pt_br prologueChoice2_4907ebc0:

    # you "...why not?"
    you "...por que não?"

# game/prologue.rpy:178
translate pt_br prologueChoice2_e5fab8a0:

    # cat "Meow!"
    cat "Miau!"

# game/prologue.rpy:179
translate pt_br prologueChoice2_3abd7e46:

    # you "You're all alone and well... I'm kind of in the same boat myself. So..."
    you "Você está sozinho e, bom... Meio que eu estou no mesmo barco. Então..."

# game/prologue.rpy:180
translate pt_br prologueChoice2_7dc50f87:

    # "You bring the cat close."
    "Você coloca o gato próximo."

# game/prologue.rpy:181
translate pt_br prologueChoice2_bf60a3c6:

    # "You didn't realize it was shivering until just then... but it slowly breathes easier as it presses into your chest."
    "Você não percebeu que ele estava tremendo até aquele momento... Mas ele começa a respirar com mais facilidade à medida que encosta em seu peito."

# game/prologue.rpy:182
translate pt_br prologueChoice2_5498dacc:

    # you "...why not stick together, right? At least for a little while."
    you "...por que não ficarmos juntos, né? Pelo menos por um tempo."

# game/prologue.rpy:184
translate pt_br prologueChoice2_55355e09:

    # cat "Purr... Purr..."
    cat "Purr... Purr..."

# game/prologue.rpy:185
translate pt_br prologueChoice2_d091f8d9:

    # "You think \"a little while\" will probably be more like a day. You'll be responsible and take it to a shelter tomorrow, but for now..."
    "Você acha que \"por um tempo\" tá mais pra um dia. Você será responsável e o levará a um abrigo amanhã, mas por enquanto..."

# game/prologue.rpy:186
translate pt_br prologueChoice2_a7af763b:

    # you "Let's get you out of the rain, okay?"
    you "Vamos te tirar da chuva, tá bem?"

# game/prologue.rpy:188
translate pt_br prologueChoice2_085f82bc:

    # cat "Meow..."
    cat "Miau..."

# game/prologue.rpy:194
translate pt_br prologueChoice2_6139ffca:

    # "You stop by a small, local pet store for some cat food, then head back home."
    "Você para em um pequeno pet shop local para comprar ração para gatos, então, vai para casa."

# game/prologue.rpy:197
translate pt_br prologueChoice2_df101305:

    # "You live in a modest apartment."
    "Você vive em um apartamento humilde."

# game/prologue.rpy:200
translate pt_br prologueChoice2_247ad3ce:

    # "One bedroom. One bathroom."
    "Um quarto. Um banheiro."

# game/prologue.rpy:201
translate pt_br prologueChoice2_2d3f71e5:

    # "One {i}you{/i} living alone in it..."
    "Só {i}você{/i} sozinho vivendo nele..."

# game/prologue.rpy:205
translate pt_br prologueChoice2_f380a402:

    # "So it feels weird having another living being inside it after so long."
    "Então, é estranho ter outro ser vivo aí dentro depois de tanto tempo."

# game/prologue.rpy:206
translate pt_br prologueChoice2_8b0c916e:

    # "Even if it {i}is{/i} just a cat."
    "Mesmo que {i}seja{/i} só um gato."

# game/prologue.rpy:210
translate pt_br prologueChoice2_566e1d7f:

    # "After locking the front door and placing the cat on the floor, you watch for a moment as it curiously explores the new environment."
    "Depois de trancar a porta e colocar o gato no chão, você observa enquanto ele explora curiosamente o novo ambiente."

# game/prologue.rpy:211
translate pt_br prologueChoice2_fddd40fa:

    # "Leaving the feline to its own devices, you set about making the both of you some dinner."
    "Deixando o felino à vontade, você começa a preparar o jantar para vocês dois."

# game/prologue.rpy:214
translate pt_br prologueChoice2_c9d1a483:

    # "You take out the can of cat food and open it with the tab on top."
    "Você pega a lata de ração para gatos e a abre com a aba no topo."

# game/prologue.rpy:217
translate pt_br prologueChoice2_e15d0030:

    # "You put some cat food on a saucer and click your tongue to call the cat over to you."
    "Você coloca um pouco de ração para gatos em um pratinho e estala a língua para chamar o gato."

# game/prologue.rpy:218
translate pt_br prologueChoice2_b5c20577:

    # "It perks up at your beckoning and rushes over."
    "Ele se anima com seu chamado e corre para perto de você."

# game/prologue.rpy:219
translate pt_br prologueChoice2_be0440b9:

    # "It looks at the plate of food..."
    "Ele olha para o prato de comida..."

# game/prologue.rpy:220
translate pt_br prologueChoice2_8dabefc6_1:

    # ".."
    ".."

# game/prologue.rpy:221
translate pt_br prologueChoice2_a20cefa7_1:

    # "..."
    "..."

# game/prologue.rpy:223
translate pt_br prologueChoice2_655f9b6a:

    # "...and completely ignores it."
    "...e o ignora completamente."

# game/prologue.rpy:224
translate pt_br prologueChoice2_a5cadf35:

    # you "Not hungry, I guess..."
    you "Tá sem fome, eu acho..."

# game/prologue.rpy:225
translate pt_br prologueChoice2_e322cfa9:

    # "You try not to let it annoy you."
    "Você tenta não deixar isso te incomodar."

# game/prologue.rpy:226
translate pt_br prologueChoice2_ce62169f:

    # "The cat doesn't understand the concept of money to appreciate that you spent your hard-earned cash on it."
    "O gato não compreende o conceito de dinheiro para ficar agradecido que você gastou seu dinheiro suado com ele."

# game/prologue.rpy:227
translate pt_br prologueChoice2_562ebb7f:

    # "It's just a cat after all."
    "É só um gato, afinal de contas."

# game/prologue.rpy:228
translate pt_br prologueChoice2_bf6a731d:

    # you "I'll just... leave it here if you get hungry later, okay?"
    you "Então eu vou... deixar aqui caso fique com fome mais tarde, viu?"

# game/prologue.rpy:230
translate pt_br prologueChoice2_369ea70f:

    # "The cat rubs its body against your legs with a purr."
    "O gato se esfrega nas suas pernas, ronronando."

# game/prologue.rpy:231
translate pt_br prologueChoice2_94dc0c23:

    # "You smile. That's enough of a thanks for you."
    "Você sorri. Isso é o suficiente como agradecimento para você."

# game/prologue.rpy:232
translate pt_br prologueChoice2_0bb73e9b:

    # "It follows you into the kitchen as you start on your own dinner."
    "Ele te segue para a cozinha enquanto você prepara seu próprio jantar."

# game/prologue.rpy:233
translate pt_br prologueChoice2_41ce0cbe:

    # "You decide that you have enough ingredients for a sandwich."
    "Você decide que tem ingredientes suficientes para um sanduíche."

# game/prologue.rpy:234
translate pt_br prologueChoice2_edb918a9:

    # "Bread toasted... {w}Mayo and mustard spread... {w}Turkey and cheese and lettuce perfectly placed... {w}Tomato sliced--{w=0.3}{nw}"
    "Pão tostado... {w}Maionese e mostarda espalhadas... {w}Peru, queijo e alface perfeitamente colocados... {w}Tomate fatiado--{w=0.3}{nw}"

# game/prologue.rpy:239
translate pt_br prologueChoice2_dfc857fd:

    # you "OW!" with vpunch
    you "AI!" with vpunch

# game/prologue.rpy:241
translate pt_br prologueChoice2_0d62a972:

    # "You wince as you cut your finger on the knife while slicing a tomato."
    "Você faz uma cara feia ao cortar o dedo com a faca enquanto fatiava um tomate."

# game/prologue.rpy:242
translate pt_br prologueChoice2_04d2c1e4:

    # you "Stupid..."
    you "Burro..."

# game/prologue.rpy:243
translate pt_br prologueChoice2_970b6c6e:

    # "You feel a little embarrassed for such a blunder and sigh, tossing the knife onto the cutting board."
    "Você se sente meio envergonhado por um erro tão besta e suspira, jogando a faca sobre a tábua de cortar."

# game/prologue.rpy:244
translate pt_br prologueChoice2_3047da37:

    # "You're about to head to the bathroom for a bandage when the cat hops up onto the counter."
    "Você está prestes a ir ao banheiro buscar um curativo quando o gato pula para cima do balcão."

# game/prologue.rpy:245
translate pt_br prologueChoice2_316203fa:

    # "It sniffs at the knife and meows almost pointedly at you."
    "Ele cheira a faca e mia diretamente para você."

# game/prologue.rpy:246
translate pt_br prologueChoice2_eddf2ff6:

    # you "Hehe... Don't worry, I'm alright. It was just an--"
    you "Hehe... Não se preocupe, eu tô bem. Foi só um--"

# game/prologue.rpy:247
translate pt_br prologueChoice2_ca13fffe:

    # you "!!" with hpunch
    you "!!" with hpunch

# game/prologue.rpy:248
translate pt_br prologueChoice2_e32ed4c0:

    # "You watch as the cat starts to..."
    "Você observa enquanto o gato começa a..."

# game/prologue.rpy:249
translate pt_br prologueChoice2_40d9ca73:

    # "..?"
    "..?"

# game/prologue.rpy:253
translate pt_br prologueChoice2_2f1c2108:

    # "...lick lightly, but {b}enthusiastically{/b} at the blood on the knife."
    "...lamber suavemente, mas {b}com entusiasmo{/b}, o sangue da faca."

# game/prologue.rpy:254
translate pt_br prologueChoice2_fe70304c:

    # "At {i}your{/i} blood."
    "O {i}seu{/i} sangue."

# game/prologue.rpy:255
translate pt_br prologueChoice2_31324b11:

    # "You're so shocked that by the time you come to your senses, the knife has been completely licked clean."
    "Você fica tão chocado que, quando volta a si, a faca estava completamente limpa."

# game/prologue.rpy:258
translate pt_br prologueChoice2_8477717d:

    # "The cat sits back, staring at you."
    "O gato senta, encarando você."

# game/prologue.rpy:259
translate pt_br prologueChoice2_dae0ec55:

    # you "..."
    you "..."

# game/prologue.rpy:260
translate pt_br prologueChoice2_9b097520:

    # "You... {w}feel a little uneasy."
    "Você... {w}se sente um pouco desconfortável."

# game/prologue.rpy:261
translate pt_br prologueChoice2_23fd2960:

    # "Sure cats are meat-eating predators but that was a little weird."
    "Claro que gatos são predadores carnívoros, mas isso foi um pouco estranho."

# game/prologue.rpy:262
translate pt_br prologueChoice2_01fb927e:

    # "Right..?"
    "Né..?"

# game/prologue.rpy:263
translate pt_br prologueChoice2_7de205f2:

    # "Sure, you're no cat expert... but that was definitely not something an ordinary cat would do..."
    "Claro, você não é um especialista em gatos... mas isso definitivamente não é algo que um gato normal faria..."

# game/prologue.rpy:264
translate pt_br prologueChoice2_a20cefa7_2:

    # "..."
    "..."

# game/prologue.rpy:265
translate pt_br prologueChoice2_c65aa055:

    # "{size=-5}...Right?{/size}"
    "{size=-5}...Né?{/size}"

# game/prologue.rpy:267
translate pt_br prologueChoice2_e5fab8a0_1:

    # cat "Meow!"
    cat "Miau!"

# game/prologue.rpy:268
translate pt_br prologueChoice2_dae0ec55_1:

    # you "..."
    you "..."

# game/prologue.rpy:270
translate pt_br prologueChoice2_252add1f:

    # "Well regardless... You're not about to abandon a cat in need while it's still raining outside. Not after all your efforts."
    "Enfim... Você não vai abandonar um gato necessitado enquanto ainda está chovendo lá fora. Não depois de todo esse esforço."

# game/prologue.rpy:271
translate pt_br prologueChoice2_94b91a9f:

    # "You were going to take it to the shelter tomorrow anyway. What's one night of awkwardness?"
    "Você ia levá-lo ao abrigo amanhã de qualquer jeito. O que é uma noite desconfortável?"

# game/prologue.rpy:272
translate pt_br prologueChoice2_e1de2017:

    # "Weird or not..."
    "Estranho ou não..."

# game/prologue.rpy:273
translate pt_br prologueChoice2_e8d99b4a:

    # "...it's just a cat."
    "...é só um gato."

# game/prologue.rpy:276
translate pt_br prologueChoice2_4141585e:

    # "The rest of the evening, unfortunately, goes downhill from there."
    "O resto da noite, infelizmente, só piora a partir daí."

# game/prologue.rpy:277
translate pt_br prologueChoice2_a2f3b22c:

    # "Even after covering up your finger's cut with a bandage, the cat keeps trying to lick at the wound."
    "Mesmo depois de cobrir o corte com um curativo, o gato continua tentando lamber a ferida."

# game/prologue.rpy:278
translate pt_br prologueChoice2_d1ec5fd6:

    # "While you're eating your sandwich..."
    "Enquanto você come o sanduíche..."

# game/prologue.rpy:279
translate pt_br prologueChoice2_20bbb144:

    # "While you're cleaning up the kitchen..."
    "Enquanto você limpa a cozinha..."

# game/prologue.rpy:280
translate pt_br prologueChoice2_960243fa:

    # "While trying to watch TV..."
    "Enquanto você tenta assistir TV..."

# game/prologue.rpy:281
translate pt_br prologueChoice2_59387313:

    # "You gently push it away every time, but you're starting to get worried at the strange behavior."
    "Você gentilmente o afasta toda vez, mas começa a ficar preocupado com o comportamento estranho."

# game/prologue.rpy:282
translate pt_br prologueChoice2_f35db5a7:

    # "What if it's got a taste for blood and thinks you're food now? You're not sure what you'll do if it starts to get more aggressive."
    "E se ele tem gosto por sangue e agora acha que você é comida? Você não tem certeza do que fazer se ele começar a ficar mais agressivo."

# game/prologue.rpy:283
translate pt_br prologueChoice2_851a5259:

    # "You keep thinking about the cat food sitting in the corner..."
    "Você continua pensando na ração do gato no canto..."

# game/prologue.rpy:284
translate pt_br prologueChoice2_f303bb24:

    # "...Untouched."
    "...Intacta."

# game/prologue.rpy:286
translate pt_br prologueChoice2_e5fab8a0_2:

    # cat "Meow!"
    cat "Miau!"

# game/prologue.rpy:288
translate pt_br prologueChoice2_5e84b463:

    # cat "Meow! Meow!"
    cat "Miau! Miau!"

# game/prologue.rpy:290
translate pt_br prologueChoice2_699a0b08:

    # cat "Meow! Meow! {b}{i}Meow!{/i}{/b}" with hpunch
    cat "Miau! Miau! {b}{i}Miau!{/i}{/b}" with hpunch

# game/prologue.rpy:291
translate pt_br prologueChoice2_2d1f6e2d:

    # you "Ugh, come on! {i}Enough{/i} already!"
    you "Ahh, qual é! Já {i}chega{/i}!"

# game/prologue.rpy:292
translate pt_br prologueChoice2_2a835de7:

    # "You shove it away a little more forcefully this time out of annoyance."
    "Você o afasta com um pouco mais de força desta vez, irritado."

# game/prologue.rpy:293
translate pt_br prologueChoice2_80296b88:

    # "You feel bad immediately but before you can do anything, the cat meows sharply at you and dashes off around the corner and into the hall."
    "Você se sente mal na mesma hora, mas antes que possa fazer algo, o gato mia alto para você e sai correndo pelo canto e para o corredor."

# game/prologue.rpy:294
translate pt_br prologueChoice2_116e7855:

    # "You sigh deeply."
    "Você suspira profundamente."

# game/prologue.rpy:295
translate pt_br prologueChoice2_eb31519a:

    # "At this point, you're just worried that it's going to take a bite out of you in your sleep."
    "Neste ponto, você só está preocupado que ele arranque um pedaço de você enquanto dorme."

# game/prologue.rpy:296
translate pt_br prologueChoice2_5cac017b:

    # you "{i}Maybe a vet will have an idea on how to calm it down..?{/i}"
    you "{i}Talvez um veterinário tenha idéia de como acalmá-lo..?{/i}"

# game/prologue.rpy:297
translate pt_br prologueChoice2_760ce1f2:

    # "You can only hope. You don't have many other options left other than tossing the cat out in the rain..."
    "Só lhe resta esperar. Você não tem muita opção além de largar o gato no meio da chuva..."

# game/prologue.rpy:298
translate pt_br prologueChoice2_7e95c19a:

    # "After finding the number of a local vet..."
    "Depois de encontrar o número de um veterinário local..."

# game/prologue.rpy:299
translate pt_br prologueChoice2_684db044:

    # "...you pick up your landline and--{w=1.0}{nw}"
    "...você pega o telefone e--{w=1.0}{nw}"

# game/prologue.rpy:303
translate pt_br prologueChoice2_28b3ac41:

    # you "!!"
    you "!!"

# game/prologue.rpy:304
translate pt_br prologueChoice2_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/prologue.rpy:305
translate pt_br prologueChoice2_a66b8231:

    # "The lights just..."
    "As luzes..."

# game/prologue.rpy:306
translate pt_br prologueChoice2_f41aa0f8:

    # "...went out?"
    "...apagaram?"

# game/prologue.rpy:310
translate pt_br prologueChoice2_dec218fc:

    # "Great. Just great. Rain must have knocked out the power."
    "Ótimo. Perfeito. A chuva deve ter feito a energia cair."

# game/prologue.rpy:311
translate pt_br prologueChoice2_eb2b6f8b:

    # "You check your cellphone only to find that it's out of batteries."
    "Você olha o celular e descobre que a bateria acabou."

# game/prologue.rpy:312
translate pt_br prologueChoice2_adcad194:

    # "You must have forgotten to charge it before leaving out earlier."
    "Você deve ter se esquecido de carregar antes de sair mais cedo."

# game/prologue.rpy:313
translate pt_br prologueChoice2_b129dbc5:

    # "The outing had been so spur-of-the-moment that it had no doubt messed with your usual routine."
    "A saída foi tão no impulso que, sem dúvida, bagunçou sua rotina habitual."

# game/prologue.rpy:314
translate pt_br prologueChoice2_a7869f4a:

    # "You grab a flashlight and turn it on."
    "Você pega uma lanterna e liga."

# game/prologue.rpy:317
translate pt_br prologueChoice2_8dabefc6_2:

    # ".."
    ".."

# game/prologue.rpy:318
translate pt_br prologueChoice2_a20cefa7_3:

    # "..."
    "..."

# game/prologue.rpy:319
translate pt_br prologueChoice2_eff9b4f7:

    # "It's quiet."
    "Tá quieto."

# game/prologue.rpy:320
translate pt_br prologueChoice2_a3038114:

    # "It's {i}too{/i} quiet."
    "Tá quieto {i}demais{/i}."

# game/prologue.rpy:321
translate pt_br prologueChoice2_f816a0f7:

    # "Did the rain stop?"
    "A chuva parou?"

# game/prologue.rpy:322
translate pt_br prologueChoice2_3e305a49:

    # "But then... why did the power go out?"
    "Mas então... por que a energia caiu?"

# game/prologue.rpy:323
translate pt_br prologueChoice2_a20cefa7_4:

    # "..."
    "..."

# game/prologue.rpy:324
translate pt_br prologueChoice2_b6a58494:

    # "You look outside."
    "Você olha lá fora."

# game/prologue.rpy:327
translate pt_br prologueChoice2_0eccd9ec:

    # "The sky is pitch black. What time is it?"
    "O céu tá completamente preto. Que horas são?"

# game/prologue.rpy:328
translate pt_br prologueChoice2_22796bbb:

    # "You turn to check the clock..."
    "Você se vira para olhar o relógio..."

# game/prologue.rpy:329
translate pt_br prologueChoice2_479c3431:

    # you "!!" with vpunch
    you "!!" with vpunch

# game/prologue.rpy:334
translate pt_br prologueChoice2_67438124:

    # "The cat sits on top of your digital clock, staring at you."
    "O gato senta em cima do seu relógio digital, te encarando."

# game/prologue.rpy:335
translate pt_br prologueChoice2_cc2a0af7:

    # "Thinking now, you realize the clock shouldn't be working at all with the power outage, but the numbers are lit up..."
    "Parando pra pensar, você percebe que o relógio não deveria estar funcionando com a falta de energia, mas os números estão acesos..."

# game/prologue.rpy:336
translate pt_br prologueChoice2_8ce74938:

    # "...and going completely haywire."
    "...e completamente fora de controle."

# game/prologue.rpy:337
translate pt_br prologueChoice2_a4473e29:

    # "The cat stares at you. It's completely still. You'd think it was a statue if you didn't know any better."
    "O gato te encara. Completamente imóvel. Você pensaria ser uma estátua se não soubesse."

# game/prologue.rpy:338
translate pt_br prologueChoice2_1859d2a8:

    # "It's not giving off any indication that it's alive."
    "Não está dando nenhum indício de que está vivo."

# game/prologue.rpy:339
translate pt_br prologueChoice2_e2df05b3:

    # "It's not blinking. It's not even breathing. But..."
    "Não está piscando. Nem mesmo respirando. Mas..."

# game/prologue.rpy:340
translate pt_br prologueChoice2_e9e5efea:

    # "...its eyes..."
    "...seus olhos..."

# game/prologue.rpy:341
translate pt_br prologueChoice2_a20cefa7_5:

    # "..."
    "..."

# game/prologue.rpy:342
translate pt_br prologueChoice2_31ac1903:

    # "This... isn't normal."
    "Isso... não é normal."

# game/prologue.rpy:343
translate pt_br prologueChoice2_9804c7b0:

    # "You're afraid."
    "Você está com medo."

# game/prologue.rpy:344
translate pt_br prologueChoice2_65973cff:

    # "You want to run, but you're afraid of letting the cat out of your sight."
    "Você quer correr, mas tem medo de perder o gato de vista."

# game/prologue.rpy:345
translate pt_br prologueChoice2_9c9d6223:

    # "You consider tossing the cat out after all..."
    "Você considera jogar o gato na rua no final das contas..."

# game/prologue.rpy:349
translate pt_br prologueChoice2_bf0874e3:

    # "But..."
    "Mas..."

# game/prologue.rpy:350
translate pt_br prologueChoice2_d73fee82:

    # "...as soon as the thought enters your head, {w}you feel a sharp urge to vomit."
    "...assim que o pensamento vem à sua cabeça, {w}você sente uma vontade forte de vomitar."

# game/prologue.rpy:354
translate pt_br prologueChoice2_f0883f9b:

    # "Those eyes... Its eyes hold you still."
    "Aqueles olhos... Eles te paralisam."

# game/prologue.rpy:355
translate pt_br prologueChoice2_3a7a79cb:

    # "Even with your flashlight trained on it..."
    "Mesmo com sua lanterna apontada para ele..."

# game/prologue.rpy:356
translate pt_br prologueChoice2_f6f81472:

    # "Its pupils are large, round inky pits--{w=2.0}{nw}"
    "Suas pupilas são grandes e redondas, como poços de tinta--{w=2.0}{nw}"

# game/prologue.rpy:369
translate pt_br prologueChoice2_28b3ac41_1:

    # you "!!"
    you "!!"

# game/prologue.rpy:370
translate pt_br prologueChoice2_82828c42:

    # "The flashlight flickers..."
    "A lanterna pisca..."

# game/prologue.rpy:375
translate pt_br prologueChoice2_8dabefc6_3:

    # ".."
    ".."

# game/prologue.rpy:376
translate pt_br prologueChoice2_a20cefa7_6:

    # "..."
    "..."

# game/prologue.rpy:379
translate pt_br prologueChoice2_c6952d96:

    # "...and the cat is gone."
    "...e o gato some."

# game/prologue.rpy:380
translate pt_br prologueChoice2_14176a20:

    # "Fear immediately grips your mind."
    "O medo imediatamente consome sua mente."

# game/prologue.rpy:382
translate pt_br prologueChoice2_447e9442:

    # "The silence punctuated with the rapid pumping of blood in your heart..."
    "O silêncio interrompido pelo rápido batimento do seu coração..."

# game/prologue.rpy:383
translate pt_br prologueChoice2_5f6e3577:

    # "...is overwritten as your ears slowly start to pick up the sound of static all around you."
    "...é substituído à medida que seus ouvidos começam a captar lentamente o som de estática ao seu redor."

# game/prologue.rpy:384
translate pt_br prologueChoice2_84a95582:

    # "How is the clock working with no power..?"
    "Como o relógio está funcionando sem energia..?"

# game/prologue.rpy:385
translate pt_br prologueChoice2_2a8eb917:

    # "You don't know why such a question matters at the moment..."
    "Você não sabe por que uma pergunta dessas importa neste momento..."

# game/prologue.rpy:386
translate pt_br prologueChoice2_e79a1e8f:

    # "...but you feel as if having the answer will make sense out of everything that's happening."
    "...mas você sente que ter a resposta dará sentido a tudo o que está acontecendo."

# game/prologue.rpy:387
translate pt_br prologueChoice2_741f7e05:

    # "That order will be restored."
    "Que a ordem será restaurada."

# game/prologue.rpy:389
translate pt_br prologueChoice2_a20cefa7_7:

    # "..."
    "..."

# game/prologue.rpy:390
translate pt_br prologueChoice2_30396cff:

    # "But no answer comes to mind."
    "Mas nenhuma resposta vem à mente."

# game/prologue.rpy:393
translate pt_br prologueChoice2_f028268f:

    # "You back away from the clock..."
    "Você se afasta do relógio..."

# game/prologue.rpy:394
translate pt_br prologueChoice2_dbe9efe4:

    # "...and feel as if the air itself coils tightly and abruptly in response..."
    "...e sente como se o próprio ar te sufocasse abruptamente em resposta..."

# game/prologue.rpy:395
translate pt_br prologueChoice2_cc431bef:

    # "...like a predator prepared to pounce..."
    "...como um predador pronto para atacar..."

# game/prologue.rpy:396
translate pt_br prologueChoice2_7331e0b1:

    # "...but waiting."
    "...mas à espera."

# game/prologue.rpy:397
translate pt_br prologueChoice2_d877d809:

    # "Waiting... for your next move."
    "À espera... do seu próximo movimento."

# game/prologue.rpy:398
translate pt_br prologueChoice2_e0dc85ac:

    # "But you're afraid to move. {w}You're afraid to even take a breath."
    "Mas você está com medo de se mover. {w}Está com medo até de respirar."

# game/prologue.rpy:399
translate pt_br prologueChoice2_a20cefa7_8:

    # "..."
    "..."

# game/prologue.rpy:400
translate pt_br prologueChoice2_ac25f573:

    # "But you can't stay still forever... right?"
    "Mas você não pode ficar parado para sempre... certo?"

# game/prologue.rpy:401
translate pt_br prologueChoice2_c2f2e565:

    # "Whatever is watching you... you can already feel its impatience."
    "O que quer que esteja te vigiando... você já pode sentir sua impaciência."

# game/prologue.rpy:402
translate pt_br prologueChoice2_af10a9a1:

    # "It's too eager."
    "Está ansioso demais."

# game/prologue.rpy:403
translate pt_br prologueChoice2_80a275c9:

    # "You don't know how you know this... {w}But you can sense it as clearly as if it had whispered--"
    "Você não sabe como sabe disso... {w}Mas pode sentir claramente, como se tivesse sussurrado--"

# game/prologue.rpy:410
translate pt_br prologueChoice2_a20cefa7_9:

    # "..."
    "..."

# game/prologue.rpy:411
translate pt_br prologueChoice2_4bca7969:

    # "...right into your ear."
    "...bem no seu ouvido."

# game/prologue.rpy:412
translate pt_br prologueChoice2_176e11ae:

    # "Right into your {i}soul...{/i}"
    "Bem na sua {i}alma...{/i}"

# game/prologue.rpy:413
translate pt_br prologueChoice2_a20cefa7_10:

    # "..."
    "..."

# game/prologue.rpy:414
translate pt_br prologueChoice2_590cf3c1:

    # "It won't let you wait it out. Not that you {i}could{/i} even if it did."
    "Essa coisa não vai deixar você esperar até passar. Não que você {i}pudesse{/i}, mesmo que deixasse."

# game/prologue.rpy:415
translate pt_br prologueChoice2_7b913dcf:

    # "You can't stay here."
    "Você não pode ficar aqui."

# game/prologue.rpy:416
translate pt_br prologueChoice2_55578b69:

    # "You have to {i}run{/i}."
    "Você tem que {i}correr{/i}."

# game/prologue.rpy:417
translate pt_br prologueChoice2_8f91c31e:

    # "With this thought, a sudden, primal instinct awakens within you..."
    "Com esse pensamento, um súbito instinto primitivo desperta dentro de você..."

# game/prologue.rpy:418
translate pt_br prologueChoice2_b8f3a2d1:

    # "...making you tear yourself into a hasty burst of movement."
    "...fazendo com que você se lance em um movimento rápido."

# game/prologue.rpy:419
translate pt_br prologueChoice2_9d930911:

    # "Of {i}action{/i}."
    "De {i}ação{/i}."

# game/prologue.rpy:420
translate pt_br prologueChoice2_bf0874e3_1:

    # "But..."
    "Mas..."

# game/prologue.rpy:421
translate pt_br prologueChoice2_314b731c:

    # "...You're still weak from the fear's grip on your mind."
    "...Você ainda está fraco pela influência do medo em sua mente."

# game/prologue.rpy:422
translate pt_br prologueChoice2_aaefb8e2:

    # "Your legs tangle together under you in your haste and you fall to the ground."
    "Na pressa, suas pernas se enroscam sob você, fazendo você cair no chão."

# game/prologue.rpy:430
translate pt_br prologueChoice2_8ca8510a_1:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/prologue.rpy:431
translate pt_br prologueChoice2_75f6eebc:

    # "A sharp pain explodes in the center of your foot."
    "Do nada você sente uma dor aguda no centro do seu pé."

# game/prologue.rpy:432
translate pt_br prologueChoice2_741dce68:

    # "At first, you think you've broken your ankle..."
    "A princípio, você pensa ter quebrado o tornozelo..."

# game/prologue.rpy:433
translate pt_br prologueChoice2_b904d1f8:

    # "...but something warm and {i}wet{/i} trickles down the length of your foot, pooling underneath it."
    "...mas algo quente e {i}úmido{/i} escorre pela lateral do seu pé, formando uma poça."

# game/prologue.rpy:435
translate pt_br prologueChoice2_b7ab4763:

    # "You hear the sound of metal scraping on tiles after skidding across the floor... as if it had been kicked..."
    "Você ouve o som de metal raspando nos azulejos após deslizar pelo chão... como se tivesse sido chutado..."

# game/prologue.rpy:438
translate pt_br prologueChoice2_db2b1596:

    # "Winded from your fall, you look up in a daze and see the object glinting in a strange light coming in from outside..."
    "Sem fôlego por causa da queda, você olha para cima atordoado e vê o objeto reluzindo sob uma luz estranha vinda de fora..."

# game/prologue.rpy:439
translate pt_br prologueChoice2_05b49e6d:

    # "...the light pouring in from your now {b}open{/b} front door."
    "...luz essa que entra pela porta da frente agora {b}aberta{/b}."

# game/prologue.rpy:440
translate pt_br prologueChoice2_b61a396d:

    # "Thoughts of how, when, who, {i}what{/i} in regards to your inexplicably opened door screech to a halt..."
    "Pensamentos de como, quando, quem, {i}o que{/i} em relação à sua porta inexplicavelmente aberta param abruptamente..."

# game/prologue.rpy:441
translate pt_br prologueChoice2_d4e0cc13:

    # "...as your brain finally identifies the metallic object you've been staring at..."
    "...assim que seu cérebro finalmente identifica o objeto metálico que você estava encarando..."

# game/prologue.rpy:442
translate pt_br prologueChoice2_40d9ca73_1:

    # "..?"
    "..?"

# game/prologue.rpy:443
translate pt_br prologueChoice2_2e361f97:

    # "It's your kitchen knife..."
    "É sua faca de cozinha..."

# game/prologue.rpy:444
translate pt_br prologueChoice2_8546520a:

    # "And still tinted red from your earlier blunder..? But that's not right."
    "E ainda tingida de vermelho pelo seu erro anterior..? Mas isso não está certo."

# game/prologue.rpy:445
translate pt_br prologueChoice2_38a7b342:

    # "Wasn't it completely licked clean by the..?"
    "Não tinha sido completamente limpa pelo..?"

# game/prologue.rpy:446
translate pt_br prologueChoice2_dae0ec55_2:

    # you "..."
    you "..."

# game/prologue.rpy:447
translate pt_br prologueChoice2_f5f34102:

    # "You gulp dryly at the pain in your foot."
    "Você engole seco devido à dor no seu pé."

# game/prologue.rpy:448
translate pt_br prologueChoice2_fe5b649d:

    # "You barely have time to wonder how the knife ended up on your {i}living room floor{/i} to be stepped on..."
    "Você mal tem tempo de pensar em como a faca acabou no {i}chão da sala de estar{/i} para ser pisada..."

# game/prologue.rpy:449
translate pt_br prologueChoice2_21d29f45:

    # "...instead of resting on your cutting board in the {i}kitchen{/i} where you'd left it..."
    "...em vez de estar na sua tábua de cortar na {i}cozinha{/i}, onde você a havia deixado..."

# game/prologue.rpy:452
translate pt_br prologueChoice2_f0b53c63:

    # "...when you spy something in the darkness just beyond the knife..."
    "...quando você vê algo na escuridão logo além da faca..."

# game/prologue.rpy:453
translate pt_br prologueChoice2_a20cefa7_11:

    # "..."
    "..."

# game/prologue.rpy:454
translate pt_br prologueChoice2_e77542e3:

    # "It spies right back at you."
    "Essa coisa olha de volta pra você."

# game/prologue.rpy:457
translate pt_br prologueChoice2_10142e0e:

    # "A pair of glowing, golden eyes come forward as the cat emerges from the shadows into the light from your doorway."
    "Um par de olhos dourados e brilhantes surge à medida que o gato emerge das sombras para a luz que vem da porta."

# game/prologue.rpy:460
translate pt_br prologueChoice2_e5652646:

    # "It pads lightly over to the knife, as if skipping in delight..."
    "Ele se aproxima da faca com passos leves, como se estivesse pulando de alegria..."

# game/prologue.rpy:467
translate pt_br prologueChoice2_70938f8a:

    # "...and bends down to lap at the blood dripping from the blade."
    "...e se inclina para lamber a sangue que escorre da lâmina."

# game/prologue.rpy:468
translate pt_br prologueChoice2_ed5ea61e:

    # you "Ah..."
    you "Ah..."

# game/prologue.rpy:470
translate pt_br prologueChoice2_393f5166:

    # "Your senses slowly begin to overwhelm you."
    "Seus sentidos lentamente começam a te sobrecarregar."

# game/prologue.rpy:471
translate pt_br prologueChoice2_2a730601:

    # "The chill of the air as it starts to suffocate you under its weight..."
    "O frio do ar enquanto começa a te sufocar com seu peso..."

# game/prologue.rpy:472
translate pt_br prologueChoice2_1593a3aa:

    # "The sound of your shaky breaths, discordant against the static now piercing your skull..."
    "O som das suas respirações trêmulas, ressonante em relação à estática que agora penetra sua cabeça..."

# game/prologue.rpy:473
translate pt_br prologueChoice2_ed11f665:

    # "The dryness on your tongue spreading to your throat..."
    "A secura na sua língua se espalhando para a garganta..."

# game/prologue.rpy:476
translate pt_br prologueChoice2_34bcc68c:

    # "The incomprehensible sight of the stray you'd taken in... {w}{i}licking{/i} away at your kitchen knife... once again completely clean..."
    "A visão incompreensível do vira-lata que você havia acolhido... {w}{i}lambendo{/i} a sua faca de cozinha... completamente limpa de novo..."

# game/prologue.rpy:477
translate pt_br prologueChoice2_b0a9a5c6:

    # "The scent of blood from the fresh wound on your foot..."
    "O cheiro de sangue da ferida fresca no seu pé..."

# game/prologue.rpy:478
translate pt_br prologueChoice2_40d9ca73_2:

    # "..?"
    "..?"

# game/prologue.rpy:479
translate pt_br prologueChoice2_eed16faf:

    # "Blood..?"
    "Sangue..?"

# game/prologue.rpy:482
translate pt_br prologueChoice2_7f0ac95c:

    # cat "..."
    cat "..."

# game/prologue.rpy:483
translate pt_br prologueChoice2_50e9be35:

    # "Golden eyes slide up to you as if in response to your sudden realization..."
    "Os olhos dourados se voltam para você como se em resposta à sua súbita compreensão..."

# game/prologue.rpy:484
translate pt_br prologueChoice2_281091c2:

    # "Blood..."
    "Sangue..."

# game/prologue.rpy:485
translate pt_br prologueChoice2_8ffe853a:

    # "You're hurt..."
    "Você está ferido..."

# game/prologue.rpy:486
translate pt_br prologueChoice2_9224c60b:

    # "Your foot is bleeding..."
    "Seu pé está sangrando..."

# game/prologue.rpy:487
translate pt_br prologueChoice2_8121a06c:

    # "You're bleeding..."
    "Você está sangrando..."

# game/prologue.rpy:488
translate pt_br prologueChoice2_00bb4f59:

    # "You're {b}{i}{color=#FF0000}bleeding{/color}{/i}{/b}."
    "Você está {b}{i}{color=#FF0000}sangrando{/color}{/i}{/b}."

# game/prologue.rpy:489
translate pt_br prologueChoice2_2da587a4:

    # "The cat barely moves, shoulders twitching as if just {i}considering{/i} the act of pouncing forward..."
    "O gato mal se move, os ombros se contraindo como se apenas estivesse {i}considerando{/i} avançar em sua direção..."

# game/prologue.rpy:492
translate pt_br prologueChoice2_a20cefa7_12:

    # "..."
    "..."

# game/prologue.rpy:493
translate pt_br prologueChoice2_3b91b0ca:

    # "But you're already on your feet and out the door."
    "Mas você já está de pé e do lado de fora da porta."

# game/prologue.rpy:496
translate pt_br prologueChoice2_5f801ea2:

    # "You run, or rather {i}limp{/i}, down the empty street."
    "Você corre, ou melhor, {i}manca{/i}, pela rua vazia."

# game/prologue.rpy:497
translate pt_br prologueChoice2_ccea669c:

    # "The sky is black and bleeding red..."
    "O céu está preto e sangrando vermelho..."

# game/prologue.rpy:498
translate pt_br prologueChoice2_cfd4e5e1:

    # "...but there's a strange light emitting from nowhere that casts everything else in white."
    "...mas há uma luz estranha que emana de lugar nenhum e deixa tudo em branco.."

# game/prologue.rpy:499
translate pt_br prologueChoice2_09cf8ffc:

    # "The houses, the trees, the road, even you..."
    "As casas, as árvores, a estrada, até mesmo você..."

# game/prologue.rpy:500
translate pt_br prologueChoice2_e4427836:

    # "{i}Everything{/i}..."
    "{i}Tudo{/i}..."

# game/prologue.rpy:501
translate pt_br prologueChoice2_220b03d6:

    # "...except your blood."
    "...exceto o seu sangue."

# game/prologue.rpy:502
translate pt_br prologueChoice2_a7c4df5f:

    # "You can just barely glimpse the bloody imprints your injured foot leaves in your wake with every impact it makes with the ground."
    "Você consegue apenas vislumbrar as marcas de sangue que seu pé machucado deixa para trás a cada impacto com o chão."

# game/prologue.rpy:505
translate pt_br prologueChoice2_62c0c671:

    # "It hurts..."
    "Isso dói..."

# game/prologue.rpy:506
translate pt_br prologueChoice2_e6f06c3d:

    # "It {i}hurts{/i}."
    "Isso {i}dói{/i}."

# game/prologue.rpy:507
translate pt_br prologueChoice2_3dd82419:

    # "But you can't stop. You {i}don't{/i} stop."
    "Mas você não pode parar. Você {i}não pode{/i} parar."

# game/prologue.rpy:508
translate pt_br prologueChoice2_511a53e8:

    # "Not when the shadows grow around you..."
    "Não quando as sombras se erguem à sua volta..."

# game/prologue.rpy:509
translate pt_br prologueChoice2_c94026dc:

    # "Not when you feel the gaze of eyes all over you..."
    "Não quando você sente o olhar de vários olhos sobre você..."

# game/prologue.rpy:513
translate pt_br prologueChoice2_11fab02e:

    # "Not when the road ahead of you is darkened by a long shadow of {i}something{/i} behind you."
    "Não quando o caminho à sua frente está escurecido por uma longa sombra de {i}alguma coisa{/i} atrás de você."

# game/prologue.rpy:514
translate pt_br prologueChoice2_24687875:

    # "Even then... you don't stop running. Because..."
    "Mesmo assim... você não para de correr. Porque..."

# game/prologue.rpy:517
translate pt_br prologueChoice2_d31c0957:

    # "If that's the cat right there ahead of you..."
    "Se aquele é o gato bem à sua frente..."

# game/prologue.rpy:518
translate pt_br prologueChoice2_f64ee9d8:

    # "Then..."
    "Então..."

# game/prologue.rpy:519
translate pt_br prologueChoice2_a20cefa7_13:

    # "..."
    "..."

# game/prologue.rpy:522
translate pt_br prologueChoice2_39b2e350:

    # "{size=-8}...what in the world is behind you?{/size}"
    "{size=-8}...o que, afinal, está atrás de você?{/size}"

# game/prologue.rpy:531
translate pt_br prologueEND1_45eb1440:

    # "Ending ?: Nya-t A Fool"
    "Final ?: Nyão Sou Idiota"

# game/prologue.rpy:540
translate pt_br prologueEND2_6f50b679:

    # who "..."
    who "..."

# game/prologue.rpy:541
translate pt_br prologueEND2_2821b9de:

    # who "Huh... {w}Interesting..."
    who "Hum... {w}Interessante..."

# game/prologue.rpy:542
translate pt_br prologueEND2_c29791ce:

    # who "How very, very... interesting..."
    who "Muito, muito... interessante..."

# game/prologue.rpy:543
translate pt_br prologueEND2_a20cefa7:

    # "..."
    "..."

# game/prologue.rpy:544
translate pt_br prologueEND2_b715ae86:

    # "Ending 0: It Begins"
    "Final 0: O Início"

translate pt_br strings:

    # game/prologue.rpy:138
    old "Do not take cat home"
    new "Não levar o gato para casa"

    # game/prologue.rpy:138
    old "Take cat home"
    new "Levar o gato para casa"

    old "Let's play~"
    new "Vamos brincar~"

    # game/prologue.rpy:524
    old "Look behind you."
    new "Olhar atrás de você."

    # game/prologue.rpy:524
    old "Keep running."
    new "Continuar correndo."
