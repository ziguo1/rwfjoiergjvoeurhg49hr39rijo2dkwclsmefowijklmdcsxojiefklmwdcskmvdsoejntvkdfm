﻿# TODO: Translation updated at 2024-11-02 03:15

# game/completedStory.rpy:65
translate pt_br hereAgain_8644fdbf:

    # who "play with me..." nointeract
    who "brinque comigo..." nointeract

# game/completedStory.rpy:68
translate pt_br hereAgain_6f50b679:

    # who "..."
    who "..."

# game/completedStory.rpy:69
translate pt_br hereAgain_a11fa0b8:

    # who "then get lost."
    who "então suma."

# game/completedStory.rpy:72
translate pt_br hereAgain_6f50b679_1:

    # who "..."
    who "..."

# game/completedStory.rpy:73
translate pt_br hereAgain_17114041:

    # who "truly?"
    who "de verdade?"

# game/completedStory.rpy:74
translate pt_br hereAgain_88bc4e2a:

    # who "you'll abandon this pathetic conclusion..."
    who "você vai abandonar essa conclusão patética..."

# game/completedStory.rpy:75
translate pt_br hereAgain_92534b16:

    # who "...and play with me some more?"
    who "...e brincar mais um pouco comigo?"

# game/completedStory.rpy:76
translate pt_br hereAgain_78091749:

    # who "Don't promise unless you mean it." nointeract
    who "Não prometa se não estiver falando sério." nointeract

# game/completedStory.rpy:79
translate pt_br hereAgain_6f50b679_2:

    # who "..."
    who "..."

# game/completedStory.rpy:80
translate pt_br hereAgain_a11fa0b8_1:

    # who "then get lost."
    who "então suma."

# game/completedStory.rpy:83
translate pt_br hereAgain_84de3be0:

    # who "...good."
    who "...bom."

# game/completedStory.rpy:84
translate pt_br hereAgain_a5457a87:

    # who "Very good."
    who "Muito bom."

# game/completedStory.rpy:85
translate pt_br hereAgain_281311fe:

    # who "Find me..."
    who "Me encontre..."

# game/completedStory.rpy:135
translate pt_br hereAgain_9ea2f78c:

    # " "
    "\ "

translate pt_br strings:

    # game/completedStory.rpy:65
    old "no. never again."
    new "não. nunca mais."

    # game/completedStory.rpy:65
    old "yes..."
    new "sim..."

    # game/completedStory.rpy:76
    old "no..."
    new "não..."

    # game/completedStory.rpy:76
    old "yes."
    new "sim."

    old "D{alpha=0.0}O NOT BETRAY ME AGAIN.{/alpha}"
    new "N{alpha=0.0}ÃO ME TRAIA DE NOVO.{/alpha}"

    old "DO{alpha=0.0} NOT BETRAY ME AGAIN.{/alpha}"
    new "NÃ{alpha=0.0}O ME TRAIA DE NOVO.{/alpha}"

    old "DO {alpha=0.0}NOT BETRAY ME AGAIN.{/alpha}"
    new "NÃO{alpha=0.0} ME TRAIA DE NOVO.{/alpha}"

    old "DO N{alpha=0.0}OT BETRAY ME AGAIN.{/alpha}"
    new "NÃO {alpha=0.0}ME TRAIA DE NOVO.{/alpha}"

    old "DO NO{alpha=0.0}T BETRAY ME AGAIN.{/alpha}"
    new "NÃO M{alpha=0.0}E TRAIA DE NOVO.{/alpha}"

    old "DO NOT{alpha=0.0} BETRAY ME AGAIN.{/alpha}"
    new "NÃO ME{alpha=0.0} TRAIA DE NOVO.{/alpha}"

    old "DO NOT {alpha=0.0}BETRAY ME AGAIN.{/alpha}"
    new "NÃO ME {alpha=0.0}TRAIA DE NOVO.{/alpha}"

    old "DO NOT B{alpha=0.0}ETRAY ME AGAIN.{/alpha}"
    new "NÃO ME T{alpha=0.0}RAIA DE NOVO.{/alpha}"

    old "DO NOT BE{alpha=0.0}TRAY ME AGAIN.{/alpha}"
    new "NÃO ME TR{alpha=0.0}AIA DE NOVO.{/alpha}"

    old "DO NOT BET{alpha=0.0}RAY ME AGAIN.{/alpha}"
    new "NÃO ME TRA{alpha=0.0}IA DE NOVO.{/alpha}"

    old "DO NOT BETR{alpha=0.0}AY ME AGAIN.{/alpha}"
    new "NÃO ME TRAI{alpha=0.0}A DE NOVO.{/alpha}"

    old "DO NOT BETRA{alpha=0.0}Y ME AGAIN.{/alpha}"
    new "NÃO ME TRAIA{alpha=0.0} DE NOVO.{/alpha}"

    old "DO NOT BETRAY{alpha=0.0} ME AGAIN.{/alpha}"
    new "NÃO ME TRAIA {alpha=0.0}DE NOVO.{/alpha}"

    old "DO NOT BETRAY {alpha=0.0}ME AGAIN.{/alpha}"
    new "NÃO ME TRAIA D{alpha=0.0}E NOVO.{/alpha}"

    old "DO NOT BETRAY M{alpha=0.0}E AGAIN.{/alpha}"
    new "NÃO ME TRAIA DE{alpha=0.0} NOVO.{/alpha}"

    old "DO NOT BETRAY ME{alpha=0.0} AGAIN.{/alpha}"
    new "NÃO ME TRAIA DE {alpha=0.0}NOVO.{/alpha}"

    old "DO NOT BETRAY ME {alpha=0.0}AGAIN.{/alpha}"
    new "NÃO ME TRAIA DE N{alpha=0.0}OVO.{/alpha}"

    old "DO NOT BETRAY ME A{alpha=0.0}GAIN.{/alpha}"
    new "NÃO ME TRAIA DE NO{alpha=0.0}VO.{/alpha}"

    old "DO NOT BETRAY ME AG{alpha=0.0}AIN.{/alpha}"
    new "NÃO ME TRAIA DE NOV{alpha=0.0}O.{/alpha}"

    old "DO NOT BETRAY ME AGA{alpha=0.0}IN.{/alpha}"
    new "NÃO ME TRAIA DE NOVO{alpha=0.0}.{/alpha}"

    old "DO NOT BETRAY ME AGAI{alpha=0.0}N.{/alpha}"
    new "NÃO ME TRAIA DE NOVO."

    old "DO NOT BETRAY ME AGAIN{alpha=0.0}.{/alpha}"
    new "NÃO ME TRAIA DE NOVO."

    old "DO NOT BETRAY ME AGAIN."
    new "NÃO ME TRAIA DE NOVO."
