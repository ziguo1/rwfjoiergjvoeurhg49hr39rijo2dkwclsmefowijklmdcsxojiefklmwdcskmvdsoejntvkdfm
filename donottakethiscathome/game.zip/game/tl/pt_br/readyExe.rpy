﻿# TODO: Translation updated at 2024-11-02 03:15

# game/readyExe.rpy:60
translate pt_br end_Hint_71219ec6:

    # "What should you do with a cat that has been {i}very...{/i}"
    "O que você deve fazer com um gato que tem sido {i}muito…{/i}"

# game/readyExe.rpy:61
translate pt_br end_Hint_8794b742:

    # "{i}very...{/i}"
    "{i}muito…{/i}"

# game/readyExe.rpy:62
translate pt_br end_Hint_ba6b8484:

    # "{i}{size=+10}very...{/size}{/i}"
    "{i}{size=+10}muito…{/size}{/i}"

# game/readyExe.rpy:63
translate pt_br end_Hint_7cf748e5:

    # "{color=#FF0000}{b}n a u g h t y . . ?{/b}{/color}"
    "{color=#FF0000}{b}l e v a d o . . ?{/b}{/color}"

# game/readyExe.rpy:73
translate pt_br end_Hint2_8d9f4bf5:

    # "It's something it {color=#FF0000}deserves.{/color}"
    "É algo que ele {color=#FF0000}merece.{/color}"

# game/readyExe.rpy:74
translate pt_br end_Hint2_22b30d96:

    # "Something... {w}{color=#FF0000}{b}final...{/b}{/color}"
    "Algo... {w}{color=#FF0000}{b}definitivo…{/b}{/color}"

# game/readyExe.rpy:84
translate pt_br end_Hint3_829c3289:

    # "Something it has been doing to you this entire time."
    "Algo que ele esteve fazendo com você esse tempo todo."

# game/readyExe.rpy:85
translate pt_br end_Hint3_bd62e827:

    # "...Over and over and {i}{b}over{/b}{/i} again."
    "...Vez após vez, {i}{b}sem{/b}{/i} parar."

# game/readyExe.rpy:95
translate pt_br end_Hint4_40d9ca73:

    # "..?"
    "..?"

# game/readyExe.rpy:96
translate pt_br end_Hint4_2ace7158:

    # "The act of taking a life..?"
    "O ato de tirar uma vida..?"

# game/readyExe.rpy:103
translate pt_br end_Hint4_a3784eb7:

    # "{alpha=0.1}kill it{/alpha}"
    "{alpha=0.1}matar{/alpha}"

# game/readyExe.rpy:109
translate pt_br end_Hint5_a3784eb7:

    # "{alpha=0.1}kill it{/alpha}"
    "{alpha=0.1}matar{/alpha}"

# game/readyExe.rpy:112
translate pt_br end_Hint5_cc680146:

    # "{alpha=0.3}kill it{/alpha}"
    "{alpha=0.3}matar{/alpha}"

# game/readyExe.rpy:115
translate pt_br end_Hint5_e0c70f7b:

    # "{alpha=0.5}{size=+5}kill it{/size}{/alpha}"
    "{alpha=0.5}{size=+5}matar{/size}{/alpha}"

# game/readyExe.rpy:118
translate pt_br end_Hint5_f209d4a5:

    # "{alpha=0.7}{size=+10}kill it{/size}{/alpha}"
    "{alpha=0.7}{size=+10}matar{/size}{/alpha}"

# game/readyExe.rpy:121
translate pt_br end_Hint5_4190fec2:

    # "{size=+20}{color=#FF0000}{b}kill it{/b}{/color}{/size}"
    "{size=+20}{color=#FF0000}{b}matar{/b}{/color}{/size}"

translate pt_br strings:
    old "Begin restoration _ _ _ _ \ _ _"
    new "Comece a restauração: _ _ _ _ _"

    old "Begin restoration: K _ _ _ \ _ _"
    new "Comece a restauração: M _ _ _ _"

    old "Begin restoration: K I _ _ \ _ _"
    new "Comece a restauração: M A _ _ _"

    old "Begin restoration: K I L _ \ _ _"
    new "Comece a restauração: M A T _ _"

    old "Begin restoration: K I L L \ _ _"
    new "Comece a restauração: M A T A _"

    old "Begin restoration: K I L L \ I _"
    new "Restauração Completa: M A T A R"

    old "Restoration Complete: K I L L \ I T"
    new "Restauração Completa: M A T A R"

    # game/readyExe.rpy:30
    old "Hint?"
    new "Dica?"

    # game/readyExe.rpy:65
    old "Ok, got it."
    new "Beleza, entendi."

    # game/readyExe.rpy:65
    old "Need another hint."
    new "Preciso de outra dica."

    # game/readyExe.rpy:76
    old "Gonna need another hint."
    new "Vou precisar de outra dica."

    # game/readyExe.rpy:87
    old "Still not following..."
    new "Ainda não peguei…"

    # game/readyExe.rpy:98
    old "Okay, one more hint..."
    new "Tá, só mais uma dica…"

    # game/readyExe.rpy:125
    old "..?"
    new "..?"
