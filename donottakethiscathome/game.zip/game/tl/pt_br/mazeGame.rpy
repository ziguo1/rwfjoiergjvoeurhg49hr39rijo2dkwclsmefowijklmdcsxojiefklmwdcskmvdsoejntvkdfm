﻿# TODO: Translation updated at 2024-11-02 03:15

# game/mazeGame.rpy:216
translate pt_br mazeStart_a48e0df5:

    # who "Hello, daring adventurer~!"
    who "Olá, ousado aventureiro~!"

# game/mazeGame.rpy:217
translate pt_br mazeStart_8ca8510a:

    # you "!!!" with vpunch
    you "!!!" with vpunch

# game/mazeGame.rpy:218
translate pt_br mazeStart_95254b2e:

    # "Who said tha--{w=0.3}{nw}"
    "Quem disse is--{w=0.3}{nw}"

# game/mazeGame.rpy:219
translate pt_br mazeStart_5149a957:

    # who "Welcome to the Mirror Maze!"
    who "Bem-vindo ao Labirinto de Espelhos!"

# game/mazeGame.rpy:220
translate pt_br mazeStart_75539f95:

    # who "Would you like to know how to navigate the maze?" nointeract
    who "Gostaria de saber como navegar pelo labirinto?" nointeract

# game/mazeGame.rpy:225
translate pt_br mazeStart_58e7d283:

    # who "Okay, okay! {w}No need to get snippy..."
    who "Tá bom, tá bom! {w}Não precisa ficar irritado..."

# game/mazeGame.rpy:227
translate pt_br mazeStart_1bc7b06c:

    # who "Let's begin then!"
    who "Vamos começar então!"

# game/mazeGame.rpy:228
translate pt_br mazeStart_1847df9a:

    # who "3... {w}2... {w}1..."
    who "3... {w}2... {w}1..."

# game/mazeGame.rpy:230
translate pt_br mazeStart_7486d4f4:

    # who "{size=+25}{b}GO!{/b}{/size}" with vpunch
    who "{size=+25}{b}JÁ!{/b}{/size}" with vpunch

# game/mazeGame.rpy:238
translate pt_br mazeTutorial_523cd98e:

    # "Once again... {w}Welcome to the Mirror Maze!"
    "Mais uma vez... {w}Bem-vindo ao Labirinto de Espelhos!"

# game/mazeGame.rpy:239
translate pt_br mazeTutorial_b20052dc:

    # "You're in a bit of a jam, but don't worry!"
    "Você está em uma sinuca de bico, mas não se preocupe!"

# game/mazeGame.rpy:240
translate pt_br mazeTutorial_39fb6b3b:

    # "You're in {i}good{/i} hands!"
    "Você está em {i}boas{/i} mãos!"

# game/mazeGame.rpy:241
translate pt_br mazeTutorial_9985c05f:

    # "Or rather..."
    "Ou melhor..."

# game/mazeGame.rpy:242
translate pt_br mazeTutorial_0c5f5726:

    # "...good {b}paws!{/b}"
    "...boas {b}patas!{/b}"

# game/mazeGame.rpy:245
translate pt_br mazeTutorial_5fc3dcc7:

    # "See these little cuties here?"
    "Está vendo essas fofurinhas aqui?"

# game/mazeGame.rpy:246
translate pt_br mazeTutorial_ff9fc1d5:

    # "They'll be doing their best to guide you through the maze!"
    "Elas vão fazer o seu melhor para te guiar pelo labirinto!"

# game/mazeGame.rpy:247
translate pt_br mazeTutorial_9043d317:

    # "Aren't they generous~?"
    "Não são um doce~?"

# game/mazeGame.rpy:248
translate pt_br mazeTutorial_59691f37:

    # "When you enter a room... the emergency light will flash, letting you see the paths before you for a second."
    "Quando você entrar em uma sala... a luz de emergência vai piscar, te permitindo ver os caminhos à sua frente por um instante."

# game/mazeGame.rpy:249
translate pt_br mazeTutorial_dcc59543:

    # "And also what lies beyond them."
    "E também o que há além deles."

# game/mazeGame.rpy:250
translate pt_br mazeTutorial_0d753b90:

    # "Whenever you see these kind kitties..."
    "Sempre que vir esses gatinhos gentis..."

# game/mazeGame.rpy:251
translate pt_br mazeTutorial_824e766c:

    # "...just go where they are and you'll reach the next room!"
    "...basta ir onde eles estão e você chegará à próxima sala!"

# game/mazeGame.rpy:252
translate pt_br mazeTutorial_96380374:

    # "Unfortunately..."
    "Mas infelizmente..."

# game/mazeGame.rpy:255
translate pt_br mazeTutorial_74dfdecc:

    # "...they're not the only things in here."
    "...eles não são os únicos por aqui."

# game/mazeGame.rpy:256
translate pt_br mazeTutorial_93e0e5fe:

    # "It is {i}highly{/i} suggested that you refrain from following {i}any{/i} of our other... {w}{b}{i}guests{/i}{/b}"
    "É {i}altamente{/i} recomendado que você evite seguir {i}qualquer um{/i} dos nossos outros... {w}{b}{i}convidados.{/i}{/b}"

# game/mazeGame.rpy:257
translate pt_br mazeTutorial_22a32adf:

    # "They can be sneaky or distracting... {w}but they're {b}always{/b} hostile."
    "Eles podem ser sorrateiros ou distraí-lo... {w}mas são {b}sempre{/b} hostis."

# game/mazeGame.rpy:258
translate pt_br mazeTutorial_106eb8ca:

    # "So please take caution when advancing to the next room!"
    "Eles podem ser sorrateiros ou distraí-lo... {w}mas são {b}sempre{/b} hostis."

# game/mazeGame.rpy:261
translate pt_br mazeTutorial_e361bedb:

    # "Of course this wouldn't be much of a mirror maze without mirrors!"
    "Claro que isso não seria bem um labirinto de espelhos sem espelhos!"

# game/mazeGame.rpy:262
translate pt_br mazeTutorial_7fa0fc05:

    # "\"Can they hurt you?\""
    "\"Eles podem te machucar?\""

# game/mazeGame.rpy:263
translate pt_br mazeTutorial_1907bcc0:

    # "No! They're just mirrors, silly!"
    "Não! São apenas espelhos, bobinho!"

# game/mazeGame.rpy:264
translate pt_br mazeTutorial_c4e8c1f8:

    # "They don't do anything at all~!"
    "Eles não podem fazer nadinha~!"

# game/mazeGame.rpy:265
translate pt_br mazeTutorial_d7a493b8:

    # "And you can't do anything to them either."
    "E você também não pode fazer nada com eles."

# game/mazeGame.rpy:266
translate pt_br mazeTutorial_fa242737:

    # "They're just an obstacle you can't pass through."
    "São apenas um obstáculo que você não pode atravessar."

# game/mazeGame.rpy:269
translate pt_br mazeTutorial_876495c2:

    # "Go {b}left{/b}, {w}go {b}center{/b}, {w}or go {b}right{/b}!"
    "Vá pela {b}esquerda{/b}, {w}pelo {b}meio{/b}, {w}ou pela {b}direita{/b}!"

# game/mazeGame.rpy:270
translate pt_br mazeTutorial_4931dda6:

    # "The choice is yours!"
    "Você que sabe!"

# game/mazeGame.rpy:271
translate pt_br mazeTutorial_23e939ae:

    # "Though..."
    "No entanto..."

# game/mazeGame.rpy:272
translate pt_br mazeTutorial_15510f8f:

    # "If you find a room with no helpful kitties in sight..."
    "Se você encontrar uma sala sem nenhum gatinho prestativo à vista..."

# game/mazeGame.rpy:273
translate pt_br mazeTutorial_d32e4fb5:

    # "...and all the paths lead to a mirror or... {w}{color=#FF0000}{b}something else...{/b}{/color}"
    "...e todos os caminhos levarem a um espelho ou... {w}{color=#FF0000}{b}alguma outra coisa...{/b}{/color}"

# game/mazeGame.rpy:274
translate pt_br mazeTutorial_a78f88cc:

    # "It's recommended that you {b}stay put{/b}... {w}and just maybe it will work itself out!"
    "É recomendável que você {b}fique parado{/b}... {w}e talvez isso se resolva por conta própria!"

# game/mazeGame.rpy:277
translate pt_br mazeTutorial_4dfacc44:

    # "Now for your navigation tools!"
    "Agora, para suas ferramentas de navegação!"

# game/mazeGame.rpy:281
translate pt_br mazeTutorial_194e688a:

    # "That {b}flashlight{/b} you found doesn't have much juice left..."
    "Essa {b}lanterna{/b} que você encontrou não tem muita carga sobrando..."

# game/mazeGame.rpy:282
translate pt_br mazeTutorial_0ba8aaf5:

    # "It'll only let you get a {b}quick{/b} extra peek at your surroundings about five times."
    "Ela só permitirá que você dê uma {b}rápida{/b} olhada nos arredores cerca de cinco vezes."

# game/mazeGame.rpy:283
translate pt_br mazeTutorial_f28a1cba:

    # "So try not to use it all up at once!"
    "Então, tente não gastar tudo de uma vez!"

# game/mazeGame.rpy:288
translate pt_br mazeTutorial_7938b891:

    # "You can keep track of your progress through the {b}rooms{/b} up to the left..."
    "Você pode acompanhar seu progresso pelas {b}salas{/b} em cima à esquerda..."

# game/mazeGame.rpy:289
translate pt_br mazeTutorial_519aa538:

    # "...and your {b}lives{/b} up to the right!"
    "...e suas {b}vidas{/b} à direita!"

# game/mazeGame.rpy:290
translate pt_br mazeTutorial_238bd2a4:

    # "You've got three lives, so be careful to avoid the less friendly guests lurking around."
    "Você tem três vidas, então fique atento para evitar os convidados pouco amigáveis à espreita."

# game/mazeGame.rpy:291
translate pt_br mazeTutorial_69a6fef7:

    # "\"Why only {b}three{/b} lives\", you ask?"
    "\"Por que só {b}três{/b} vidas\", você pergunta?"

# game/mazeGame.rpy:292
translate pt_br mazeTutorial_f56b6035:

    # "Because you're soft and squishy!"
    "Porque você é mole e flácido!"

# game/mazeGame.rpy:293
translate pt_br mazeTutorial_d3a59e2c:

    # "It wouldn't take much to damage you beyond repair..."
    "Não precisa de muito para te danificar além do reparo..."

# game/mazeGame.rpy:297
translate pt_br mazeTutorial_a20cefa7:

    # "..."
    "..."

# game/mazeGame.rpy:298
translate pt_br mazeTutorial_53b3ffb5:

    # "And besides..."
    "Além disso..."

# game/mazeGame.rpy:299
translate pt_br mazeTutorial_781b2cf3:

    # "...you're human. And humans usually only have the {b}one{/b} life, yes?"
    "...você é humano. E humanos costumam ter apenas {b}uma{/b} vida, sim?"

# game/mazeGame.rpy:300
translate pt_br mazeTutorial_91cf105d:

    # "And yet here, you get three!"
    "E ainda assim, aqui, você tem três!"

# game/mazeGame.rpy:301
translate pt_br mazeTutorial_8dabefc6:

    # ".."
    ".."

# game/mazeGame.rpy:303
translate pt_br mazeTutorial_a20cefa7_1:

    # "..."
    "..."

# game/mazeGame.rpy:304
translate pt_br mazeTutorial_00557775:

    # "Don't you think... {w}you ought to show... {w}a little more..."
    "Você não acha... {w}que deveria demonstrar... {w}um pouco mais de..."

# game/mazeGame.rpy:305
translate pt_br mazeTutorial_40553271:

    # "{b}...g {w=0.2}r {w=0.2}a {w=0.2}t {w=0.2}i {w=0.2}t {w=0.2}u {w=0.2}d {w=0.2}e {w=0.2}?{/b}"
    "{b}...g {w=0.2}r {w=0.2}a {w=0.2}t {w=0.2}i {w=0.2}d {w=0.2}ã {w=0.2}o {w=0.2}?{/b}"

# game/mazeGame.rpy:306
translate pt_br mazeTutorial_8dabefc6_1:

    # ".."
    ".."

# game/mazeGame.rpy:307
translate pt_br mazeTutorial_a20cefa7_2:

    # "..."
    "..."

# game/mazeGame.rpy:309
translate pt_br mazeTutorial_e4ba3fc6:

    # "And that's the end of your tutorial!!"
    "E esse é o fim do seu tutorial!!"

# game/mazeGame.rpy:310
translate pt_br mazeTutorial_c4fbff42:

    # "Hopefully it was helpful!"
    "Espero que tenha sido útil!"

# game/mazeGame.rpy:311
translate pt_br mazeTutorial_bf623419:

    # "Are you ready to play?"
    "Está pronto para jogar?"

# game/mazeGame.rpy:316
translate pt_br mazeSettings_02557781:

    # who "What would you like to know?~" nointeract
    who "O que você gostaria de saber?~" nointeract

# game/mazeGame.rpy:320
translate pt_br mazeSettings_1ff6beab:

    # "Okay!"
    "Ok!"

# game/mazeGame.rpy:321
translate pt_br mazeSettings_a05e1dc4:

    # "3... {w}2... {w}1..."
    "3... {w}2... {w}1..."

# game/mazeGame.rpy:323
translate pt_br mazeSettings_e5f078db:

    # "{size=+25}{b}GO!{/b}{/size}" with vpunch
    "{size=+25}{b}JÁ!{/b}{/size}" with vpunch

# game/mazeGame.rpy:326
translate pt_br mazeSettings_909322d8:

    # who "Your request to forfeit is denied!~"
    who "Seu pedido de desistência foi negado!~"

# game/mazeGame.rpy:327
translate pt_br mazeSettings_74a88101:

    # you "Let me out of here!" with vpunch
    you "Me deixa sair daqui!" with vpunch

# game/mazeGame.rpy:328
translate pt_br mazeSettings_616c59ce:

    # who "Screaming is not allowed in the maze!~"
    who "Não é permitido gritar no labirinto!~"

# game/mazeGame.rpy:331
translate pt_br mazeSettings_0862e669:

    # who "Of course!"
    who "Certamente!"

# game/mazeGame.rpy:333
translate pt_br mazeSettings_7ee6eac8:

    # who "Flash {b}ON!{/b}"
    who "Flash {b}LIGADO!{/b}"

# game/mazeGame.rpy:337
translate pt_br mazeSettings_0862e669_1:

    # who "Of course!"
    who "Certamente!"

# game/mazeGame.rpy:339
translate pt_br mazeSettings_4388c99c:

    # who "Flash {b}OFF!{/b}"
    who "Flash {b}DESLIGADO!{/b}"

# game/mazeGame.rpy:343
translate pt_br mazeSettings_b56089a4:

    # who "Oh, alright..."
    who "Ah, tudo bem..."

# game/mazeGame.rpy:346
translate pt_br mazeSettings_dca85608:

    # who "Your flashlight will give you {b}seven{/b} second chances now..."
    who "Sua lanterna te dará {b}sete{/b} segundas chances agora..."

# game/mazeGame.rpy:347
translate pt_br mazeSettings_412f0fff:

    # who "{i}And{/i} the flash will last longer..."
    who "{i}E{/i} a luz vai durar mais..."

# game/mazeGame.rpy:348
translate pt_br mazeSettings_1d4dacaf:

    # who "Is that better~?"
    who "Melhor assim~?"

# game/mazeGame.rpy:351
translate pt_br mazeSettings_6f50b679:

    # who "..."
    who "..."

# game/mazeGame.rpy:352
translate pt_br mazeSettings_6647ecc8:

    # who "Is that {b}so?{/b}"
    who "É {b}mesmo?{/b}"

# game/mazeGame.rpy:355
translate pt_br mazeSettings_8dabefc6:

    # ".."
    ".."

# game/mazeGame.rpy:356
translate pt_br mazeSettings_a20cefa7:

    # "..."
    "..."

# game/mazeGame.rpy:357
translate pt_br mazeSettings_24c97862:

    # who "There... {w}all done!"
    who "Vejamos... {w}pronto!"

# game/mazeGame.rpy:358
translate pt_br mazeSettings_95022402:

    # you "Wait, what did you do?"
    you "Pera, o que você fez?"

# game/mazeGame.rpy:359
translate pt_br mazeSettings_6f50b679_1:

    # who "..."
    who "..."

# game/mazeGame.rpy:360
translate pt_br mazeSettings_279d8c4f:

    # who "You'll see~"
    who "Você vai ver~"

# game/mazeGame.rpy:366
translate pt_br mazeSettings_3ab9acb5:

    # who "You got it!"
    who "Deixa comigo!"

# game/mazeGame.rpy:369
translate pt_br mazeSettings_6bf745f8:

    # who "As you wish!"
    who "Como desejar!"

# game/mazeGame.rpy:432
translate pt_br maze1Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:454
translate pt_br maze1Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:470
translate pt_br maze1Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:477
translate pt_br maze1Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:486
translate pt_br maze1Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:534
translate pt_br maze2Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:535
translate pt_br maze2Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:544
translate pt_br maze2Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:560
translate pt_br maze2Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:567
translate pt_br maze2Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:576
translate pt_br maze2Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:622
translate pt_br maze3Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:635
translate pt_br maze3Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:657
translate pt_br maze3Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:673
translate pt_br maze3Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:682
translate pt_br maze3Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:734
translate pt_br maze4Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:756
translate pt_br maze4Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:778
translate pt_br maze4Menu_76061708_2:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:794
translate pt_br maze4Menu_dc06f641:

    # you "This room feels off..."
    you "Essa sala parece estranha..."

# game/mazeGame.rpy:795
translate pt_br maze4Menu_1ad23f1f:

    # you "Just wait..."
    you "Melhor esperar..."

# game/mazeGame.rpy:796
translate pt_br maze4Menu_dae0ec55:

    # you "..."
    you "..."

# game/mazeGame.rpy:797
translate pt_br maze4Menu_e4612ec1:

    # you "..!"
    you "..!"

# game/mazeGame.rpy:798
translate pt_br maze4Menu_ceb48012:

    # you "I think something just changed..."
    you "Acho que alguma coisa mudou..."

# game/mazeGame.rpy:811
translate pt_br maze4Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:857
translate pt_br maze5Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:870
translate pt_br maze5Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:892
translate pt_br maze5Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:908
translate pt_br maze5Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:917
translate pt_br maze5Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:963
translate pt_br maze6Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:976
translate pt_br maze6Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:998
translate pt_br maze6Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1014
translate pt_br maze6Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1023
translate pt_br maze6Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1077
translate pt_br maze7Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1094
translate pt_br maze7Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1095
translate pt_br maze7Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1104
translate pt_br maze7Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1120
translate pt_br maze7Menu_dc06f641:

    # you "This room feels off..."
    you "Essa sala parece estranha..."

# game/mazeGame.rpy:1121
translate pt_br maze7Menu_1ad23f1f:

    # you "Just wait..."
    you "Melhor esperar..."

# game/mazeGame.rpy:1122
translate pt_br maze7Menu_dae0ec55:

    # you "..."
    you "..."

# game/mazeGame.rpy:1123
translate pt_br maze7Menu_e4612ec1:

    # you "..!"
    you "..!"

# game/mazeGame.rpy:1124
translate pt_br maze7Menu_ceb48012:

    # you "I think something just changed..."
    you "Acho que alguma coisa mudou..."

# game/mazeGame.rpy:1136
translate pt_br maze7Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1188
translate pt_br maze8Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1204
translate pt_br maze8Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1217
translate pt_br maze8Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1233
translate pt_br maze8Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1242
translate pt_br maze8Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1275
translate pt_br maze9Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1276
translate pt_br maze9Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1280
translate pt_br maze9Menu_ef682bac_1:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1281
translate pt_br maze9Menu_9af1e7a3_1:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1284
translate pt_br maze9Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1291
translate pt_br maze9Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1300
translate pt_br maze9Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1338
translate pt_br maze10Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1360
translate pt_br maze10Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1376
translate pt_br maze10Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1383
translate pt_br maze10Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1392
translate pt_br maze10Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1439
translate pt_br maze11Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1440
translate pt_br maze11Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1449
translate pt_br maze11Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1465
translate pt_br maze11Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1472
translate pt_br maze11Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1481
translate pt_br maze11Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1535
translate pt_br maze12Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1552
translate pt_br maze12Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1553
translate pt_br maze12Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1556
translate pt_br maze12Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1563
translate pt_br maze12Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1572
translate pt_br maze12Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1619
translate pt_br maze13Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1620
translate pt_br maze13Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1623
translate pt_br maze13Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1631
translate pt_br maze13Menu_ef682bac_1:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1632
translate pt_br maze13Menu_9af1e7a3_1:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1635
translate pt_br maze13Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1644
translate pt_br maze13Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1682
translate pt_br maze14Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1698
translate pt_br maze14Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1706
translate pt_br maze14Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1707
translate pt_br maze14Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1710
translate pt_br maze14Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1719
translate pt_br maze14Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1766
translate pt_br maze15Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1767
translate pt_br maze15Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1771
translate pt_br maze15Menu_ef682bac_1:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1772
translate pt_br maze15Menu_9af1e7a3_1:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1776
translate pt_br maze15Menu_ef682bac_2:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1777
translate pt_br maze15Menu_9af1e7a3_2:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1780
translate pt_br maze15Menu_dc06f641:

    # you "This room feels off..."
    you "Essa sala parece estranha..."

# game/mazeGame.rpy:1781
translate pt_br maze15Menu_1ad23f1f:

    # you "Just wait..."
    you "Melhor esperar..."

# game/mazeGame.rpy:1782
translate pt_br maze15Menu_dae0ec55:

    # you "..."
    you "..."

# game/mazeGame.rpy:1783
translate pt_br maze15Menu_e4612ec1:

    # you "..!"
    you "..!"

# game/mazeGame.rpy:1784
translate pt_br maze15Menu_ceb48012:

    # you "I think something just changed..."
    you "Acho que alguma coisa mudou..."

# game/mazeGame.rpy:1797
translate pt_br maze15Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1843
translate pt_br maze16Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1856
translate pt_br maze16Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1878
translate pt_br maze16Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1894
translate pt_br maze16Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1903
translate pt_br maze16Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:1941
translate pt_br maze17Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:1957
translate pt_br maze17Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:1965
translate pt_br maze17Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:1966
translate pt_br maze17Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:1969
translate pt_br maze17Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:1978
translate pt_br maze17Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2030
translate pt_br maze18Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2047
translate pt_br maze18Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:2048
translate pt_br maze18Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:2051
translate pt_br maze18Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:2058
translate pt_br maze18Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:2067
translate pt_br maze18Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2116
translate pt_br maze19Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:2117
translate pt_br maze19Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:2120
translate pt_br maze19Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:2133
translate pt_br maze19Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2149
translate pt_br maze19Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:2158
translate pt_br maze19Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2190
translate pt_br maze20Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:2203
translate pt_br maze20Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2220
translate pt_br maze20Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:2221
translate pt_br maze20Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:2224
translate pt_br maze20Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:2233
translate pt_br maze20Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2280
translate pt_br maze21Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:2281
translate pt_br maze21Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:2284
translate pt_br maze21Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:2297
translate pt_br maze21Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2313
translate pt_br maze21Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:2322
translate pt_br maze21Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2374
translate pt_br maze22Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2390
translate pt_br maze22Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:2403
translate pt_br maze22Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2419
translate pt_br maze22Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:2428
translate pt_br maze22Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2460
translate pt_br maze23Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:2468
translate pt_br maze23Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:2469
translate pt_br maze23Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:2473
translate pt_br maze23Menu_ef682bac_1:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:2474
translate pt_br maze23Menu_9af1e7a3_1:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:2477
translate pt_br maze23Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:2486
translate pt_br maze23Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2518
translate pt_br maze24Menu_a9f7373b:

    # you "Okay, next room..."
    you "Tá, próxima sala..."

# game/mazeGame.rpy:2531
translate pt_br maze24Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2548
translate pt_br maze24Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:2549
translate pt_br maze24Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:2552
translate pt_br maze24Menu_5a213e14:

    # you "I'm pretty sure this room has an exit..."
    you "Tenho certeza de que essa sala tem uma saída..."

# game/mazeGame.rpy:2561
translate pt_br maze24Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2613
translate pt_br maze25Menu_76061708:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2635
translate pt_br maze25Menu_76061708_1:

    # you "OW! Not that way!"
    you "AI! Por aí não!"

# game/mazeGame.rpy:2652
translate pt_br maze25Menu_ef682bac:

    # "*CLANG!*"
    "*CLANG!*"

# game/mazeGame.rpy:2653
translate pt_br maze25Menu_9af1e7a3:

    # you "A mirror? I can't go this way!"
    you "Um espelho? Não posso ir por aqui!"

# game/mazeGame.rpy:2656
translate pt_br maze25Menu_dc06f641:

    # you "This room feels off..."
    you "Essa sala parece estranha..."

# game/mazeGame.rpy:2657
translate pt_br maze25Menu_1ad23f1f:

    # you "Just wait..."
    you "Melhor esperar..."

# game/mazeGame.rpy:2658
translate pt_br maze25Menu_dae0ec55:

    # you "..."
    you "..."

# game/mazeGame.rpy:2659
translate pt_br maze25Menu_e4612ec1:

    # you "..!"
    you "..!"

# game/mazeGame.rpy:2660
translate pt_br maze25Menu_ceb48012:

    # you "I think something just changed..."
    you "Acho que alguma coisa mudou..."

# game/mazeGame.rpy:2672
translate pt_br maze25Menu_c3c3f39d:

    # "Crap... Flashlight's dead..."
    "Droga... Acabou a lanterna..."

# game/mazeGame.rpy:2709
translate pt_br mazeWin_8dabefc6:

    # ".."
    ".."

# game/mazeGame.rpy:2710
translate pt_br mazeWin_a20cefa7:

    # "..."
    "..."

# game/mazeGame.rpy:2711
translate pt_br mazeWin_a513413e:

    # "..!"
    "..!"

# game/mazeGame.rpy:2714
translate pt_br mazeWin_0c52a734:

    # "You see it! The exit!"
    "Você vê! É a saída!"

# game/mazeGame.rpy:2717
translate pt_br mazeWin_bb7d045b:

    # "You run forward, but as you do..."
    "Você corre até ela, mas enquanto faz isso..."

# game/mazeGame.rpy:2720
translate pt_br mazeWin_2fa70f34:

    # "...the scenery... {b}shifts{/b}."
    "...o cenário... {b}muda{/b}."

# game/mazeGame.rpy:2721
translate pt_br mazeWin_ca8b0a70:

    # "Just slightly at first..."
    "A princípio, só um pouco..."

# game/mazeGame.rpy:2724
translate pt_br mazeWin_a20cefa7_1:

    # "..."
    "..."

# game/mazeGame.rpy:2725
translate pt_br mazeWin_ee3778a5:

    # "...but you’re running too fast to stop yourself from colliding into the glass."
    "...mas você está correndo rápido demais para evitar bater no vidro."

# game/mazeGame.rpy:2728
translate pt_br mazeWin_a20cefa7_2:

    # "..."
    "..."

# game/mazeGame.rpy:2729
translate pt_br mazeWin_a513413e_1:

    # "..!"
    "..!"

# game/mazeGame.rpy:2730
translate pt_br mazeWin_a5cb5de7:

    # "Except..."
    "Só que..."

# game/mazeGame.rpy:2733
translate pt_br mazeWin_1bd92e64:

    # "...you don’t quite go {i}into{/i} the glass."
    "...você não vai exatamente {i}contra{/i} o vidro."

# game/mazeGame.rpy:2734
translate pt_br mazeWin_3c2eb60a:

    # "You don’t exactly {i}collide{/i} with it either."
    "Também não chega a {i}bater{/i} nele também."

# game/mazeGame.rpy:2735
translate pt_br mazeWin_77c290a9:

    # "You simply... {w}pass {b}through{/b} it."
    "Você simplesmente... {w}{b}passa{/b} por ele."

# game/mazeGame.rpy:2736
translate pt_br mazeWin_c7791603:

    # "And on the other side, you see an endless white void and..."
    "E do outro lado, você vê um vazio branco infinito e..."

# game/mazeGame.rpy:2737
translate pt_br mazeWin_40d9ca73:

    # "..?"
    "..?"

# game/mazeGame.rpy:2740
translate pt_br mazeWin_bb6dce2b:

    # "...yourself?"
    "...você mesmo?"

# game/mazeGame.rpy:2741
translate pt_br mazeWin_6f2f53b2:

    # "Dozens of you."
    "Dezenas de você."

# game/mazeGame.rpy:2742
translate pt_br mazeWin_f99b0994:

    # "{i}Hundreds{/i} of you wandering around..."
    "{i}Centenas{/i} de você vagando por aí..."

# game/mazeGame.rpy:2743
translate pt_br mazeWin_d5c80074:

    # "Aimless..."
    "Sem propósito..."

# game/mazeGame.rpy:2744
translate pt_br mazeWin_d4aabc08:

    # "Faceless..."
    "Sem um rosto..."

# game/mazeGame.rpy:2745
translate pt_br mazeWin_a20cefa7_3:

    # "..."
    "..."

# game/mazeGame.rpy:2746
translate pt_br mazeWin_2bfa9431:

    # "And empty..."
    "E vazios..."

# game/mazeGame.rpy:2747
translate pt_br mazeWin_8a444783:

    # "So empty and listless, they don't even acknowledge your presence."
    "Tão vazios e apáticos que nem mesmo reconhecem sua presença."

# game/mazeGame.rpy:2748
translate pt_br mazeWin_28b3ac41:

    # you "!!"
    you "!!"

# game/mazeGame.rpy:2751
translate pt_br mazeWin_b9a65d59:

    # "You try to turn back..."
    "Você tenta voltar..."

# game/mazeGame.rpy:2752
translate pt_br mazeWin_a20cefa7_4:

    # "..."
    "..."

# game/mazeGame.rpy:2753
translate pt_br mazeWin_8df49ab6:

    # "...but the glass doesn’t give."
    "...mas o vidro não cede."

# game/mazeGame.rpy:2754
translate pt_br mazeWin_e6523116:

    # "Past the glass..."
    "Atrás do vidro..."

# game/mazeGame.rpy:2768
translate pt_br mazeWin_c3b5585c:

    # "...a familiar black cat walks up and looks at you."
    "...um gato preto familiar surge e olha para você."

# game/mazeGame.rpy:2769
translate pt_br mazeWin_6e960518:

    # "You think it meows at you..."
    "Você pensa que ele miou para você..."

# game/mazeGame.rpy:2770
translate pt_br mazeWin_a20cefa7_5:

    # "..."
    "..."

# game/mazeGame.rpy:2771
translate pt_br mazeWin_b1b87e48:

    # "...but you can’t make out the sound."
    "...mas você não consegue ouvir o som."

# game/mazeGame.rpy:2772
translate pt_br mazeWin_7f0ac95c:

    # cat "..."
    cat "..."

# game/mazeGame.rpy:2773
translate pt_br mazeWin_38c1149b:

    # "It tilts its head..."
    "Ele inclina sua cabeça..."

# game/mazeGame.rpy:2776
translate pt_br mazeWin_e391259c:

    # "...then walks away."
    "...e vai embora."

# game/mazeGame.rpy:2779
translate pt_br mazeWin_7d5b08ef:

    # "The glass goes dark..."
    "O vidro escurece..."

# game/mazeGame.rpy:2782
translate pt_br mazeWin_ed2c108e:

    # "Then you watch helplessly as it disappears completely..."
    "Então, você assiste impotente enquanto ele desaparece completamente..."

# game/mazeGame.rpy:2785
translate pt_br mazeWin_8dabefc6_1:

    # ".."
    ".."

# game/mazeGame.rpy:2786
translate pt_br mazeWin_a20cefa7_6:

    # "..."
    "..."

# game/mazeGame.rpy:2787
translate pt_br mazeWin_15e0cbf3:

    # "You’re trapped..."
    "Você está preso..."

# game/mazeGame.rpy:2788
translate pt_br mazeWin_5bbdfcf4:

    # "...with only yourself as company."
    "...apenas consigo mesmo como companhia."

# game/mazeGame.rpy:2789
translate pt_br mazeWin_a20cefa7_7:

    # "..."
    "..."

# game/mazeGame.rpy:2790
translate pt_br mazeWin_cbc07846:

    # "Ending 19: You beat the maze :D"
    "Final 19: Você venceu o labirinto :D"

# game/mazeGame.rpy:2807
translate pt_br mazeLose_8dabefc6:

    # ".."
    ".."

# game/mazeGame.rpy:2808
translate pt_br mazeLose_a20cefa7:

    # "..."
    "..."

# game/mazeGame.rpy:2809
translate pt_br mazeLose_f8342e66:

    # "Suddenly..."
    "De repente..."

# game/mazeGame.rpy:2812
translate pt_br mazeLose_054e707a:

    # "The lights turn on..."
    "As luzes acendem..."

# game/mazeGame.rpy:2813
translate pt_br mazeLose_539b0333:

    # "Your eyes burn from the sudden brightness..."
    "Seus olhos ardem com o clarão repentino..."

# game/mazeGame.rpy:2814
translate pt_br mazeLose_da4b1c21:

    # "As your vision adjusts, you see that you're completely surrounded by mirrors..."
    "À medida que sua visão se ajusta, você vê que está completamente cercado por espelhos..."

# game/mazeGame.rpy:2819
translate pt_br mazeLose_71354367:

    # "The reflections, all grotesque in unique ways..."
    "Os reflexos, um mais grotesco que o outro..."

# game/mazeGame.rpy:2822
translate pt_br mazeLose_f0156f30:

    # "...look nothing like you."
    "...não se parecem nada com você."

# game/mazeGame.rpy:2825
translate pt_br mazeLose_a20cefa7_1:

    # "..."
    "..."

# game/mazeGame.rpy:2826
translate pt_br mazeLose_b19017ca:

    # "But they {i}do{/i} look..."
    "Mas eles {i}parecem{/i}..."

# game/mazeGame.rpy:2828
translate pt_br mazeLose_a20cefa7_2:

    # "..."
    "..."

# game/mazeGame.rpy:2831
translate pt_br mazeLose_515f36c9:

    # "...{b}h u n g r y.{/b}"
    "...{b}f a m i n t o s.{/b}"

# game/mazeGame.rpy:2833
translate pt_br mazeLose_28b3ac41:

    # you "!!"
    you "!!"

# game/mazeGame.rpy:2834
translate pt_br mazeLose_3106400c:

    # "You back up. {w}You don’t know where to go. {w}Was there even a way out to begin with?"
    "Você dá um passo para trás. {w}Você não sabe para onde ir. {w}Havia mesmo uma saída, pra início de conversa?"

# game/mazeGame.rpy:2837
translate pt_br mazeLose_39d54166:

    # "You bump back into a mirror..."
    "Você esbarra em um espelho..."

# game/mazeGame.rpy:2852
translate pt_br mazeLose_f38c3a4c:

    # "...and feel a hand firmly grip your shoulder."
    "...e sente uma mão segurando firme seu ombro."

# game/mazeGame.rpy:2858
translate pt_br mazeLose_c84580e0:

    # "{size=+25}{b}CHOMP!!{/b}{/size}"
    "{size=+25}{b}CHOMP!!{/b}{/size}"

# game/mazeGame.rpy:2859
translate pt_br mazeLose_bbe064f5:

    # you "{b}GAHH!!{/b}" with vpunch
    you "{b}GAHH!!{/b}" with vpunch

# game/mazeGame.rpy:2860
translate pt_br mazeLose_3360de48:

    # "There’s a sharp pain in your other shoulder."
    "Há uma dor aguda em seu outro ombro."

# game/mazeGame.rpy:2867
translate pt_br mazeLose_aa4f8089:

    # "You rip away, looking back to see some... {i}{b}thing{/b}{/i} leaning out of the mirror."
    "Você se solta, olha para trás e vê alguma... {i}{b}coisa{/b}{/i} saindo do espelho."

# game/mazeGame.rpy:2868
translate pt_br mazeLose_a1e48554:

    # "Its face has no features... {w}Save for a large gaping mouth..."
    "Seu rosto não tem feições... {w}Exceto por uma grande boca escancarada..."

# game/mazeGame.rpy:2869
translate pt_br mazeLose_5244ba66:

    # "...stained in your blood."
    "...suja com seu sangue."

# game/mazeGame.rpy:2873
translate pt_br mazeLose_44a8fb9b:

    # "Looking around in a panic, you think that the mirrors feel closer than before."
    "Olhando ao redor em pânico, você acha que os espelhos parecem mais próximos do que antes."

# game/mazeGame.rpy:2874
translate pt_br mazeLose_a01def9f:

    # "The path you'd come in from is long gone."
    "O caminho por onde você entrou sumiu."

# game/mazeGame.rpy:2876
translate pt_br mazeLose_7f1405b1:

    # "You’re surrounded... and every time you blink..."
    "Você está cercado... e cada vez que pisca..."

# game/mazeGame.rpy:2877
translate pt_br mazeLose_986a69fb:

    # "...you could {i}swear{/i} the mirrors were getting closer..."
    "...pode {i}jurar{/i} que os espelhos chegam mais perto..."

# game/mazeGame.rpy:2878
translate pt_br mazeLose_57fba23d:

    # "And closer..."
    "E mais perto..."

# game/mazeGame.rpy:2879
translate pt_br mazeLose_0650d5b6:

    # "...and closer."
    "...e mais perto."

# game/mazeGame.rpy:2880
translate pt_br mazeLose_7865cabc:

    # "Your horrifying reflections looking hungrier..."
    "Seus reflexos horripilantes parecem mais famintos..."

# game/mazeGame.rpy:2881
translate pt_br mazeLose_10364f30:

    # "...and hungrier..."
    "...e mais famintos..."

# game/mazeGame.rpy:2882
translate pt_br mazeLose_becd9a7d:

    # "...and hungr--{w=0.3}{nw}"
    "...e mais famin--{w=0.3}{nw}"

# game/mazeGame.rpy:2894
translate pt_br mazeLose_8dabefc6_1:

    # ".."
    ".."

# game/mazeGame.rpy:2895
translate pt_br mazeLose_a20cefa7_3:

    # "..."
    "..."

# game/mazeGame.rpy:2896
translate pt_br mazeLose_e1f94697:

    # "Ending 20: You failed the maze :("
    "Final 20: Você falhou no labirinto :("

translate pt_br strings:

    # game/mazeGame.rpy:220
    old "Yes, I need help!"
    new "Sim, preciso de ajuda!"

    # game/mazeGame.rpy:220
    old "No! I don't even know you!"
    new "Não! Eu nem te conheço!"

    # game/mazeGame.rpy:220
    old "No, but I have some questions..."
    new "Não, mas tenho algumas perguntas..."

    # game/mazeGame.rpy:316
    old "{b}{size=+5}I'm ready to play!{/size}{/b}"
    new "{b}{size=+5}Tô pronto pra jogar!{/size}{/b}"

    # game/mazeGame.rpy:316
    old "Can you let me go?"
    new "Pode me deixar ir?"

    # game/mazeGame.rpy:316
    old "Can you turn {b}ON{/b} the flash, please?"
    new "Pode {b}LIGAR{/b} o flash, por favor?"

    # game/mazeGame.rpy:316
    old "Can you turn {b}OFF{/b} the flash, please?"
    new "Pode {b}DESLIGAR{/b} o flash, por favor?"

    # game/mazeGame.rpy:316
    old "This game is too hard..."
    new "Esse jogo é muito difícil..."

    # game/mazeGame.rpy:316
    old "Psh! This game's {i}{b}way{/b}{/i} too easy!"
    new "Pff! Esse jogo é fácil {i}{b}demais{/b}{/i}!"

    # game/mazeGame.rpy:316
    old "Reset Settings"
    new "Redefinir Configurações"

    # game/mazeGame.rpy:316
    old "Can you tell me about the maze again?"
    new "Pode me falar sobre o labirinto de novo?"

    # game/mazeGame.rpy:424
    old "LEFT"
    new "ESQUERDA"

    # game/mazeGame.rpy:424
    old "CENTER"
    new "MEIO"

    # game/mazeGame.rpy:424
    old "RIGHT"
    new "DIREITA"

    # game/mazeGame.rpy:424
    old "STAY"
    new "FICAR"

    # game/mazeGame.rpy:424
    old "Flashlight ([flashlight]/[maxLight])"
    new "Lanterna ([flashlight]/[maxLight])"

    old "LIVES: [mazeLives]/[maxLives]"
    new "VIDAS: [mazeLives]/[maxLives]"

    old "Room [roomCounter]/25"
    new "Salas [roomCounter]/25"

    old "[mazeClock]"
    new "[mazeClock]"
