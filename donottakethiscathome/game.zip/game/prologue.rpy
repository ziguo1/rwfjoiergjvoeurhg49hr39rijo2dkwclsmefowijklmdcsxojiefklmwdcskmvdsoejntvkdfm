﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

image p_clock:
    "PROLOGUE/clock01.png"
    pause .12
    "PROLOGUE/clock02.png"
    pause .12
    "PROLOGUE/clock03.png"
    pause .12
    "PROLOGUE/clock04.png"
    pause .12
    "PROLOGUE/clock05.png"
    pause .12
    "PROLOGUE/clock06.png"
    pause .12
    "PROLOGUE/clock07.png"
    pause .12
    "PROLOGUE/clock08.png"
    pause .12
    repeat

image raining:
    "PROLOGUE/rain1.png"
    pause .1
    "PROLOGUE/rain2.png"
    pause .1
    "PROLOGUE/rain3.png"
    pause .1
    repeat

init:
    image bg p1 = "PROLOGUE/prologue01.png"
    image bg p2 = "PROLOGUE/prologue02.png"
    image bg p3 = "PROLOGUE/prologue03.png"
    image bg p4 = "PROLOGUE/prologue04.png"
    image bg p5 = "PROLOGUE/prologue05.png"
    image bg p6 = "PROLOGUE/prologue06.png"
    image bg p7 = "PROLOGUE/prologue07.png"
    image bg p8 = "PROLOGUE/prologue08.png"
    image bg p9 = "PROLOGUE/prologue09.png"
    image bg p9a = "PROLOGUE/prologue09a.png"
    image bg p10 = "PROLOGUE/prologue10.png"
    image bg p11a = "PROLOGUE/prologue11a.png"
    image bg p11b = "PROLOGUE/prologue11b.png"
    image bg p11c = "PROLOGUE/prologue11c.png"
    image bg p11d = "PROLOGUE/prologue11d.png"
    image bg p11e = "PROLOGUE/prologue11e.png"
    image bg p11f = "PROLOGUE/prologue11f.png"
    image bg p11g = "PROLOGUE/prologue11g.png"
    image bg p11h = "PROLOGUE/prologue11h.png"
    image bg p12 = "PROLOGUE/prologue12.png"
    image bg p13 = "PROLOGUE/prologue13.png"
    image bg p14 = "PROLOGUE/prologue14.png"
    image bg p15 = "PROLOGUE/prologue15.png"
    image bg p16 = "PROLOGUE/prologue16.png"
    image bg pKitchen = "normalBGs/apt_KITCHEN.png"
    image bg pLivingRoom = "normalBGs/apt_LIVINGRoom.png"
    image bg owRed = "redSCREEN.png"
    image bg p_flashlight = "PROLOGUE/flashlight.png"
    image bg clockNoCat = "PROLOGUE/clockNoCat.png"
    image bg p_catFood = "PROLOGUE/prologueCatFood.png"

    $ p_Red = Fade(.08, 0.1, .5, color="#FF0000")

screen p_Light():
    add Image("PROLOGUE/flashlight.png")


# The game starts here.

label prologue_start:
    scene black
    "You're not having a great day, as usual."
    play music "audio/rainLOOP.mp3" volume 0.4 loop
    show raining
    with fade_Red
    you "Oh great..."
    "It's the first time in a while that you've felt like going out..."
    "But in the middle of your walk, it starts to rain."
    "Typical. But..."
    "...maybe this is just a sign that you should've stayed home today?"
    "Yeah. You can always try again tomorrow... {w}right?"
    "You turn to head home when--"
    play sound "audio/cat_sadLONG.mp3" volume 0.05
    who "{size=-5}{alpha=0.25}Meow...{/alpha}{/size}"
    you "{i}Huh? What was that..?{/i}"
    "There are only a few people around on the street..."
    "Makes sense due to the increase of missing persons around the area recently..."
    "Well {i}that{/i} and the weather..."
    ".."
    "..."
    "But none of them react to the sound at {i}all.{/i}"
    stop music fadeout 2
    hide raining
    with dissolve
    play music "audio/rainLOOP_Quiet.mp3" loop
    scene bg p2
    with dissolve
    "Curiosity guiding your steps, you follow the sound to the entrance of a dark, dingy alleyway."
    "You timidly enter the alley and walk forward..."
    "The ground dampened by the rain makes your steps sound louder and more confident than you actually feel."
    play sound "audio/cat_sadLONG.mp3" volume 0.1
    who "Meow! Meow!"
    "Finally, the sound's source comes into view in the cold, dim light of the alley..."
    "At the end of the alley, in a big cardboard box..."
    scene bg p3
    with dissolve
    "...is a cat."
    you "Huh. Guess that should've been obvious..."
    "It's an interesting looking cat. Its pretty yellow eyes shine like gold among the dark sea of its black fur."
    scene bg p4
    with dissolve
    "It puts its front paws up on the edge of the box and looks up at you."
    play sound "audio/cat_confused.mp3" volume 0.2
    cat "Meow..."
    you "!!!" with hpunch
    you "{i}S-{w}So cute..!{/i}"
    "And it definitely {i}knows{/i} it..."
    "You've never had much of an opinion one way or another about cats before..."
    "But if they're all like this one..."
    "...it's a shock they haven't already found a way to rule the world."
    "You don't think you'd mind bowing down to a feline overlord."
    you "..."
    "You look around the alley with a small frown."
    you "Who leaves cats in cardboard boxes these days anyway? Wouldn't they just jump out and leave the box eventually?"
    cat "..."
    "The cat doesn't answer you. {w}Obviously."
    "It also doesn't do as you suggest and leave the box."
    "It's just... looking at you?"
    "As if waiting for you to make the next move..."

if not renpy.music.is_playing('music'):
    play music "audio/rainLOOP_Quiet.mp3" loop

menu:
    "Do not take cat home":
        jump prologueChoice1
    "Take cat home":
        jump prologueChoice2

label prologueChoice1:
    scene bg p2
    with dissolve
    "With a sigh, you take a decisive step back."
    "As cute as the cat is, you really can't afford to be taking in a pet on a whim."
    "Rent's coming up soon. And your job doesn't exactly leave you rolling in dough..."
    "You give the cat a sad nod."
    you "Sorry... Good luck out here, okay?"
    cat "..."
    stop music fadeout 2
    pause .6
    play music "audio/rainLOOP.mp3" volume 0.4 loop
    show raining
    with dissolve
    "You turn around and leave the cat and the alley behind."
    play sound "audio/cat_sadLONG.mp3" volume 0.025
    "Rain's picking up."
    stop music fadeout 2
    scene black
    with dissolve
    play sound "audio/cat_sadLONG.mp3" volume 0.007
    "..."
    "Time to head home."
    jump prologueEND1

label prologueChoice2:
    ".."
    "..."
    you "You know what..?"
    scene black
    with dissolve
    "You reach into the box and pick the cat up, holding it out in front of you."
    you "...why not?"
    play sound "audio/cat_happyLONG.mp3" volume 0.2
    cat "Meow!"
    you "You're all alone and well... I'm kind of in the same boat myself. So..."
    "You bring the cat close."
    "You didn't realize it was shivering until just then... but it slowly breathes easier as it presses into your chest."
    you "...why not stick together, right? At least for a little while."
    play sound "audio/cat_purr.mp3" volume 0.3
    cat "Purr... Purr..."
    "You think \"a little while\" will probably be more like a day. You'll be responsible and take it to a shelter tomorrow, but for now..."
    you "Let's get you out of the rain, okay?"
    play sound "audio/cat_happy.mp3" volume 0.4
    cat "Meow..."
    stop music fadeout 2
    pause .6
    play music "audio/rainLOOP.mp3" volume 0.4 loop
    scene bg p5
    with dissolve
    "You stop by a small, local pet store for some cat food, then head back home."
    scene bg p6
    with dissolve
    "You live in a modest apartment."
    scene bg p7
    with dissolve
    "One bedroom. One bathroom."
    "One {i}you{/i} living alone in it..."
    stop music fadeout 4
    scene black
    with dissolve
    "So it feels weird having another living being inside it after so long."
    "Even if it {i}is{/i} just a cat."
    scene bg pLivingRoom
    with dissolve
    play music "audio/LOOPS/01home.mp3" loop
    "After locking the front door and placing the cat on the floor, you watch for a moment as it curiously explores the new environment."
    "Leaving the feline to its own devices, you set about making the both of you some dinner."
    scene bg pKitchen
    with dissolve
    "You take out the can of cat food and open it with the tab on top."
    scene bg p_catFood
    with dissolve
    "You put some cat food on a saucer and click your tongue to call the cat over to you."
    "It perks up at your beckoning and rushes over."
    "It looks at the plate of food..."
    ".."
    "..."
    scene bg pKitchen
    "...and completely ignores it."
    you "Not hungry, I guess..."
    "You try not to let it annoy you."
    "The cat doesn't understand the concept of money to appreciate that you spent your hard-earned cash on it."
    "It's just a cat after all."
    you "I'll just... leave it here if you get hungry later, okay?"
    play sound "audio/cat_purr.mp3" volume 0.3
    "The cat rubs its body against your legs with a purr."
    "You smile. That's enough of a thanks for you."
    "It follows you into the kitchen as you start on your own dinner."
    "You decide that you have enough ingredients for a sandwich."
    "Bread toasted... {w}Mayo and mustard spread... {w}Turkey and cheese and lettuce perfectly placed... {w}Tomato sliced--{w=0.3}{nw}"
    $ renpy.music.set_volume(0.0, 0, "music")
    play sound "audio/cut.mp3" volume 0.2
    show screen blank
    with p_Red
    you "OW!" with vpunch
    hide screen blank
    "You wince as you cut your finger on the knife while slicing a tomato."
    you "Stupid..."
    "You feel a little embarrassed for such a blunder and sigh, tossing the knife onto the cutting board."
    "You're about to head to the bathroom for a bandage when the cat hops up onto the counter."
    "It sniffs at the knife and meows almost pointedly at you."
    you "Hehe... Don't worry, I'm alright. It was just an--"
    you "!!" with hpunch
    "You watch as the cat starts to..."
    "..?"
    play sound "audio/cat_eating.mp3" volume 0.02
    scene bg p8
    with dissolve
    "...lick lightly, but {b}enthusiastically{/b} at the blood on the knife."
    "At {i}your{/i} blood."
    "You're so shocked that by the time you come to your senses, the knife has been completely licked clean."
    scene bg pKitchen
    with dissolve
    "The cat sits back, staring at you."
    you "..."
    "You... {w}feel a little uneasy."
    "Sure cats are meat-eating predators but that was a little weird."
    "Right..?"
    "Sure, you're no cat expert... but that was definitely not something an ordinary cat would do..."
    "..."
    "{size=-5}...Right?{/size}"
    play sound "audio/cat_trilling.mp3" volume 0.3
    cat "Meow!"
    you "..."
    $ renpy.music.set_volume(1.0, 0, "music")
    "Well regardless... You're not about to abandon a cat in need while it's still raining outside. Not after all your efforts."
    "You were going to take it to the shelter tomorrow anyway. What's one night of awkwardness?"
    "Weird or not..."
    "...it's just a cat."
    scene bg pLivingRoom
    with dissolve
    "The rest of the evening, unfortunately, goes downhill from there."
    "Even after covering up your finger's cut with a bandage, the cat keeps trying to lick at the wound."
    "While you're eating your sandwich..."
    "While you're cleaning up the kitchen..."
    "While trying to watch TV..."
    "You gently push it away every time, but you're starting to get worried at the strange behavior."
    "What if it's got a taste for blood and thinks you're food now? You're not sure what you'll do if it starts to get more aggressive."
    "You keep thinking about the cat food sitting in the corner..."
    "...Untouched."
    play sound "audio/cat_angryQUICK.mp3" volume 0.3
    cat "Meow!"
    play sound "audio/cat_beg.mp3" volume 0.4
    cat "Meow! Meow!"
    play sound "audio/cat_angry.mp3" volume 0.5
    cat "Meow! Meow! {b}{i}Meow!{/i}{/b}" with hpunch
    you "Ugh, come on! {i}Enough{/i} already!"
    "You shove it away a little more forcefully this time out of annoyance."
    "You feel bad immediately but before you can do anything, the cat meows sharply at you and dashes off around the corner and into the hall."
    "You sigh deeply."
    "At this point, you're just worried that it's going to take a bite out of you in your sleep."
    you "{i}Maybe a vet will have an idea on how to calm it down..?{/i}"
    "You can only hope. You don't have many other options left other than tossing the cat out in the rain..."
    "After finding the number of a local vet..."
    "...you pick up your landline and--{w=1.0}{nw}"
    stop music
    play sound "audio/click.mp3" volume 0.2
    show screen blackOut
    you "!!"
    you "!!!" with vpunch
    "The lights just..."
    "...went out?"
    scene bg p9
    hide screen blackOut
    with dissolve
    "Great. Just great. Rain must have knocked out the power."
    "You check your cellphone only to find that it's out of batteries."
    "You must have forgotten to charge it before leaving out earlier."
    "The outing had been so spur-of-the-moment that it had no doubt messed with your usual routine."
    "You grab a flashlight and turn it on."
    play sound "audio/click.mp3" volume 0.03
    scene bg p9a
    ".."
    "..."
    "It's quiet."
    "It's {i}too{/i} quiet."
    "Did the rain stop?"
    "But then... why did the power go out?"
    "..."
    "You look outside."
    scene black
    with dissolve
    "The sky is pitch black. What time is it?"
    "You turn to check the clock..."
    you "!!" with vpunch
    play music "audio/heartbeatEcho.mp3" loop
    show screen p_Light
    show p_clock
    with dissolve
    "The cat sits on top of your digital clock, staring at you."
    "Thinking now, you realize the clock shouldn't be working at all with the power outage, but the numbers are lit up..."
    "...and going completely haywire."
    "The cat stares at you. It's completely still. You'd think it was a statue if you didn't know any better."
    "It's not giving off any indication that it's alive."
    "It's not blinking. It's not even breathing. But..."
    "...its eyes..."
    "..."
    "This... isn't normal."
    "You're afraid."
    "You want to run, but you're afraid of letting the cat out of your sight."
    "You consider tossing the cat out after all..."
    play sound "audio/tvStatic.mp3" loop fadein 2
    show static
    with dissolve
    "But..."
    "...as soon as the thought enters your head, {w}you feel a sharp urge to vomit."
    stop sound fadeout 2
    hide static
    with dissolve
    "Those eyes... Its eyes hold you still."
    "Even with your flashlight trained on it..."
    "Its pupils are large, round inky pits--{w=2.0}{nw}"
    stop music
    play sound "audio/click.mp3" volume 0.03
    hide screen p_Light
    pause .15
    play sound "audio/click.mp3" volume 0.03
    show screen p_Light
    pause .2
    play sound "audio/click.mp3" volume 0.03
    hide screen p_Light
    pause .15
    play sound "audio/click.mp3" volume 0.03
    show screen p_Light
    you "!!"
    "The flashlight flickers..."
    play sound "audio/click.mp3" volume 0.03
    hide screen p_Light
    hide p_clock
    scene black
    ".."
    "..."
    scene bg clockNoCat
    with dissolve
    "...and the cat is gone."
    "Fear immediately grips your mind."
    play music "audio/heartbeat.mp3" loop fadein 3
    "The silence punctuated with the rapid pumping of blood in your heart..."
    "...is overwritten as your ears slowly start to pick up the sound of static all around you."
    "How is the clock working with no power..?"
    "You don't know why such a question matters at the moment..."
    "...but you feel as if having the answer will make sense out of everything that's happening."
    "That order will be restored."
    stop music fadeout 2
    "..."
    "But no answer comes to mind."
    scene bg p9
    with dissolve
    "You back away from the clock..."
    "...and feel as if the air itself coils tightly and abruptly in response..."
    "...like a predator prepared to pounce..."
    "...but waiting."
    "Waiting... for your next move."
    "But you're afraid to move. {w}You're afraid to even take a breath."
    "..."
    "But you can't stay still forever... right?"
    "Whatever is watching you... you can already feel its impatience."
    "It's too eager."
    "You don't know how you know this... {w}But you can sense it as clearly as if it had whispered--"
    show text "Let's play~" at truecenter
    with dissolve
    play sound "audio/letsPLAY.mp3" volume 0.1
    pause 2
    hide text
    with dissolve
    "..."
    "...right into your ear."
    "Right into your {i}soul...{/i}"
    "..."
    "It won't let you wait it out. Not that you {i}could{/i} even if it did."
    "You can't stay here."
    "You have to {i}run{/i}."
    "With this thought, a sudden, primal instinct awakens within you..."
    "...making you tear yourself into a hasty burst of movement."
    "Of {i}action{/i}."
    "But..."
    "...You're still weak from the fear's grip on your mind."
    "Your legs tangle together under you in your haste and you fall to the ground."
    play sound "audio/cut.mp3" volume 0.2
    queue sound "audio/splat.mp3" volume 0.2
    scene bg redScreen
    pause .2
    scene black
    with dissolve
    play sound "audio/humanImpact.mp3"
    you "!!!" with vpunch
    "A sharp pain explodes in the center of your foot."
    "At first, you think you've broken your ankle..."
    "...but something warm and {i}wet{/i} trickles down the length of your foot, pooling underneath it."
    play sound "audio/metalFall.mp3" volume 0.2
    "You hear the sound of metal scraping on tiles after skidding across the floor... as if it had been kicked..."
    scene bg p11a
    with dissolve
    "Winded from your fall, you look up in a daze and see the object glinting in a strange light coming in from outside..."
    "...the light pouring in from your now {b}open{/b} front door."
    "Thoughts of how, when, who, {i}what{/i} in regards to your inexplicably opened door screech to a halt..."
    "...as your brain finally identifies the metallic object you've been staring at..."
    "..?"
    "It's your kitchen knife..."
    "And still tinted red from your earlier blunder..? But that's not right."
    "Wasn't it completely licked clean by the..?"
    you "..."
    "You gulp dryly at the pain in your foot."
    "You barely have time to wonder how the knife ended up on your {i}living room floor{/i} to be stepped on..."
    "...instead of resting on your cutting board in the {i}kitchen{/i} where you'd left it..."
    scene bg p11b
    with dissolve
    "...when you spy something in the darkness just beyond the knife..."
    "..."
    "It spies right back at you."
    scene bg p11c
    with dissolve
    "A pair of glowing, golden eyes come forward as the cat emerges from the shadows into the light from your doorway."
    scene bg p11d
    with dissolve
    "It pads lightly over to the knife, as if skipping in delight..."
    scene bg p11e
    with dissolve
    pause .8
    play sound "audio/cat_eating.mp3" volume 0.02
    scene bg p11f
    with dissolve
    "...and bends down to lap at the blood dripping from the blade."
    you "Ah..."
    play music "audio/LOOPS/02prologue.mp3" loop
    "Your senses slowly begin to overwhelm you."
    "The chill of the air as it starts to suffocate you under its weight..."
    "The sound of your shaky breaths, discordant against the static now piercing your skull..."
    "The dryness on your tongue spreading to your throat..."
    scene bg p11g
    with dissolve
    "The incomprehensible sight of the stray you'd taken in... {w}{i}licking{/i} away at your kitchen knife... once again completely clean..."
    "The scent of blood from the fresh wound on your foot..."
    "..?"
    "Blood..?"
    scene bg p11h
    with dissolve
    cat "..."
    "Golden eyes slide up to you as if in response to your sudden realization..."
    "Blood..."
    "You're hurt..."
    "Your foot is bleeding..."
    "You're bleeding..."
    "You're {b}{i}{color=#FF0000}bleeding{/color}{/i}{/b}."
    "The cat barely moves, shoulders twitching as if just {i}considering{/i} the act of pouncing forward..."
    scene black
    with dissolve
    "..."
    "But you're already on your feet and out the door."
    scene bg p12
    with dissolve
    "You run, or rather {i}limp{/i}, down the empty street."
    "The sky is black and bleeding red..."
    "...but there's a strange light emitting from nowhere that casts everything else in white."
    "The houses, the trees, the road, even you..."
    "{i}Everything{/i}..."
    "...except your blood."
    "You can just barely glimpse the bloody imprints your injured foot leaves in your wake with every impact it makes with the ground."
    scene bg p13
    with dissolve
    "It hurts..."
    "It {i}hurts{/i}."
    "But you can't stop. You {i}don't{/i} stop."
    "Not when the shadows grow around you..."
    "Not when you feel the gaze of eyes all over you..."
    play sound "audio/tvStatic.mp3" loop fadein 2
    scene bg p14
    with dissolve
    "Not when the road ahead of you is darkened by a long shadow of {i}something{/i} behind you."
    "Even then... you don't stop running. Because..."
    scene bg p15
    with dissolve
    "If that's the cat right there ahead of you..."
    "Then..."
    "..."
    scene bg p16
    with dissolve
    "{size=-8}...what in the world is behind you?{/size}"

menu:
    "Look behind you.":
        jump prologueEND2
    "Keep running.":
        jump prologueEND2

label prologueEND1:
    "Ending ?: Nya-t A Fool"
    jump endScreen

label prologueEND2:
    scene black
    with dissolve
    stop sound
    stop music
    pause 1
    who "..."
    who "Huh... {w}Interesting..."
    who "How very, very... interesting..."
    "..."
    "Ending 0: It Begins"
    $persistent.realMenu = True
    if persistent.prologue:
        jump endScreen
    else:
        $persistent.prologue = True
        $persistent.endCounter += 1
        jump endScreen

label endScreen:
    # $ persistent.testingNow = False

    return
