﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define rat = Character("Mouse")
define phoneText = Character("Text")
define catOnScreen = Character("Cat on screen")
define audience = Character("Audience")
define dog = Character("Dog")
define catDoll = Character("Cat Doll")
define kitten = Character("Kitten")


default hurtPup1 = 0
default hurtPup2 = 0
default hurtPup3 = 0

default leaveCounter = 0
default fakeOldMovie = 0
default fakeNewMovie = 0
default fakeCarnival = 0
default fakePark = 0

default spareMouseCounter = 0
default feedMouseCounter = 0

default restoreCounter = 0
default gotB = 0
default gotA = 0
default gotC = 0
default gotK = 0
default gotU = 0
default gotP = 0

default clock1 = 0
default clock2 = 0

default restore_clock = 0
default lastAlleyChoice = 0

image theaterStranger:
    "normalBGs/oldTheater7a.png"
    pause .1
    "normalBGs/oldTheater7b.png"
    pause .1
    "normalBGs/oldTheater7c.png"
    pause .1
    repeat

image theaterStrangerSmile:
    "normalBGs/oldTheater7d.png"
    pause .1
    "normalBGs/oldTheater7e.png"
    pause .1
    "normalBGs/oldTheater7f.png"
    pause .1
    repeat

image screenCat:
    "normalBGs/newCinema06a.png"
    pause .1
    "normalBGs/newCinema06b.png"
    pause .1
    "normalBGs/newCinema06c.png"
    pause .1
    repeat

image audienceStare:
    "normalBGs/newCinema08a.png"
    pause .1
    "normalBGs/newCinema08b.png"
    pause .1
    "normalBGs/newCinema08c.png"
    pause .1
    repeat

image cinemaStare:
    "stare1.png"
    pause .1
    "stare2.png"
    pause .1
    "stare3.png"
    pause .1
    repeat

image cinema12:
    "normalBGs/newCinema12b.png"
    pause .1
    "normalBGs/newCinema12c.png"
    pause .1
    "normalBGs/newCinema12d.png"
    pause .1
    repeat

image static:
    "static1.png"
    pause .1
    "static2.png"
    pause .1
    "static3.png"
    pause .1
    repeat

image dogPark5:
    "normalBGs/dogPark05d.png"
    pause 2
    "static3.png"
    pause .1
    "normalBGs/dogPark05e.png"
    pause .2
    "static1.png"
    pause .1
    "static2.png"
    pause .1
    "normalBGs/dogPark05d.png"
    pause 2
    "static3.png"
    pause .1
    "normalBGs/dogPark05f.png"
    pause .2
    "static1.png"
    pause .1
    "static2.png"
    pause .1
    "normalBGs/dogPark05d.png"
    pause 2
    "static3.png"
    pause .1
    "normalBGs/dogPark05g.png"
    pause .2
    "static1.png"
    pause .1
    "static2.png"
    pause .1
    repeat

image dogPark7:
    "normalBGs/dogPark07b.png"
    pause 2
    "normalBGs/dogPark07c.png"
    pause .1
    "normalBGs/dogPark07d.png"
    pause .2
    "normalBGs/dogPark07e.png"
    pause .07
    "normalBGs/dogPark07d.png"
    pause .1
    "normalBGs/dogPark07c.png"
    pause .1
    repeat

image dogPark11:
    "normalBGs/dogPark11a.png"
    pause 2.5
    "normalBGs/dogPark11b.png"
    pause .1
    "normalBGs/dogPark11c.png"
    pause .1
    "normalBGs/dogPark11d.png"
    pause .1
    "normalBGs/dogPark11e.png"
    pause .1
    repeat

image dogPark13:
    "normalBGs/dogPark13a.png"
    pause .1
    "normalBGs/dogPark13b.png"
    pause .1
    "normalBGs/dogPark13c.png"
    pause .1
    repeat

image turnedBack2:
    "normalBGs/turnedBack02b.png"
    pause 2
    "normalBGs/turnedBack02c.png"
    pause .3
    "normalBGs/turnedBack02d.png"
    pause .1
    "normalBGs/turnedBack02e.png"
    pause .1
    repeat

image turnedBack3:
    "normalBGs/turnedBack03c.png"
    pause 2
    "normalBGs/turnedBack03d.png"
    pause .2
    "normalBGs/turnedBack03e.png"
    pause .15
    repeat

image turnedBack4:
    "normalBGs/turnedBack04a.png"
    pause 3.5
    "normalBGs/turnedBack04b.png"
    pause .1
    "normalBGs/turnedBack04c.png"
    pause .09
    "normalBGs/turnedBack04d.png"
    pause .08
    repeat

image mouse4:
    "normalBGs/alleyMouse04a.png"
    pause .1
    "normalBGs/alleyMouse04b.png"
    pause .1
    "normalBGs/alleyMouse04c.png"
    pause .1
    repeat

image mouse6:
    "normalBGs/alleyMouse06a.png"
    pause .1
    "normalBGs/alleyMouse06b.png"
    pause .1
    "normalBGs/alleyMouse06c.png"
    pause .1
    repeat

image mouse7:
    "normalBGs/alleyMouse07b.png"
    pause .3
    "normalBGs/alleyMouse07c.png"
    pause .3
    "normalBGs/alleyMouse07d.png"
    pause .3
    repeat

image mouse8:
    "normalBGs/alleyMouse08b.png"
    pause .1
    "normalBGs/alleyMouse08c.png"
    pause .1
    "normalBGs/alleyMouse08d.png"
    pause .1
    repeat

image mouse9:
    "normalBGs/alleyMouse09a.png"
    pause .1
    "normalBGs/alleyMouse09b.png"
    pause .1
    "normalBGs/alleyMouse09c.png"
    pause .1
    repeat

image feedPockets3:
    "normalBGs/alleyPockets03a.png"
    pause 2
    "normalBGs/alleyPockets03b.png"
    pause .15
    "normalBGs/alleyPockets03c.png"
    pause .6
    "normalBGs/alleyPockets03b.png"
    pause .15
    repeat

image yarnJumpscare:
    "normalBGs/aptYarn06a.png"
    pause .075
    "normalBGs/aptYarn06b.png"
    pause .075
    "normalBGs/aptYarn06c.png"
    pause .075
    "normalBGs/aptYarn06d.png"
    pause .075
    "normalBGs/aptYarn06e.png"
    pause .075
    "normalBGs/aptYarn06f.png"
    pause .075
    "normalBGs/aptYarn06g.png"
    pause .075
    "CAT/upNeutral.png"

image game3:
    "normalBGs/alleyGame03a.png"
    pause .075
    "normalBGs/alleyGame03b.png"
    pause .075
    repeat

image game5:
    "normalBGs/alleyGame05a.png"
    pause 2.5
    "normalBGs/alleyGame05b.png"
    pause .15
    "normalBGs/alleyGame05c.png"
    pause .15
    "normalBGs/alleyGame05d.png"
    pause .15
    "normalBGs/alleyGame05e.png"
    pause .15
    "normalBGs/alleyGame05f.png"
    pause .15
    "normalBGs/alleyGame05g.png"
    pause .15
    "normalBGs/alleyGame05h.png"
    pause .15
    "normalBGs/alleyGame05i.png"
    pause .15
    "normalBGs/alleyGame05j.png"
    pause .15
    "normalBGs/alleyGame05k.png"
    pause .15
    "normalBGs/alleyGame05l.png"
    pause .15
    repeat

image doll2:
    "normalBGs/alleyDoll02a.png"
    pause 1.25
    "normalBGs/alleyDoll02b.png"
    pause .15
    "normalBGs/alleyDoll02c.png"
    pause .3
    "normalBGs/alleyDoll02d.png"
    pause .15
    "normalBGs/alleyDoll02e.png"
    pause .15
    "normalBGs/alleyDoll02f.png"
    pause .15
    "normalBGs/alleyDoll02g.png"
    pause .15
    "normalBGs/alleyDoll02h.png"
    pause .15
    "normalBGs/alleyDoll02i.png"
    pause .15
    "normalBGs/alleyDoll02j.png"
    pause .15
    repeat

image doll3:
    "normalBGs/alleyDoll03a.png"
    pause 1.25
    "normalBGs/alleyDoll03b.png"
    pause .15
    "normalBGs/alleyDoll03c.png"
    pause .3
    "normalBGs/alleyDoll03d.png"
    pause .15
    "normalBGs/alleyDoll03e.png"
    pause .15
    "normalBGs/alleyDoll03f.png"
    pause .15
    "normalBGs/alleyDoll03g.png"
    pause .15
    "normalBGs/alleyDoll03h.png"
    pause .15
    "normalBGs/alleyDoll03i.png"
    pause .15
    "normalBGs/alleyDoll03j.png"
    pause .15
    repeat



init:
    image bg phone1a = "normalBGs/alleyPhone01a.png"
    image bg phone1b = "normalBGs/alleyPhone01b.png"
    image bg phone1c = "normalBGs/alleyPhone01c.png"
    image bg phone1d = "normalBGs/alleyPhone01d.png"
    image bg phone1e = "normalBGs/alleyPhone01e.png"
    image bg phone2a = "normalBGs/alleyPhone02a.png"
    image bg phone2b = "normalBGs/alleyPhone02b.png"
    image bg phone3a = "normalBGs/alleyPhone03a.png"
    image bg phone3b = "normalBGs/alleyPhone03b.png"
    image bg phone4a = "normalBGs/alleyPhone04a.png"
    image bg phone4b = "normalBGs/alleyPhone04b.png"
    image bg phone4c = "normalBGs/alleyPhone04c.png"
    image bg phone5a = "normalBGs/alleyPhone05a.png"
    image bg phone5b = "normalBGs/alleyPhone05b.png"
    image bg phone6a = "normalBGs/alleyPhone06a.png"
    image bg phone6b = "normalBGs/alleyPhone06b.png"
    image bg phone7a = "normalBGs/alleyPhone07a.png"
    image bg phone7b = "normalBGs/alleyPhone07b.png"
    image bg phone7c = "normalBGs/alleyPhone07c.png"
    image bg phone7d = "normalBGs/alleyPhone07d.png"
    image bg phone7e = "normalBGs/alleyPhone07e.png"
    image bg phone8a = "normalBGs/alleyPhone08a.png"
    image bg phone8b = "normalBGs/alleyPhone08b.png"
    image bg phone8c = "normalBGs/alleyPhone08c.png"
    image bg phone8d = "normalBGs/alleyPhone08d.png"
    image bg phone9a = "normalBGs/alleyPhone09a.png"
    image bg phone9b = "normalBGs/alleyPhone09b.png"
    image bg phone9c = "normalBGs/alleyPhone09c.png"
    image bg phone9d = "normalBGs/alleyPhone09d.png"
    image bg phone9e = "normalBGs/alleyPhone09e.png"
    image bg phone9f = "normalBGs/alleyPhone09f.png"
    image bg phone9g = "normalBGs/alleyPhone09g.png"
    image bg phone9h = "normalBGs/alleyPhone09h.png"
    image bg phone10a = "normalBGs/alleyPhone10a.png"
    image bg phone10b = "normalBGs/alleyPhone10b.png"
    image bg phone11a = "normalBGs/alleyPhone11a.png"
    image bg phone11b = "normalBGs/alleyPhone11b.png"
    image bg carnival1 = "normalBGs/carnival01.png"
    image bg carnival2 = "normalBGs/carnival02.png"
    image bg carnival3 = "normalBGs/carnival03.png"
    image bg carnival4 = "normalBGs/carnival04.png"
    image bg carnival5 = "normalBGs/carnival05.png"
    image bg dogPark1 = "normalBGs/dogPark01.png"
    image bg dogPark2 = "normalBGs/dogPark02.png"
    image bg dogPark3 = "normalBGs/dogPark03.png"
    image bg dogPark4 = "normalBGs/dogPark04.png"
    image bg dogPark5a = "normalBGs/dogPark05a.png"
    image bg dogPark5b = "normalBGs/dogPark05b.png"
    image bg dogPark5c = "normalBGs/dogPark05c.png"
    image bg dogPark5d = "normalBGs/dogPark05d.png"
    image bg dogPark6a = "normalBGs/dogPark06a.png"
    image bg dogPark6b = "normalBGs/dogPark06b.png"
    image bg dogPark6c = "normalBGs/dogPark06c.png"
    image bg dogPark6d = "normalBGs/dogPark06d.png"
    image bg dogPark6e = "normalBGs/dogPark06e.png"
    image bg dogPark6f = "normalBGs/dogPark06f.png"
    image bg dogPark6g = "normalBGs/dogPark06g.png"
    image bg dogPark6h = "normalBGs/dogPark06h.png"
    image bg dogPark7a = "normalBGs/dogPark07a.png"
    image bg dogPark7b = "normalBGs/dogPark07b.png"
    image bg dogPark7f = "normalBGs/dogPark07f.png"
    image bg dogPark8a = "normalBGs/dogPark08a.png"
    image bg dogPark8b = "normalBGs/dogPark08b.png"
    image bg dogPark8c = "normalBGs/dogPark08c.png"
    image bg dogPark9a = "normalBGs/dogPark09a.png"
    image bg dogPark9b = "normalBGs/dogPark09b.png"
    image bg dogPark9c = "normalBGs/dogPark09c.png"
    image bg dogPark9d = "normalBGs/dogPark09d.png"
    image bg dogPark9e = "normalBGs/dogPark09e.png"
    image bg dogPark9f = "normalBGs/dogPark09f.png"
    image bg dogPark10a = "normalBGs/dogPark10a.png"
    image bg dogPark10b = "normalBGs/dogPark10b.png"
    image bg dogPark10c = "normalBGs/dogPark10c.png"
    image bg dogPark11a = "normalBGs/dogPark11a.png"
    image bg dogPark12a = "normalBGs/dogPark12a.png"
    image bg dogPark12b = "normalBGs/dogPark12b.png"
    image bg dogPark12c = "normalBGs/dogPark12c.png"
    image bg dogPark12d = "normalBGs/dogPark12d.png"
    image bg dogPark12e = "normalBGs/dogPark12e.png"
    image bg dogPark12f = "normalBGs/dogPark12f.png"
    image bg dogPark12g = "normalBGs/dogPark12g.png"
    image bg dogPark12h = "normalBGs/dogPark12h.png"
    image bg dogPark12i = "normalBGs/dogPark12i.png"
    image bg dogPark12j = "normalBGs/dogPark12j.png"
    image bg dogPark12k = "normalBGs/dogPark12k.png"
    image bg dogPark12l = "normalBGs/dogPark12l.png"
    image bg dogPark12m = "normalBGs/dogPark12m.png"
    image bg dogPark12n = "normalBGs/dogPark12n.png"
    image bg dogPark12o = "normalBGs/dogPark12o.png"
    image bg cinema1 = "normalBGs/newCinema01.png"
    image bg cinema2 = "normalBGs/newCinema02.png"
    image bg cinema3 = "normalBGs/newCinema03.png"
    image bg cinema4 = "normalBGs/newCinema04.png"
    image bg cinema5a = "normalBGs/newCinema05a.png"
    image bg cinema5b = "normalBGs/newCinema05b.png"
    image bg cinema7a = "normalBGs/newCinema07a.png"
    image bg cinema7b = "normalBGs/newCinema07b.png"
    image bg cinema7c = "normalBGs/newCinema07c.png"
    image bg cinema9a = "normalBGs/newCinema09a.png"
    image bg cinema9b = "normalBGs/newCinema09b.png"
    image bg cinema9c = "normalBGs/newCinema09c.png"
    image bg cinema9d = "normalBGs/newCinema09d.png"
    image bg cinema9e = "normalBGs/newCinema09e.png"
    image bg cinema9f = "normalBGs/newCinema09f.png"
    image bg cinema9g = "normalBGs/newCinema09g.png"
    image bg cinema9h = "normalBGs/newCinema09h.png"
    image bg cinema10a = "normalBGs/newCinema10a.png"
    image bg cinema10b = "normalBGs/newCinema10b.png"
    image bg cinema11a = "normalBGs/newCinema11a.png"
    image bg cinema11b = "normalBGs/newCinema11b.png"
    image bg cinema11c = "normalBGs/newCinema11c.png"
    image bg cinema11d = "normalBGs/newCinema11d.png"
    image bg cinema11e = "normalBGs/newCinema11e.png"
    image bg cinema11f = "normalBGs/newCinema11f.png"
    image bg cinema11g = "normalBGs/newCinema11g.png"
    image bg cinema12a = "normalBGs/newCinema12a.png"
    image bg cinema13a = "normalBGs/newCinema13a.png"
    image bg cinema13b = "normalBGs/newCinema13b.png"
    image bg cinema13c = "normalBGs/newCinema13c.png"
    image bg cinema13d = "normalBGs/newCinema13d.png"
    image bg theater1 = "normalBGs/oldTheater01.png"
    image bg theater2 = "normalBGs/oldTheater02.png"
    image bg theater3 = "normalBGs/oldTheater03.png"
    image bg theater4 = "normalBGs/oldTheater04.png"
    image bg theater5a = "normalBGs/oldTheater05a.png"
    image bg theater5b = "normalBGs/oldTheater05b.png"
    image bg theater5c = "normalBGs/oldTheater05c.png"
    image bg theater6a = "normalBGs/oldTheater6a.png"
    image bg theater6b = "normalBGs/oldTheater6b.png"
    image bg theater6c = "normalBGs/oldTheater6c.png"
    image bg theater6d = "normalBGs/oldTheater6d.png"
    image bg theater6e = "normalBGs/oldTheater6e.png"
    image bg theater6f = "normalBGs/oldTheater6f.png"
    image bg theater8a = "normalBGs/oldTheater8a.png"
    image bg theater8b = "normalBGs/oldTheater8b.png"
    image bg theater8c = "normalBGs/oldTheater8c.png"
    image bg theater8d = "normalBGs/oldTheater8d.png"
    image bg theater8e = "normalBGs/oldTheater8e.png"
    image bg theater8f = "normalBGs/oldTheater8f.png"
    image bg theater8g = "normalBGs/oldTheater8g.png"
    image bg theater8h = "normalBGs/oldTheater8h.png"
    image bg turnedBack1a = "normalBGs/turnedBack01a.png"
    image bg turnedBack1b = "normalBGs/turnedBack01b.png"
    image bg turnedBack2a = "normalBGs/turnedBack02a.png"
    image bg turnedBack2b = "normalBGs/turnedBack02b.png"
    image bg turnedBack5a = "normalBGs/turnedBack05a.png"
    image bg turnedBack5b = "normalBGs/turnedBack05b.png"
    image bg turnedBack6a = "normalBGs/turnedBack06a.png"
    image bg turnedBack6b = "normalBGs/turnedBack06b.png"
    image bg turnedBack6c = "normalBGs/turnedBack06c.png"
    image bg turnedBack6d = "normalBGs/turnedBack06d.png"
    image bg blood1 = "normalBGs/alleyBlood01.png"
    image bg blood2a = "normalBGs/alleyBlood02a.png"
    image bg blood2b = "normalBGs/alleyBlood02b.png"
    image bg blood2c = "normalBGs/alleyBlood02c.png"
    image bg blood3a = "normalBGs/alleyBlood03a.png"
    image bg blood3b = "normalBGs/alleyBlood03b.png"
    image bg blood4a = "normalBGs/alleyBlood04a.png"
    image bg blood4b = "normalBGs/alleyBlood04b.png"
    image bg blood4c = "normalBGs/alleyBlood04c.png"
    image bg blood4d = "normalBGs/alleyBlood04d.png"
    image bg blood4e = "normalBGs/alleyBlood04e.png"
    image bg blood4f = "normalBGs/alleyBlood04f.png"
    image bg blood4g = "normalBGs/alleyBlood04g.png"
    image bg blood4h = "normalBGs/alleyBlood04h.png"
    image bg blood4i = "normalBGs/alleyBlood04i.png"
    image bg blood5a = "normalBGs/alleyBlood05a.png"
    image bg blood5b = "normalBGs/alleyBlood05b.png"
    image bg blood5c = "normalBGs/alleyBlood05c.png"
    image bg blood5d = "normalBGs/alleyBlood05d.png"
    image bg blood5e = "normalBGs/alleyBlood05e.png"
    image bg blood5f = "normalBGs/alleyBlood05f.png"
    image bg blood5g = "normalBGs/alleyBlood05g.png"
    image bg blood5h = "normalBGs/alleyBlood05h.png"
    image bg blood5i = "normalBGs/alleyBlood05i.png"
    image bg blood5j = "normalBGs/alleyBlood05j.png"
    image bg blood5k = "normalBGs/alleyBlood05k.png"
    image bg blood5l = "normalBGs/alleyBlood05l.png"
    image bg blood5m = "normalBGs/alleyBlood05m.png"
    image bg blood5n = "normalBGs/alleyBlood05n.png"
    image bg blood5o = "normalBGs/alleyBlood05o.png"
    image bg blood5p = "normalBGs/alleyBlood05p.png"
    image bg blood5q = "normalBGs/alleyBlood05q.png"
    image bg blood5r = "normalBGs/alleyBlood05r.png"
    image bg blood5s = "normalBGs/alleyBlood05s.png"
    image bg blood5t = "normalBGs/alleyBlood05t.png"
    image bg blood5u = "normalBGs/alleyBlood05u.png"
    image bg blood6a = "normalBGs/alleyBlood06a.png"
    image bg blood6b = "normalBGs/alleyBlood06b.png"
    image bg blood7a = "normalBGs/alleyBlood07a.png"
    image bg blood7b = "normalBGs/alleyBlood07b.png"
    image bg blood7c = "normalBGs/alleyBlood07c.png"
    image bg blood7d = "normalBGs/alleyBlood07d.png"
    image bg blood7e = "normalBGs/alleyBlood07e.png"
    image bg blood7f = "normalBGs/alleyBlood07f.png"
    image bg blood8 = "normalBGs/alleyBlood08.png"
    image bg mouse1a = "normalBGs/alleyMouse01a.png"
    image bg mouse1b = "normalBGs/alleyMouse01b.png"
    image bg mouse1c = "normalBGs/alleyMouse01c.png"
    image bg mouse1d = "normalBGs/alleyMouse01d.png"
    image bg mouse1e = "normalBGs/alleyMouse01e.png"
    image bg mouse2a = "normalBGs/alleyMouse02a.png"
    image bg mouse2b = "normalBGs/alleyMouse02b.png"
    image bg mouse2c = "normalBGs/alleyMouse02c.png"
    image bg mouse3a = "normalBGs/alleyMouse03a.png"
    image bg mouse3b = "normalBGs/alleyMouse03b.png"
    image bg mouse5a = "normalBGs/alleyMouse05a.png"
    image bg mouse5b = "normalBGs/alleyMouse05b.png"
    image bg mouse7a = "normalBGs/alleyMouse07a.png"
    image bg mouse7b = "normalBGs/alleyMouse07b.png"
    image bg mouse7c = "normalBGs/alleyMouse07c.png"
    image bg mouse7d = "normalBGs/alleyMouse07d.png"
    image bg mouse8a = "normalBGs/alleyMouse08a.png"
    image bg feedPockets1a = "normalBGs/alleyPockets01a.png"
    image bg feedPockets1b = "normalBGs/alleyPockets01b.png"
    image bg feedPockets1c = "normalBGs/alleyPockets01c.png"
    image bg feedPockets2a = "normalBGs/alleyPockets02a.png"
    image bg feedPockets2b = "normalBGs/alleyPockets02b.png"
    image bg feedPockets2c = "normalBGs/alleyPockets02c.png"
    image bg feedPockets2d = "normalBGs/alleyPockets02d.png"
    image bg feedPockets2e = "normalBGs/alleyPockets02e.png"
    image bg feedPockets2f = "normalBGs/alleyPockets02f.png"
    image bg feedPockets2g = "normalBGs/alleyPockets02g.png"
    image bg feedPockets3a = "normalBGs/alleyPockets03a.png"
    image bg feedPockets3b = "normalBGs/alleyPockets03b.png"
    image bg feedPockets3c = "normalBGs/alleyPockets03c.png"
    image bg feedPockets4a = "normalBGs/alleyPockets04a.png"
    image bg feedPockets4b = "normalBGs/alleyPockets04b.png"
    image bg feedPockets4c = "normalBGs/alleyPockets04c.png"
    image bg feedPockets4d = "normalBGs/alleyPockets04d.png"
    image bg feedPockets4e = "normalBGs/alleyPockets04e.png"
    image bg feedPockets5a = "normalBGs/alleyPockets05a.png"
    image bg feedPockets5b = "normalBGs/alleyPockets05b.png"
    image bg feedPockets5c = "normalBGs/alleyPockets05c.png"
    image bg feedPockets5d = "normalBGs/alleyPockets05d.png"
    image bg feedPockets5e = "normalBGs/alleyPockets05e.png"
    image bg feedPockets5f = "normalBGs/alleyPockets05f.png"
    image bg feedPockets5g = "normalBGs/alleyPockets05g.png"
    image bg feedPockets5h = "normalBGs/alleyPockets05h.png"
    image bg feedPockets5i = "normalBGs/alleyPockets05i.png"
    image bg feedPockets6a = "normalBGs/alleyPockets06a.png"
    image bg feedPockets6b = "normalBGs/alleyPockets06b.png"
    image bg feedPockets6c = "normalBGs/alleyPockets06c.png"
    image bg feedPockets6d = "normalBGs/alleyPockets06d.png"
    image bg feedPockets6e = "normalBGs/alleyPockets06e.png"
    image bg feedPockets6f = "normalBGs/alleyPockets06f.png"
    image bg feedPockets6g = "normalBGs/alleyPockets06g.png"
    image bg feedPockets6h = "normalBGs/alleyPockets06h.png"
    image bg feedPockets7a = "normalBGs/alleyPockets07a.png"
    image bg feedPockets7b = "normalBGs/alleyPockets07b.png"
    image bg game1a = "normalBGs/alleyGame01a.png"
    image bg game2a = "normalBGs/alleyGame02a.png"
    image bg game2b = "normalBGs/alleyGame02b.png"
    image bg game2c = "normalBGs/alleyGame02c.png"
    image bg game4a = "normalBGs/alleyGame04a.png"
    image bg game6a = "normalBGs/alleyGame06a.png"
    image bg game6b = "normalBGs/alleyGame06b.png"
    image bg game6c = "normalBGs/alleyGame06c.png"
    image bg game6d = "normalBGs/alleyGame06d.png"
    image bg game6e = "normalBGs/alleyGame06e.png"
    image bg game6f = "normalBGs/alleyGame06f.png"
    image bg game6g = "normalBGs/alleyGame06g.png"
    image bg game7a = "normalBGs/alleyGame07a.png"
    image bg game7b = "normalBGs/alleyGame07b.png"
    image bg game7c = "normalBGs/alleyGame07c.png"
    image bg game8a = "normalBGs/alleyGame08a.png"
    image bg game8b = "normalBGs/alleyGame08b.png"
    image bg toy = "normalBGs/alleyToy.png"
    image bg toy1a = "normalBGs/alleyToy01a.png"
    image bg toy1b = "normalBGs/alleyToy01b.png"
    image bg toy1c = "normalBGs/alleyToy01c.png"
    image bg toy2a = "normalBGs/alleyToy02a.png"
    image bg toy3a = "normalBGs/alleyToy03a.png"
    image bg toy3b = "normalBGs/alleyToy03b.png"
    image bg toy3c = "normalBGs/alleyToy03c.png"
    image bg toy3d = "normalBGs/alleyToy03d.png"
    image bg toy3e = "normalBGs/alleyToy03e.png"
    image bg toy3f = "normalBGs/alleyToy03f.png"
    image bg toy3g = "normalBGs/alleyToy03g.png"
    image bg toy3h = "normalBGs/alleyToy03h.png"
    image bg toy3i = "normalBGs/alleyToy03i.png"
    image bg toy4a = "normalBGs/alleyToy04a.png"
    image bg toy4b = "normalBGs/alleyToy04b.png"
    image bg toy4c = "normalBGs/alleyToy04c.png"
    image bg toy5a = "normalBGs/alleyToy05a.png"
    image bg toy5b = "normalBGs/alleyToy05b.png"
    image bg toy5c = "normalBGs/alleyToy05c.png"
    image bg toy5d = "normalBGs/alleyToy05d.png"
    image bg toy5e = "normalBGs/alleyToy05e.png"
    image bg toy5f = "normalBGs/alleyToy05f.png"
    image bg toy5g = "normalBGs/alleyToy05g.png"
    image bg toy5h = "normalBGs/alleyToy05h.png"
    image bg toy5i = "normalBGs/alleyToy05i.png"
    image bg doll1a = "normalBGs/alleyDoll01a.png"
    image bg doll1b = "normalBGs/alleyDoll01b.png"
    image bg doll1c = "normalBGs/alleyDoll01c.png"
    image bg doll1d = "normalBGs/alleyDoll01d.png"
    image bg doll1d1 = "normalBGs/alleyDoll01d1.png"
    image bg doll1d2 = "normalBGs/alleyDoll01d2.png"
    image bg doll1d3 = "normalBGs/alleyDoll01d3.png"
    image bg doll1d4 = "normalBGs/alleyDoll01d4.png"
    image bg doll1e = "normalBGs/alleyDoll01e.png"
    image bg doll1f = "normalBGs/alleyDoll01f.png"
    image bg doll1g = "normalBGs/alleyDoll01g.png"
    image bg doll1h = "normalBGs/alleyDoll01h.png"
    image bg doll1i = "normalBGs/alleyDoll01i.png"
    image bg doll1j = "normalBGs/alleyDoll01j.png"
    image bg doll1k = "normalBGs/alleyDoll01k.png"
    image bg chocolate = "chocolate.png"
    image bg shortString = "shortString.png"

screen chocolatePanel():
    add Image("chocolate.png")

screen stringPanel():
    add Image("shortString.png")


screen pickUpPup_timer():
    text "[clock1]" size 72 color "#FFF"
    if clock1 <= 10:
        text "[clock1]" size 72 color "#FF0000"
    if clock1 >= 1:
        timer 1 repeat True action [
                SetVariable("clock1", clock1 - 1),
                renpy.restart_interaction
            ]
    else:
        timer 1 action [
                Hide("pickUpPup_timer"),
                Jump("time_outPup")
            ]

screen frisbee_timer():
    text "[clock2]" size 72 color "#FFF"
    if clock2 <= 10:
        text "[clock2]" size 72 color "#FF0000"
    if clock2 >= 1:
        timer 1 repeat True action [
                SetVariable("clock2", clock2 - 1),
                renpy.restart_interaction
            ]
    else:
        timer 1 action [
                Hide("frisbee_timer"),
                Jump("didntThrowFrisbee")
            ]

screen restore_timer():
    text "[restore_clock]" size 72 color "#FFF"
    if restore_clock <= 10:
        text "[restore_clock]" size 72 color "#FF0000"
    if restore_clock >= 1:
        timer 1 repeat True action [
                SetVariable("restore_clock", restore_clock - 1),
                renpy.restart_interaction
            ]
    else:
        timer 1 action [
                Hide("restore_timer"),
                Jump("restoreBackUp")
            ]


# The game starts here.

label inAlley_start:

if not renpy.music.is_playing('music'):
    play music "audio/LOOPS/03catTheme.mp3" loop

menu:
    "Leave cat":
        jump leaveCat
    "Feed cat":
        jump feedAlley
    "Play with cat":
        jump playAlley
    "On second thought...":
        jump mainChoiceMenu
    "?????" if persistent.endCounter <= 35:
        "..."
        $ renpy.music.set_volume(0.0, 0, "music")
        show screen blackOut
        "{b}{size=-10}You are not ready.{/size}{/b}"
        $ renpy.music.set_volume(1.0, 0, "music")
        hide screen blackOut
        jump inAlley_start
    "{b}You are ready...{/b}" if persistent.endCounter >= 36 and lastAlleyChoice == 0:
        stop music fadeout 1.5
        scene black
        with dissolve
        "Only one thing left..."
        "So..."
        "What should you do with a cat that has been {i}very...{/i}"
        "{i}very...{/i}"
        "{i}{size=+10}very...{/size}{/i}"
        "{color=#FF0000}{b}n a u g h t y . . ?{/b}{/color}"
        jump runEndgame
    "{color=#FF0000}{b}K I L L{/b}{/color} \ cat.." if lastAlleyChoice == 1:
        jump endCat


label leaveCat:
    you "..."
    "You don't think it's a good idea to get the cat's hopes up of having someone look after it if you're not willing to commit."
    "What if it gets attached and somehow tracks you down back to your home?"
    "{size=-10}You'd never get away from it, then.{/size}{w=0.4}{nw}"
    you "Sorry... See you around, I guess."
    "You stand up, the cat watching your every move."
    scene bg alley2
    with dissolve
    play sound "audio/cat_sadLONG.mp3" volume 0.2
    "You make it halfway out of the alley when the cat meows almost pitifully at you."
    scene bg upSad
    with dissolve
    pause .1
    scene bg upSadMeow
    with dissolve
    play sound "audio/cat_sad.mp3" volume 0.4
    cat "Meoww... Meoww... Meowwww..."
    scene bg upSad
    you "..."

if not renpy.music.is_playing('music'):
    play music "audio/LOOPS/03catTheme.mp3" loop

menu:
    "Ignore":
        scene bg alley2
        with dissolve
        "No. Nope. You need to nip this in the bud and get on with your day."
        "It's what's best for the both of you."
        stop music fadeout 2.5
        scene bg street1
        with dissolve
        "You leave the alley and continue on your way."
        you "Wait, what was I doing..?"
        "In all the excitement of dealing with your furry dilemma..."
        "...you'd forgotten that you still hadn't decided on what you were going to do for your day off."
        play music "audio/LOOPS/20possibilitiesLOOP.mp3" loop
        jump aloneMenu
    "Turn back":
        "Awwww~"
        "How are you supposed to walk away from {i}that?{/i}"
        "What kind of {b}monster{/b} would you be if you could?"
        jump turnedBack

label aloneMenu:
    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/20possibilitiesLOOP.mp3" loop

menu:
    "I think I'll..."
    "Go watch a movie":
        jump goToMovies
    "Go to the carnival":
        jump goToCarnival
    "Go to dog park":
        jump goToDogPark


label goToMovies:
    scene bg street2
    with dissolve
    "It's been a while since a film came out that looked interesting enough for you to drag yourself to a movie theater..."
    "...but there's a showing of one such film at the old theater."
    "The movie was a little too niche to be picked up by the new cinema that opened right across the street."
    "That's okay though. You're not exactly a fan of the crowds."
    "And nothing ruins the experience of watching a new movie for you more than a noisy audience."

    label moviesMenu:
        if not renpy.music.is_playing('music'):
            play music "audio/LOOPS/20possibilitiesLOOP.mp3" loop
        menu:
            "Go to the old theater.":
                stop music fadeout 2
                jump oldTheater
            "Go to the new cinema.":
                "You don’t know why...{w} but you don’t really feel great about the idea of being alone right now."
                stop music fadeout 2
                scene bg cinema1
                with dissolve
                jump newCinema
            "On second thought...":
                jump aloneMenu


    label oldTheater:
        scene bg theater1
        with dissolve
        "You eagerly buy your ticket from the kind old man in the booth and head inside."
        play music "audio/LOOPS/21pictureShowLOOP.mp3" loop
        scene bg theater4
        with dissolve
        "It’s barren of any trace of other people and the décor looks like it hasn’t changed since the eighties..."
        "...maybe even the seventies."
        "But it’s what you were counting on."
        "You consider buying some popcorn..."
        "...but can’t help but be concerned that everything at the concession stand might be expired."
        scene bg theater2
        with dissolve
        "You move on and walk through the halls, finally locating the theater designated on your ticket stub."
        scene bg theater5a
        with dissolve
        "As expected, the theater your movie will be playing in is completely empty."
        "Perfect."
        "You pick a spot right in the middle, even counting the seats and taking into consideration the gap of the staircase."
        #stop music fadeout 1.5
        scene black
        with dissolve
        "As you settle in, the dim lights fade away leaving the room pitch black for a few seconds..."
        ".."
        "..."
        scene bg theater5b
        with dissolve
        "...before the screen flickers on."
        "No commercials or trailers pop up – the movie just begins."
        "Pleased, you shrug and let yourself get immersed in the opening scene."
        "But just as you’re getting into the premise..."
        scene bg theater5b
        with whiteFlash
        "...the doors open behind you, momentarily casting light into the room and ruining the atmosphere."
        "You hold in a frustrated sigh."
        "It’s a public establishment after all."
        "The place can’t exactly afford to stay open if {i}you’re{/i} the only customer."
        "You try to refocus on the movie but you sense the new presence slowly shifting around the theater..."
        "...before heading in your general direction."
        ".."
        "..."
        stop music fadeout 1.5
        you "..?! Wha-"
        scene bg theater6a
        with dissolve
        pause .1
        scene bg theater6b
        with dissolve
        pause .1
        scene bg theater6c
        with dissolve
        pause .1
        scene bg theater6d
        with dissolve
        pause .1
        "You gape in utter disbelief as the stranger shuffles down the aisle only to sit {b}RIGHT{/b} in front of you."
        you "..."
        "There’s no one else here and plenty of places to sit."
        "The stranger is also..."
        "...{i}unusually{/i} tall."
        "Even with the stadium-like arrangement of the seats being on a somewhat steep incline, they’re completely blocking your view."

    menu:
        "Move to another spot.":
            jump moveTheater1
        "Confront the stranger.":
            jump confrontTheater
        "Leave the theater.":
            "This is too weird."
            "Feeling uncomfortable, you decide to leave the theater. There's still enough time left in the day to do something else."
            scene black
            with wipeleft
            pause .6
            scene bg street2
            with dissolve
            "Now what?"
            jump moviesMenu

    label moveTheater1:
        "You don’t want to risk escalating the situation further. This whole thing is already making you uneasy."
        "Why would they choose to sit right in front of you? Surely they know you wouldn’t be able to see past them?"
        scene bg theater5b
        with dissolve
        "Shaking your head with a passive aggressive scoff in the stranger's direction... {w}you reluctantly pick another, less perfect, seat in the theater..."
        "But..."
        "As you settle down..."
        "...you see the strange person get up..."
        scene bg theater6d
        with dissolve
        "...only to once again sit down in the seat {i}directly{/i} in front of you."
        you "!!!"
        "You look around somewhat helplessly as if waiting for someone to silently agree with you about how odd all of this is."
        "Or to at least inform you that it's all an elaborate prank."
        "But there’s no one else here with you. That's how you’ve always liked it but..."
        "..."
        "You can’t help but think that maybe it would be nice to have {i}someone{/i} else here if it meant not being alone with this weird jerk..."

    menu:
        "Move to another spot.":
            jump moveTheater2
        "Confront the stranger.":
            jump confrontTheater
        "Leave the theater.":
            "This is too weird."
            "Feeling uncomfortable, you decide to leave the theater. There's still enough time left in the day to do something else."
            scene black
            with wipeleft
            pause .6
            scene bg street2
            with dissolve
            "Now what?"
            jump moviesMenu

    label moveTheater2:
        scene bg theater5b
        with dissolve
        "You move again..."
        "!!!"
        scene bg theater6d
        with dissolve
        "...and {i}again,{/i} they sit right in front of you."
        "You bristle, annoyed and a little humiliated."
        "Are they just getting a kick out of this or something?"
        "You’ve wasted enough time with this jerk that you don’t even know what’s going on in the movie anymore."
        you "..."

    menu:
        "Confront the stranger.":
            jump confrontTheater
        "Leave the theater.":
            "This is too weird."
            "Feeling uncomfortable, you decide to leave the theater. There's still enough time left in the day to do something else."
            scene black
            with wipeleft
            pause .6
            scene bg street2
            with dissolve
            "Now what?"
            jump moviesMenu


    label confrontTheater:
        "You hate confrontation. You can already feel your palms starting to sweat at the idea of it."
        play music "audio/heartbeat.mp3" loop
        "Your throat’s closing up and your body's starting to shake."
        "You’ve always been more of a ‘Flight-er’ than a ‘Fighter’..."
        "...but you paid for this ticket. {w}You’ve wanted to watch this movie for ages..."
        "...and now this total stranger has ruined the entire experience for you."
        "You’re all alone in this theater. There’s no one who’ll help you if something goes wrong..."
        "But you’re angry enough that you ignore the signs of your body begging you to put as much distance as you can between yourself and this stranger."
        "You stand up. Even standing and higher up on the incline, the stranger is still {i}at least{/i} a head taller than you."
        show screen dread
        with fade_Red
        "The movie continues to play in the background, but you feel as if a hush immediately falls heavily over the theater at your movement..."
        "...as if you can the sense the stranger anticipating what you plan to do next."
        "You square your shoulders and force a little bass into your voice."
        stop music
        you "{size=+10}{b}HEY!{/b}{/size}" with hpunch
        "The effort makes your words come out more harshly than you intended, like a sudden and vicious bark..."
        "...but you figure they deserve it anyway."
        you "You’re being a real jerk, you know that? Just what are you playing at, huh? Are you trying to piss me off?"
        who "..."
        you "..."
        ".."
        "..."
        "The silence that follows your words is {b}deafening{/b}..."
        "...so much so that you glance at the screen only to find that the movie has..."
        "...paused?"
        you "..?"
        you "!!"
        play music "audio/LOOPS/22audienceOfTwoLOOP.mp3" loop
        "Your attention is ripped back to the stranger in front of you as they shift slightly."
        "Like a small animal trying desperately to anticipate the moves of a predator... {w}{b}you don’t move an inch.{/b}"
        "You don’t look away. {w}You don’t dare to {i}blink.{/i}"
        scene bg theater6e
        with dissolve
        "Instead, your eyes widen as the person’s head turns..."
        scene bg theater6f
        with dissolve
        "Then turns some more..."
        "..."
        show theaterStranger
        with dissolve
        "Then turns more... {i}beyond{/i} what should be possible... neck bones {i}cracking{/i}..."
        "...to face you directly."
        show theaterStrangerSmile
        with dissolve
        you "...ah..."
        "You can’t move."
        "Wide glowing eyes resting above a wider grinning mouth gaze down at you."
        "The stranger opens their mouth and what comes out..."
        "...is something impossible to comprehend."
        play sound "audio/nyaStranger.mp3"
        who "Nyaaaa-a-a-a-a-a-ahh~{w=2.75}{nw}"
        you "?!{w=0.3}{nw}"
        who "Nyaaaa-a-a-a-a-a-ahh~{w=2.5}{nw}"
        who "Nyaaaa{w=0.75}-a{w=0.75}-a{w=0.75}-a{w=0.75}-aaahhh~"
        you "!!!" with vpunch
        "The voice is endlessly deep and creaks like a weighty door, foreboding and oddly melodic..."
        "Alluring..."
        "But it also snaps you out of your terrified trance and before you know it, you’re already out the door."
        scene black
        with wiperight
        pause .6
        scene bg theater3
        with wipeleft
        "You run through the halls of the empty theater, heading for the exit."
        scene bg theater2
        with wiperight
        "You feel something watching you from behind..."
        "{size=-5}...but you're too afraid to look.{/size}"
        scene bg theater4
        with wipeleft
        "The exit now in sight, you sprint forward and burst through the doors."
        scene bg cinema1
        with whiteFlash
        "You look around frantically and spot the crowded cinema across the street."
        "People! That’s what you need. Safety in numbers and all that..."
        "Without thinking, you rush into the street when a sinking sensation crawls down your spine, compelling you to look behind you."


        label lookBehindYou_movie:
            if not renpy.music.is_playing('music'):
                play music "audio/LOOPS/22audienceOfTwoLOOP.mp3" loop

            menu:
                "{size=-8}Don't look behind you. Don't look behind you. Don't look behind you. Don't look behind you.{/size}"
                "Go to the new cinema.":
                    "Refusing to even risk a peek over your shoulder, you rush across the street to the new cinema theater."
                    "You didn't realize that it felt like you've been surrounded by some kind of dreadful pressure..."
                    stop music fadeout 4
                    hide screen dread
                    with flash
                    "..."
                    "...until it very suddenly vanishes. Leaving you feeling more than a little shaken."
                    "But at least breathing comes easier."
                    "{size=-7}You think it's within your best interests to repress {b}everything{/b} that just happened.{/size}"
                    "..."
                    "Yeah..."
                    jump newCinema
                "{b}{color=#FF0000}{s}Don't{/s}{/color} look behind you...{/b}":
                    jump endOldMovie


        label endOldMovie:
            scene black
            with dissolve
            hide screen dread
            ".."
            "..."
            "Despite your resistance..."
            "...you feel your head turning to look back of its own accord."
            "While in the middle of the street..."
            scene bg theater8a
            with dissolve
            "...you catch a glimpse of a grotesque looking person standing behind the glass doors of the old theater..."
            "Watching you intensely..."
            "Cradling something their arms..."
            "Something..."
            "{size=-10}...familiar.{/size}"
            "..."
            "But..."
            stop music
            play sound "audio/truck.mp3" volume 0.55
            "{size=+30}{b}{i}BEEP!{/i}{/b}{/size}" with hpunch
            you "..?"
            scene bg theater8b
            pause .1
            scene bg theater8c
            pause .1
            scene bg theater8d
            pause .1
            play sound "audio/truck.mp3" volume 0.55
            scene bg theater8e
            pause .1
            scene bg theater8f
            pause .1
            scene bg theater8g
            pause .1
            scene bg theater8h
            pause .1
            scene bg redScreen
            play sound "audio/punch_LOW.mp3"
            show screen bloody
            with hpunch
            pause .6
            play sound "audio/humanImpact.mp3"
            you "!!!" with vpunch
            "A glimpse is all you get..."
            "...as a truck speeds forward and {b}crashes{/b} into your body."
            hide screen bloody
            with dissolve
            pause .5
            scene black
            with fade_Red
            ".."
            "..."
            "You’re killed on impact, your body splattered across the road and crushed further under the heavy tires."
            "..."
            "Ending 16: Poor Screening Arrangements"
            # if persistent.testingNow:
            #     jump endAlley
            if persistent.ending16Done:
                jump endAlley
            else:
                $persistent.ending16Done = True
                $persistent.endCounter += 1
                jump endAlley



    label newCinema:
        "Deciding to wait for the movie you’ve been anticipating to be available on DVD or streaming..."
        "...you join the long line outside the new cinema."
        "By the time you’ve reached the ticket booth, you just want to get inside..."
        "...so you pick a movie at random and take your ticket from the tired looking teenager manning the booth."
        play music "audio/LOOPS/23aloneInACrowdLOOP.mp3" loop
        scene bg cinema2
        with dissolve
        "The décor is chic and sleek and the inside is bustling with people."
        "It’s not what you’re usually into..."
        "...but it’s kind of nice not being alone..."
        "...even if you feel a little lonely watching families and groups of friends laughing among themselves."
        "You’d get some popcorn, but the lines at the concession stands are long and the prices are criminal anyway."
        scene bg cinema3
        with dissolve
        "You go through the halls..."
        scene bg cinema4
        with dissolve
        "...and follow the signs to the theater designated on your ticket before heading inside."
        scene black
        with dissolve
        ".."
        "..."
        you "*Sigh*..."
        scene bg cinema5a
        with dissolve
        "You sigh at the sight of the absolutely crowded theater."
        "You head towards a seat only to be told by the person next to it that it’s being saved for someone."
        "This happens a few more times before you finally manage to get yourself settled into a seat annoyingly off center to the screen."
        "But the screen is at least visible, if not a little too close. So you grit your teeth and bear it."
        scene black
        with dissolve
        "The lights fade out..."
        "...but the chatter doesn’t."
        scene bg cinema5b
        with dissolve
        "The rest of the audience seems content to talk through the commercials and even through the trailers."
        "You figure the chatter will stop when the movie actually begins..."
        "...but it doesn’t get even {i}slightly{/i} quieter as the opening scene starts to play out."
        "You sigh out loud not thinking anyone would hear you anyway."
        "This is why you avoid movie theaters like the plague."
        stop music
        scene bg whiteScreen
        with whiteFlash
        pause .8
        play music "audio/tvStatic.mp3" loop
        show screenCat
        with fade_Red
        "Suddenly, the screen changes, showing the face of a black cat..."
        "..."
        "{size=-8}A {b}familiar{/b} black cat.{/size}"
        "Confused murmurs fill the room... but then... {w}the cat on the screen..."
        "{b}...meows.{/b}"
        play sound "audio/nyaCat.mp3"
        catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        you "!!"
        "The sound is... {i}strange{/i} and not at all like any cat {i}should{/i} sound."
        "Haunting... Almost melodic..."
        "And layered as if made of multiple voices of different creatures."
        "Creatures that would probably never say-"
        play sound "audio/nyaCat.mp3"
        catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        you "..."
        stop music fadeout 3.5
        scene bg cinema5b
        with dissolve
        "You sit in confusion wondering why you haven’t already gotten up and left to complain to the cinema staff..."
        "But then you {b}hear{/b} it..."
        "It's scattered and dissonant at first... but among the crowd... people start to chant along with the cat on the screen."
        play sound "audio/nyaCrowd.mp3" volume 0.3
        audience "{size=-10}Nyaa... Nyaa... Nyaaa-a-a-a-ah...{/size}"
        play sound "audio/nyaCrowd.mp3" volume 0.7
        audience "{size=-5}Nyaa... Nyaa... Nyaaa-a-a-a-ah...{/size}"
        play music "audio/nyaCrowd.mp3" loop
        audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        "Soon... the entire room is chanting in perfect unison, everyone staring intently at the cat on the screen."
        "You’re feeling strangely drawn to the screen yourself..."
        "...but the compulsion to stare blankly like the others isn’t that strong..."
        "...for {b}now.{/b}"
        "Also... {w}you start to notice out of the corner of your eye..."
        "...that some of the people in your immediate vicinity are... {w}{i}looking{/i} at you..."
        "No..."
        scene bg cinema7a
        with dissolve
        "They’re outright staring {b}holes{/b} into you, even as they continue chanting."
        scene bg cinema7b
        with dissolve
        "They don’t miss a beat as they slowly begin to frown at you in blatant disapproval..."
        scene bg cinema7c
        with dissolve
        "Their scowls deepen as time goes on as if they’re getting...{w} {i}impatient...{/i}"

    if not renpy.music.is_playing('music'):
        play music "audio/nyaCrowd.mp3" loop

    menu:
        "Try to leave the theater.":
            jump leaveCinema
        "Try to blend in with the crowd.":
            jump blendInCinema


    label leaveCinema:
        you "{i}This is too weird... I need to get out of here...{/i}"
        scene black
        with dissolve
        "Gathering your courage...{w} or perhaps putting your fear to use, you stand up,{w} fully intending to leave the theater..."
        stop music
        "..."
        "...when everything comes to an abrupt {b}STOP.{/b}"
        "All of the chanting stops, even the cat's chanting on the screen."
        you "..."
        "You tense and risk a glance around the theater."
        you "!!!" with vpunch
        play sound "audio/tvStatic.mp3" loop
        show audienceStare
        with dissolve
        "They’re all staring at you."
        play music "audio/heartbeat.mp3" loop
        "Every. {w}Single. {w}One of them."
        "They’re not moving. They’re not even {i}blinking.{/i}"
        "You swallow, throat suddenly dry even though a nervous sweat completely soaks through your clothes."
        "You highly doubt that sitting back down will fix the situation."
        "Your legs are shaking under the audience’s unnaturally intense scrutiny..."
        "...but you force yourself to step forward and forward and {i}forward{/i} until you finally reach the end of the aisle."
        "You feel their collective gaze even worse on the staircase."
        "All their heads have turned uncomfortably to the left to look directly at you."
        "The screen illuminates their faces... making clear their blank scowls."
        "They seem even {i}more{/i} upset than they had been minutes ago, identical frown lines digging between their brows."
        you "..."
        stop sound fadeout 2.5
        scene black
        with dissolve
        "You keep going, the heavy atmosphere becoming more and more oppressive with every step."
        "You’re so tense with anticipation that you fully expect someone to grab at you from behind..."
        ".."
        "..."
        "...but no one does."
        "You don’t hear any of them even get up."
        "You exit the theater, holding your breath as the doors close behind you."
        stop music fadeout 2.5
        scene bg cinema4
        with wipeleft
        pause .6
        scene bg cinema3
        with wiperight
        "You briskly walk through the halls, putting as much distance as possible between you and that theater full of people."
        scene bg cinema2
        with dissolve
        "Finally reaching the lobby, you just barely manage to catch yourself from falling to the floor as you gulp in huge gasps of air."
        you "*pant*... *pant*... *pant*..."
        "You expect to feel relief as your breathing calms..."
        "...but you feel a lingering sense of dread that only spikes once you finally notice it..."
        "...as well as its source."
        "You look up...{w} and your stomach {b}sinks.{/b}"
        you "!!!" with vpunch
        play music "audio/heartbeatEcho.mp3" loop
        scene bg cinema9a
        with dissolve
        pause .6
        scene bg cinema9b
        with dissolve
        pause .3
        scene bg cinema9c
        with dissolve
        pause .05
        scene bg cinema9d
        with dissolve
        pause .05
        scene bg cinema9e
        with dissolve
        pause .05
        scene black
        with dissolve
        pause 2
        scene bg cinema9f
        with dissolve
        pause .6
        scene bg cinema9g
        with dissolve
        pause .6
        scene bg cinema9h
        with dissolve
        pause .6
        "..."
        "All the people in the lobby area of the movie theater..."
        "...everyone in line at the concession stand..."
        "...{i}all{/i} of them..."
        "...are staring at you."
        "And they..."
        "..."
        stop music
        show screen blackOut
        "{size=-8}They look even angrier than the people in the theater.{/size}"
        scene black
        hide screen blackOut
        "You don’t hesitate this time."
        "You duck your head, avoiding eye contact, and leave the cinema."
        scene bg cinema1
        with wiperight
        pause .2
        play music "audio/LOOPS/24avoidanceIN.mp3"
        queue music "audio/LOOPS/24avoidanceLOOP.mp3" loop
        show cinemaStare
        with dissolve
        pause .6
        "You ignore the glares of everyone in the ticket booths and the lines leading to them."
        scene bg street2
        with wipeleft
        pause .2
        show cinemaStare
        with dissolve
        pause .6
        "You make your way home."
        scene bg street1
        with wiperight
        pause .2
        show cinemaStare
        with dissolve
        pause .6
        "Whenever you dare to look up at a someone on the way..."
        "...you flinch at the blatant anger, fury, and {i}disgust{/i} on their face."
        scene bg street3
        with wipeleft
        pause .2
        show cinemaStare
        with dissolve
        pause .6
        "You think you start to hear the faint sound of a cat’s meowing behind you... or maybe a kitten’s?"
        scene bg aptFront
        with wiperight
        pause .2
        show cinemaStare
        with dissolve
        pause .6
        "Doesn’t matter. You just want to go home."
        scene bg aptDoor
        with wipeleft
        pause .2
        show cinemaStare
        with dissolve
        pause .6
        "You reach your front door and fumble with the keys..."
        "...cowering from the look of pure hatred on your neighbor’s face as he stares at you from his door."
        play music "audio/LOOPS/24avoidanceOUT.mp3" noloop
        scene black
        with dissolve
        ".."
        "..."
        pause .6
        scene bg aptLivingRoom
        with dissolve
        "Finally, you get inside your apartment..."
        "...lock all the locks on the door..."
        "...and slide down with your back against it till you're sitting on the floor."
        you "*pant*... *pant*... *gulp*... *pant*..."
        "You allow yourself a moment to breathe."
        "Now home, your heartbeat calms and your fear slowly bleeds from you, leaving you feeling strangely..."
        "...empty."
        "..."
        scene black
        with wipeleft
        pause .6
        scene bg aptBedroom
        with dissolve
        "You pass the kitchen, head to your room, and slip under the covers of your bed, trying to fall asleep."
        scene black
        with dissolve
        "Maybe it’s all just a bad dream."
        "As you fall into a fitful sleep, sure to be full of nightmares of glaring eyes..."
        "...you try to ignore the ever-increasing sounds of cats meowing and yowling in the distance outside your apartment."
        "..."
        "Ending 17: Black Sheep"
        # if persistent.testingNow:
        #     jump endAlley
        if persistent.ending17Done:
            jump endAlley
        else:
            $persistent.ending17Done = True
            $persistent.endCounter += 1
            jump endAlley



    label blendInCinema:
        stop music fadeout 1.5
        audience "..."
        "Thinking fast, you look to the screen and begin to chant in tandem with the crowd."
        you "N-Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        audience "..."
        scene bg cinema7b
        with dissolve
        you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        audience "..."
        scene bg cinema7a
        with dissolve
        audience "..."
        scene bg cinema5b
        with dissolve
        "You feel the harshness of their collective gaze start to ebb away..."
        "...the air in the theater becoming lighter once again."
        play music "audio/nyaCrowd.mp3" loop
        audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        "You release air shakily, just realizing that you’d been holding your breath earlier."
        "..."
        "You feel stuck."
        "Surely you can’t just up and leave {i}now...{/i}"
        "Not after... {i}whatever{/i} all that was..."
        "The people around you all seem fine now..."
        "...but there’s no telling if they’d get aggressive at you for even moving too much..."
        "...never mind outright getting up and leaving."
        "You decide to let this run its course. Hopefully someone will come along..."
        "Right?"
        "{size=-5}Or at least turn the film off?{/size}"
        "..."
        stop music fadeout 3.5
        "You continue to chant along with everyone..."
        play sound "audio/tvStatic.mp3" loop
        show screenCat
        with dissolve
        you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        play music "audio/LOOPS/25creepingCreedIN.mp3"
        queue music "audio/LOOPS/25creepingCreedLOOP.mp3" loop
        ".."
        "..."
        "You start to feel lightheaded..."
        "You feel as if you could fall asleep, but your eyes don’t feel heavy in the slightest."
        "You try to look around and gauge the others' emotional state..."
        "..."
        "..?"
        "But you can’t seem to look away from the screen."
        "You try again, but you’re still locked into eye contact with the cat onscreen."
        play sound "audio/nyaCat.mp3"
        catOnScreen "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        play sound "audio/nyaCrowdEcho.mp3"
        audience "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        scene bg cinema5b
        with dissolve
        "You attempt to physically force your line of vision away."
        "You steel your nerves, ready to throw yourself to the ground if you need to..."
        "But your body only gets as far as tensing up for a moment before completely loosening itself again..."
        "...making you lay back limply into your seat."
        "You think you should be panicking right about now..."
        "But even your brain feels limp..."
        play sound "audio/nyaCrowdEcho.mp3"
        scene bg cinema10a
        with dissolve
        "...your thoughts a vaguely muted pastel pink..."
        "...airy..."
        "...sickeningly sweet and loosely spun..."
        "...like cotton candy."
        "..."
        "You..."
        "You like cotton candy..."
        "You think you shouldn’t mind your thoughts and body being like cotton candy either..."
        "So... {w}why get up and {i}ruin{/i} that?"
        play sound "audio/nyaCrowdEcho.mp3"
        scene bg cinema10b
        with dissolve
        "It’s nice here."
        "You’re more at peace than you’ve ever felt before in such a crowded room."
        "Still chanting, you’ve never felt so aligned and in tune with another person..."
        "...let {i}alone{/i} with an entire room full of complete strangers."
        "You’re not..."
        "..."
        "You're not alone..."
        play sound "audio/nyaCrowdEcho.mp3"
        scene bg cinema11a
        with dissolve
        "Out of the corner of your eye, the person next to you starts to sink back even further into their chair..."
        scene bg cinema11b
        with dissolve
        "Then they sink more."
        scene bg cinema11c
        with dissolve
        "Then {i}more.{/i}"
        "Not like they’re slouching or reclining, but more like they’re..."
        ".."
        "..."
        $ renpy.music.set_volume(0.0, 0, "music")
        play sound "audio/squelchLOOP.mp3"
        scene bg cinema11d
        pause .1
        scene bg cinema11e
        pause .1
        scene bg cinema11f
        pause .1
        scene bg cinema11g
        pause .1
        stop sound
        show screen blackOut
        scene black
        "..."
        "{size=-5}...{b}deflating.{/b}{/size}"
        "Their skin bunches up and wrinkles like fabric as if their muscles... their {i}bones...{/i} have started to disintegrate."
        "Their eyes dim before sinking into their sockets."
        "Their mouth, still attempting to chant, falls open over a cut off \"Nya-\"..."
        play sound "audio/airHiss.mp3"
        "...gaping as the word ends in an awful {i}{b}hiss{/b}{/i}... a final, weak release of air."
        hide screen blackOut
        "..."
        "You muse thoughtfully about whether or not you should be distressed at the sight..."
        $ renpy.music.set_volume(1.0, 0, "music")
        play sound "audio/nyaCrowdEcho.mp3"
        scene bg cinema12a
        with dissolve
        "...but even {i}then,{/i} the blanket of peace doesn’t leave you."
        "Suddenly, from the pile of skin and clothes next to you... {w}you see a lump moving around..."
        "You watch in dazed fascination as the lump makes its way to the part of the skin where the head used to be..."
        "And out from the mouth..."
        show cinema12
        with dissolve
        "...crawls a tiny black kitten."
        "..."
        you "Nyaa... Nyaa... Nyaaa-a-a-a-ah..."
        play sound "audio/airHiss.mp3"
        pause 1
        play sound "audio/airHiss.mp3"
        pause 1
        play sound "audio/airHiss.mp3"
        pause 1
        "You can hear the familiar hissing sound all around you now as the unified chants start to fade..."
        play sound "audio/kitten1.mp3" volume 0.5
        queue sound "audio/kitten2.mp3" volume 0.5
        queue sound "audio/kitten4.mp3" volume 0.5
        "...only to be replaced with the faint mewling of kittens."
        scene bg cinema13a
        with dissolve
        "Finally, your voice is the only one still chanting... still human..."
        "And alone... {w}again."
        "{size=-8}You don’t want that. {w}You can’t go back to that. {w}Not again. {w}Not again... {w}{b}Please...{/b}{/size}"
        "Just then, you go completely limp."
        "Your body feels light, but it might as well weigh several tons..."
        "...because you realize quite suddenly that you can’t move..."
        "Not an {b}inch.{/b}"
        "You can’t shift your eyes to look around..."
        "You can’t even {i}breathe...{/i}"
        "But somehow..."
        "...the chant continues to creak weakly from your mouth."
        you "{size=-5}N-Nyaa... Nyaa... N-Nyaaa-a-a-a-ah...{/size}"
        play music "audio/LOOPS/25creepingCreedOUT.mp3" noloop
        play sound "audio/kitten1.mp3" volume 0.6
        queue sound "audio/kitten2.mp3" volume 0.6
        queue sound "audio/kitten4.mp3" volume 0.6
        scene bg cinema13b
        with dissolve
        pause .3
        scene bg cinema13c
        with dissolve
        "A few kittens come forward and perch themselves on the chairs around you..."
        "...watching your sinking body..."
        "...mewling as they wait for their youngest sibling to emerge..."
        "...from {i}you.{/i}"
        "Dozens of glowing eyes peer down at you..."
        show screen dread
        with dissolve
        "...and as {i}your{/i} eyes start to cave into the sockets of your softening skull..."
        scene bg cinema13d
        with dissolve
        "...you manage to make out the silhouette of a {b}familiar{/b} cat, perching on the seat right in front of you..."
        scene black
        with dissolve
        "Your vision finally fades..."
        play sound "audio/airHiss.mp3"
        "And as that same hiss of air expels itself from your mouth..."
        "...the last thing you sense is something small and {b}{i}alive{/i}{/b} shifting eagerly under your skin."
        '..'
        "..."
        "Ending 18: Happy Birthday."
        # if persistent.testingNow:
        #     jump endAlley
        if persistent.ending18Done:
            jump endAlley
        else:
            $persistent.ending18Done = True
            $persistent.endCounter += 1
            jump endAlley



label goToCarnival:
    scene black
    with dissolve
    pause .3
    play music "audio/LOOPS/26carnivalIN.mp3" fadein 2.5
    queue music "audio/LOOPS/26carnivalLOOP.mp3" loop
    scene bg carnival1
    with dissolve
    "You spend the day at the carnival."
    "Ferris wheel, roller coaster, pharaoh boat... {w}Rides you’ve been on before."
    "Hoops, coin toss, balloon darts... {w}Games you’ve played before."
    "Funnel cake, popcorn, cotton candy... {w}Food you’ve eaten before."
    "All things you’ve enjoyed {i}before.{/i}"
    "You’re surrounded by groups of people all having fun together..."
    "Laughing, playing, eating, taking pictures... Making memories..."
    "And then there’s you."
    "..."
    "The sun hasn’t started to set yet, still high in the sky, but it will soon."
    "You start to wonder if maybe you should just go home for the day...{w} when you stop in your tracks."
    scene bg carnival2
    with dissolve
    "You see something...{w} {i}new.{/i} {w}An attraction you’ve never seen before."
    "A maze of... funhouse mirrors?"
    "It sounds..."
    "..."
    "...kind of lame, honestly."
    "There isn’t even a line to get in."
    "..."
    "But then... {w}what else is there to do..?"

    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/26carnivalIN.mp3"
        queue music "audio/LOOPS/26carnivalLOOP.mp3" loop

    menu:
        "Do something else.":
            "There's got to be a better way to spend your day off than wandering around staring at weird mirrors..."
            stop music
            scene black
            with wipeleft
            pause .6
            scene bg street2
            with dissolve
            "Now what?"
            jump aloneMenu
        "Enter the maze.":
            jump enteringMaze

    label enteringMaze:
        scene black
        with dissolve
        "You enter the maze."
        $ renpy.music.set_volume(0.3, 0, "music")
        scene bg carnival3
        with dissolve
        "A few rooms in and you notice that the mirrors aren’t {i}all{/i} weird."
        "Some just show {i}you{/i} looking back at yourself."
        "A little bored... A lot tired... And so very, very..."
        "..."
        $ renpy.music.set_volume(0.05, 0, "music")
        scene bg carnival4
        with dissolve
        ".."
        "..."
        #stop music
        "...Maybe this was a mistake."
        #$ renpy.music.set_volume(1.0, 0, "music")
        "Why did you think going into a maze of {b}mirrors{/b} was a good idea? Even if it was something new to experience?"
        you "{i}I... I can't do this today...{/i}"
        "You turn around to head back the way you came..."
        stop music
        play sound "audio/humanImpact.mp3" volume 0.5
        scene bg carnival5
        with vpunch
        $ renpy.music.set_volume(1.0, 0, "music")
        "...only to bump into a mirror."
        you "Ow! What the..? Where's the exit?"
        "You try again only to find another mirror blocking your way."
        "By the time you're all turned around, you've realized that the way you came in is completely gone."
        you "!!!" with hpunch
        ".."
        "..."
        you "O-Okay, don't panic. I just have to... keep going forward... right?"
        "You step through the only opening you can find and nearly trip over something on the ground."
        "You bend down and pick it up."
        you "..?"
        you "What's {i}this{/i} doing here?"
        "In your hand rests a worn looking flashlight."
        "Curious, you flick it on."
        play sound "audio/click.mp3" volume 0.1
        "*Click*"
        "... {w}Huh... {w}The light doesn't look very-{w=1.0}{nw}"
        play sound "audio/click.mp3"
        show screen blackOut
        scene black
        you "!!"
        hide screen blackOut
        you "Crap! The lights!"
        "Did the power go out or did the attraction operator forget you were in here?"
        "..."
        "How long {i}have{/i} you been in here, actually?"
        "You pull out your phone to check the time or maybe call the police..."
        ".."
        "..."
        "{size=-6}Your phone is dead.{/size}"
        "..."
        "You grip the flashlight in your hand."
        "The light it emitted earlier was dim enough for you to know there's probably not that much juice left."
        "Best to reserve it for a worst case scenario and feel your way out."
        "Yeah. Yeah, you can do this."
        "You take a calming breath."
        you "{i}Well. {w}Forward we go...{/i}"
        "..."
        jump mazeStart


label goToDogPark:
    scene bg street4
    with dissolve
    stop music fadeout 4
    "You decide to take a stroll in a park or something."
    "The only one within walking distance is the nearby dog park."
    "You think it’ll make you feel better."
    "First you get to see a cute cat today, now you’ll get to see a cute dog!"
    "{i}Several{/i} of them, in fact."
    play music "audio/LOOPS/30dogLOOP.mp3" loop
    scene bg dogPark1
    with dissolve
    "The park is bustling with owners and their canine companions."
    "Playing Frisbee, fetch, running, jumping, even napping~!"
    "Such cuties-{w=0.5}{nw}"
    $ renpy.music.set_volume(0.0, 0, "music")
    show screen blackOut
    "{size=-8}{b}Whatever. {w}Like you’d want anything to do with these mangy mutts.{/b}{/size}"
    hide screen blackOut
    $ renpy.music.set_volume(1.0, 0, "music")
    you "{i}..?!{/i}"
    "..."
    "...What's wrong?"
    "You didn’t think that?"
    ".."
    "..."
    "You decide to move on."
    scene bg dogPark2
    with dissolve
    "The dogs are all so adorable. You want to pet every single one you come across..."
    "...but you know not all owners are cool with strangers just walking up and manhandling their pets."
    "Not all dogs appreciate it either."
    "So you stroll around the path, trying to exude a welcoming aura that will beckon one of these cute doggies to you."
    scene black
    with dissolve
    "You don’t have to wait very long."
    play sound "audio/dogSmall.mp3"
    who "Bark!"
    scene bg dogPark3
    with dissolve
    "You stop as the smallest, cutest puppy you’ve ever seen scampers up to you, blocking your path~"

label puppyMenu:

    menu:
        "Leave the park.":
            stop music
            scene black
            who "{b}yes leave leave leave dogs are stupid and they all deserve to-{/b}{w=1.5}{nw}"
            scene bg street1
            "Now what?"
            jump aloneMenu
        "Kick the puppy." if hurtPup1 < 1:
            $ renpy.music.set_volume(0.0, 0, "music")
            show screen blackOut
            you "{i}...What?! It's just a puppy!{/i}"
            $ hurtPup1 += 1
            jump dontHurtPuppy
        "Kill the puppy." if hurtPup2 < 1:
            $ renpy.music.set_volume(0.0, 0, "music")
            show screen blackOut
            you "!!!" with vpunch
            you "{i}{b}NO!{/b} That's horrible!!{/i}"
            $ hurtPup2 += 1
            jump dontHurtPuppy
        "Eat the puppy." if hurtPup3 < 1:
            $ renpy.music.set_volume(0.0, 0, "music")
            show screen blackOut
            you "!!!" with vpunch
            you "{i}That's disgusting! I think I'm going to be sick...{/i}"
            $ hurtPup3 += 1
            jump dontHurtPuppy
        "Pick up the puppy.":
            jump pickUpPup

    label dontHurtPuppy:
        you "{i}There's no way I would {b}ever{/b} do that!{/i}"
        hide screen blackOut
        $ renpy.music.set_volume(1.0, 0, "music")
        jump puppyMenu

label pickUpPup:
    "You pick up the puppy and-{w=0.75}{nw}"
    $ renpy.music.set_volume(0.0, 0, "music")
    play sound "audio/glitch.mp3"
    scene bg chaseDogPark3
    with vpunch
    $ clock1 = 3
    show screen pickUpPup_timer
    menu:
        "{size=+5}DROP IT!{/size}":
            hide screen pickUpPup_timer
            jump time_outPup
        "{size=-5}Hold on!{/size}":
            hide screen pickUpPup_timer
            jump heldPup

label time_outPup:
    scene black
    you "AAAHH!" with hpunch
    play sound "audio/humanImpact.mp3" volume 0.5
    queue sound "audio/dogYelp.mp3"
    "Terrified, you drop the puppy to the ground... {w}practically throwing it from you."
    "You immediately feel horrible, wincing in guilt at the tiny yelp it releases upon hitting the ground."
    "The owner shoves you aside with a cutting glare and storms away with their puppy."
    you "I-I'm sorry!"
    "You call out, but they don't turn back or respond."
    "Not that you expected them to."
    "You {i}deserved{/i} it."
    jump leavePark1

label heldPup:
    scene bg dogPark3
    you "!!!" with vpunch
    ".."
    "..."
    "You just barely manage to rein in the reflex to throw the puppy as far away from you as possible."
    you "..."
    "With shaking hands you quickly place the puppy on the grass and take several jerky steps back."
    "The owner seems confused by your reaction to their puppy, {w}but you just wave at them in a daze before hastily stumbling away."
    jump leavePark1

label leavePark1:
    $ renpy.music.set_volume(1.0, 0, "music")
    scene bg dogPark2
    with dissolve
    you "..."
    "You're not feeling so great about being at the park at the moment. Maybe you should {b}leave{/b}?"

    menu:
        "LEAVE THE PARK.":
            stop music
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            "..."
            "Good."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "Stay at the park...":
            jump stayAtPark

label stayAtPark:
    ".."
    "..."
    "..."
    "{size=+32}{b}YOU STAY AT THE PARK.{/b}{/size}"
    you "..."
    "You try to calm down by watching all the dogs from afar as you walk along the path..."
    "...but every so often, one will run up to you..."
    scene bg dogPark4
    with dissolve
    "And when they do, they look..."
    "...wrong."
    "Their owners don't seem to notice."
    scene bg dogPark1
    with dissolve
    "You find a bench and sit down for a quick break, closing your eyes."
    "Maybe... {w}this wasn’t the best idea after all."
    scene black
    with dissolve
    "Maybe..."
    "..."
    $ renpy.music.set_volume(0.0, 0, "music")
    pause .6
    show screen catEyesFade
    with dissolve
    "..."
    "y o u \ s h o u l d \ h a v e \ s t a y e d \ w i t h \ m e \ i n s t e a d"
    hide screen catEyesFade
    with dissolve
    you "..."
    "..."
    play sound "audio/humanImpact.mp3" volume 0.2
    scene black
    with whiteFlash
    you "..?"
    $ renpy.music.set_volume(1.0, 0, "music")
    scene bg dogPark1
    with dissolve
    "You’re broken out of your thoughts when something lands gently on your lap."
    "You look down and see a frisbee on your thighs."
    who "Hey! Sorry about that! Can you throw that back?"
    "You look up to see an owner waving at you in the distance..."
    "But more importantly..."
    play sound "audio/dogBig.mp3"
    dog "Bark! Bark! {b}Bark!!{/b}" with hpunch
    you "..?"
    scene bg dogPark5a
    with dissolve
    play sound "audio/dogBig.mp3"
    dog "Bark!{w=0.5}{nw}" with hpunch
    scene bg dogPark5b
    with dissolve
    play sound "audio/dogBig.mp3"
    dog "Bark!{w=0.5}{nw}" with hpunch
    scene bg dogPark5c
    with dissolve
    play sound "audio/dogBig.mp3"
    dog "Bark!{w=0.5}{nw}" with hpunch
    "A series of excited barks jerks your gaze forward and you see a large dog sprinting towards you."
    scene bg dogPark5d
    with dissolve
    show dogPark5
    you "..."
    play sound "audio/dogBigWeird.mp3" loop
    dog "bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark bark"
    stop sound
    ".."
    "..."
    "A series of excited barks jerks your gaze forward and you see a large \ {b}d o g{/b} \ sprinting towards you."
    who "H-Hey! Hurry and throw it back!"
    you "Oh! Uhh..!"

    $ clock2 = 2
    show screen frisbee_timer
    menu:
        "{size=+40}{b}LEAVE! LEAVE! {color=#FF0000}LEAVE!{/color}{/b}{/size}":
            stop music
            scene black
            hide screen frisbee_timer
            pause .6
            show screen catEyesFade
            with dissolve
            "..."
            "Good. And don't come back."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "{size=-6}THROW!{/size}":
            hide screen frisbee_timer
            jump threwFrisbee

label didntThrowFrisbee:
    $ renpy.music.set_volume(0.0, 0, "music")
    hide dogPark5
    scene bg dogPark6a
    pause .05
    scene bg dogPark6b
    pause .05
    scene bg dogPark6c
    pause .05
    scene bg dogPark6d
    pause 2
    play sound "audio/dogBigWeird.mp3"
    scene bg dogPark6e
    pause .02
    scene bg dogPark6f
    pause .01
    scene bg dogPark6g
    pause .01
    scene bg dogPark6h
    pause .01
    scene bg redScreen
    with p_Red
    stop sound
    play sound "audio/punch_HIGH.mp3"
    show screen bloody
    with vpunch
    you "!!!" with hpunch
    scene black
    hide screen bloody
    with dissolve
    "The dog suddenly bounds at you, angry... {b}ferocious{/b}..."
    "It tears your limbs from your {color=#FF0000}body-{/color}{w=0.6}{nw}"
    scene bg dogPark2
    you "!!!" with vpunch
    "..."
    you "{i}Was... {w}Was that real..?{/i}"
    jump leavePark1


label threwFrisbee:
    hide dogPark5
    scene bg dogPark1
    "You throw the frisbee and the dog runs in the opposite direction..."
    "...jumping and catching it right out of the air."
    ".."
    "..."
    $ renpy.music.set_volume(1.0, 0, "music")
    "Impressive."
    "The dog and the owner walk up to you."
    who "Thanks for that. You can pet him if you want!"
    scene bg dogPark7a
    with dissolve
    pause .6
    scene bg dogPark7b
    with dissolve
    "The dog looks up at you, eager for its reward of pets and pats for catching the frisbee."
    you "..."
    you "{i}Should I..?{/i}"
    show dogPark7

    menu:
        "LEAVE.":
            stop music
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "A wise decision."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "LEAVE.":
            stop music
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "A wise decision."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "LEAVE.":
            stop music
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "A wise decision."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "Pet dog.":
            jump lastChance
        "LEAVE.":
            stop music
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "A wise decision."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "LEAVE.":
            stop music
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "A wise decision."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "LEAVE.":
            stop music
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "A wise decision."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "LEAVE.":
            stop music
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "A wise decision."
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu

label lastChance:
    $ renpy.music.set_volume(0.0, 0, "music")
    scene black
    "..."
    "Really?"
    "Are you sure?"
    ".."
    "..."
    "I'm warning you."
    scene bg dogPark7b
    with dissolve
    pause .1
    "Do {b}not{/b} touch that mutt..."
    "{size=-10}...or you {b}will{/b} regret it.{/size}"
    play sound "audio/glitch.mp3"
    scene bg dogPark7f
    with vpunch
    pause .4
    show static

    menu:
        "{size=+5}{color=#FF0000}l e av  e...{/color}{/size}":
            stop music
            $ renpy.music.set_volume(1.0, 0, "music")
            hide static
            scene black
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "{size=+5}{b}G o o d.{/b}{/size}"
            hide screen catEyesFade
            scene bg street1
            ".."
            "..."
            jump aloneMenu
        "{size=-5}pet the {b}d{/b}oG.{/size}":
            pause 4.5
            jump petTheDog

label petTheDog:
    stop music
    $ renpy.music.set_volume(1.0, 0, "music")
    hide static
    scene bg dogPark1
    ".."
    "..."
    scene bg dogPark8a
    with dissolve
    "You reach out your hand..."
    ".."
    "..."
    scene bg dogPark8b
    with dissolve
    "...and you pet the \ {b}d o g.{/b}"
    you "..."
    play sound "audio/dogBig.mp3"
    dog "ARF! ARF!" with vpunch
    "The dog seems pleased."
    ".."
    "..."
    "You don't feel well."
    "Suddenly..."
    play music "audio/LOOPS/31catPersonIN.mp3"
    queue music "audio/LOOPS/31catPersonLOOP.mp3" loop
    scene bg dogPark8c
    with dissolve
    "...the sky begins to darken rapidly."
    scene bg dogPark9a
    with dissolve
    "You look up along with all the pet owners to see that the sun has been eclipsed by the moon in the blink of an eye."
    "You vaguely remember that you should never look directly at an eclipse... {w}but for some reason..."
    "...you don't look away."
    play sound "audio/beastRoar.mp3" volume 1.5
    who "{size=+35}{b}REOWWWWRRRRR!!!{/b}{/size}" with vpunch
    "A loud piercing yowl fills the air, shaking the ground beneath you."
    "You instinctively move to lift your hands in order to shield your ears..."
    "But..."
    scene bg dogPark8c
    with dissolve
    pause .3
    play sound "audio/squelchLOOP.mp3" volume 0.3
    scene bg dogPark10a
    with dissolve
    pause .3
    scene bg dogPark10b
    with dissolve
    pause .3
    stop sound fadeout 0.5
    "...but the hand that had been cautiously pressed upon the dog's head comes away with some..."
    "...{b}resistance.{/b}"
    "...{i}Resistance{/i} like sticky slime almost cementing your hand to the dog's head."
    you "!!!" with vpunch
    "The slime stretches with your movement."
    scene bg dogPark10c
    with dissolve
    play sound "audio/splat.mp3" volume 0.3
    pause .3
    "The dog's {i}head{/i} stretches with it too... as the canine begins to just..."
    "...{b}melt.{/b}"
    scene black
    with dissolve
    "It melts..."
    "And {b}melts{/b}..."
    ".."
    "..."
    scene bg dogPark11a
    with dissolve
    pause .1
    show dogPark11
    "...until it becomes a pile of goo at your feet."
    you "Ah..! Ah..."
    "You dazedly look around for the dog's owner, only to find an empty pile of familiar clothes where they once stood."
    "You see similiar piles of clothes next to piles of goo scattered all across the park's open field."
    "All the dogs..."
    "All their owners..."
    "..."
    "The melted goo of the dog in front of you then starts to move with a shudder."
    you "!!!" with hpunch
    play sound "audio/squelchLOOP.mp3" volume 0.6
    hide dogPark11
    with dissolve
    scene bg dogPark12a
    with dissolve
    pause .6
    scene bg dogPark12b
    with dissolve
    pause .6
    scene bg dogPark12c
    with dissolve
    pause .6
    scene bg dogPark12d
    with dissolve
    stop sound fadeout 2.5
    pause .6
    "It slithers across the grass toward the field in the center of the park..."
    "{size=-5}All the other piles of goo following after it...{/size}"
    play sound "audio/squelchLOOP.mp3" volume 0.6
    scene bg dogPark12e
    with dissolve
    pause .6
    scene bg dogPark12f
    with dissolve
    pause .6
    scene bg dogPark12g
    with dissolve
    pause .6
    scene bg dogPark12h
    with dissolve
    stop sound fadeout 2.5
    pause .6
    play music "audio/LOOPS/31catPersonOUT.mp3" noloop
    "They mix and meld together into a single entity that shifts and undulates and bulges and {b}grows{/b}..."
    you "!!!"
    "You watch in dazed horror as it then fills out and shapes itself..."
    play sound "audio/squelchLOOP.mp3" volume 0.6
    scene bg dogPark12i
    with dissolve
    pause .1
    scene bg dogPark12j
    with dissolve
    pause .1
    scene bg dogPark12k
    with dissolve
    pause .1
    scene bg dogPark12l
    with dissolve
    pause .1
    scene bg dogPark12m
    with dissolve
    pause .1
    scene bg dogPark12n
    with dissolve
    pause .1
    scene bg dogPark12o
    with dissolve
    pause .1
    show dogPark13
    with dissolve
    stop sound fadeout 2.5
    pause .8
    "...into a{size=+5} {b}behemoth{/b} {/size}of a dog."
    "Snarling and frothing at the mouth... red eyes frantic and searching..."
    "..."
    "...before the glowing orbs land directly on you."
    play sound "audio/beastGrowl.mp3"
    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with hpunch
    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}{w=0.2}{nw}" with vpunch
    who "{size=+30}{b}RRRRRRRrrrrrr...{/b}{/size}" with hpunch
    "The rumbling growl it emits is so low and deep, you can feel the sound of it crash into you..."

    menu:
        "Leave the park?":
            stop music
            show screen blackOut
            with dissolve
            hide dogPark13
            scene black
            hide screen blackOut
            pause .6
            show screen catEyesFade
            with dissolve
            ".."
            "..."
            "No."
            "You had your chance."
            "{b}{size=-10}B e t t e r{/size}{size=+20} \ {/size}{size=-10}s t a r t{/size}{size=+20} \ {/size}{size=-10}r u n n i n g~{/size}{/b}"
            ".."
            "..."
            hide screen catEyesFade
            with dissolve
            pause .6
            jump justRunDog

label justRunDog:
    "You try to run."
    "..."
    "{size=-8}...But you're not fast enough.{/size}"
    "The behemoth barely takes a few leaps before its already towering over you."
    scene black
    play sound "audio/swishQUICK_low.mp3" volume 0.4
    show slash
    pause .1
    scene black
    scene bg redScreen
    with p_Red
    pause .05
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    pause .2
    hide screen bloody
    scene black
    with dissolve
    you "!!!" with vpunch
    scene black
    play sound "audio/swishQUICK_low.mp3" volume 0.4
    show slash
    pause .1
    scene black
    scene bg redScreen
    with p_Red
    pause .05
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    pause .2
    hide screen bloody
    scene black
    with dissolve
    you "..!" with vpunch
    scene black
    play sound "audio/swishQUICK_low.mp3" volume 0.4
    show slash
    pause .1
    scene black
    scene bg redScreen
    with p_Red
    pause .05
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    pause .2
    hide screen bloody
    scene black
    with dissolve
    you "..." with vpunch
    ".."
    "..."
    "It tears you apart until there's {b}nothing{/b} left."
    ".."
    "..."
    "Ending 21: {color=#FF0000}d o g{/color} \ person"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending21Done:
        jump endAlley
    else:
        $persistent.ending21Done = True
        $persistent.endCounter += 1
        jump endAlley


label turnedBack:
    "You sigh a little and walk back to the cat."
    scene bg upHappy
    with dissolve
    pause .1
    scene bg upBlinkMeow
    play sound "audio/cat_happyLONG.mp3" volume 0.4
    cat "Meow! Mreowww!" with hpunch
    scene bg upBlinkSmile
    pause .1
    scene bg upHappy
    "It looks almost hopeful... its tail swishing faster as it leans up a little more towards you..."
    "...as if eager for your next move."

    menu:
        "Stay?":
            jump stayWithCat
        "Leave?":
            jump leaveCat2

label stayWithCat:
    you "..."
    "...It's strange."
    "The more you hesitate to leave the alley... the more you find yourself wondering..."
    scene bg alleyCat2
    with dissolve
    stop music fadeout 1.5
    "...{i}\"What's the point?\"{/i}"
    "You'll go {i}where?{/i}"
    "Do {i}what?{/i}"
    scene bg upBlink
    pause .1
    scene bg alleyCat2
    "What's the point when you're always doing all of it completely and utterly {i}alone?{/i}"
    "Even going home to your apartment wouldn't help, would it..?"
    "One bedroom. One bathroom."
    "...And one {i}you{/i} living alone in it."
    "It's been like that for so, so long..."
    "..."
    "{i}So{/i} long..."
    scene bg upSad
    with dissolve
    pause .1
    scene bg upSadMeow
    play sound "audio/cat_sad.mp3" volume 0.4
    cat "Meoww..."
    scene bg upSad
    you "..!" with vpunch
    play music "audio/LOOPS/32fickleConfidantIN.mp3"
    queue music "audio/LOOPS/32fickleConfidantLOOP.mp3" loop
    "You're startled when you feel an impossibly soft paw press lightly against your wet cheek."
    "..."
    "You didn't realize you'd been crying."
    "Or that your little breakdown had literally brought you to your knees... right in front of the cat's box."
    "You feel slightly embarrassed, but the cat responds as if it can sense your self deprecating feelings creeping in."
    scene bg upAngry
    pause .1
    scene bg upAngryMeow
    play sound "audio/cat_angryQUICK.mp3" volume 0.4
    cat "Meow! Meoww!" with hpunch
    play sound "audio/humanImpact.mp3" volume 0.1
    scene bg upAngry
    with vpunch
    pause .2
    play sound "audio/humanImpact.mp3" volume 0.1
    scene bg upAngry
    with vpunch
    pause .2
    play sound "audio/humanImpact.mp3" volume 0.1
    scene bg upAngry
    with vpunch
    pause .2
    "It presses its paw on your cheek three times in quick succession..."
    "...as if trying to slap you out of your melancholic state..."
    "...but they're so light, the slaps feel more like getting gently and eagerly petted."
    you "..."
    scene bg alleyCat2
    with dissolve
    you "Heh... Hehe..."
    "You can't help but laugh a little."
    you "Can't believe I'm having a meltdown in a dirty, old alley... with a stray cat comforting me..."
    scene bg upHappy
    pause .6
    scene bg upBlinkMeow
    play sound "audio/cat_happy.mp3" volume 0.4
    cat "Meow!"
    scene bg upHappy
    "You smile and show your gratitude with a scratch to the cat's chin."
    scene bg upBlinkSmile
    with dissolve
    play sound "audio/cat_purr.mp3" volume 0.3
    cat "Purr..."
    you "Thanks... I'm fine, really. That just happens sometimes..."
    scene bg alleyCat2
    with dissolve
    play sound "audio/cat_confused.mp3" volume 0.4
    cat "Meow?"
    you "I really {i}do{/i} like being alone most of the time."
    you "It's the only time I feel comfortable being myself, you know?"
    you "...But even {i}I{/i} get lonely every now and then."
    you "It's easy to ignore when I'm keeping myself busy..."
    you "That's why I pushed myself to go out today, I think..."
    scene bg upBlink
    pause .1
    scene bg alleyCat2
    play sound "audio/cat_sad.mp3" volume 0.4
    cat "Meow..."
    you "Heh, or maybe I was hoping to make a friend or something..."
    you "...though I guess that wouldn't be a good idea."
    you "I doubt someone like me would make for a very good friend to anyone..."
    scene bg upAngry
    pause .15
    scene bg upAngryMeow
    play sound "audio/cat_angry.mp3" volume 0.5
    cat "Meow! Meow! {i}Meow!{/i}" with hpunch
    scene bg upAngry
    you "Hehehe! Okay, okay, maybe I won't go so far as to say {i}that,{/i} but..."
    scene bg alley1
    with dissolve
    ".."
    "..."
    "You stay."
    "You stay and just... talk to the cat."
    "About anything that comes to mind."
    "Your isolation... {w}your loneliness..."
    "Your many fears... {w}your losses... {w}your {i}emptiness{/i}..."
    "Although..."
    "The longer you stay there... the smaller that once significant emptiness feels."
    "It's been so long since someone just... listened."
    "Your words shift to gentler topics..."
    "Your hopes... {w}your dreams... {w}happy memories of the past..."
    play sound "audio/squelchLOOP.mp3" volume 0.3
    scene bg chaseAlley1
    with fade_Red
    "As you talk, you don't even notice the once cold, concrete walls of the alley becoming flesh-like... {w}warm and pink..."
    stop sound fadeout 1.5
    "...its softness slowly engulfing the both of you."
    "The sound of your own voice feels hypnotic as it reaches your ears..."
    "...encouraging you to speak more of the depths of your heart into the open..."
    "You give in easily..."
    "When you {i}do{/i} run out of words, you're not sure how long you've been sitting there."
    "But not knowing doesn't seem to bother you."
    "Still..."
    "A strange question enters your mind..."

    menu:
        "Leave and... go home..?":
            jump stayForever


label stayForever:
    ".."
    "..."
    you "..."
    you "{i}Why would I want to do that..?{/i}"
    show screen dread
    with fade_Red
    "You're too tired to move."
    "Pouring out your heart and soul has taken a surprising toll on you, but you have no regrets."
    "You're so..."
    "...happy."
    "You don't think you've ever felt so heard..."
    "So {i}seen{/i}..."
    play music "audio/LOOPS/32fickleConfidantOUT.mp3" noloop
    "You lean forward to rest your head on the box."
    "You don't feel the rough cardboard you were expecting..."
    "Instead you find yourself resting on a mass of... {i}something...{/i}"
    "Something soft and slightly damp and warm."
    "So, so, {i}so{/i} warm..."
    "But you can't find it in you to care on what it could be."
    "You're... so tired."
    scene black
    with dissolve
    hide screen dread
    "You close your eyes..."
    "...and you get the feeling that they'll probably never open again."
    show screen catEyesFade
    with fade_Red
    "But as that all-encompassing warmth encases you slowly, {i}completely{/i}..."
    "..."
    "...you feel nothing but pure contentment."
    ".."
    "..."
    "Ending 22: Not Alone"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending22Done:
        jump endAlley
    else:
        $persistent.ending22Done = True
        $persistent.endCounter += 1
        jump endAlley


label leaveCat2:
    "You {i}really{/i} can't afford to take the cat home with you."
    "Well..."
    "Maybe it wouldn't be {i}completely{/i} impossible..."
    "A few extraneous luxuries cut here and there and you could see things working out, sure."
    "But there's a slight problem that's been making you waver this whole time..."
    "One you simply can't ignore."
    "That problem being..."
    "..."
    stop music
    "{size=-10}...that you just can't trust this cat.{/size}"
    scene bg alleyCat2
    with dissolve
    you "..."
    "It sounds ridiculous even in your head."
    "Cats don't require trust to care for."
    "They're incapable of betrayal or deception specifically because like other animals..."
    "...they only seek out the most basic essentials of living, procreation and comfort."
    "Malice isn't something that could ever logically be applied to them..."
    "And yet..."
    scene bg upBlink
    pause .1
    scene bg alleyCat2
    "You feel it."
    "That behind that gut-wrenchingly adorable face..."
    "...is something dangerous."
    "And that \"something\"... brought you here."
    "It {i}called{/i} you here."
    "You're a curious person, but even {i}you{/i} can't shake the deep, instinctual desire to-"
    show screen blackOut
    "{size=-10}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/size}"
    hide screen blackOut
    you "..."
    scene bg alleyCat1
    with dissolve
    cat "..."
    "The cat's face looks blank."
    "It's an expression you've seen on many cats before, but something about it feels..."
    play sound "audio/heartbeat.mp3" loop
    "{size=-5}{i}...sharper.{/i}{/size}"
    "Like it's aware of your thoughts and your intention to leave..."
    show screen dread
    with fade_Red
    pause .6
    "...and it's daring you to {b}try.{/b}"
    you "..."
    "You slowly stand up."
    "The cat tracks your movement with its eyes, not bothering to move its head."
    "You don't say a word."
    "You try not to even think..."
    stop sound
    show screen blackOut
    play sound "audio/heartbeatEcho.mp3" loop
    "{size=-10}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/size}"
    stop sound
    hide screen blackOut
    "..."
    "...though you don't really succeed."
    scene black
    with dissolve
    hide screen dread
    scene bg alley2
    with wiperight
    "You turn around and quickly leave the alley, feeling those sharp eyes on you the whole way."
    scene bg street1
    with wipeup
    "When you get a good distance away, you finally take in deep gulps of air."
    you "*pant*... *pant*... *pant*..."
    "..."
    "You..."
    "You feel better now."
    "And there's still plenty of time left to enjoy your day off!"
    ".."
    "..."
    "As long as you forget everything that just happened."
    "{b}But what to do?{/b}"


label aloneMenuFAKE:
    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/20possibilitiesLOOP.mp3" loop

menu:
    "I... I think I'll..."
    "G o \ WAtc h \ A \ mo vIe" if fakeOldMovie < 1 or fakeNewMovie < 1:
        jump goToMoviesFAKE
    "G o \ To tHe cArn iVa l" if fakeCarnival < 1:
        jump goToCarnivalFAKE
    "gO \ t o  DOG pAr k" if fakePark < 1:
        jump goToDogParkFAKE
    "Go home..." if fakeOldMovie == 1 and fakeNewMovie == 1 and fakeCarnival == 1 and fakePark == 1:
        jump escapeAlley

label getAwayFromCat:
    if leaveCounter == 1:
        jump getAway1
    if leaveCounter == 2:
        jump getAway2
    if leaveCounter == 3:
        jump getAway3
    if leaveCounter == 4:
        jump getAway4

label getAway1:
    scene bg turnedBack1a
    with dissolve
    you "..!"
    cat "..."
    "What the..?!"
    "How did you get back here?!"
    scene bg turnedBack1b
    with dissolve
    "..."
    show screen blackOut
    "{size=-10}{color=#FF0000}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/color}{/size}"
    hide screen blackOut
    ".."
    "..."
    scene bg alley2
    with wiperight
    "You leave the alley. {i}Quickly.{/i}"
    scene bg street1
    with wipeup
    ".."
    "..."
    "What now..?"
    jump aloneMenuFAKE


label getAway2:
    play sound "audio/tvStatic.mp3" volume 0.02 fadein 2 loop
    scene bg turnedBack2a
    with dissolve
    you "..!"
    scene bg turnedBack2b
    with dissolve
    pause .6
    show turnedBack2
    with dissolve
    cat "..."
    "The cat's face looks..."
    "..."
    show screen blackOut
    "{size=-10}{color=#FF0000}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/color}{/size}"
    hide screen blackOut
    ".."
    "..."
    stop sound
    scene bg alley2
    with wiperight
    "You leave the alley. {i}Quickly.{/i}"
    scene bg street1
    with wipeup
    ".."
    "..."
    "What now..?"
    jump aloneMenuFAKE

label getAway3:
    play sound "audio/tvStatic.mp3" volume 0.04 fadein 2 loop
    show turnedBack3
    with dissolve
    you "..!"
    cat "..."
    "The cat's face looks..."
    "..."
    show screen blackOut
    "{size=-10}{color=#FF0000}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/color}{/size}"
    hide screen blackOut
    ".."
    "..."
    stop sound
    scene bg alley2
    with wiperight
    "You leave the alley. {i}Quickly.{/i}"
    scene bg street1
    with wipeup
    ".."
    "..."
    "What now..?"
    jump aloneMenuFAKE

label getAway4:
    play music "audio/tvStatic.mp3" fadein 2 loop
    show turnedBack4
    with dissolve
    show static
    with dissolve
    you "..!" with hpunch
    cat "..."
    "The cat's face looks..."
    "It's..."
    "..."
    show screen blackOut
    "{size=-10}{color=#FF0000}get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it get away from it {/color}{/size}"
    hide screen blackOut
    play sound "audio/catToyMeow.mp3" volume 0.4 loop
    cat "{b}meow meow meow meow meow meow meow meow meow meow meow meow meow meow{/b}"
    stop sound
    ".."
    "..."
    stop music
    scene bg alley2
    with wiperight
    "You leave the alley. {i}Quickly.{/i}"
    scene bg street1
    with wipeup
    ".."
    "..."
    "What now..?"
    jump aloneMenuFAKE


label goToMoviesFAKE:
    scene bg street2
    with dissolve
    "It's been a while since a film came out that looked interesting enough for you to drag yourself to a movie theater..."
    "...but there's a showing of one such film at the old theater."
    "It was a little too niche to be picked up by the new cinema that opened right across the street."
    "That's okay though. You're not exactly a fan of the crowds."
    "And nothing ruins the experience of watching a new movie for you more than a noisy audience."

    label moviesMenuFAKE:
        if not renpy.music.is_playing('music'):
            play music "audio/LOOPS/20possibilitiesLOOP.mp3" loop
        menu:
            "G o tO {b}old theater.{/b}" if fakeOldMovie < 1:
                jump oldTheaterFAKE
            "go t o {b}new cinema.{/b}" if fakeNewMovie < 1:
                jump newCinemaFAKE

label oldTheaterFAKE:
    scene bg theater1
    with dissolve
    "You eagerly buy your ticket from the kind old man in the booth and head inside..."
    stop music fadeout 0.5
    scene black
    with dissolve
    ".."
    "..."
    $ leaveCounter += 1
    $ fakeOldMovie += 1
    jump getAwayFromCat


label newCinemaFAKE:
    "You don’t know why...{w} but you don’t really feel great about the idea of being alone right now."
    scene bg cinema1
    with dissolve
    "Deciding to wait for the movie you’ve been anticipating to be available on DVD or streaming..."
    "...you join the long line outside the new cinema."
    "By the time you’ve reached the ticket booth, you just want to get inside..."
    "...so you pick a movie at random and take your ticket from tired looking teenager manning the booth."
    "You head inside..."
    stop music fadeout 0.5
    scene black
    with dissolve
    ".."
    "..."
    $ leaveCounter += 1
    $ fakeNewMovie += 1
    jump getAwayFromCat


label goToCarnivalFAKE:
    play music "audio/LOOPS/26carnivalIN.mp3" fadein 2.5
    queue music "audio/LOOPS/26carnivalLOOP.mp3" loop
    scene bg carnival1
    with dissolve
    "You spend the day at the carnival."
    "Ferris wheel, roller coaster, pharaoh boat... {w}Rides you’ve been on before."
    "Hoops, coin toss, balloon darts... {w}Games you’ve played before."
    "Funnel cake, popcorn, cotton candy... {w}Food you’ve eaten before."
    "All things you’ve enjoyed {i}before.{/i}"
    "You’re surrounded by groups of people all having fun together..."
    "Laughing, playing, eating, taking pictures... Making memories..."
    "And then there’s you."
    "..."
    "The sun hasn’t started to set yet, still high in the sky, but it will soon."
    "You start to wonder if maybe you should just go home for the day...{w} when you stop in your tracks."
    scene bg carnival2
    with dissolve
    "You see something...{w} {i}new.{/i} {w}An attraction you’ve never seen before."
    "A maze of... funhouse mirrors?"
    "It sounds..."
    "...kind of lame, honestly."
    "There isn’t even a line to get in."
    "..."
    "But then... {w}what else is there to do..?"

    menu:
        ".ezam eht retnE":
            jump enteringMazeFAKE

    label enteringMazeFAKE:
        stop music fadeout 1
        scene black
        with dissolve
        "You enter the maze..."
        ".."
        "..."
        $ leaveCounter += 1
        $ fakeCarnival += 1
        jump getAwayFromCat

label goToDogParkFAKE:
    scene bg street4
    with dissolve
    stop music fadeout 2.5
    "You decide to take a stroll in a park or something."
    "The only one within your walking distance for the day is the nearby dog park."
    "You think it’ll make you feel better."
    "First you get to see a cute cat today, now you’ll get to see a cute dog!"
    "{i}Several{/i} of them, in fact."
    play music "audio/LOOPS/30dogLOOP.mp3" loop
    scene bg dogPark1
    with dissolve
    "The park is bustling with owners and their canine companions."
    "Playing Frisbee, fetch, running, jumping, even napping~!"
    "Such cuties--{w=0.3}{nw}"
    $ renpy.music.set_volume(0.0, 0, "music")
    play sound "audio/glitch.mp3" volume 0.6
    show screen blackOut
    "{size=+25}{b}{i}DOGS ARE DISGUSTING!!{/i}{/b}{/size}{w=0.8}{nw}" with hpunch
    play sound "audio/glitch.mp3" volume 0.6
    "{size=+30}{b}{i}THEY SHOULD ALL JUST DIEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE!!{/i}{/b}{/size}{w=0.8}{nw}" with vpunch
    stop sound
    hide screen blackOut
    $ renpy.music.set_volume(1.0, 0, "music")
    you "{i}!!!{/i}" with vpunch
    ".."
    "..."
    "You..."
    "..."
    "{size=-8}You decide to move on.{/size}"
    scene bg dogPark2
    with dissolve
    "The dogs are all so adorable. You want to pet every single one you come across..."
    "...but you know not all owners are cool with strangers just walking up and manhandling their pets."
    "Not all dogs appreciate it either."
    "So you stroll around the path, trying to exude a welcoming aura that will beckon one of these cute doggies to you."
    stop music fadeout 1.5
    scene black
    with dissolve
    "You don’t have to wait very long."
    ".."
    "..."
    scene bg chaseDogPark3
    with dissolve
    "You stop as the smallest, cutest puppy you’ve ever seen scampers up to you, blocking your path~"

label puppyMenuFAKE:
    if not renpy.music.is_playing('music'):
        play sound "audio/heartbeat.mp3" loop

    menu:
        "{size=-8}{b}p u p p y.{/b}{/size}":
            jump pickUpPupFAKE

label pickUpPupFAKE:
    "..."
    "You pick up the puppy and-"
    stop sound
    scene black
    play sound "audio/stare.mp3" volume 0.8
    show screen catEyesFade
    with c_Red
    with hpunch
    hide screen catEyesFade
    scene black
    ".."
    "..."
    $ leaveCounter += 1
    $ fakePark += 1
    jump getAwayFromCat

label escapeAlley:
    stop music
    "...Wait."
    "Haven't you..."
    "Haven't you done this before?"
    "..."
    "You feel sick."
    "Looking around, you suddenly realize that unlike earlier..."
    "...there isn't a single person in sight."
    "You're alone."
    "You're {i}completely{/i} alone..."
    "..."
    play sound "audio/heartbeatEcho.mp3" loop
    show screen dread
    with fade_Red
    "{size=-10}...So why do you feel like you're being watched right now?{/size}"
    you "..."
    "You feel your heartbeat start to race."
    "You need to get home."
    "{b}Now.{/b}"
    scene bg street2
    with wiperight
    pause .6
    scene bg street3
    with wipeleft
    "You walk back home, the feeling of eyes on your back getting worse with each step."
    scene bg street4
    with wipeup
    pause .6
    scene bg street5
    with wiperight
    pause .6
    scene bg aptFront
    with wipeleft
    pause .6
    scene bg aptDoor
    with wiperight
    "By the time you're fumbling with the keys at your door, you're soaked through with cold sweat."
    "Your skin prickles and itches..."
    "...the heavy gaze you feel might as well be eyeballs physically pressing into your flesh... {w}sticky and unnatural."
    "You finally get inside and..."
    scene black
    with dissolve
    hide screen dread
    ".."
    stop sound fadeout 0.5
    "..."
    play music "audio/LOOPS/04homeWithYou.mp3" loop
    scene bg aptLivingRoom
    with dissolve
    you "Haaahhhh..!" with hpunch
    "The {b}weight{/b} of relief in the sigh that escapes through your lips actually causes you to physically {i}shudder.{/i}"
    "The horrible feeling from earlier immediately dissipates as if it were never there."
    "In the wake of its departure, you're left shaking and cold in your sweat-soaked clothes..."
    "...but you're too relieved to care."
    scene bg aptHall
    with dissolve
    "Exhausted, you mentally pass on the very {i}concept{/i} of eating and head straight for your bedroom."
    scene bg aptBedroom
    with dissolve
    you "..."
    "You open the door, intending to pass out immedia--{w=0.75}{nw}"
    stop music
    scene black
    pause .1
    scene bg turnedBack5a
    cat "..."
    play music "audio/LOOPS/33flightRiskIN.mp3"
    queue music "audio/LOOPS/33flightRiskLOOP.mp3" loop
    you "!!!" with vpunch
    scene bg turnedBack5b
    with fade_Red
    "Not again! No..."
    "{size=+25}NO!{/size}" with vpunch
    "You back up in fear... {w}eyes trained on the cat and its horrifying grin."
    "You need to escape."
    "You need to get out."
    "But if even {b}home{/b} isn't safe anymore..."
    "Where will you {i}go{/i}..?"
    "You risk a glance around you and-"
    you "!!!" with vpunch
    play sound "audio/squelchLOOP.mp3" volume 0.7
    scene bg turnedBack6a
    with dissolve
    stop sound fadeout 3
    "You see that the walls all around you have become fleshy and lined with sharp teeth..."
    "The ground now a tongue writhing under your feet..."
    scene bg turnedBack6b
    with dissolve
    pause .6
    scene bg turnedBack6c
    with dissolve
    "In horror, you realize that the alley's entrance is getting smaller and smaller..."
    "{i}Closing{/i}... {w}like a mouth..."
    "You try to run for the exit..."
    play sound "audio/humanImpact.mp3" volume 0.7
    scene bg redScreen
    with p_Red
    pause .05
    show screen blackOut
    with dissolve
    scene bg turnedBack6c
    "{size=-10}{i}nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide nowhere to hide {/i}{/size}"
    hide screen blackOut
    "...but trying to run on the tongue slows your speed significantly as you stumble and trip."
    scene bg turnedBack6d
    with dissolve
    you "{size=-8}No...{/size}"
    "You watch helplessly as the last sliver of light from the entrance tightens beyond a size you could never hope to squeeze through..."
    play music "audio/LOOPS/33flightRiskOUT.mp3" noloop
    scene black
    with dissolve
    hide screen dread
    "As darkness falls over you... {w}you feel the damp humidity of the mouth all around you..."
    "The walls... the walls of teeth... {i}fangs...{/i}"
    "...take their time closing in."
    "Closer..."
    "And closer..."
    "And-{w=0.2}{nw}"
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    you "!!!" with hpunch
    scene black
    hide screen bloody
    with dissolve
    you "..."
    ".."
    "..."
    "Ending 23: Feedback loop"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending23Done:
        jump endAlley
    else:
        $persistent.ending23Done = True
        $persistent.endCounter += 1
        jump endAlley


label feedAlley:
    "The cat must be hungry, right?"
    "You can't imagine that it's had much to eat if it's so attached to that box it's in."
    "Though... it doesn't exactly seem malnourished either..."
    "Surely it {i}must{/i} have left the box to search for food then..?"
    "..."
    "For some reason... something in the back of your mind tells you that's not the case."
    "{size=-10}...And not to think on it any further.{/size}"
    you "..."
    "Well, either way..."
    "You can't exactly enjoy your day out knowing you left behind a hungry cat."
    "Especially when you could have done something to help."

label feedAlleyMenu:
    "So..."
    "What to do about the hungry kitty?"

    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/03catTheme.mp3" loop

    menu:
        "Check pockets":
            jump feedPockets
        "Look around the area":
            jump feedLookAround
        "?????" if persistent.ending24Done == None or persistent.ending25Done == None or persistent.ending26Done == None or persistent.ending27Done == None:
            show screen blackOut
            "Not yet..."
            hide screen blackOut
            jump feedAlleyMenu
        "{color=#FF0000}Blood...{/color}" if persistent.ending24Done and persistent.ending25Done and persistent.ending26Done and persistent.ending27Done:
            jump feedBlood

label feedPockets:
    "You dig into your pockets."
    show screen stringPanel
    with dissolve
    "You find a small piece of string in your left pocket. Not very helpful."
    "The string is far too short."
    if persistent.ending11Done:
        "An eager and excited cat leaping for it could easily lead to you getting{w=1.0}{nw}"
        $ renpy.music.set_volume(0.0, 0, "music")
        hide screen stringPanel
        play sound "audio/glitch.mp3"
        queue sound "audio/tvStatic.mp3" volume 0.03
        show yarnJumpscare
        with vpunch
        pause .3
        stop sound
        pause .75
        hide yarnJumpscare
        you "!!!" with hpunch
        ".."
        "..."
        $ renpy.music.set_volume(1.0, 0, "music")
    else:
        "An eager and excited cat leaping for it could easily lead to you getting bitten and scratched."
        hide screen stringPanel
        with dissolve
    "In your right pocket..."
    show screen chocolatePanel
    with dissolve
    if persistent.ending24Done or persistent.ending25Done:
        $ renpy.music.set_volume(0.0, 0, "music")
        "{size=-10}...is a bar of {color=#FF0000}chocolate.{/color}{/size}"
        show screen blackOut
        "{size=-5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sor {/size}{w=0.2}{nw}"
        $ renpy.music.set_volume(1.0, 0, "music")
        hide screen blackOut
        you "..."
    else:
        "...is a bar of chocolate."
    "You find a {i}chocolate bar?!{/i}"
    "Is it..? Nope, it's not even expired!"
    "Quite the find indeed!"
    hide screen chocolatePanel
    with dissolve
    "You're about to offer it to the cat..."
    you "!!!" with hpunch
    "...when suddenly, you're hit with guilt as you remember something gut-curdling..."
    "..."
    stop music
    show screen blackOut
    "Chocolate is {color=#FF0000}{b}toxic{/b}{/color} to cats."
    hide screen blackOut
    you "Oh my gosh! I'm so..."
    "You resist the urge to vomit at your near mistake."
    scene bg upBlink
    pause .1
    scene bg alleyCat2
    "You feel so guilty, you throw the chocolate bar away into a nearby trash bin."
    "An almost-cat-killer doesn't deserve chocolate."
    "You go back to the cat, barely able to stand its innocently oblivious expression."
    scene bg upMeow
    with dissolve
    play sound "audio/cat_confused.mp3" volume 0.3
    cat "Meow?"
    scene bg alleyCat2
    you "..."
    "It doesn't even know that you almost..."
    "..."
    you "I... I'm so sorry... I don't even know what to say..."
    scene bg upMeow
    with dissolve
    play sound "audio/cat_sad.mp3" volume 0.3
    cat "Meowww?"
    scene bg alleyCat2
    "..."
    show screen blackOut
    "you're a {b}h o r r i b l e{/b} person..."
    you "...Y-You know what? Stay there, I'll be right back!"
    play sound "audio/cat_confused.mp3" volume 0.4
    cat "Meow?"
    "You leave the alley..."
    ".."
    "..."
    hide screen blackOut
    with dissolve
    "...And return with a {i}whole fish{/i} you bought at a nearby grocery shop."
    "It was a bit pricey..."
    "{size=-8}...but it was the {b}least{/b} you could do.{/size}"
    scene bg upBlinkSmile
    pause .1
    scene bg upBlinkMeow
    play sound "audio/cat_happy.mp3" volume 0.4
    cat "Meow!" with hpunch
    scene bg upBlinkSmile
    "The cat eagerly accepts your offering, munching happily at the fish after you'd placed it in the box."
    scene bg upBlinkMeow
    play sound "audio/cat_happyLONG.mp3" volume 0.5
    cat "Meow! Meow! Meow!!" with hpunch
    scene bg upBlinkSmile
    "You want to smile at the sight, but you just feel so..."
    "...{i}awful.{/i}"
    you "...S-Sorry again."
    "The cat seemingly pays you no mind as you slip back out of the alley."
    scene bg street1
    with dissolve
    "Not feeling like you deserve a peaceful day out, you decide to just head back home."
    ".."
    "..."
    play sound "audio/catStray2.mp3"
    who "Reow..."
    you "..?"
    play sound "audio/heartbeat.mp3" volume 0.5 loop
    scene bg street2
    with dissolve
    pause .3
    scene bg feedPockets1a
    with dissolve
    "On the way home, you notice more cats than usual, watching you from their hiding spots..."
    "...but you try not to think about it."
    scene bg street3
    with dissolve
    pause .3
    scene bg feedPockets1b
    with dissolve
    "You can't help but wonder..."
    "...if they know what you'd nearly {b}done.{/b}"
    "But..."
    scene bg street5
    with dissolve
    pause .3
    scene bg feedPockets1c
    with dissolve
    "It's not like you meant to hurt anyone..."
    stop sound
    show screen blackOut
    show screen catEyesFade
    with fade_Red
    "{size=-8}...right?{/size}"
    hide screen catEyesFade
    hide screen blackOut
    ".."
    "..."
    scene bg aptDoor
    with dissolve
    "You finally reach your apartment building. You're about to unlock the door when..."
    scene bg feedPockets2a
    with dissolve
    play sound "audio/catsMeowing.mp3"
    who "Reow... Reow... Reowwww...!"
    you "..?"
    you "!!!" with vpunch
    play sound "audio/heartbeatEcho.mp3" volume 0.5 loop
    scene bg feedPockets2b
    with dissolve
    "You look behind you... only to see {i}dozens{/i} of cats standing there."
    "Looking at you."
    "Did they see you feeding the cat in the alley and thought that you had more food for all of them..?"
    you "I... I'm sorry I don't have anymore food for you..."
    "None of them move an inch."
    "You're starting to feel a little unnerved when finally a single cat pushes its way to the front and..."
    scene bg feedPockets2c
    with dissolve
    pause .2
    scene bg feedPockets2d
    with dissolve
    pause .2
    scene bg feedPockets2e
    with dissolve
    cat "..."
    you "Oh! It's y-!"
    you "!!!" with vpunch
    "Oh..."
    "It's..."
    "..."
    "Held carefully between its teeth is the chocolate bar you'd thrown away earlier."
    scene bg feedPockets2f
    with dissolve
    pause .2
    scene bg feedPockets2g
    with dissolve
    "It places the chocolate bar down in front of it before looking back up at you."
    "{i}All{/i} the cats look up at you..."
    "..."
    show screen blackOut
    "{size=-5}You can feel their judgment...{/size}"
    hide screen blackOut
    you "!!" with hpunch
    you "!!!" with vpunch
    "You feel your sins weighing down heavily on your back."
    "But without the money to buy enough food for all of them..."
    "You don't know what to do..."

    menu:
        "Beg for forgiveness.":
            jump begForgive
        "Go inside.":
            jump leaveHungryCats


label begForgive:
    stop sound
    "You collapse to your knees and bow down low as you start to earnestly beg for their forgiveness."
    you "I'm so sorry! I swear!" with vpunch
    you "I... I'd do anything to make it up to all of you, but...!"
    "...but you're out of options."
    "Suddenly..."
    scene bg feedPockets2g
    with p_Red
    you "Hrk! Hmp! *choke*!!" with vpunch
    "You feel something stir in your stomach and swim its way up to your throat..."
    "...closing off your airway as it tries to force its way out of your esophogus."
    scene bg feedPockets2g
    with p_Red
    you "Bl-Blgh!" with vpunch
    "It finally succeeds with aid from your helpless gagging."
    scene bg redScreen
    with p_Red
    play sound "audio/splat.mp3"
    show screen bloody
    with vpunch
    pause .6
    you "Blurgh!!" with hpunch
    scene black
    hide screen bloody
    with dissolve
    you "..."
    play music "audio/heartbeat.mp3" volume 0.7 loop
    you "..?"
    you "!!!" with hpunch
    you "{size=-8}What... the...?{/size}"
    "Lying on the ground in front of you..."
    scene bg feedPockets3a
    with dissolve
    pause 1
    scene bg feedPockets3c
    with fade_Red
    "...is a flopping fish."
    "You just... {w}threw up a {i}living{/i} fish..."
    you "{size=-8}What the hell...?{/size}"
    scene bg feedPockets2a
    with dissolve
    "The cats come rushing forward, all tearing hungrily at the fish."
    "You're..."
    "You're {i}happy{/i} to finally be of help, truly... {w}but how-{w=0.2}{nw}"
    play sound "audio/squelchLOOP.mp3" volume 0.5
    scene bg feedPockets2a
    with p_Red
    stop sound fadeout 0.5
    play sound "audio/splat.mp3" volume 0.5
    you "Blurgh!!" with vpunch
    ".."
    "..."
    "...You throw up another fish."
    scene bg redScreen
    with p_Red
    play sound "audio/squelchLOOP.mp3" volume 0.6
    show screen bloody
    with vpunch
    stop sound
    play sound "audio/splat.mp3" volume 0.5
    you "Blurgh!!" with hpunch
    scene bg feedPockets2a
    hide screen bloody
    with dissolve
    "And another..."
    scene bg redScreen
    with p_Red
    play sound "audio/squelchLOOP.mp3" volume 0.7
    show screen bloody
    with vpunch
    stop sound
    play sound "audio/splat.mp3" volume 0.5
    you "Blurgh!!" with hpunch
    scene bg feedPockets2a
    hide screen bloody
    with dissolve
    "And {i}another{/i}..."
    scene bg redScreen
    with p_Red
    play sound "audio/squelchLOOP.mp3" volume 0.9
    show screen bloody
    with vpunch
    stop sound
    play sound "audio/splat.mp3" volume 0.5
    you "Blurgh!!" with hpunch
    scene bg feedPockets2a
    hide screen bloody
    with dissolve
    stop music fadeout 2.5
    "And..."
    "..."
    "Your stomach hurts. {w}You’re getting... dizzy."
    "You fall to your knees..."
    "Tears and snot are streaming down your face by the time you cough up a final, tiny, {i}{color=#FF0000}bloody{/color}{/i} fish and collapse forward."
    "Your throat and stomach both {i}burn{/i} in a way that feels dangerous."
    "You start to fade out..."
    scene black
    with dissolve
    "Despite the pain..."
    play music "audio/LOOPS/34sorryIN.mp3"
    queue music "audio/LOOPS/34sorryLOOP.mp3" loop
    "...you strangely feel a more overwhelming sense of hopeful pride."
    "That you've made up for your {b}disgusting{/b} actions..."
    "...That you've been forgiven."
    play sound "audio/cat_eating.mp3" volume 0.6
    pause .5
    stop sound fadeout 1.5
    pause .3
    play sound "audio/cat_happy.mp3" volume 0.5
    pause .6
    stop sound fadeout 1.5
    pause .3
    play sound "audio/cat_eating.mp3" volume 0.6
    pause .5
    stop sound fadeout 1.5
    pause .3
    play sound "audio/cat_trilling.mp3" volume 0.5
    pause .5
    stop sound fadeout 1.5
    pause .3
    play sound "audio/cat_eating.mp3" volume 0.6
    pause .5
    stop sound fadeout 1.5
    pause .3
    play sound "audio/cat_happyLONG.mp3" volume 0.5
    pause .3
    stop sound fadeout 1.5
    pause .3
    play sound "audio/cat_eating.mp3" volume 0.6
    pause .5
    stop sound fadeout 1.5
    pause .3
    play sound "audio/cat_purr.mp3" volume 0.5
    pause .6
    stop sound fadeout 1.5
    pause .3
    play sound "audio/cat_eating.mp3" volume 0.6
    pause .5
    stop sound fadeout 1.5
    pause .3
    "The sound of happy cats munching away at their fish fills your ears..."
    "Then..."
    scene bg feedPockets4a
    with dissolve
    pause .4
    scene bg feedPockets4b
    with dissolve
    pause .4
    scene bg feedPockets4c
    with dissolve
    pause .4
    scene bg feedPockets4d
    with dissolve
    pause .4
    scene bg feedPockets4e
    with dissolve
    play music "audio/LOOPS/34sorryOUT.mp3" noloop
    "...you feel something being nudged into your hand."
    "It feels like..."
    you "!!"
    "It's the bar of chocolate you'd found in your pocket."
    you "..."
    you "{size=-8}H-Heh...{/size}"
    "You smile weakly."
    scene black
    with dissolve
    "You’ve successfully atoned, but you don’t really have the strength to eat your reward."
    "Sadly, the last taste in your mouth as you leave this mortal coil doesn't get to be that of chocolate..."
    "...but raw fish."
    "..."
    "Ending 24: Fishing for pardon"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending24Done:
        jump endAlley
    else:
        $persistent.ending24Done = True
        $persistent.endCounter += 1
        jump endAlley


label leaveHungryCats:
    stop sound
    scene black
    with dissolve
    "You decide to cut your losses and head inside."
    "Your sins weigh down on you, but you’re only human. What more can you do?"
    play music "audio/LOOPS/04homeWithYou.mp3" loop
    scene bg aptLivingRoom
    with dissolve
    play sound "audio/cat_angryQUICK.mp3" volume 0.075
    queue sound "audio/cat_angry.mp3" volume 0.075
    you "{i}Geez...{/i}"
    "You try to ignore the yowling of the neighborhood cats as you go about your chores."
    "You consider preparing dinner..."
    "...but how could you enjoy it knowing how hungry those poor cats outside are?"
    "The ones you’ve wronged?"
    scene bg aptBath_C
    with dissolve
    "You decide to take a bath and go straight to bed {b}without{/b} dinner."
    "A fitting punishment for someone like you."
    scene bg feedPockets5a
    with dissolve
    "You forgo the fancy bath bubbles because you don’t deserve them and sink into the water with a sigh."
    "Your mind races but you can’t really think of any immediate solution that doesn’t require more money."
    "You wish there was something, {i}anything{/i}, you could do to make things right."
    "Suddenly... {w}your legs start to feel really itchy."
    "You try to lift one to see what’s going on, but what rises out of the water isn’t a pair of legs..."
    you "!!!" with vpunch
    scene bg feedPockets5a
    with dissolve
    pause .15
    scene bg feedPockets5b
    with dissolve
    pause .15
    scene bg feedPockets5c
    with dissolve
    pause .15
    play sound "audio/splashQUICK.mp3"
    scene bg feedPockets5d
    with dissolve
    stop music fadeout 2.5
    pause .15
    "It’s...{w} It's a fish tail..?"
    "You... You feel dizzy at the sight... Maybe you’re hallucinating from the stress?"
    "..."
    "You try to climb out of the tub to cool your head... but instead of your hand rising up to brace itself..."
    scene bg feedPockets5e
    with dissolve
    play sound "audio/splat.mp3"
    "...a wet fin stretches out to plop on the rim."
    "It’s too weak to hold your weight and you’re so startled by the sight..."
    scene bg feedPockets5f
    pause .08
    scene bg feedPockets5g
    pause .06
    scene bg feedPockets5h
    pause .03
    scene bg feedPockets5i
    pause .01
    play sound "audio/humanImpact.mp3"
    scene bg redScreen
    with p_Red
    pause .2
    scene black
    play sound "audio/splash.mp3" volume 0.7
    you "!!" with vpunch
    you "..."
    "...that you slip and smack your head on the side of the bathtub, passing out almost immediately."
    ".."
    "..."
    "You’re... awake. You {i}think,{/i} anyway."
    "You open your eyes and..."
    play sound "audio/underwaterLOOP.mp3" loop
    scene bg feedPockets6a
    with dissolve
    "..? You’re.. underwater..?"
    "..! You must’ve slid beneath the surface of the bathwater! You gasp instinctively."
    "...Except not really."
    scene bg feedPockets6b
    with dissolve
    pause .1
    scene bg feedPockets6c
    with dissolve
    pause .1
    scene bg feedPockets6d
    with dissolve
    pause .1
    scene bg feedPockets6e
    with dissolve
    pause .1
    "A bubble simply floats out of your mouth... up, up, {i}up{/i} to the surface."
    "You’re broke as heck, so you {i}know{/i} your bathtub isn’t {i}that{/i} big."
    "Did..?"
    "..."
    "Did you... {w}{b}shrink?{/b}"
    "But {i}how?{/i}"
    "And even if there were a reasonable answer..."
    "...it wouldn’t explain how you haven’t {b}drowned{/b} yet..."
    "You swim to the edge of the tub and see the truth in your shadow's silhouette..."
    you "!!"
    scene bg feedPockets6f
    with dissolve
    pause .3
    scene bg feedPockets6g
    with dissolve
    "You’ve been... {w}turned into a {i}{b}fish?!{/b}{/i}"
    you "{i}{size=-5}This... This isn't {b}possible{/b}...{/size}{/i}"
    "You don’t get any time to ponder over this unfortunately..."
    "Because just then..."
    scene bg feedPockets6h
    with dissolve
    "...a shadow looms over you from above."
    "You look up and see... the cat?"
    "It peers down at you from beyond the water's surface..."
    you "..."
    you "!!!" with vpunch
    "..."
    "And then..."
    stop sound fadeout 5
    "Then you {i}realize.{/i}"
    "{b}This{/b} is the answer..."
    "This... {w}is how you're meant to atone."
    play music "audio/LOOPS/35sorrySorryLOOP.mp3" loop
    you "..."
    "With a heavy heart..."
    "..."
    "...you swim up to the surface."
    scene black
    with dissolve
    play sound "audio/cat_angryQUICK.mp3" volume 0.6
    cat "Meoww!" with hpunch
    play sound "audio/splashQUICK.mp3"
    scene black
    with p_Red
    play sound "audio/splat.mp3"
    you "!!" with vpunch
    "The cat scoops you up, tossing you out of the tub and onto the bathroom tiles."
    scene bg aptBath_DC
    with dissolve
    pause .6
    scene bg feedPockets7a
    with dissolve
    "As you flop around gasping for air..."
    "(or water..?)"
    "...you realize the cat wasn’t alone."
    scene bg feedPockets7b
    with dissolve
    "Dozens of hungry eyes peer down at you."
    "You can hear the yowling of what sounds like hundreds of cats outside your bathroom window."
    scene black
    with dissolve
    "You send one last look to the cat before closing your eyes and accepting your fate."
    scene bg redScreen
    play sound "audio/squelchLOOP.mp3"
    show screen bloody
    with vpunch
    stop sound
    scene black
    hide screen bloody
    with dissolve
    "As the cats descend upon you, tearing at your flesh..."
    scene bg redScreen
    play sound "audio/squelchLOOP.mp3"
    show screen bloody
    with vpunch
    stop sound
    scene black
    hide screen bloody
    with dissolve
    pause .3
    scene bg redScreen
    play sound "audio/squelchLOOP.mp3"
    show screen bloody
    with vpunch
    stop sound
    scene black
    hide screen bloody
    with dissolve
    "...you find yourself mourning the fact..."
    "..."
    "{size=-6}...that you’re not even big enough to feed all of them.{/size}"
    scene bg redScreen
    play sound "audio/squelchLOOP.mp3"
    show screen bloody
    with vpunch
    stop sound
    scene black
    hide screen bloody
    with dissolve
    "Even in the end..."
    "...you couldn’t properly atone."
    scene bg redScreen
    play sound "audio/squelchLOOP.mp3"
    show screen bloody
    with vpunch
    stop sound
    scene black
    hide screen bloody
    with dissolve
    "Your efforts, your {i}life{/i}..."
    "All of it..."
    "..."
    stop music
    "...amounted to {b}nothing{/b}."
    ".."
    "..."
    "Ending 25: Seafood Sacrifice"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending25Done:
        jump endAlley
    else:
        $persistent.ending25Done = True
        $persistent.endCounter += 1
        jump endAlley


label feedLookAround:
    scene bg alley1
    with dissolve
    "You glance around the dark, dingy alley..."
    "...and only see garbage bags, trash bins, empty cardboard boxes, and scattered litter here and there."
    "If there were something for the cat to eat, surely it would’ve found it by now, right?"
    "But you don't want to just give up so easily."
    "You keep looking."
    "You look and only see garbage."
    "You sniff and only smell garbage."
    stop music fadeout 3.5
    "You listen..."
    ".."
    "..."
    play sound "audio/cut.mp3" volume 0.2
    queue sound "audio/cut.mp3" volume 0.2
    "{size=-10}*scritch* *scritch*{/size}"
    "..!"
    "You just barely make out the sound of faint scurrying by a trash bin a few feet away."
    "Quietly... Oh so quietly... you creep over to the bin..."
    "And..."
    ".."
    "..."
    "..!"
    "{size=+5}You {i}lunge!{/i}{/size}"
    play sound "audio/crash.mp3" volume 0.6
    "{size=+20}{b}CRASH!!{/b}{/size}" with vpunch
    "..."
    "You weren't very graceful in your attempt."
    "You'd stumbled and knocked over a stack of nearby boxes full of more trash, {w}but as you stand up..."
    "...grasped in your hand..."
    "..."
    scene bg mouse1a
    with dissolve
    "...is a small mouse."
    play sound "audio/mouseSqueak.mp3"
    rat "Squeak! Squeak!" with vpunch
    "The mouse squeaks and shrieks in distress, wriggling and struggling desperately in your grip."
    "You’re holding it too tightly and carefully for it to be able to bite or scratch you though."
    "It wears itself out eventually and looks up at you with black eyes..."
    "..."
    "It’s {i}completely{/i} at your mercy."


label spareFeedMouse:

    menu:
        "Spare the mouse." if spareMouseCounter == 0:
            jump spareMouse
        "Spare the mouse..." if spareMouseCounter == 1:
            jump spareMouse2
        "{i}Spare the mouse.{/i}" if spareMouseCounter == 2:
            jump spareMouse3
        "{b}{i}Spare the mouse.{/i}{/b}" if spareMouseCounter == 3:
            jump spareMouse4
        "SpaRe tHe {color=#FF0000}{b}mouse{/b}{/color}." if spareMouseCounter == 4:
            jump freeMouse
        "Feed mouse to cat." if feedMouseCounter == 0:
            jump feedCatMouse
        "{color=#FF0000}{b}Feed mouse to cat.{/b}{/color}" if feedMouseCounter == 1:
            jump feedCatMouse2

label spareMouse:
    scene bg alleyCat2
    with dissolve
    pause .3
    scene bg upMeow
    with dissolve
    play sound "audio/cat_sad.mp3" volume 0.3
    cat "Meow..."
    scene bg alleyCat2
    "Are... you sure?"
    $ spareMouseCounter += 1
    jump spareFeedMouse

label spareMouse2:
    scene bg upSad
    with dissolve
    pause .3
    scene bg upSadMeow
    play sound "audio/cat_sadLONG.mp3" volume 0.25
    cat "Meowww..."
    scene bg upSad
    "You can hear the cat's stomach growling."
    "It must be so hungry..."
    "It must be {b}starving...{/b}"
    $ spareMouseCounter += 1
    jump spareFeedMouse

label spareMouse3:
    scene bg alleyCat2
    ".{w=1.0}.{w=1.0}.{w=1.0}{nw}"
    scene bg upAngryMeow
    play sound "audio/cat_angryQUICK.mp3" volume 0.75
    cat "{size=+10}{b}MREOW!{/b}{/size}" with hpunch
    scene bg upAngry
    "You know the cat is hungry."
    "Why are you hesitating?"
    "You caught prey for the cat's sake, didn't you?"
    "Are you really going to value the life of a filthy rodent more than the cat's?"
    $ spareMouseCounter += 1
    jump spareFeedMouse

label spareMouse4:
    scene bg alleyCat2
    pause 3
    play sound "audio/glitch.mp3"
    scene bg upSlits
    pause .1
    scene bg upWide
    pause .05
    scene black
    pause .6
    ".."
    "..."
    show screen catEyesFade
    with dissolve
    pause .7
    "{size=-8}{color=#FF0000}You're mocking me, aren't you?{/color}{/size}"
    "Last chance..."
    hide screen catEyesFade
    with dissolve
    pause .5
    scene bg upWideDark
    with dissolve
    "H a n d... {w}o v e r... {w}t h e... {w}p r e y..."
    "{b}{color=#FF0000}Now.{/color}{/b}"
    $ spareMouseCounter += 1
    jump spareFeedMouse

label freeMouse:
    scene black
    with dissolve
    ".."
    "..."
    "You let the mouse go."
    play music "audio/LOOPS/36betrayalIN.mp3"
    queue music "audio/LOOPS/36betrayalLOOP.mp3" loop
    scene bg alley1
    with dissolve
    "It scurries away, squeezing into a tiny hole in the wall..."
    "But you don't pay it much mind."
    scene bg alley2
    with dissolve
    pause .6
    scene bg mouse2a
    with dissolve
    "You don't flinch as a giant clawed paw slowly falls in front of you..."
    "...blocking your path to the alley's entrance..."
    "Not that you had any delusions about escaping."
    "..."
    "The cat is hungry after all."
    scene bg mouse2b
    with dissolve
    pause .3
    scene bg mouse2c
    with dissolve
    pause .2
    scene black
    with dissolve
    "You close your eyes in acceptance as the paw gently pulls you back..."
    "And back..."
    "And-{w=0.175}{nw}"
    stop music
    scene bg redScreen
    play sound "audio/punch_LOW.mp3" volume 0.8
    show screen bloody
    with vpunch
    "{size=+20}{b}CHOMP!!{/b}{/size}" with hpunch
    scene black
    hide screen bloody
    with dissolve
    ".."
    "..."
    "Ending 26: A life spared"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending26Done:
        jump endAlley
    else:
        $persistent.ending26Done = True
        $persistent.endCounter += 1
        jump endAlley


label feedCatMouse:
    scene bg mouse1b
    with dissolve
    "The mouse looks scared, as if it can sense your intentions."
    scene bg mouse1c
    pause .075
    scene bg mouse1d
    pause .075
    scene bg mouse1c
    pause .075
    scene bg mouse1e
    pause .075
    scene bg mouse1c
    pause .075
    scene bg mouse1d
    pause .075
    scene bg mouse1c
    pause .075
    scene bg mouse1e
    pause .075
    scene bg mouse1c
    pause .075
    "It weakly starts to struggle again."
    scene bg mouse1b
    play sound "audio/mouseScared.mp3"
    rat "{size=+10}SQUEAK! SQUEAK! {b}SQUEEEAAK!!{/b}{/size}" with hpunch
    ".."
    "..."
    "{size=-10}The mouse is reluctant.{/size}"
    $ feedMouseCounter += 1
    jump spareFeedMouse

label feedCatMouse2:
    show screen blackOut
    with dissolve
    scene bg alley1
    ".."
    "..."
    "You feed the mouse to the cat."
    hide screen blackOut
    with dissolve
    play sound "audio/cat_happy.mp3" volume 0.8
    cat "Meowww!" with hpunch
    "The cat tears it apart instantly..."
    scene bg alley1
    with p_Red
    play sound "audio/mouseScared.mp3"
    rat "SQUEAK!" with hpunch
    play sound "audio/mousePanic.mp3"
    rat "SQUEAK! {b}SQUEEEAAK!!{/b}" with hpunch
    play sound "audio/mousePanic.mp3" volume 1.25
    rat "SQUE-{w=0.175}{nw}" with hpunch
    stop sound
    scene bg redScreen
    play sound "audio/squelchLOOP.mp3" volume 0.8
    show screen bloody
    with vpunch
    pause .5
    stop sound fadeout 0.5
    scene black
    play sound "audio/cat_eating.mp3" volume 0.5
    hide screen bloody
    with dissolve
    "..."
    "The mouse's pained squeaks and squeals pierce through you until they're abruptly cut off."
    scene bg alley1
    with dissolve
    "Satisfied, the cat mewls happily at you, red tinting its fangs."
    play sound "audio/cat_happy.mp3" volume 0.8
    cat "Meoww!"
    you "..."
    "The cat curls up in its now blood-stained box and goes to sleep."
    you "..."
    scene bg alley2
    with dissolve
    "You take the chance to leave."
    "A well-fed cat will likely follow you home, after all..."
    "...and cute as the cat is, you..."
    "..."
    "...you really can’t afford a pet right now."
    scene bg street1
    with dissolve
    "Still feeling a little guilty about the mouse, you decide to just go home."
    scene bg street2
    with dissolve
    you "..."
    scene bg street3
    with dissolve
    "..."
    scene bg street4
    with dissolve
    you "..."
    scene bg street5
    with dissolve
    "..."
    scene bg aptFront
    with dissolve
    pause .6
    scene bg aptDoor
    with dissolve
    pause .6
    scene black
    with dissolve
    you "..."
    play music "audio/LOOPS/04homeWithYou.mp3" loop
    scene bg aptLivingRoom
    with dissolve
    "After a long walk home, you finally enter your apartment..."
    scene bg aptHall
    with dissolve
    "You head straight for your room..."
    scene bg aptBedroom
    with dissolve
    pause .6
    stop music fadeout 1
    scene black
    with dissolve
    "...and collapse on your bed, falling into a fitful sleep."
    ".."
    "..."
    "Later..."
    "You wake up..."
    scene bg mouse3a
    with dissolve
    play sound "audio/cut.mp3" volume 0.2
    queue sound "audio/cut.mp3" volume 0.2
    "{size=-5}*scritch* *scritch*{/size}"
    play sound "audio/mouseInfestation.mp3"
    who "{size=-5}squeak squeak squeak...{/size}"
    "...to squeaking and scurrying noises {b}all{/b} around you..."
    "...so loud and constant, they sound like {i}screams.{/i}"
    "In the darkness of your room..."
    "..."
    scene bg mouse3b
    with dissolve
    play music "audio/heartbeat.mp3"
    "...you see the shifting shadows of {b}{i}hundreds{/i}{/b} of mice surrounding your bed."
    you "!!!"
    "You try to run..."
    play sound "audio/humanImpact.mp3" volume 0.7
    scene bg mouse3b
    with p_Red
    you "!!!" with vpunch
    you "AHH!" with vpunch
    "But you cry out as twin lances of pain race up your legs."
    "You fall off the bed in your attempt to escape..."
    "...the hoards of mice dodging you as you crash to the ground."
    "You..."
    "..."
    "{size=-8}You can't stand up.{/size}"
    "Looking back and squinting in the dark, {w}you just about make out the source of your pain..."
    play music "audio/heartbeatEcho.mp3"
    show mouse4
    with dissolve
    "The flesh and tendons of your heels and ankles are mangled..."
    "{b}Bitten{/b} through your socks..."
    you "N-No... No! L-Leave me alone..!" with hpunch
    stop music fadeout 2.5
    "Desperate, you crawl with only your arms towards the door..."
    scene black
    with dissolve
    ".."
    "..."
    play music "audio/LOOPS/37tinierPawsLOOP.mp3" loop
    "The mice descend upon you..."
    play sound "audio/cut.mp3" volume 1
    queue sound "audio/cat_eating.mp3" volume 0.2
    scene bg mouse5a
    with p_Red
    pause .03
    scene black
    with dissolve
    you "!!!" with vpunch
    "...biting into your skin."
    play sound "audio/cut.mp3" volume 1
    queue sound "audio/cat_eating.mp3" volume 0.2
    scene bg mouse5a
    with p_Red
    pause .03
    scene black
    with dissolve
    you "!!!" with vpunch
    "Gnawing away {b}pieces{/b} of you..."
    play sound "audio/cut.mp3" volume 1
    queue sound "audio/cat_eating.mp3" volume 0.2
    scene bg mouse5a
    with p_Red
    pause .03
    scene black
    with dissolve
    you "..."
    "You start to fade in and out of consciousness..."
    "...but you still reach up for the doorknob..."
    scene bg mouse5b
    with dissolve
    "...your arm heavy, weighed down by the mice clinging to it with little claws and tiny teeth."
    "You manage to jostle the knob enough for the door to slowly swing open..."
    play sound "audio/cut.mp3" volume 1
    queue sound "audio/cut.mp3" volume 1
    queue sound "audio/cut.mp3" volume 1
    scene bg redScreen
    play sound "audio/gooeySquish.mp3"
    show screen bloody
    with vpunch
    scene black
    hide screen bloody
    with dissolve
    pause .6
    play sound "audio/humanImpact.mp3"
    scene black
    with p_Red
    "*PLOP!*" with hpunch
    "..."
    show mouse6
    with fade_Red
    "...But your outstretched arm suddenly falls to the ground, lifeless."
    you "!!!"
    "The mice managed to chew through the flesh and bone of your now dismembered limb."
    "As a few mice creep forward to curiously inspect your arm, you stare blankly at it for a moment before sliding your gaze up."
    scene bg mouse7a
    with dissolve
    "In the newly opened doorway, sits a familiar looking..."
    "..?"
    "...mouse?"
    "It stares at you."
    "The darkness in its beady, black eyes... {w}You can’t begin to measure their depths..."
    $ renpy.music.set_volume(0.0, 0, "music")
    play sound "audio/violinSting.mp3" volume 0.8
    scene bg mouse7b
    with vpunch
    pause 1.5
    show screen dread
    with fade_Red
    play sound "audio/heartbeatEcho.mp3" loop
    "..."
    "Nor the hatred pouring out from within them..."
    scene bg mouse7c
    with dissolve
    "All of it..."
    scene bg mouse7d
    with dissolve
    "...aimed at {b}you.{/b}"
    stop sound
    $ renpy.music.set_volume(1.0, 0, "music")
    scene black
    play sound "audio/humanImpact.mp3"
    hide screen dread
    with p_Red
    you "A-Ah..."
    "You collapse, head hitting the floor as your other arm is eaten away as well."
    "You’re not sure how you’re still conscious. The pain should be indescribable..."
    "And yet... you just feel a cold sense of loss..."
    "The mice have clustered along your back now..."
    "...gnawing and ripping their way between your shoulder blades..."
    "Into your back... Into your {i}chest--{/i}"
    scene bg redScreen
    play sound "audio/squelchLOOP.mp3"
    show screen bloody
    with vpunch
    stop sound fadeout 1
    you "!!!" with hpunch
    you "*cough*! *cough*!.." with hpunch
    scene black
    hide screen bloody
    with dissolve
    "...You weakly cough up blood. They must have damaged something important..."
    "You feel something being {i}pulled out of you...{/i}"
    "And in between the moments that blankets of darkness fade out your vision..."
    play sound "audio/gooeySquish.mp3" volume 0.5
    "{size=-8}*splat*{/size}"
    "...you hear something wet plop on the ground in front of you."
    "You pry your eyes open and see {i}it{/i} in front of the mouse..."
    scene bg mouse8a
    with dissolve
    "Weirdly shaped, red with your blood and {b}pulsing{/b} and..."
    "Oh, that’s..."
    "That’s your heart... {w}isn’t it..?"
    play sound "audio/cat_eating.mp3" volume 0.5
    show mouse8
    with dissolve
    "The other mice all descend upon it, abandoning your half-eaten body."
    show screen blackOut
    with dissolve
    stop music fadeout 4
    "You’re... losing a lot of blood."
    "You feel sleepy... {w}But..."
    "You... also feel..."
    play sound "audio/heartbeat.mp3" loop
    "..?"
    "Anger?"
    "...{b}Yes.{/b}"
    "So... {i}so{/i} much anger."
    "How dare they..?"
    "..."
    "{size=-6}How {b}dare{/b} they..?{/size}"
    stop sound fadeout 2.5
    hide screen blackOut
    with dissolve
    "The last thing you see before your vision fails you..."
    show mouse9
    with dissolve
    show static
    with dissolve
    "...is a pair of glowing eyes leering in from the darkness beyond the doorway."
    play sound "audio/swishQUICK.mp3" volume 0.4
    queue sound "audio/splat.mp3" volume 0.4
    scene black
    with p_Red
    play sound "audio/cat_angryQUICK.mp3" volume 0.4
    queue sound "audio/mouseScared.mp3" volume 0.4
    pause 1
    play sound "audio/swishQUICK.mp3" volume 0.4
    queue sound "audio/splat.mp3" volume 0.4
    pause .5
    play sound "audio/mousePanic.mp3" volume 0.4
    pause .2
    play sound "audio/swishQUICK.mp3" volume 0.4
    queue sound "audio/splat.mp3" volume 0.4
    "You can hear squeaks and shrieks of terror all around you..."
    play sound "audio/cat_angry.mp3" volume 0.4
    queue sound "audio/squelchLOOP.mp3"
    pause 1.5
    play sound "audio/mouseScared.mp3"
    queue sound "audio/splat.mp3" volume 0.4
    "Low yowls... {w}deep snarls... {w}{i}gnashing teeth...{/i} {w}{b}tearing flesh...{/b}"
    "As your remaining senses leave you..."
    "...you smile weakly with the last of your strength..."
    "...when something with soft, slightly damp and sticky fur nuzzles your cheek."
    play sound "audio/cat_purr.mp3" volume 0.4
    who "Purr..."
    ".."
    "..."
    you "{i}Good kitty.{/i}"
    "..."
    "Ending 27: Well-Fed"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending27Done:
        jump endAlley
    else:
        $persistent.ending27Done = True
        $persistent.endCounter += 1
        jump endAlley


label feedBlood:
    scene bg upSad
    with dissolve
    pause .3
    scene bg upSadMeow
    with dissolve
    play sound "audio/cat_sad.mp3" volume 0.2
    cat "Meowww..."
    scene bg upSad
    "The cat lets out a sad, pleading little sound."
    "It's hungry."
    "It must be starving."
    "So..."
    "You..."
    you "..."
    scene bg blood1
    with dissolve
    "You look around and see a nearby shard of glass..."
    "Your body moves as if it knows what to do... {w}What {i}needs{/i} to be done..."
    scene bg blood2a
    with dissolve
    "You take the shard and..."
    "..."
    stop music
    scene bg blood2b
    pause .1
    scene bg blood2c
    play sound "audio/cut.mp3"
    queue sound "audio/squelchLOOP.mp3" volume 0.3
    scene black
    with p_Red
    stop sound fadeout 0.5
    "..?!" with hpunch
    scene bg blood3a
    with dissolve
    "Wh-"
    "{b}{i}Why would you—{/i}{/b}"
    "..."
    show screen blackOut
    "{size=-8}Why would you {b}do{/b} that?{/size}"
    hide screen blackOut
    pause 1.5
    play music "audio/heartbeatEcho.mp3" loop
    scene bg blood3b
    with fadeToRed
    pause 3
    scene black
    with dissolve
    pause 3
    scene bg blood4a
    with dissolve
    "You carefully hold your finger over the cat."
    "Dark red blood beads at the wound..."
    scene bg blood4b
    with dissolve
    pause 2
    scene bg blood4c
    pause .1
    scene bg blood4d
    pause .1
    scene bg blood4e
    pause .1
    scene bg blood4f
    pause .1
    scene bg blood4g
    pause .1
    scene bg blood4h
    pause .1
    scene bg blood4b
    pause .1
    stop music fadeout 4
    "...before growing heavy enough to drip into the cat’s open, waiting jaws."
    scene bg blood4i
    with dissolve
    "It mewls happily at you."
    play sound "audio/cat_happyLONG.mp3" volume 0.4
    cat "Meowww!"
    "You smile warmly and lower your hand into the box..."
    "...stroking the cat’s cheek before letting it lap gently at your bleeding finger."
    "When the flow gets weak and the cat meows for more, you squeeze below the wound, coaxing more blood out."
    scene bg alley1
    with dissolve
    "You feel a strange, but welcome sense of comfort from the odd exchange."
    "A being other than yourself was hungry..."
    "...and {i}you{/i} were able to provide it sustenance."
    "A small wrong in the world made right... {w}even if so strangely done and only temporarily."
    scene bg blood5a
    with dissolve
    "Ironically, it’s at that moment that you start to feel... dizzy..."
    "You didn’t think you were losing that much blood..."
    show screen dread
    with dissolve
    "You slump against the cat’s box and listen to it mewl in distress."
    play sound "audio/cat_sadLONG.mp3" volume 0.4
    cat "Mreow! Mreowww!" with hpunch
    "You think it sounds worried about you. Or at least you'd {i}like{/i} to think so."
    "It {i}could{/i} just want more blood as well."
    "The cat hops out of the box and into your lap, nuzzling at your stomach and meowing unhappily."
    "You wish you could ease its concerns, but it’s not like you can just talk to each other."
    "You can’t help but try to remember the last time you talked to {i}anyone{/i}, actually..."
    show screen blackOut
    with dissolve
    "If you were to die here and now in this alley..."
    "...how long would it take for someone to realize you were missing?"
    hide screen dread
    "That you were {b}{i}gone{/i}{/b}..?"
    scene bg alley1
    "..."
    play sound "audio/cat_angryQUICK.mp3" volume 0.7
    cat "{size=+10}Mreow!!{/size}" with hpunch
    hide screen blackOut
    with vpunch
    you "!!"
    "Your thoughts are interrupted when the cat yowls loudly, tensing up in your lap."
    "You don’t have time to wonder why as a voice rings out from the entryway to the alley."
    who "Hello..?"
    scene bg alley2
    with dissolve
    pause .6
    scene bg blood5b
    with dissolve
    who "Hey, you! Are you... alright?"
    "You don’t answer. You don't think you {i}can.{/i}"
    "Your voice feels locked away... deep, deep within you."
    "The cat looks up at you with a long stare... {w}as if assessing you."
    "It looks back towards the voice and with a final nuzzle to your stomach..."
    play music "audio/LOOPS/11irritationIN.mp3"
    queue music "audio/LOOPS/11irritationLOOP.mp3" loop
    scene bg blood5c
    with dissolve
    "...it hops out of your lap, walking towards the alley's entrance..."
    "But then..."
    scene bg blood5d
    with dissolve
    "...it starts to {b}shift{/b}... as—{w=0.5}{nw}"
    play sound "audio/punch_HIGH.mp3" volume 0.3
    scene bg blood5e
    with vpunch
    "Crack!" with vpunch
    you "..?"
    play sound "audio/punch_HIGH.mp3" volume 0.5
    scene bg blood5f
    with vpunch
    pause .2
    play sound "audio/punch_HIGH.mp3" volume 0.6
    scene bg blood5g
    with vpunch
    pause .2
    you "!!!"
    "Its face... {i}opens up{/i}..."
    play sound "audio/punch_HIGH.mp3" volume 0.8
    scene bg blood5h
    with vpunch
    "{size=+15}{b}CRACK!!{/b}{/size}" with vpunch
    "It peels back."
    play sound "audio/punch_HIGH.mp3" volume 0.9
    scene bg blood5i
    with vpunch
    pause .2
    play sound "audio/punch_HIGH.mp3"
    scene bg blood5j
    with vpunch
    pause .2
    "...and opens {i}again{/i}..."
    play sound "audio/squelchLOOP.mp3"
    scene bg blood5k
    with dissolve
    pause .6
    stop sound fadeout 0.5
    "...writhing tendrils peeking out from where you think its mouth should be."
    scene bg blood5l
    with dissolve
    "The stranger’s silhouette freezes in the light beyond the alley..."
    who "W-What the hell is-?"
    "But they don’t have the chance to finish their question."
    play sound "audio/squelchLOOP.mp3" volume 0.7
    scene bg blood5m
    with dissolve
    pause .2
    scene bg blood5n
    with dissolve
    pause .2
    play sound "audio/gooeySquish.mp3" volume 0.4
    scene bg blood5o
    pause .2
    "The tendrils converge into one..."
    scene bg blood5l
    with dissolve
    "...before shooting out of the cat’s jaws-"
    play sound "audio/swishQUICK.mp3" volume 0.4
    scene bg blood5p
    pause .2
    play sound "audio/swishQUICK.mp3" volume 0.4
    scene bg blood5q
    pause .2
    play sound "audio/swishQUICK_low.mp3" volume 0.4
    scene bg blood5r
    pause .2
    play sound "audio/gooeySquish.mp3" volume 0.4
    scene bg blood5s
    pause .05
    play sound "audio/punch_MEDIUM.mp3" volume 0.9
    show screen bloody
    scene bg blood5t
    with hpunch
    pause .2
    "...and {i}{b}piercing{/b}{/i} into the stranger’s shoulder."
    who "{size=+10}GAH!!{/size}" with vpunch
    who "{size=+10}{i}A-AAAHHHHH!{/i}{/size}" with vpunch
    play music "audio/LOOPS/11irritationOUT.mp3" noloop
    "They let a out a pained cry... a fearful yell."
    "They claw at the tendrils, trying to pull them loose... {w}but to no avail."
    "You... {w}can’t seem to process their screams."
    scene bg blood5u
    hide screen bloody
    with dissolve
    "You stare at the creature before you..."
    "So different from the cat who mewled out of concern for you earlier..."

    menu:
        "Stop the cat.":
            jump blood_stopCat
        "Let cat feed.":
            jump blood_letCatFeed

label blood_stopCat:
    scene black
    with dissolve
    "You can't..."
    "You can't let this happen.."
    you "..."
    play music "audio/LOOPS/38selfishSacrificeIN.mp3"
    queue music "audio/LOOPS/38selfishSacrificeLOOP.mp3" loop
    "You shakily crawl forward..."
    scene bg blood6a
    with dissolve
    pause .4
    scene bg blood6b
    with dissolve
    "...and weakly grab at the conjoined tendrils that pulse as they drain the stranger’s blood."
    "When you tug as firmly as you’re able, the tendrils' pulsing halts... and the cat turns to you."
    play sound "audio/cat_trilling.mp3" volume 0.6
    cat "Plrr? Pllrrr?"
    "It makes a strange trilling noise that sounds like a question..."
    "But you have no answer."
    "You can't even understand the question..."
    "So you simply scoop up the creature... {w}the {i}cat{/i}... {w}cradling it in your arms."
    scene bg alley2
    with dissolve
    pause .5
    "You gaze almost longingly at the light beyond the alley's entrance."
    "You don’t know what’s going on..."
    "...but you just can’t sit by and watch someone else be eaten so viciously..."
    "Not when they’d tried to see if you were okay..."
    "..."
    show screen blackOut
    "...Not when you could offer yourself instead."
    hide screen blackOut
    scene bg alley2
    with dissolve
    "You think the stranger is set free..."
    "...because after the sound of shoes hastily scuffing on the pavement fades into the distance..."
    play sound "audio/gooeySquish.mp3" volume 0.4
    scene bg redScreen
    with p_Red
    pause .4
    show screen blackOut
    with dissolve
    you "Nn!" with vpunch
    "...you feel something sharp pierce your back."
    "It feels thin... {w}almost like a needle... {w}so the pain passes quickly as your body adjusts to the intrusion."
    "You're sure it wasn't so thin when it skewered through the stranger's shoulder earlier..."
    scene bg alley2
    play sound "audio/heartbeat.mp3"
    hide screen blackOut
    with p_Red
    "...but as you feel your blood leave your body, slowly as if being pumped out..."
    "...it gets harder to think and your vision starts to fail you."
    show screen blackOut
    with dissolve
    scene black
    play sound "audio/cat_trilling.mp3" volume 0.4
    "The creature in your arms makes a soft sound."
    hide screen blackOut
    "You hold it as tightly and closely to you as your weak arms can manage."
    play sound "audio/heartbeat.mp3"
    scene black
    with p_Red
    "..."
    "This is fine... {w}You’re okay with this..."
    "You don’t know if this will change anything..."
    "Surely the cat will get hungry again at some point after you’re gone and..."
    "...{i}no longer an {b}option{/b}{/i}..."
    play sound "audio/heartbeat.mp3"
    scene black
    with p_Red
    play music "audio/LOOPS/38selfishSacrificeOUT.mp3" noloop
    "..."
    "But..."
    "At least {i}this{/i} time..."
    play sound "audio/heartbeat.mp3"
    scene black
    with p_Red
    "...you were able... {w}to save someone."
    ".."
    "..."
    "Ending 28: Personal care package"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending28Done:
        jump endAlley
    else:
        $persistent.ending28Done = True
        $persistent.endCounter += 1
        jump endAlley



label blood_letCatFeed:
    play sound "audio/squelchLOOP.mp3" volume 0.7
    scene bg blood7a
    with p_Red
    stop sound fadeout 1
    who "AAAHH!" with hpunch
    play sound "audio/squelchLOOP.mp3" volume 0.7
    scene bg blood7b
    with dissolve
    stop sound fadeout 1
    who "Someone! Help me! Help!" with vpunch
    play sound "audio/squelchLOOP.mp3" volume 0.7
    scene bg blood7c
    with dissolve
    pause .2
    scene bg blood7d
    with dissolve
    stop sound fadeout 1
    who "*gurgle* Hel..p... ..."
    play sound "audio/squelchLOOP.mp3" volume 0.7
    scene bg blood7e
    with dissolve
    stop sound fadeout 0.5
    you "..."
    "You look away as the creature devours the stranger..."
    play sound "audio/gooeySquish.mp3" volume 0.5
    scene bg blood7f
    with dissolve
    pause .3
    play sound "audio/tvStatic.mp3" loop
    show static
    with dissolve
    "...draining them until they’re nothing but a husk of bone, skin and clothes heaped on the floor."
    "..."
    "You feel awful but..."
    "What could you do?"
    "The creature is also a living thing..."
    "Shouldn’t it be allowed to eat what it needs to?"
    "Does it not also have a right to do what it must to survive?"
    "..."
    "You ignore the voice in the back of your head that questions if there could’ve been another way."
    "It’s not like you tried to see if it could eat anything other blood... {w}{i}Human blood{/i}..."
    stop sound
    show screen blackOut
    "{size=-10}{b}...now {i}did{/i} you?{/b}{/size}"
    hide static
    scene bg blood7e
    hide screen blackOut
    you "..."
    scene bg alley2
    with dissolve
    play sound "audio/cat_purr.mp3" volume 0.7
    "The creature purrs as it rubs its side into your arm."
    "You realize that after a bit of rest, you’ve already started feeling better."
    "..."
    "But..."
    show screen dread
    with dissolve
    "You also think..."
    "...that something inside you..."
    "{size=-8}...feels a little bit broken too.{/size}"
    play music "audio/LOOPS/39hungerIN.mp3"
    queue music "audio/LOOPS/39hungerLOOP.mp3" loop
    "..."
    "You're just not quite sure what it is yet."
    ".."
    "..."
    "You stand and hold out your arms."
    you "Still hungry?"
    play sound "audio/cat_trilling.mp3" volume 0.7
    cat "Pllrrrrrrp!" with hpunch
    "The creature trills happily and hops into your outstretched arms."
    you "..."
    you "...Let's go then, yeah?"
    play sound "audio/cat_trilling.mp3" volume 0.2
    cat "Plrrrr..."
    "..."
    "You leave the alley together."
    show screen blackOut
    with dissolve
    hide screen dread
    "You go out into the world {i}together.{/i}"
    "..."
    "The cat is hungry..."
    "...and it will be hungry often from now on."
    "{i}Very{/i} often."
    play music "audio/LOOPS/39hungerOUT.mp3" noloop
    "..."
    play sound "audio/crowdScream.mp3"
    scene bg blood8
    show static
    hide screen blackOut
    with dissolve
    "Screams of fear and terror follow you both wherever you go..."
    "And without thought or care or concern for any of it..."
    "You just stand back..."
    stop sound
    show screen blackOut
    "{size=-8}...and \ {b}w a t c h{/b}.{/size}"
    ".."
    "..."
    "Ending 29: All You Can Eat Blood-fey"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending29Done:
        jump endAlley
    else:
        $persistent.ending29Done = True
        $persistent.endCounter += 1
        jump endAlley



label playAlley:
    scene bg upMeow
    with hpunch
    play sound "audio/cat_happyLONG.mp3" volume 0.5
    cat "Meow! Meowww!"
    you "Awww... You just want a little attention, don't you~?"
    scene bg upBlinkSmile
    play sound "audio/cat_purr.mp3" volume 0.5
    cat "Purr..."
    "The poor thing must be bored sitting in that box all day."
    "You're not sure you're much of an interesting companion, but you're willing to do your best."
    "There's got to be something you can entertain the little critter with..."
    scene bg alleyCat2
    "But what?"

label alley_playMenu:

    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/03catTheme.mp3" loop

    menu:
        "Check pockets.":
            jump play_pockets
        "Look around the area.":
            jump play_lookAround
        "Buy a toy":
            jump play_buyToy

label play_pockets:
    "You dig into your pockets."
    show screen stringPanel
    with dissolve
    "You find a small piece of string in your left pocket. Not very helpful."
    "The string is far too short."
    if persistent.ending11Done:
        "An eager and excited cat leaping for it could easily lead to you getting{w=1.0}{nw}"
        $ renpy.music.set_volume(0.0, 0, "music")
        hide screen stringPanel
        play sound "audio/glitch.mp3"
        queue sound "audio/tvStatic.mp3"
        show yarnJumpscare
        with vpunch
        pause .3
        stop sound
        pause .75
        hide yarnJumpscare
        you "!!!" with hpunch
        ".."
        "..."
        $ renpy.music.set_volume(1.0, 0, "music")
    else:
        "An eager and excited cat leaping for it could easily lead to you getting bitten and scratched."
        hide screen stringPanel
        with dissolve
    "In your right pocket..."
    show screen chocolatePanel
    with dissolve
    if persistent.ending24Done or persistent.ending25Done:
        $ renpy.music.set_volume(0.0, 0, "music")
        "{size=-10}...is a bar of {color=#FF0000}chocolate.{/color}{/size}"
        show screen blackOut
        "{size=-5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sorry {w=0.5}i'm sor {/size}{w=0.2}{nw}"
        $ renpy.music.set_volume(1.0, 0, "music")
        hide screen blackOut
        you "..."
    else:
        "...is a bar of chocolate."
    "Not too helpful either right now."
    hide screen chocolatePanel
    with dissolve
    pause .6
    scene bg phone1a
    with dissolve
    "The only other thing you’ve got on you is your phone."
    "..."
    "It's not much of anything the cat can play with but..."
    scene bg phone1b
    with dissolve
    "There {i}is{/i} something {i}you{/i} can do..."
    play sound "audio/camera.mp3"
    scene bg phone1c
    with whiteFlash
    pause .8
    play sound "audio/camera.mp3"
    scene bg phone1d
    with whiteFlash
    pause .8
    play sound "audio/camera.mp3"
    scene bg phone1e
    with whiteFlash
    "{size=+15}{b}{i}Photo montage~!!!{/i}{/b}{/size}" with hpunch
    scene bg alleyCat2
    "..."
    you "Well, that was fun, right?"
    stop music fadeout 5
    cat "..."
    you "..."
    "Well {i}you{/i} enjoyed yourself..."
    "With nothing else to do and no intention of taking the cat home..."
    "...you decide it's probably best to just leave."
    "You don't want the cat to get too attached after all."
    "At least you'll have some memories to take with you."
    you "Okay, um... See you around, I guess. Good luck?"
    cat "..."
    you "...Okay."
    scene bg alley1
    with dissolve
    "You turn and walk away, but as you leave the alley-{w=1.2}{nw}"
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    you "Hm?"
    "Your phone just got a message."
    "You open it up and..."
    "..."
    "..?"
    you "What..?"
    play sound "audio/notification.mp3"
    scene bg phone2a
    pause .5
    play sound "audio/notificationQUICK.mp3"
    scene bg phone2b
    pause .5
    phoneText "{b}--aren't i cutte??--{/b}"
    "It's a picture of a familiar looking cat..."
    you "Huh?"
    "The cat {i}does{/i} look cute..."
    "And happier in the picture..."
    "..."
    "...but it's {b}not{/b} a picture you recognize."
    you "What the heck..? D-Did I..?"
    "{size=-10}you didn't take this picture.{/size}"
    "You peek over your shoulder at the cat..."
    scene bg alleyCat2
    with dissolve
    "..."
    "...but the cat is simply looking at you."
    scene bg upSad
    with dissolve
    pause .3
    scene bg upSadMeow
    with dissolve
    play sound "audio/cat_sad.mp3" volume 0.5
    cat "Meowww..."
    scene bg upSad
    "It mewls sadly, as if pleading you to come back."

    menu:
        "Hang out and do something else?":
            you "..."
            you "Well... I guess I could stay a little longer..."
            scene bg upHappy
            with dissolve
            pause .2
            scene bg upBlinkMeow
            play sound "audio/cat_happy.mp3" volume 0.5
            cat "Meoww!" with hpunch
            scene bg upHappy
            you "But now what to do.."
            scene bg alleyCat2
            play sound "audio/cat_confused.mp3" volume 0.3
            cat "Meow?"
            jump inAlley_start
        "Get out of the alley.":
            jump phoneHome

label phoneHome:
    you "..."
    "You ignore the cat and briskly walk out of the alley without another look."
    scene black
    with wiperight
    pause 1
    scene bg street1
    with dissolve
    you "Phew..."
    you "That was weird..."
    "You're a good distance away when-"
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    you "..! Not again..."
    "You reluctantly look at the new message and..."
    play sound "audio/notification.mp3"
    scene bg phone3a
    pause .5
    play sound "audio/notificationQUICK.mp3"
    scene bg phone3b
    pause .5
    phoneText "{b}--dont ignore meeee ;_;--{/b}"
    ".."
    "..."
    "Creeped out... you decide to just go home."
    scene bg street2
    with wiperight
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    play sound "audio/notification.mp3"
    scene bg phone4a
    pause .5
    phoneText "{b}--i know youre seeing these--{/b}"
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    play sound "audio/notification.mp3"
    scene bg phone4b
    pause .5
    phoneText "{b}--come back--{/b}"
    scene bg street2
    you "..."
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    play sound "audio/notification.mp3"
    scene bg phone4b
    pause .5
    play sound "audio/notificationQUICK.mp3"
    scene bg phone4c
    pause .5
    phoneText "{b}--come back--{/b}"
    scene bg street3
    with wipeleft
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    play sound "audio/notification.mp3"
    scene bg phone5a
    pause .5
    play sound "audio/notificationQUICK.mp3"
    scene bg phone5b
    pause .5
    phoneText "{b}--come back--{/b}"
    scene bg street4
    with wipeup
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    play sound "audio/notification.mp3"
    scene bg phone6a
    pause .5
    play sound "audio/notificationQUICK.mp3"
    scene bg phone6b
    pause .5
    phoneText "{b}--come back--{/b}"
    scene bg street5
    with wiperight
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    play sound "audio/notification.mp3"
    scene bg phone7a
    pause .5
    phoneText "{b}--come back--{/b}"
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*!" with hpunch
    play sound "audio/phoneVibrate.mp3"
    "*BZZT*! *BZZT*!" with hpunch
    play sound "audio/notification.mp3"
    scene bg phone7b
    pause .5
    phoneText "{b}--come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back come back--{/b}"
    you "..."
    play sound "audio/notification.mp3"
    scene bg phone7c
    pause .1
    play sound "audio/notificationQUICK.mp3"
    scene bg phone7d
    pause .1
    play sound "audio/glitch.mp3"
    scene bg phone7e
    pause .075
    show screen blackOut
    scene black
    pause 3
    play sound "audio/phoneVibrate.mp3" volume 0.4
    "{size=-8}*bzzt*...{/size}"
    hide screen blackOut
    play sound "audio/notificationSLOW.mp3"
    scene bg phone8a
    pause .5
    phoneText "{b}--can see you--{/b}"
    play sound "audio/phoneVibrate.mp3" volume 0.4
    "{size=-8}*bzzt*...{/size}"
    play sound "audio/notificationSLOW.mp3"
    scene bg phone8b
    pause .5
    phoneText "{b}--can ALWAYS see you--{/b}"
    play sound "audio/notificationSLOW.mp3"
    scene bg phone8c
    pause .5
    phoneText "{b}--YOU CANT HIDE--{/b}"
    play sound "audio/notificationSLOW.mp3"
    scene bg phone8d
    pause .5
    phoneText "{b}--i'll always find uuuuu OwO--{/b}"
    scene black
    pause 1
    you "..."
    "Your eyes dart around nervously... {i}certain{/i} that you're being followed."
    ".."
    "..."
    "{size=-8}But there's nothing there.{/size}"
    play music "audio/heartbeat.mp3" loop
    scene bg street5
    with dissolve
    you "..."
    scene black
    with wiperight
    pause 1
    ".."
    "..."
    scene bg aptLivingRoom
    with dissolve
    "You're finally home, but you feel too shaken for any relief to calm you down."
    scene bg aptHall
    with wiperight
    "You rush to the bathroom and slam the door behind you."
    play sound "audio/doorClose.mp3"
    show screen blackOut
    scene bg aptBath_DC
    pause 2
    you "Everything's okay..."
    hide screen blackOut
    with dissolve
    you "This isn't real..."
    scene bg cabinetDark
    with dissolve
    "It's just like a bad dream..."
    "Everything's... okay..."
    "..."
    "You fumble in the dark to turn on the sink and splash your face with some cold water..."
    "...hoping it will calm your mind... {w}and stop the hallucinations."
    "{size=-5}Because that's all they are, right?{/size}"
    "{size=-8}...Hallucinations?{/size}"
    "..."
    "You’re really regretting leaving home today."
    "You must have been overworking yourself more than you realized..."
    "Yeah... That must be-"
    stop music
    play sound "audio/phoneVibrate.mp3"
    "{b}*BZZT*!{/b}" with hpunch
    you "!!!" with vpunch
    scene bg phone9a
    pause .3
    scene bg phone9b
    pause .6
    play sound "audio/notificationSLOW.mp3"
    scene bg phone9c
    pause .1
    scene bg phone9d
    pause .1
    scene bg phone9e
    pause .1
    scene bg phone9f
    pause .5
    "You jump as your phone alerts you to yet another message received."
    you "..."

    menu:
        "Check phone...":
            jump checkPhone
        "Ignore phone...":
            jump ignorePhone

label checkPhone:
    scene bg cabinetDark
    with dissolve
    "With shaking hands, you look at your phone..."
    play sound "audio/notificationSLOW.mp3"
    scene bg phone9g
    phoneText "{b}--hI FRienD--{/b}"
    play sound "audio/notificationSLOW_noise.mp3"
    scene bg phone9h
    pause 1.5
    you "!!!" with vpunch
    play sound "audio/punch_HIGH.mp3"
    queue sound "audio/crash.mp3" volume 0.8
    scene bg phone10a
    with p_Red
    #play sound "audio/crash.mp3" volume 0.8
    show screen blank
    with vpunch
    pause .5
    you "Wh... What...?"
    play music "audio/LOOPS/40curiosityIN.mp3"
    queue music "audio/LOOPS/40curiosityLOOP.mp3" loop
    show screen blackOut
    hide screen blank
    "Startled, you whirl around and instinctively jump back..."
    "..."
    "You..."
    "You {i}slip...{/i}"
    scene bg phone11a
    hide screen blackOut
    with dissolve
    "...smashing the back of your head into the bathroom mirror."
    "You don't register the pain just yet, your eyes shifting wildly around the room."
    show screen blackOut
    with dissolve
    ".."
    "..."
    "There’s..."
    "There’s nothing there."
    "Nothing at all..."
    hide screen blackOut
    with dissolve
    play music "audio/LOOPS/40curiosityOUT.mp3" noloop
    "..."
    "...You feel dizzy."
    "You dazedly feel the back of your head and examine your hand."
    ".."
    "..."
    "You can't really see anything..."
    "..."
    "But it feels warm..."
    "...and {i}wet.{/i}"
    scene bg phone11b
    with dissolve
    "The smell of copper fills the air..."
    "The dizziness overwhelms you and you collapse on the bathroom tiles."
    scene black
    with dissolve
    you "Hel..p..."
    "You reach for your phone to call an ambulance..."
    ".."
    "..."
    "...The batteries are dead."
    ".."
    "..."
    "Ending 30: Photo bomber"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending30Done:
        jump endAlley
    else:
        $persistent.ending30Done = True
        $persistent.endCounter += 1
        jump endAlley


label ignorePhone:
    play sound "audio/phoneVibrate.mp3"
    "{b}*BZZT*!{/b}" with hpunch
    play sound "audio/phoneVibrate.mp3"
    queue sound "audio/phoneVibrate.mp3"
    "{b}*BZZT*! *BZZT*! *BZZT*! {/b}" with hpunch
    play sound "audio/phoneVibrate.mp3" loop
    "{size=+20}{b}*BZZT*!{/b}{/size}" with hpunch
    "The phone vibrates insistently over and over..."
    "..."
    play music "audio/LOOPS/41leftOnReadLOOP.mp3"
    "...but you just can’t look."
    scene black
    with dissolve
    "You keep your eyes squeezed shut. Your fingers tightly grip the sink."
    "In your mind, you beg whoever... or {i}whatever{/i} is doing this to just stop already..."
    "Please... Please..."
    you "Please... Just put me out of my misery..."
    "You mutter this quietly. You don’t... {i}really{/i} mean it."
    "You {i}don't.{/i}"
    "..."
    "But as the words take shape in the darkest corners of your mind..."
    stop sound
    "...the phone {i}immediately{/i} stops vibrating."
    "You’d think that this would give you relief..."
    "..."
    "...but you only feel dread sinking heavily into your stomach."
    "You can feel eyes on you..."
    play sound "audio/beastBreath.mp3" volume 0.5
    "You can feel puffs of air on the back of your neck... {w}damp and deep and {b}slow{/b}..."
    "You take a deep breath and open your eyes..."
    "You look..."
    "...at the mirror."
    ".."
    "..."
    scene bg cabinetDark
    with dissolve
    "...Nothing."
    "You peek around the room."
    ".."
    "..."
    "...Still nothing. {w}Nothing at all..."
    "But you know. You {i}know{/i} that something is there..."
    "Waiting to be acknowledged..."
    "For you to accept the fact of its existence."
    "Only {i}then{/i} will it deign to give you peace.."
    "...to free you from a life of constantly looking over your shoulder..."
    "...of fearing your own image... {w}your own reflection."
    "You can feel its patience, limitless and old."
    "You can’t win against it in a war of attrition."
    "Your lifespan will long expire before it tires of you."
    "So..."
    "..."
    scene black
    with dissolve
    "You close your eyes..."
    ".."
    "..."
    "...and accept it."
    stop music
    play sound "audio/swishQUICK_low.mp3" volume 0.4
    show slash
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3"
    show screen bloody
    with vpunch
    you "!!!" with hpunch
    you "..."
    scene black
    hide screen bloody
    with dissolve
    "As your head is severed from your neck, you’re filled with peace... {w}grateful that at the very least..."
    "...you never had to see {color=#FF0000}it.{/color}"
    "Whatever {color=#FF0000}it{/color} was.."
    ".."
    "..."
    "Ending 31: Headshot"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending31Done:
        jump endAlley
    else:
        $persistent.ending31Done = True
        $persistent.endCounter += 1
        jump endAlley


label play_lookAround:
    scene bg alley1
    with dissolve
    "You search around..."
    "...but there's really nothing in the alley that looks interesting enough for the cat to play with."
    "So maybe..."
    scene bg alleyCat2
    with dissolve
    you "How about... a game?"
    play sound "audio/cat_confused.mp3" volume 0.4
    cat "Meow?"
    "You decide on a game you've known since childhood..."
    "Red Light, Green Light... {w}a classic."
    "Teaching a cat how to play might be a bit of a challenge..."
    "...but you get the feeling the feline’s natural hunting instincts will help it along."
    scene bg alley2
    with dissolve
    "You walk to the entrance of the alley, the cat meowing at you."
    play sound "audio/cat_sadLONG.mp3" volume 0.3
    cat "Meow! Meowww!"
    you "Don't worry, I'm not going anywhere~"
    "You exaggerate your movements, covering your eyes with your hands... and turn around."
    scene black
    with dissolve
    you "One... {w}Two... {w}Three... {w}.{w}.{w}."
    you "...Red light!" with hpunch
    scene bg alley1
    with dissolve
    "You spin around."
    scene bg alleyCat2
    with dissolve
    pause .6
    scene bg alleyCat1
    with dissolve
    pause .2
    play sound "audio/cat_confused.mp3" volume 0.3
    scene bg game1a
    with dissolve
    "The cat hasn’t left the box, tilting its head at you in curious confusion."

    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/03catTheme.mp3" loop

    menu:
        "Try something else?":
            "Maybe the concept is too advanced for a cat after all..."
            "That's okay. You'll think of something else to do."
            scene bg alleyCat2
            with dissolve
            jump alley_playMenu
        "Keep playing?":
            jump playRedLight

label playRedLight:
    scene bg alley2
    with dissolve
    "You try again."
    "This time you go a bit slower."
    scene black
    with dissolve
    you "One..."
    "..."
    you "Twooo~"
    "..."
    you "Threeee~"
    ".."
    "..."
    you "RED LIGHT~!" with hpunch
    scene bg alley2
    with dissolve
    pause .5
    scene bg alley1
    with wipeleft
    "When you turn around this time..."
    scene bg game2a
    with dissolve
    pause .2
    "...the cat is out of the box."
    play sound "audio/cat_trilling.mp3" volume 0.4
    cat "!!!" with hpunch
    "The cat freezes under your stare, as if it thinks you can’t see it if it doesn’t move."
    you "{i}So cute~{/i}"
    scene bg alley2
    with wiperight
    "Satisfied that the cat is getting the hang of the game, you turn again... speeding back up."
    scene black
    with dissolve
    you "One... Two... Three..."
    you "Red light!" with hpunch
    scene bg alley2
    with dissolve
    pause .3
    scene bg alley1
    with wipeleft
    "You turn around..."
    scene bg game2b
    with dissolve
    pause .3
    "The cat is a few steps away from the box now, peeking out from behind a dumpster..."
    "...its eyes trained rather... {w}{i}intensely{/i} on you."
    "..."
    "Well... {w}at least it’s having fun?"
    "..."
    scene bg alley2
    with wiperight
    "You turn again..."
    stop music fadeout 5
    "..."
    "...and feel a sudden chill run down your spine."
    you "..?"
    scene black
    with dissolve
    "You feel silly... {w}but you can't help counting just a {i}little{/i} faster this time..."
    you "One, two, three, red light!" with hpunch
    scene bg alley2
    with dissolve
    pause .1
    scene bg alley1
    with wipeleft
    "...whirling around after saying \"red light!\""
    "..."
    "You... look at the cat."
    scene bg game2c
    with dissolve
    pause .5
    "It’s halfway down the alley closer to you now, but..."
    "..."
    "...it’s as if the perspective of what you’re seeing is {b}off{/b} somehow."
    "Doesn’t the cat look a little... {w}{i}bigger{/i}..?"
    play music "audio/heartbeat.mp3"
    "Its pupils are thin slits now."
    cat "..."
    you "..."
    "Something..."
    "{size=-5}Something’s not right.{/size}"
    play sound "audio/cat_angry.mp3" volume 0.5
    cat "Reowrrr..."
    "The cat meows at you again, but it sounds much {b}deeper{/b} than earlier."
    "It’s crouched down... as if poised to lunge forward..."
    "Your breath shudders a little as your heart starts to race."
    "Your foot instinctively shifts back-"
    stop music
    show screen blackOut
    show screen catEyesFade
    with c_Red
    pause .3
    hide screen catEyesFade
    hide screen blackOut
    play music "audio/heartbeatEcho.mp3"
    show game3
    play sound "audio/cat_angryQUICK.mp3" volume 0.7
    cat "{size=+20}{b}REAAWWWRRR!{/b}{/size}" with hpunch
    you "!!!" with vpunch
    "You freeze immediately."
    "The cat looks..."
    "...{b}impatient{/b}."
    "It... It wants to keep playing?"
    "{size=-5}But...{/size}"
    you "..."
    "You gulp and turn around, {w}swiftly counting and turning again as you gasp out..."
    scene bg alley2
    with wiperight
    pause .5
    scene black
    you "{size=-5}O-One-two-three-red-light!!{/size}"
    scene bg alley2
    play sound "audio/crashHuge.mp3"
    "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch
    you "!!!" with hpunch
    scene bg alley1
    with wipeleft
    "The ground shakes as you whirl back around..."
    scene bg game4a
    with dissolve
    "...to find yourself staring at a long surface of black fur."
    "You slowly look up..."
    "And up..."
    stop music fadeout 1.5
    scene black
    with dissolve
    "And {i}up{/i}..."
    "..."
    play music "audio/LOOPS/42greenLightLOOP.mp3" loop
    show game5
    with dissolve
    play sound "audio/beastBreath.mp3" volume 0.6 loop
    "...to see a giant, shadowy figure leering down from its position hunched over you."
    "Fangs dripping with saliva..."
    "Claws crushing into the concrete walls of the alley..."
    "Its glowing eyes are unblinking as they look back at you... {w}the cat waiting for your next turn."
    "But it's so {b}close{/b}... {w}If you turn around {i}{b}now{/b}...{/i}"
    you "..."
    "You..."
    "{size=-10}you don’t want to play anymore{/size}"

    menu:
        "Run...":
            jump play_gameRun
        "Back up...":
            jump play_backUp


label play_gameRun:
    stop music
    stop sound
    scene bg redScreen
    with p_Red
    play sound "audio/humanImpact.mp3" volume 0.6
    show screen bloody
    with vpunch
    you "!!!" with hpunch
    scene black
    hide screen bloody
    with dissolve
    "You don’t even finish turning around before claws grip your torso..."
    "...digging in and piercing the soft flesh of your stomach with ease."
    "As you’re lifted into the drooling, gaping jaws above you..."
    "...you can’t help but think that there must’ve been another way out of this."
    "But pointless regrets are pretty typical for you..."
    "{size=-5}...aren't they?{/size}"
    "..."
    "Ending 32: Fear Quitter"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending32Done:
        jump endAlley
    else:
        $persistent.ending32Done = True
        $persistent.endCounter += 1
        jump endAlley

label play_backUp:
    "Keeping your eyes trained on the giant looming over you..."
    "...you take a step back."
    stop music
    play sound "audio/glitch.mp3"
    scene black
    who "No."
    who "That's {b}cheating{/b}."

    menu:
        "Run...":
            jump play_gameRun
        "Run {size=-10}restoreBACKUP.exe{/size}":
            jump restoreBackUp

label restoreBackUp:

    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/43fatalErrorIN.mp3"
        queue music "audio/LOOPS/43fatalErrorLOOP.mp3" loop

    menu:
        "Begin restoration: _ _ _ _ \ _ _" if restoreCounter == 0:
            jump restoreB
        "Begin restoration: B _ _ _ \ _ _" if restoreCounter == 1:
            jump restoreA
        "Begin restoration: B A _ _ \ _ _" if restoreCounter == 2:
            jump restoreC
        "Begin restoration: B A C _ \ _ _" if restoreCounter == 3:
            jump restoreK
        "Begin restoration: B A C K \ _ _" if restoreCounter == 4:
            jump restoreU
        "Begin restoration: B A C K \ U _" if restoreCounter == 5:
            jump restoreP
        "Restoration Complete: B A C K \ U P" if restoreCounter == 6:
            jump runBackUp


label restoreB:
    $ restore_clock = 3
    show screen restore_timer
    menu:
        "-B-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-V-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-8-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-D-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-E-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-H-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-E-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp

label restoreA:
    $ restore_clock = 3
    show screen restore_timer
    menu:
        "-R-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-4-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-V-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-A-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-O-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-N-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-X-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp

label restoreC:
    $ restore_clock = 3
    show screen restore_timer
    menu:
        "-O-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-<-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-C-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-L-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-G-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-(-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-6-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp

label restoreK:
    $ restore_clock = 3
    show screen restore_timer
    menu:
        "-W-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-M-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-Z-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-4-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-X-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-K-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-T-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp

label restoreU:
    $ restore_clock = 3
    show screen restore_timer
    menu:
        "-V-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-F-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-U-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-A-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-W-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-D-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-Z-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp

label restoreP:
    $ restore_clock = 3
    show screen restore_timer
    menu:
        "-9-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-P-" if _preferences.language == "eng":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-R-" if _preferences.language == "pt_br":
            play sound "audio/dataReveal.mp3"
            $ restoreCounter += 1
            hide screen restore_timer
            jump restoreBackUp
        "-F-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-B-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-Q-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp
        "-S-":
            play sound "audio/glitch.mp3"
            hide screen restore_timer
            jump restoreBackUp



label runBackUp:

    who "What are you doing?"
    who "{size=+15}{b}STOP!{/b}{/size}" with hpunch
    who "{size=+25}{b}YOU'LL BREAK EVERYTH-{/b}{/size}{w=0.5}{nw}" with hpunch
    play sound "audio/glitch.mp3"

    menu:
        "Run...":
            jump play_gameRun
        "{b}B A C K \ U P{/b}":
            play sound "audio/dataReveal.mp3"
            jump backedUp

label backedUp:
    play music "audio/LOOPS/43fatalErrorOUT.mp3" noloop
    show game5
    with dissolve
    "The cat \ {b}s t a r e s {/b}\  as you keep eye contact and back up..."
    "You step bAck..."
    "AnD baCk..."
    scene black
    with dissolve
    "ANd aS YOu takE one mOre stEP baCk OuT oF tHe aLLeY..."
    ".."
    "..."
    scene bg street1
    with dissolve
    you "..."

    menu:
        "gO HOmE...":
            ".."
            "..."
            play sound "audio/glitch.mp3"
            "ERROR."
            scene bg game6a
            pause .1
            scene bg street1
            play sound "audio/glitch.mp3"
            "ERROR."
            scene bg game6a
            pause .1
            scene bg game6b
            pause .1
            scene bg game6c
            pause .1
            scene bg game6d
            pause .1
            scene bg game6e
            play sound "audio/glitch.mp3"
            "ERROR."
            scene bg game6d
            pause .1
            scene bg game6e
            pause .1
            scene bg game6f
            pause .1
            scene bg game6g
            play sound "audio/glitch.mp3"
            "ERROR."
            scene bg game7a
            pause .3
            play sound "audio/glitch.mp3"
            queue sound "audio/glitch.mp3"
            queue sound "audio/glitch.mp3"
            "ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR. ERROR."
            play sound "audio/glitch.mp3" loop
            scene bg game7b
            pause .1
            scene bg game7c
            pause .1
            scene bg game8a
            pause .05
            scene bg game8b
            pause .05
            scene bg game8a
            pause .05
            scene bg game8b
            pause .05
            scene bg game8a
            pause .05
            scene bg game8b
            pause .05
            scene bg game8a
            pause .05
            scene bg game8b
            pause .05
            scene bg game8a
            pause .05
            scene bg game8b
            pause .05
            stop sound
            show screen blackOut
            ".."
            "..."
            "The world outside the alley seems to be... {w}{i}broken.{/i}"
            "{size=-8}What exactly did you {b}do?{/b}{/size}"
            "..."
            "Ending 33: {b}eRRoR{/b} \ FoUnD"
            # if persistent.testingNow:
            #     jump endAlley
            if persistent.ending33Done:
                jump endAlley
            else:
                $persistent.ending33Done = True
                $persistent.endCounter += 1
                jump endAlley


label play_buyToy:
    "After being out in this alley all alone for who knows how long..."
    "...you personally think your furry friend deserves something {b}special{/b}."
    stop music fadeout 0.5
    scene black
    with dissolve
    you "I'll be right back, okay?"
    play sound "audio/cat_confused.mp3" volume 0.4
    cat "Meow?"
    play sound "audio/shopBell.mp3"
    scene bg toy
    with wiperight
    "You quickly leave the alley and rush to the nearby pet store."
    "You browse through all the different toys for cats."
    "There are so many to choose from... plush and bright-colored and scented with catnip..."
    "But..."
    "You realize that most of the toys aren't meant for a cat to play with alone."
    "You can't stay in the alley playing {i}forever...{/i}"
    "And you can't exactly afford to get {i}another{/i} cat as a playmate..."
    "..."
    "\"Another...\""
    you "{i}{size=+8}That's it!{/size}{/i}" with vpunch
    "You know exactly what to get now!"
    "After a quick and successful search of the store..."
    "...you make your purchase and rush back to the alley... {w}eager to show off your find."
    scene bg alley1
    with wipeleft
    pause .6
    play music "audio/LOOPS/03catTheme.mp3" loop
    scene bg alleyCat1
    with dissolve
    you "I'm back~!"
    scene bg upMeow
    play sound "audio/cat_trilling.mp3" volume 0.4
    cat "Meow!" with hpunch
    scene bg upBlinkSmile
    "The alley feels even gloomier after spending time in direct sunlight..."
    "It makes you feel that much prouder of your gift."
    "You skip over to the cat and dig in the store's plastic bag."
    you "I've got something for you~"
    scene bg alleyCat2
    play sound "audio/cat_confused.mp3" volume 0.3
    cat "Meow?"
    "The cat leans up, curious at the bag's contents."
    ".."
    "..."
    scene bg toy1a
    with dissolve
    "You pull out your gift to the cat..."
    scene bg toy1b
    with dissolve
    you "{size=+5}TADA~!{/size}" with hpunch
    "It's a small cat plushie."
    "The plushie is a light orange-cream color with burnt sepia stripes, {w}making it resemble a tabby cat."
    "The synthetic fur is soft, but not unrealistically so..."
    "...and the large eyes are a pale green more subdued than you would've expected for a toy."
    "There's no denying it's just a plushie, but the thoughtful details still make it almost..."
    "...{b}uncanny{/b} to the real thing."
    "..."
    "Which makes it {i}perfect.{/i}"
    "A companion for the cat, {w}and one you could actually afford."
    "Win-win."
    play sound "audio/cat_confused.mp3" volume 0.5
    cat "Meow?"
    you "That's not all!"
    scene bg toy1c
    with dissolve
    "You give the plushie a little squeeze and-"
    scene bg toy1b
    play sound "audio/catToyMeow.mp3"
    catDoll "{i}meeooww{/i}"
    cat "..."
    stop music fadeout 5
    scene bg alleyCat1
    with dissolve
    "The cat looks..."
    "...unimpressed."
    you "{i}Hmph.{/i}"
    "Well. {w}{i}You{/i} think it's cute..."
    "Guess your purchase wasn't so successful after all."
    "Out of options and lower on cash, {w}you awkwardly place the plushie in the box next to the cat."
    "You get up and turn to leave."
    scene bg alley2
    with dissolve
    "You're a few steps away when you hear an electronic meow behind you."
    play sound "audio/catToyMeow.mp3"
    catDoll "{i}meeooww{/i}"
    you "Huh?"
    scene bg alley1
    with dissolve
    pause .6
    scene bg toy2a
    with dissolve
    pause .8
    "You turn to see the plushie on the ground next to the box."
    "The cat is watching you closely, staring."

    menu:
        "Pick up plushie.":
            jump pickUpDoll
        "Leave.":
            jump leaveDoll


label pickUpDoll:
    "You sigh and go over to pick up the stuffed toy..."
    scene bg toy2a
    pause 1
    scene bg alleyCat1
    play sound "audio/bubblePop.mp3" volume 0.5
    pause .8
    you "You really {i}do{/i} just want attention, don't you?"
    scene bg downBlinkMeow
    play sound "audio/cat_happyLONG.mp3" volume 0.4
    cat "Meow! Meoww!"
    scene bg downBlinkSmile
    pause .6
    scene bg toy3a
    with dissolve
    "You hold up the cat doll, examining it a little..."
    ".."
    "..."
    "It looks a little... different."
    scene bg toy3a
    with dissolve
    pause .01
    scene bg toy3a
    with dissolve
    scene bg toy3b
    pause .5
    you "!!" with vpunch
    "Did it just..."
    "{size=-8}...{b}look{/b} at you?{/size}"
    play sound "audio/catToyMeow.mp3"
    catDoll "{i}meeooww{/i}"
    scene bg toy3c
    with fade_Red
    "..."
    play sound "audio/catToyMeow.mp3"
    catDoll "{i}{b}m e e o o w w...{/b}{/i}{w=0.8}{nw}"
    play sound "audio/catToyMeowOW1.mp3"
    catDoll "{i}{b}m e e o o w w-ow...{/b}{/i}{w=0.8}{nw}"
    play sound "audio/catToyMeowOW2.mp3"
    catDoll "{i}{b}m e e o o w w-ow-ow...{/b}{/i}{w=0.8}{nw}"
    play sound "audio/catToyMeowOW3.mp3"
    catDoll "{i}{b}m e e o o w w-ow-ow-ow...{/b}{/i}{w=0.8}{nw}"
    play sound "audio/catToyMeowOW4.mp3"
    catDoll "{i}{b}m e e o o w w-ow-ow-ow-ow...{/b}{/i}"
    play music "audio/LOOPS/44animateIN.mp3"
    queue music "audio/LOOPS/44animateLOOP.mp3" loop
    scene bg toy3d
    pause .15
    scene bg toy3e
    pause .15
    play sound "audio/fabricTear.mp3"
    scene bg toy3f
    pause .15
    scene bg toy3g
    pause .1
    scene bg toy3h
    pause .1
    scene bg toy3i
    pause .075
    scene bg redScreen
    with p_Red
    play sound "audio/punch_MEDIUM.mp3" volume 0.4
    show screen bloody
    with vpunch
    "{size=+20}{b}{i}CHOMP!!{/i}{/b}{/size}" with hpunch
    you "!!!" with vpunch
    scene bg toy4a
    hide screen bloody
    with dissolve
    scene bg toy4b
    with dissolve
    "The plushie somehow opens it sewn-on mouth before biting into your wrist!"
    you "{b}OW!!{/b} S-STOP!" with vpunch
    "You try to fling it off, but its grip on you is strong as it drinks your blood, ravenous and frantic."
    play sound "audio/gooeySquish.mp3" volume 0.7
    scene bg toy4a
    with p_Red
    with vpunch
    "You hit it against the concrete walls of the alley..."
    play sound "audio/gooeySquish.mp3" volume 0.7
    scene bg toy4a
    with p_Red
    with vpunch
    "You try to tear at its sturdy fabric..."
    play sound "audio/gooeySquish.mp3" volume 0.7
    scene bg toy4a
    with p_Red
    with vpunch
    "But try as you might, you can’t seem to hurt it or make it stop..."
    "It’s just a toy after all."
    scene bg alley1
    with fade_Red
    "Eventually, you start to feel faint... {w}enough to collapse to your knees in defeat."
    scene bg toy4c
    with dissolve
    "The stuffed doll is drinking more calmly now..."
    "...as if its previous aggression had been a mere reaction to your desperation."
    "..."
    "It seems satisfied that you’re no longer putting up a fight."
    play music "audio/LOOPS/44animateOUT.mp3" noloop
    scene black
    with dissolve
    ".."
    "..."
    "You think you blacked out for a second..."
    "...because though you're still sitting the next time you're conscious, your eyes are closed."
    "You..."
    "You feel so weak..."
    "You have to use all your strength just to pry open your eyes and when you do..."
    play sound "audio/cat_eating.mp3" volume 0.2
    scene bg toy5a
    with dissolve
    "..?"
    scene bg toy5b
    with dissolve
    "...you see a... {w}kitten?"
    "Its fur a familiar orange-cream with burnt sepia stripes..."
    "..."
    "It's lapping at your wrist..."
    scene bg toy5c
    with dissolve
    "The kitten lifts its head and looks at you with piercing, pale green eyes..."
    scene bg toy5d
    with dissolve
    play sound "audio/kittenToy.mp3"
    kitten "Miiiiew!"
    "It mewls at you with a high, squeaky pitch..."
    "...mouth covered in blood."
    scene bg toy5e
    with dissolve
    you "..."
    "It’d be downright adorable... {w}if you weren’t about to die from blood loss..."
    scene bg toy5e
    with dissolve
    pause .3
    scene bg toy5f
    with dissolve
    pause .3
    scene bg toy5g
    with dissolve
    pause .3
    scene bg toy5h
    with dissolve
    pause .2
    scene bg toy5i
    with dissolve
    pause .3
    "The cat strolls into your line of vision and picks the kitten up."
    "It gives you an indecipherable look..."
    "...before turning away."
    scene black
    with dissolve
    "The cat carries the kitten back to the box and starts to carefully and dutifully clean it."
    play sound "audio/kittenToy.mp3"
    kitten "Miiieeww..."
    play sound "audio/cat_purr.mp3" volume 0.4
    cat "Purr..."
    you "..."
    "You sway and find you can’t right yourself before falling to the ground."
    play sound "audio/humanImpact.mp3" volume 0.5
    scene black
    with p_Red
    "It would seem that in the end..."
    "...you'd gotten the cat a playmate after all."
    "..."
    "Ending 34: Living doll"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending34Done:
        jump endAlley
    else:
        $persistent.ending34Done = True
        $persistent.endCounter += 1
        jump endAlley


label leaveDoll:
    cat "..."
    you "..."
    show screen blackOut
    "{size=-10}Ungrateful little monster.{/size}"
    hide screen blackOut
    "You huff in annoyance."
    you "You're {i}{b}welcome{/b}{/i}..."
    scene bg alley2
    with wiperight
    "Shaking your head, you turn to leave once again-"
    play sound "audio/gooeySquish.mp3" volume 0.4
    scene bg alley2
    with p_Red
    you "!!!"
    you "{b}AHH!{/b}" with vpunch
    play music "audio/heartbeat.mp3"
    "...when a sharp pain lances up your arm."
    play sound "audio/gooeySquish.mp3" volume 0.6
    scene bg alley2
    with p_Red
    you "{b}{size=+10}GAHH!!{/size}{/b}" with vpunch
    "Crying out, you grab at your arm only for it to-"
    play sound "audio/fabricTear.mp3" volume 0.6
    queue sound "audio/humanImpact.mp3" volume 0.3
    scene bg doll1a
    with p_Red
    you "!!!" with hpunch
    scene bg doll1c
    with dissolve
    "{size=-5}...fall off.{/size}"
    "{size=-8}Your arm just falls right {i}off.{/i}{/size}"
    "You stare in shock at your severed limb on the ground."
    "Gathering your courage..."
    "...you turn to look at where your arm had once connected to the rest of you, only to see..."
    scene bg doll1d
    with dissolve
    you "..!?"
    "Not blood..? It’s..."
    "It’s {i}{b}cotton?!{/b}{/i}"
    scene bg doll1d1
    with dissolve
    "Touching it, the stump doesn’t even hurt..."
    "..."
    "That is..."
    play sound "audio/fabricTear_QUICK.mp3" volume 0.6
    scene bg doll1d1
    with p_Red
    pause .5
    scene bg doll1d2
    pause .1
    scene bg doll1d3
    pause .1
    scene bg doll1d4
    pause .15
    show screen blackOut
    scene bg doll1b
    play sound "audio/humanImpact.mp3" volume 0.3
    "..."
    "{size=-8}...until the same thing happens to your other arm.{/size}"
    hide screen blackOut
    play sound "audio/fabricTear.mp3" volume 0.6
    you "{b}{size=+10}AAAAHHH!!{/size}{/b}" with vpunch
    play sound "audio/fabricTear_QUICK.mp3" volume 0.6
    you "{b}{size=+20}{i}GAAAHHH!!!{/i}{/size}{/b}" with vpunch
    play sound "audio/fabricTear_LONG.mp3"
    scene bg doll1b
    with p_Red
    you "!!!" with vpunch
    play sound "audio/humanImpact.mp3" volume 0.8
    scene black
    with p_Red
    you "AHH!!" with vpunch
    stop music fadeout 5
    "You fall when both your legs succumb to the same nonsensical fate..."
    "...crying out at the agony that comes and goes like it never happened..."
    "...as if you're not currently laying on the dirty ground of an alley..."
    "{b}...limbless{/b}."
    "{size=-8}What in the world is going on..?{/size}"
    "You can't make sense of it..."
    "You can't think straight..."
    ".."
    "..."
    scene bg doll1e
    with dissolve
    "..."
    play music "audio/LOOPS/45perfectFriendIN.mp3"
    queue music "audio/LOOPS/45perfectFriendLOOP.mp3" loop
    "The pain has receded..."
    "...leaving you with a strangely empty pit in your stomach."
    "Considering you still {i}have{/i} a stomach and it wasn't replaced with..."
    "..."
    "As you lay back... helpless and still in shock, staring at the sky..."
    scene bg doll1f
    with dissolve
    "...the cat’s face appears in your line of vision."
    you "..."
    cat "..."
    play sound "audio/cat_angryQUICK.mp3" volume 0.6
    queue sound "audio/fabricTear_LONG.mp3"
    scene bg doll1g
    pause .1
    scene bg doll1h
    pause .075
    scene bg doll1i
    pause .05
    play sound "audio/squelchLOOP.mp3" volume 0.8
    show screen blackOut
    with p_Red
    scene black
    stop sound fadeout 1
    "It lunges at your torso and starts biting and clawing into your chest like you’re a chew toy."
    "It doesn’t hurt anymore..."
    "You feel like it {i}should.{/i}"
    "You’re... not sure if you’re glad that it {i}{b}doesn’t{/b}{/i}..."
    "..."
    play sound "audio/gooeySquish.mp3" volume 0.6
    hide screen blackOut
    with p_Red
    play sound "audio/fabricTear_LONG.mp3"
    "Eventually, you feel the cat {i}pull{/i} something out of you..."
    scene bg doll1j
    with dissolve
    pause .8
    "...a small doll, that looks very, very familiar."
    "It's hard to tell but... that doll is..."
    "That's {i}you{/i}..."
    "{size=-8}...isn't it?{/size}"
    scene bg doll1k
    with fade_Red
    pause .1
    scene black
    with dissolve
    "The cat hops off of you and heads back to the box with its prize."
    "At least you {i}think{/i} so..."
    "Everything’s... {w}{size=-5}too dark...{/size} {w}{size=-8}to tell...{/size}"
    ".."
    "..."
    show doll2
    with dissolve
    "...You wake up and find that you can’t move an inch."
    "You can’t look around."
    "You can’t even breathe."
    "Though none of those realizations seem to be... a {i}problem?{/i}"
    "All you can see is the face of a familiar looking cat curled around you, purring in its sleep."
    play sound "audio/cat_purr.mp3" volume 0.4
    cat "Purr... Purrr..."
    "For some reason, this doesn’t bother you."
    "You’re not sure why you feel like it should."
    "You try to latch on to thoughts in your head, that feel like memories of another life..."
    "Another time..."
    "Another {i}you{/i}..."
    "...but the thoughts slip away like forgotten dreams."
    ".."
    "..."
    show doll3
    with fade_Red
    play music "audio/LOOPS/45perfectFriendOUT.mp3" noloop
    "Oh well."
    "That's fine, isn't it?"
    "{size=-5}You're just a \ {b}d o l l{/b}, after all...{/size}"
    "And a doll’s role isn’t to have silly {i}thoughts{/i} or to {i}remember{/i} unimportant things..."
    "...but to be a {i}companion.{/i}"
    play sound "audio/cat_purr.mp3" volume 0.6
    cat "Purrr..."
    "And judging from the cat’s contented purring..."
    "...you seem to be performing your role perfectly."
    "You are filled with an overwhelmingly strong sense of pride at this fact."
    scene black
    with dissolve
    "And so you {i}too{/i}... {w}feel content."
    ".."
    "..."
    "Ending 35: Cotton Headed"
    # if persistent.testingNow:
    #     jump endAlley
    if persistent.ending35Done:
        jump endAlley
    else:
        $persistent.ending35Done = True
        $persistent.endCounter += 1
        jump endAlley



label endAlley:
    # $ persistent.testingNow = False

    return
