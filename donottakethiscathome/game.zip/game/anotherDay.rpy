﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

# The game starts here.

label newDay:
    ".."
    "..."
    play sound "audio/rainLOOP.mp3" volume 0.4 fadein 0.5 loop
    show raining
    with fade_Red
    "..."
    "Today's been... {w}surprising..?"
    "..."
    stop sound fadeout 2.5
    "Yeah... {w}{i}Pleasantly{/i} so."
    play music "audio/LOOPS/53tomorrowIN.mp3"
    queue music "audio/LOOPS/53tomorrowLOOP.mp3" loop
    scene bg theater1
    with dissolve
    "A day off that started with admittedly crummy weather led me to the old theater..."
    scene bg theater5b
    with dissolve
    "...where I enjoyed a movie by myself. {w}My laughter filled up the empty theater."
    scene bg street2
    with dissolve
    "The rain had stopped by the time the movie was over..."
    scene bg cinema1
    with dissolve
    "...and I was in such a good mood, I hopped over to the not-so-new cinema..."
    "Not to watch another movie..."
    scene bg cinema2
    with dissolve
    "...but to play around in the arcade, earning a few high scores."
    scene bg carnival1
    with dissolve
    "With the gamer in me awakened, I went to the carnival to play some more..."
    "...and was humbled fairly quickly."
    show EG lastDay1a
    with dissolve
    "But I {i}did{/i} manage to win a small stuffed animal at the ring toss booth..."
    "The design is... {w}questionable..."
    ".."
    "..."
    show EG lastDay1b
    with dissolve
    "...and I freaking {b}love{/b} it."
    scene bg carnival1
    with dissolve
    "The rides weren't so bad either."
    "I got inducted into a group for a bit, while waiting in line at the ferris wheel..."
    "...bonding over our shared mistrust of the carnival's game vendors."
    "I even shared a carriage on the ferris wheel with a few of them..."
    "...and exchanged numbers before we parted ways."
    scene black
    with dissolve
    "I don't know if I'll ever see them again or if any of them will ever call me..."
    "...or if I even have it in me to call any of {i}them...{/i}"
    "But..."
    "...having the option to do so is... {w}nice."
    "It feels nice."
    "..."
    "Baby steps..."
    "After all, even that tiny bit of interaction, {w}though fun... {w}exhausted me."
    scene bg dogPark1
    with dissolve
    "So I went to recharge at the dog park..."
    "...feeling rejuvenated at the sight of dogs... {w}old, young, big and small, {w}all running around..."
    scene bg dogPark3
    with dissolve
    "...happy and carefree."
    play sound "audio/camera.mp3"
    show EG lastDay1c
    with whiteFlash
    "A few of the owners even let me take pictures."
    scene bg dogPark3
    with dissolve
    "...Yeah."
    "Today was a good day."
    scene black
    with dissolve
    play music "audio/LOOPS/53tomorrowOUT.mp3"
    queue music "audio/birdsNormalQUIET.mp3" loop
    "..."
    "I don't think about the cat, or \"it\", I guess... all that much these days..."
    "It was hard at first..."
    "In the immediate days and weeks that followed..."
    "...what happened to me was all I could think about."
    "There were days I blamed myself..."
    "Days I questioned my choices..."
    "I went back to the alley more times than I want to admit..."
    "The feeling that always went through me at the sight of that empty cardboard box..."
    "...was so indescribable... {w}so {i}{b}overwhelming{/b}...{/i}"
    "...I'd sometimes break down and cry right where I stood."
    "It took a while, but eventually that strange emotion became clearer and clearer..."
    "...until I had the courage to recognize it for what it was..."
    "..."
    "...\"Relief.\""
    "I'd been afraid to feel it for so long..."
    "...terrified to let my guard down."
    "..."
    "But that sense of relief finally returned."
    "Relief that \"it\" was gone..."
    "Relief that I was free to live my life..."
    "..."
    "...however simply or extraordinarily {b}{i}I{/i}{/b} wished."
    "The ones \"it\" had imprisoned..."
    "I never heard their voices again either..."
    "But that's for the best..."
    "Living here and now..."
    "Never forgetting what they did for me..."
    "...and what I did for them, too..."
    "..."
    "For now... I think that's enough..."
    "At least, I hope so..."
    "...and that wherever they are, they're finally at peace."
    "I'm fighting for my own peace too..."
    "One day at a time..."
    "One tomorrow after another..."
    scene black
    pause .6
    scene bg street2
    with fade_Red
    pause .6
    scene bg street3
    with fade_Red
    pause .6
    scene bg street4
    with fade_Red
    pause .6
    scene bg street5
    with fade_Red
    pause .6
    scene bg aptFront
    with fade_Red
    pause .6
    "Finally... {w}I head home..."
    "...to my little apartment."
    scene bg aptDoor
    with dissolve
    "One bedroom... {w}one bathroom... {w}and one {i}me{/i} living alone in it."
    stop music fadeout 1.5
    scene black
    with dissolve
    ".."
    "..."
    "Well..."
    "{i}Almost{/i} anyway..."
    scene bg aptLivingRoom
    with dissolve
    you "I'm home, baby~!"
    play sound "audio/kitten2.mp3"
    who "Miiiiiew!" with hpunch
    play music "audio/LOOPS/54homeAgainFULL.mp3" loop
    show EG lastDay1d
    with dissolve
    "A little kitten flails as it awkwardly runs over and mewls up at me..."
    show EG lastDay1e
    pause .1
    show EG lastDay1f
    pause .1
    play sound "audio/kitten1.mp3"
    kitten "Miiiiiew~"
    show EG lastDay1d
    "I kneel down, looking fondly at its hazel-green eye."
    "The poor thing had been hurt and starving when I found it a few weeks ago..."
    show EG lastDay1e
    pause .1
    show EG lastDay1d
    pause .1
    "...but it certainly got its energy back after a little food and care."
    you "Did you miss me?"
    show EG lastDay1g
    play sound "audio/kitten2.mp3"
    kitten "Miiiiew!" with hpunch
    show EG lastDay1d
    you "Hungry, huh?"
    show EG lastDay1e
    pause .1
    show EG lastDay1f
    pause .1
    play sound "audio/kitten4.mp3"
    kitten "Miii..."
    show EG lastDay1d
    you "Hehe! Me too. It's been a {b}{i}long{/i}{/b} day..."
    "I smile helplessly at its cute little face."
    you "Let's find something to eat, okay?"
    show EG lastDay1e
    play sound "audio/kittenPurr.mp3"
    kitten "Purr..."
    show EG lastDay1d
    pause .6
    scene black
    with fade_Red
    "Well... I guess there {i}is{/i} one more thing living in my home..."
    "And... {w}at least for {i}now{/i}..."
    "..."
    "...I wouldn't have it any other way."
    ".."
    "..."
    "Ending N/A: Another day..."
    # if persistent.testingNow:
    #     jump rollCredits
    if persistent.ending39Done:
        jump rollCredits
    else:
        $persistent.ending39Done = True
        $persistent.endCounter += 1
        jump rollCredits

label rollCredits:
    $ persistent.testingNow = False
    #credits
    show text "{color=#FF0000}Backgrounds & BG/Art References{/color}\n\nPexels.com" at truecenter
    with fade_Red
    pause 5
    hide text
    with fade_Red
    pause 2
    show text "{color=#FF0000}Sound Effects{/color}\n\nPixabay.com" at truecenter
    with fade_Red
    pause 5
    hide text
    with fade_Red
    pause 2
    show text "{color=#FF0000}Programmed With{/color}\n\nRen'Py" at truecenter
    with fade_Red
    pause 5
    hide text
    with fade_Red
    pause 2
    show text "{color=#FF0000}Português-BR Translation{/color}\n\nGeorge Ribeiro" at truecenter
    with fade_Red
    pause 5
    hide text
    with fade_Red
    pause 2
    show text "{color=#FF0000}And you...{/color}\n\nThank you for playing" at truecenter
    with fade_Red
    pause 5
    hide text
    with fade_Red
    pause 2
    show text "The End" at truecenter
    with fade_Red
    "\ "

    return
