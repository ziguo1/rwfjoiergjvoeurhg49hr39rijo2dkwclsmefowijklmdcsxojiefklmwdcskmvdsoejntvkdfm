﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

default persistent.beatHardMode = False

default flashlight = 5
default maxLight = 5
default mazeLives = 3
default maxLives = 3
default roomCounter = 0

default easyMode = False
default hardMode = False
default flashOff = False

default mazeClock = 100

image carnival7:
    "normalBGs/carnival07a.png"
    pause .1
    "normalBGs/carnival07b.png"
    pause .1
    "normalBGs/carnival07c.png"
    pause .1
    repeat

image carnival11:
    "normalBGs/carnival11a.png"
    pause .1
    "normalBGs/carnival11b.png"
    pause .1
    "normalBGs/carnival11c.png"
    pause .1
    repeat

image maze16Hard:
    "mazeHard/maze_16a.png"
    pause .1
    "mazeHard/maze_16b.png"
    pause .1
    "mazeHard/maze_16c.png"
    pause .1
    repeat

image maze3Hard:
    "mazeHard/maze_3a.png"
    pause .1
    "mazeHard/maze_3b.png"
    pause .1
    "mazeHard/maze_3c.png"
    pause .1
    repeat

image maze13Hard:
    "mazeHard/maze_13a.png"
    pause .1
    "mazeHard/maze_13b.png"
    pause .1
    "mazeHard/maze_13c.png"
    pause .1
    repeat

image maze15Hard:
    "mazeHard/maze_15a.png"
    pause .1
    "mazeHard/maze_15b.png"
    pause .1
    "mazeHard/maze_15c.png"
    pause .1
    repeat

image maze12Hard:
    "mazeHard/maze_12a.png"
    pause .1
    "mazeHard/maze_12b.png"
    pause .1
    "mazeHard/maze_12c.png"
    pause .1
    repeat

image maze8Hard:
    "mazeHard/maze_8a.png"
    pause .1
    "mazeHard/maze_8b.png"
    pause .1
    "mazeHard/maze_8c.png"
    pause .1
    repeat

image maze18Hard:
    "mazeHard/maze_18a.png"
    pause .1
    "mazeHard/maze_18b.png"
    pause .1
    "mazeHard/maze_18c.png"
    pause .1
    repeat

image maze7Hard:
    "mazeHard/maze_7a.png"
    pause .1
    "mazeHard/maze_7b.png"
    pause .1
    "mazeHard/maze_7c.png"
    pause .1
    repeat


init:
    image bg maze1 = "maze_1.png"
    image bg maze2 = "maze_2.png"
    image bg maze3 = "maze_3.png"
    image bg maze4 = "maze_4.png"
    image bg maze5 = "maze_5.png"
    image bg maze6 = "maze_6.png"
    image bg maze7 = "maze_7.png"
    image bg maze8 = "maze_8.png"
    image bg maze9 = "maze_9.png"
    image bg maze10 = "maze_10.png"
    image bg maze11 = "maze_11.png"
    image bg maze12 = "maze_12.png"
    image bg maze13 = "maze_13.png"
    image bg maze14 = "maze_14.png"
    image bg maze15 = "maze_15.png"
    image bg maze16 = "maze_16.png"
    image bg maze17 = "maze_17.png"
    image bg maze18 = "maze_18.png"
    image bg maze19 = "maze_19.png"
    image bg maze20 = "maze_20.png"
    image bg maze21 = "maze_21.png"
    image bg maze22 = "maze_22.png"
    image bg maze23 = "maze_23.png"
    image bg maze24 = "maze_24.png"
    image bg maze25 = "maze_25.png"
    image bg redScreen = "redSCREEN.png"
    image bg whiteScreen = "whiteSCREEN.png"
    image bg mazeGood = "maze_allGOOD.png"
    image bg mazePaths = "maze_paths.png"
    image bg carnival6a = "normalBGs/carnival06a.png"
    image bg carnival6b = "normalBGs/carnival06b.png"
    image bg carnival6c = "normalBGs/carnival06c.png"
    image bg carnival6d = "normalBGs/carnival06d.png"
    image bg carnival8a = "normalBGs/carnival08a.png"
    image bg carnival8b = "normalBGs/carnival08b.png"
    image bg carnival8c = "normalBGs/carnival08c.png"
    image bg carnival8d = "normalBGs/carnival08d.png"
    image bg carnival8e = "normalBGs/carnival08e.png"
    image bg carnival8f = "normalBGs/carnival08f.png"
    image bg carnival9a = "normalBGs/carnival09a.png"
    image bg carnival9b = "normalBGs/carnival09b.png"
    image bg carnival9c = "normalBGs/carnival09c.png"
    image bg carnival9d = "normalBGs/carnival09d.png"
    image bg carnival10a = "normalBGs/carnival10a.png"
    image bg carnival10b = "normalBGs/carnival10b.png"
    image bg carnival10c = "normalBGs/carnival10c.png"
    image bg carnival10d = "normalBGs/carnival10d.png"
    image bg carnival10e = "normalBGs/carnival10e.png"
    image bg carnival10f = "normalBGs/carnival10f.png"
    image bg carnival10g = "normalBGs/carnival10g.png"
    image bg carnival11a = "normalBGs/carnival11a.png"
    image bg carnival11b = "normalBGs/carnival11b.png"
    image bg carnival11c = "normalBGs/carnival11c.png"

    $ flash = Fade(.02, 0, 1, color="#fff")
    $ easyFlash = Fade(.02, 0, 1.75, color="#fff")
    $ hardFlash = Fade(.02, 0, .6, color="#fff")
    $ flashRed = Fade(.03, 0.1, .5, color="#FF0000")
    $ fadeToRed = Dissolve(4)

screen wrongPath():
    add Image("redSCREEN.png") alpha 0.5


screen lifeScreen():
    frame:
        xpadding 30
        ypadding 20
        xalign 0.98
        yalign 0.03
        text "LIVES: [mazeLives]/[maxLives]"
    frame:
        xpadding 30
        ypadding 20
        xalign 0.02
        yalign 0.03
        text "Room [roomCounter]/25"

screen maze_timer():
    frame:
        xpadding 30
        ypadding 20
        xalign 0.5
        yalign 0.03
        if mazeClock <= 10:
            text "[mazeClock]" size 40 color "#FF0000" xalign 0.5 yalign 0.03
        else:
            text "[mazeClock]" size 40 color "#FFF" xalign 0.5 yalign 0.03
    if mazeClock >= 1:
        timer 1 repeat True action [
                SetVariable("mazeClock", mazeClock - 1),
                renpy.restart_interaction
            ]
    else:
        timer 1 action [
                Hide("maze_timer"),
                Jump("mazeTimeOut")
            ]


# The game starts here.
label mazeStart:
    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/26carnivalLOOP_Slow.mp3" loop
    who "Hello, daring adventurer~!"
    you "!!!" with vpunch
    "Who said tha--{w=0.3}{nw}"
    who "Welcome to the Mirror Maze!"
    menu:
        who "Would you like to know how to navigate the maze?"
        "Yes, I need help!":
            jump mazeTutorial
        "No! I don't even know you!":
            who "Okay, okay! {w}No need to get snippy..."
            stop music fadeout 2
            who "Let's begin then!"
            who "3... {w}2... {w}1..."
            play sound "audio/whistle.mp3"
            who "{size=+25}{b}GO!{/b}{/size}" with vpunch
            jump setDifficulty
        "No, but I have some questions...":
            jump mazeSettings

label mazeTutorial:
    scene bg mazePaths
    with dissolve
    "Once again... {w}Welcome to the Mirror Maze!"
    "You're in a bit of a jam, but don't worry!"
    "You're in {i}good{/i} hands!"
    "Or rather..."
    "...good {b}paws!{/b}"
    scene bg mazeGood
    with dissolve
    "See these little cuties here?"
    "They'll be doing their best to guide you through the maze!"
    "Aren't they generous~?"
    "When you enter a room... the emergency light will flash, letting you see the paths before you for a second."
    "And also what lies beyond them."
    "Whenever you see these kind kitties..."
    "...just go where they are and you'll reach the next room!"
    "Unfortunately..."
    scene bg mazePaths
    with dissolve
    "...they're not the only things in here."
    "It is {i}highly{/i} suggested that you refrain from following {i}any{/i} of our other... {w}{b}{i}guests{/i}{/b}"
    "They can be sneaky or distracting... {w}but they're {b}always{/b} hostile."
    "So please take caution when advancing to the next room!"
    scene bg maze15
    with dissolve
    "Of course this wouldn't be much of a mirror maze without mirrors!"
    "\"Can they hurt you?\""
    "No! They're just mirrors, silly!"
    "They don't do anything at all~!"
    "And you can't do anything to them either."
    "They're just an obstacle you can't pass through."
    scene bg mazePaths
    with dissolve
    "Go {b}left{/b}, {w}go {b}center{/b}, {w}or go {b}right{/b}!"
    "The choice is yours!"
    "Though..."
    "If you find a room with no helpful kitties in sight..."
    "...and all the paths lead to a mirror or... {w}{color=#FF0000}{b}something else...{/b}{/color}"
    "It's recommended that you {b}stay put{/b}... {w}and just maybe it will work itself out!"
    scene black
    with dissolve
    "Now for your navigation tools!"
    play sound "audio/click.mp3"
    scene bg mazeGood
    with flash
    "That {b}flashlight{/b} you found doesn't have much juice left..."
    "It'll only let you get a {b}quick{/b} extra peek at your surroundings about five times."
    "So try not to use it all up at once!"
    scene black
    with dissolve
    show screen lifeScreen
    with dissolve
    "You can keep track of your progress through the {b}rooms{/b} up to the left..."
    "...and your {b}lives{/b} up to the right!"
    "You've got three lives, so be careful to avoid the less friendly guests lurking around."
    "\"Why only {b}three{/b} lives\", you ask?"
    "Because you're soft and squishy!"
    "It wouldn't take much to damage you beyond repair..."
    hide screen lifeScreen
    with dissolve
    stop music fadeout 3
    "..."
    "And besides..."
    "...you're human. And humans usually only have the {b}one{/b} life, yes?"
    "And yet here, you get three!"
    ".."
    play sound "audio/heartbeat.mp3" loop
    "..."
    "Don't you think... {w}you ought to show... {w}a little more..."
    "{b}...g {w=0.2}r {w=0.2}a {w=0.2}t {w=0.2}i {w=0.2}t {w=0.2}u {w=0.2}d {w=0.2}e {w=0.2}?{/b}"
    ".."
    "..."
    stop sound
    "And that's the end of your tutorial!!"
    "Hopefully it was helpful!"
    "Are you ready to play?"

label mazeSettings:
    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/26carnivalLOOP_Slow.mp3" loop
    menu:
        who "What would you like to know?~"
        "{b}{size=+5}I'm ready to play!{/size}{/b}":
            stop music fadeout 1.5
            "Okay!"
            "3... {w}2... {w}1..."
            play sound "audio/whistle.mp3"
            "{size=+25}{b}GO!{/b}{/size}" with vpunch
            jump setDifficulty
        "Can you let me go?":
            who "Your request to forfeit is denied!~"
            you "Let me out of here!" with vpunch
            who "Screaming is not allowed in the maze!~"
            jump mazeSettings
        "Can you turn {b}ON{/b} the flash, please?" if flashOff == True:
            who "Of course!"
            play sound "audio/click.mp3"
            who "Flash {b}ON!{/b}"
            $ flashOff = False
            jump mazeSettings
        "Can you turn {b}OFF{/b} the flash, please?" if flashOff == False:
            who "Of course!"
            play sound "audio/click.mp3"
            who "Flash {b}OFF!{/b}"
            $ flashOff = True
            jump mazeSettings
        "This game is too hard..." if easyMode != True:
            who "Oh, alright..."
            $ easyMode = True
            $ hardMode = False
            who "Your flashlight will give you {b}seven{/b} second chances now..."
            who "{i}And{/i} the flash will last longer..."
            who "Is that better~?"
            jump mazeSettings
        "Psh! This game's {i}{b}way{/b}{/i} too easy!" if hardMode != True:
            who "..."
            who "Is that {b}so?{/b}"
            $ hardMode = True
            $ easyMode = False
            ".."
            "..."
            who "There... {w}all done!"
            you "Wait, what did you do?"
            who "..."
            who "You'll see~"
            jump mazeSettings
        "Reset Settings":
            $ flashOff = False
            $ easyMode = False
            $ hardMode = False
            who "You got it!"
            jump mazeSettings
        "Can you tell me about the maze again?":
            who "As you wish!"
            jump mazeTutorial


label setDifficulty:
    if easyMode:
        $ flashlight = 7
        $ maxLight = 7
        $ flash = easyFlash
        $ roomCounter += 1
        play music "audio/LOOPS/27funhouseIN.mp3"
        queue music "audio/LOOPS/27funhouseLOOP.mp3" loop
        jump maze1
    if hardMode:
        $ flashlight = 3
        $ maxLight = 3
        $ flash = hardFlash
        show screen maze_timer
        $ roomCounter += 1
        play music "audio/LOOPS/27funhouseIN.mp3"
        queue music "audio/LOOPS/27funhouseLOOP.mp3" loop
        jump maze20
    else:
        $ roomCounter += 1
        play music "audio/LOOPS/27funhouseIN.mp3"
        queue music "audio/LOOPS/27funhouseLOOP.mp3" loop
        jump maze1


label maze1:
    if hardMode:
        $ renpy.block_rollback()
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if flashOff:
        if hardMode:
            scene bg maze1
            pause .45
        else:
            scene bg maze1
            pause .6
    else:
        scene bg maze1
        with flash


label maze1Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze1
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze1Menu
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze1
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze1Menu
        "RIGHT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze24
            $ roomCounter += 1
            jump maze2
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze1Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze1
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze1Menu

label maze2:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze2
            pause .45
            pause .01
            play sound "audio/stare.mp3"
            show screen stareScreen
            with hpunch
            pause .1
            hide screen stareScreen
        else:
            scene bg maze2
            pause .6
    else:
        if hardMode:
            scene bg maze2
            with flash
            pause .01
            play sound "audio/stare.mp3"
            show screen stareScreen
            with hpunch
            pause .1
            hide screen stareScreen
        else:
            scene bg maze2
            with flash

label maze2Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze2Menu
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze2
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze2Menu
        "RIGHT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze19
            $ roomCounter += 1
            jump maze3
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze2Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze2
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze2Menu


label maze3:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            show maze3Hard
            pause .45
            pause .01
            play sound "audio/wind.mp3"
            show wind
            pause .5
            hide wind
        else:
            scene bg maze3
            pause .6
    else:
        if hardMode:
            show maze3Hard
            with flash
            pause .01
            play sound "audio/wind.mp3"
            show wind
            pause .5
            hide wind
        else:
            scene bg maze3
            with flash

label maze3Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze13
            $ roomCounter += 1
            jump maze4
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze3
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze3Menu
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze3
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze3Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze3Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze3
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze3Menu


label maze4:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze4
            pause .45
            pause .01
            play sound "audio/wind.mp3"
            show wind
            pause .5
            hide wind
        else:
            scene bg maze4
            pause .6
    else:
        if hardMode:
            scene bg maze4
            with flash
            pause .01
            play sound "audio/wind.mp3"
            show wind
            pause .5
            hide wind
        else:
            scene bg maze4
            with flash

label maze4Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze4
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze4Menu
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze4
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze4Menu
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze4
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze4Menu
        "STAY":
            you "This room feels off..."
            you "Just wait..."
            you "..."
            you "..!"
            you "I think something just changed..."
            if hardMode:
                $ roomCounter += 1
                jump maze11
            $ roomCounter += 1
            jump maze5
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze4
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze4Menu


label maze5:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze5
            pause .45
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze5
            pause .6
    else:
        if hardMode:
            scene bg maze5
            with flash
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze5
            with flash

label maze5Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze22
            $ roomCounter += 1
            jump maze6
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze5
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze5Menu
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze5
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze5Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze5Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze5
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze5Menu


label maze6:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze6
            pause .45
            pause .01
            play sound "audio/swishMEDIUM.mp3"
            show slash
            with vpunch
            hide slash
        else:
            scene bg maze6
            pause .6
    else:
        if hardMode:
            scene bg maze6
            with flash
            pause .01
            play sound "audio/swishMEDIUM.mp3"
            show slash
            with vpunch
            hide slash
        else:
            scene bg maze6
            with flash

label maze6Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze21
            $ roomCounter += 1
            jump maze7
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze6
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze6Menu
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze6
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze6Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze5Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze6
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze6Menu


label maze7:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            show maze7Hard
            pause .45
            pause .01
            play sound "audio/stare.mp3"
            show screen stareScreen
            with hpunch
            pause .1
            hide screen stareScreen
        else:
            scene bg maze7
            pause .6
    else:
        if hardMode:
            show maze7Hard
            with flash
            pause .01
            play sound "audio/stare.mp3"
            show screen stareScreen
            with hpunch
            pause .1
            hide screen stareScreen
        else:
            scene bg maze7
            with flash

label maze7Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze7
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze7Menu
        "CENTER":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze7Menu
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze7
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze7Menu
        "STAY":
            you "This room feels off..."
            you "Just wait..."
            you "..."
            you "..!"
            you "I think something just changed..."
            if hardMode:
                jump mazeWin
            $ roomCounter += 1
            jump maze8
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze7
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze7Menu


label maze8:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            show maze8Hard
            pause .45
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze8
            pause .6
    else:
        if hardMode:
            show maze8Hard
            with flash
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze8
            with flash

label maze8Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze8
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze8Menu
        "CENTER":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze18
            $ roomCounter += 1
            jump maze9
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze8
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze8Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze8Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze8
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze8Menu


label maze9:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze9
            pause .45
        else:
            scene bg maze9
            pause .6
    else:
        scene bg maze9
        with flash

label maze9Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze9Menu
        "CENTER":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze9Menu
        "RIGHT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze10
            $ roomCounter += 1
            jump maze10
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze9Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze9
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze9Menu


label maze10:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze10
            pause .45
        else:
            scene bg maze10
            pause .6
    else:
        scene bg maze10
        with flash

label maze10Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze10
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze10Menu
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze10
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze10Menu
        "RIGHT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze1
            $ roomCounter += 1
            jump maze11
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze10Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze10
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze10Menu


label maze11:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze11
            pause .45
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze11
            pause .6
    else:
        if hardMode:
            scene bg maze11
            with flash
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze11
            with flash

label maze11Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze11Menu
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze11
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze11Menu
        "RIGHT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze6
            $ roomCounter += 1
            jump maze12
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze11Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze11
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze11Menu


label maze12:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            show maze12Hard
            pause .45
            pause .01
            play sound "audio/stare.mp3"
            show screen stareScreen
            with hpunch
            pause .1
            hide screen stareScreen
        else:
            scene bg maze12
            pause .6
    else:
        if hardMode:
            show maze12Hard
            with flash
            pause .01
            play sound "audio/stare.mp3"
            show screen stareScreen
            with hpunch
            pause .1
            hide screen stareScreen
        else:
            scene bg maze12
            with flash

label maze12Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze12
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze12Menu
        "CENTER":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze12Menu
        "RIGHT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze8
            $ roomCounter += 1
            jump maze13
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze11Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze12
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze12Menu


label maze13:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            show maze13Hard
            pause .45
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze13
            pause .6
    else:
        if hardMode:
            show maze13Hard
            with flash
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze13
            with flash

label maze13Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze13Menu
        "CENTER":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze15
            $ roomCounter += 1
            jump maze14
        "RIGHT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze13Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze13Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze13
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze13Menu


label maze14:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze14
            pause .45
        else:
            scene bg maze14
            pause .6
    else:
        scene bg maze14
        with flash

label maze14Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze14
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze14Menu
        "CENTER":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze25
            $ roomCounter += 1
            jump maze15
        "RIGHT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze14Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze14Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze14
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze14Menu


label maze15:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            show maze15Hard
            pause .45
            pause .01
            play sound "audio/wind.mp3"
            show wind
            pause .5
            hide wind
        else:
            scene bg maze15
            pause .6
    else:
        if hardMode:
            show maze15Hard
            with flash
            pause .01
            play sound "audio/wind.mp3"
            show wind
            pause .5
            hide wind
        else:
            scene bg maze15
            with flash

label maze15Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze15Menu
        "CENTER":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze15Menu
        "RIGHT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze15Menu
        "STAY":
            you "This room feels off..."
            you "Just wait..."
            you "..."
            you "..!"
            you "I think something just changed..."
            if hardMode:
                $ roomCounter += 1
                jump maze12
            $ roomCounter += 1
            jump maze16
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze15
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze15Menu


label maze16:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            show maze16Hard
            pause .45
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze16
            pause .6
    else:
        if hardMode:
            show maze16Hard
            with flash
            play sound "audio/splat.mp3"
            show screen bloody
            with hpunch
            pause .1
            hide screen bloody
        else:
            scene bg maze16
            with flash

label maze16Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze3
            $ roomCounter += 1
            jump maze17
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze16
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze16Menu
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze16
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze16Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze16Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze16
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze16Menu


label maze17:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze17
            pause .45
        else:
            scene bg maze17
            pause .6
    else:
        scene bg maze17
        with flash

label maze17Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze17
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze17Menu
        "CENTER":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze9
            $ roomCounter += 1
            jump maze18
        "RIGHT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze17Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze16Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze17
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze17Menu


label maze18:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            show maze18Hard
            pause .45
            pause .01
            play sound "audio/swishMEDIUM.mp3"
            show slash
            with vpunch
            hide slash
        else:
            scene bg maze18
            pause .6
    else:
        if hardMode:
            show maze18Hard
            with flash
            pause .01
            play sound "audio/swishMEDIUM.mp3"
            show slash
            with vpunch
            hide slash
        else:
            scene bg maze18
            with flash

label maze18Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze18
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze18Menu
        "CENTER":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze18Menu
        "RIGHT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze7
            $ roomCounter += 1
            jump maze19
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze18Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze18
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze18Menu


label maze19:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze19
            pause .45
            pause .01
            play sound "audio/stare.mp3"
            show screen stareScreen
            with hpunch
            pause .1
            hide screen stareScreen
        else:
            scene bg maze19
            pause .6
    else:
        if hardMode:
            scene bg maze19
            with flash
            pause .01
            play sound "audio/stare.mp3"
            show screen stareScreen
            with hpunch
            pause .1
            hide screen stareScreen
        else:
            scene bg maze19
            with flash

label maze19Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze19Menu
        "CENTER":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze4
            $ roomCounter += 1
            jump maze20
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze19
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze19Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze19Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze19
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze19Menu


label maze20:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze20
            pause .45
        else:
            scene bg maze20
            pause .6
    else:
        scene bg maze20
        with flash

label maze20Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze23
            $ roomCounter += 1
            jump maze21
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze20
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze20Menu
        "RIGHT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze20Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze20Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze20
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze20Menu


label maze21:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze21
            pause .45
            pause .01
            play sound "audio/swishMEDIUM.mp3"
            show slash
            with vpunch
            hide slash
        else:
            scene bg maze21
            pause .6
    else:
        if hardMode:
            scene bg maze21
            with flash
            pause .01
            play sound "audio/swishMEDIUM.mp3"
            show slash
            with vpunch
            hide slash
        else:
            scene bg maze21
            with flash

label maze21Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze21Menu
        "CENTER":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze16
            $ roomCounter += 1
            jump maze22
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze21
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze21Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze21Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze21
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze21Menu


label maze22:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze22
            pause .45
            pause .01
            play sound "audio/swishMEDIUM.mp3"
            show slash
            with vpunch
            hide slash
        else:
            scene bg maze22
            pause .6
    else:
        if hardMode:
            scene bg maze22
            with flash
            pause .01
            play sound "audio/swishMEDIUM.mp3"
            show slash
            with vpunch
            hide slash
        else:
            scene bg maze22
            with flash

label maze22Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze22
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze22Menu
        "CENTER":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze2
            $ roomCounter += 1
            jump maze23
        "RIGHT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze22
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze22Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze22Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze22
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze22Menu


label maze23:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze23
            pause .45
        else:
            scene bg maze23
            pause .6
    else:
        scene bg maze23
        with flash

label maze23Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze17
            $ roomCounter += 1
            jump maze24
        "CENTER":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze23Menu
        "RIGHT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze23Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze23Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze23
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze23Menu


label maze24:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze24
            pause .45
        else:
            scene bg maze24
            pause .6
    else:
        scene bg maze24
        with flash

label maze24Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            you "Okay, next room..."
            if hardMode:
                $ roomCounter += 1
                jump maze14
            $ roomCounter += 1
            jump maze25
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze24
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze24Menu
        "RIGHT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze24Menu
        "STAY":
            you "I'm pretty sure this room has an exit..."
            jump maze24Menu
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze24
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze24Menu


label maze25:
    hide screen lifeScreen
    scene black
    play sound "audio/click.mp3"

    if hardMode:
        $ renpy.block_rollback()

    if flashOff:
        if hardMode:
            scene bg maze25
            pause .45
            pause .01
            play sound "audio/wind.mp3"
            show wind
            pause .5
            hide wind
        else:
            scene bg maze25
            pause .6
    else:
        if hardMode:
            scene bg maze25
            with flash
            pause .01
            play sound "audio/wind.mp3"
            show wind
            pause .5
            hide wind
        else:
            scene bg maze25
            with flash

label maze25Menu:
    scene black
    show screen lifeScreen

    if hardMode:
        $ renpy.block_rollback()

    menu:
        "LEFT":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze25
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze25Menu
        "CENTER":
            hide screen lifeScreen
            play sound "audio/swishQUICK.mp3"
            queue sound "audio/punch_HIGH.mp3"
            scene bg maze25
            with flashRed
            with vpunch
            you "OW! Not that way!"
            $ mazeLives -= 1
            if mazeLives <= 0:
                if hardMode:
                    hide screen maze_timer
                    with dissolve
                play music "audio/LOOPS/27funhouseOUT.mp3" noloop
                scene bg redScreen
                with fadeToRed
                pause .6
                hide screen lifeScreen
                scene black
                with dissolve
                jump mazeLose
            jump maze25Menu
        "RIGHT":
            play sound "audio/humanImpact.mp3"
            "*CLANG!*"
            you "A mirror? I can't go this way!"
            jump maze25Menu
        "STAY":
            you "This room feels off..."
            you "Just wait..."
            you "..."
            you "..!"
            you "I think something just changed..."
            if hardMode:
                $ roomCounter += 1
                jump maze5
            jump mazeWin
        "Flashlight ([flashlight]/[maxLight])" if flashlight >= 1:
            $ flashlight -= 1
            jump maze25
        "Flashlight ([flashlight]/[maxLight])" if flashlight == 0:
            play sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            queue sound "audio/click.mp3"
            "Crap... Flashlight's dead..."
            jump maze25Menu

label mazeTimeOut:

    if hardMode:
        $ renpy.block_rollback()

    if hardMode:
        hide screen maze_timer
        with dissolve
    play music "audio/LOOPS/27funhouseOUT.mp3" noloop
    hide wind
    hide screen bloody
    hide slash
    hide screen stareScreen
    scene bg redScreen
    with fadeToRed
    pause .6
    hide screen lifeScreen
    scene black
    with dissolve
    jump mazeLose


label mazeWin:

    if hardMode:
        $ renpy.block_rollback()

    play music "audio/LOOPS/27funhouseOUT.mp3" noloop
    hide screen lifeScreen
    if hardMode:
        if persistent.beatHardMode != True:
            $ persistent.beatHardMode = True
        hide screen maze_timer
        with dissolve
    ".."
    "..."
    "..!"
    scene bg carnival6a
    with dissolve
    "You see it! The exit!"
    scene bg carnival6b
    with dissolve
    "You run forward, but as you do..."
    scene bg carnival6c
    with dissolve
    "...the scenery... {b}shifts{/b}."
    "Just slightly at first..."
    scene bg carnival6d
    with dissolve
    "..."
    "...but you’re running too fast to stop yourself from colliding into the glass."
    scene bg whiteScreen
    with whiteFlash
    "..."
    "..!"
    "Except..."
    play music "audio/LOOPS/28emptyReflectionIN.mp3"
    queue music "audio/LOOPS/28emptyReflectionLOOP.mp3" loop
    "...you don’t quite go {i}into{/i} the glass."
    "You don’t exactly {i}collide{/i} with it either."
    "You simply... {w}pass {b}through{/b} it."
    "And on the other side, you see an endless white void and..."
    "..?"
    show carnival7
    with fade_Red
    "...yourself?"
    "Dozens of you."
    "{i}Hundreds{/i} of you wandering around..."
    "Aimless..."
    "Faceless..."
    "..."
    "And empty..."
    "So empty and listless, they don't even acknowledge your presence."
    you "!!"
    scene bg carnival8b
    with dissolve
    "You try to turn back..."
    "..."
    "...but the glass doesn’t give."
    "Past the glass..."
    scene bg carnival8c
    with dissolve
    pause .1
    scene bg carnival8d
    with dissolve
    pause .1
    scene bg carnival8e
    with dissolve
    pause .1
    play music "audio/LOOPS/28emptyReflectionOUT.mp3" noloop
    scene bg carnival8f
    with dissolve
    pause .6
    "...a familiar black cat walks up and looks at you."
    "You think it meows at you..."
    "..."
    "...but you can’t make out the sound."
    cat "..."
    "It tilts its head..."
    scene bg carnival8d
    with dissolve
    "...then walks away."
    scene bg carnival8a
    with dissolve
    "The glass goes dark..."
    scene bg whiteScreen
    with fade_Red
    "Then you watch helplessly as it disappears completely..."
    scene black
    with dissolve
    ".."
    "..."
    "You’re trapped..."
    "...with only yourself as company."
    "..."
    "Ending 19: You beat the maze :D"
    # if persistent.testingNow:
    #     jump mazeEnd
    if persistent.ending19Done:
        jump mazeEnd
    else:
        $persistent.ending19Done = True
        $persistent.endCounter += 1
        jump mazeEnd



label mazeLose:

    if hardMode:
        $ renpy.block_rollback()

    ".."
    "..."
    "Suddenly..."
    scene bg carnival9a
    with whiteFlash
    "The lights turn on..."
    "Your eyes burn from the sudden brightness..."
    "As your vision adjusts, you see that you're completely surrounded by mirrors..."
    play music "audio/LOOPS/29theyLookBackIN.mp3"
    queue music "audio/LOOPS/29theyLookBackLOOP.mp3" loop
    scene bg carnival9b
    with dissolve
    "The reflections, all grotesque in unique ways..."
    scene bg carnival9c
    with dissolve
    "...look nothing like you."
    scene bg carnival9d
    with dissolve
    "..."
    "But they {i}do{/i} look..."
    show screen blackOut
    "..."
    scene bg carnival9a
    with dissolve
    "...{b}h u n g r y.{/b}"
    hide screen blackOut
    you "!!"
    "You back up. {w}You don’t know where to go. {w}Was there even a way out to begin with?"
    scene bg carnival10a
    with dissolve
    "You bump back into a mirror..."
    scene bg carnival10b
    pause .1
    scene bg carnival10c
    pause .1
    scene bg carnival10d
    pause .1
    scene bg carnival10e
    pause .1
    scene bg carnival10f
    pause .1
    play sound "audio/humanImpact.mp3" volume 0.3
    scene bg carnival10g
    with vpunch
    pause .1
    "...and feel a hand firmly grip your shoulder."
    scene bg redScreen
    with p_Red
    play sound "audio/crunch.mp3"
    show screen bloody
    with vpunch
    "{size=+25}{b}CHOMP!!{/b}{/size}"
    you "{b}GAHH!!{/b}" with vpunch
    "There’s a sharp pain in your other shoulder."
    scene black
    hide screen bloody
    with dissolve
    pause .6
    show carnival11
    with dissolve
    "You rip away, looking back to see some... {i}{b}thing{/b}{/i} leaning out of the mirror."
    "Its face has no features... {w}Save for a large gaping mouth..."
    "...stained in your blood."
    play music "audio/LOOPS/29theyLookBackOUT.mp3" noloop
    scene black
    with dissolve
    "Looking around in a panic, you think that the mirrors feel closer than before."
    "The path you'd come in from is long gone."
    play music "audio/heartbeatEcho.mp3" loop
    "You’re surrounded... and every time you blink..."
    "...you could {i}swear{/i} the mirrors were getting closer..."
    "And closer..."
    "...and closer."
    "Your horrifying reflections looking hungrier..."
    "...and hungrier..."
    "...and hungr--{w=0.3}{nw}"
    stop music
    scene black
    scene bg redScreen
    with p_Red
    play sound "audio/punch_LOW.mp3"
    show screen bloody
    with vpunch
    pause .6
    hide screen bloody
    scene black
    with dissolve
    ".."
    "..."
    "Ending 20: You failed the maze :("
    # if persistent.testingNow:
    #     jump mazeEnd
    if persistent.ending20Done:
        jump mazeEnd
    else:
        $persistent.ending20Done = True
        $persistent.endCounter += 1
        jump mazeEnd



label mazeEnd:
    # $ persistent.testingNow = False

    return
