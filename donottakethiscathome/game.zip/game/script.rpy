﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define persistent.menuMusic = "audio/rainLOOP.mp3"

define who = Character("???")
define you = Character("You")
define cat = Character("Cat")

default persistent.endCounter = 0
default persistent.story1 = 0
default persistent.story2 = 0
default persistent.story3 = 0
# default persistent.testingNow = False
default persistent.story1Scare = False
default persistent.story2Scare = False
default persistent.readyNow = False


image menu1:
    "MENU/menu1a.png"
    pause .1
    "MENU/menu1b.png"
    pause .1
    "MENU/menu1c.png"
    pause .1
    repeat

image menu3:
    "MENU/menu3a.png"
    pause 5
    "MENU/menu3b.png"
    pause .1
    "MENU/menu3c.png"
    pause .1
    "MENU/menu3d.png"
    pause .1
    "MENU/menu3e.png"
    pause .1
    "MENU/menu3f.png"
    pause .1
    "MENU/menu3g.png"
    pause .1
    "MENU/menu3h.png"
    pause 10
    "MENU/menu3f.png"
    pause .1
    "MENU/menu3g.png"
    pause .1
    repeat


image slash:
    "slash1.png"
    pause .05
    "slash2.png"
    pause .03
    "slash3.png"
    pause .02
    "slash4.png"
    pause .01

init:
    image bg blackScreen = "blackSCREEN.png"
    image bg whiteScreen = "whiteSCREEN.png"
    image bg redScreen = "redSCREEN.png"
    image bg dreadScreen = "dreadSCREEN.png"
    image bg street1 = "normalBGs/street01.png"
    image bg street2 = "normalBGs/street02.png"
    image bg street3 = "normalBGs/street03.png"
    image bg street4 = "normalBGs/street04.png"
    image bg street5 = "normalBGs/street05.png"
    image bg alley1 = "normalBGs/alley01.png"
    image bg alley2 = "normalBGs/alley02.png"
    image bg aptDoor = "normalBGs/apt_DOOR.png"
    image bg aptFront = "normalBGs/apt_FRONT.png"
    image bg aptLivingRoom = "normalBGs/apt_LIVINGRoom.png"
    image bg alleyCat1 = "CAT/downNeutral.png"
    image bg alleyCat2 = "CAT/upNeutral.png"
    image bg upSad = "CAT/upSad.png"
    image bg upSadMeow = "CAT/upSad_meow.png"
    image bg upBlink = "CAT/upBlink.png"
    image bg upBlinkSmile = "CAT/upBlink_smile.png"
    image bg upBlinkMeow = "CAT/upBlink_meow.png"
    image bg upHappy = "CAT/upHappy.png"
    image bg upAngry = "CAT/upAngry.png"
    image bg upAngryMeow = "CAT/upAngry_meow.png"
    image bg upMeow = "CAT/upNeutral_meow.png"
    image bg upWide = "CAT/upWide_light.png"
    image bg upWideDark = "CAT/upWide_dark.png"
    image bg upSlits = "CAT/upSlits_light.png"
    image bg upSlitsDark = "CAT/upSlits_dark.png"
    image bg downBlinkMeow = "CAT/downBlink_meow.png"
    image bg downBlinkSmile = "CAT/downBlink_smile.png"
    image bg downMeow = "CAT/downNeutral_meow.png"


    $ whiteFlash = Fade(.08, 0.1, .5, color="#FFFFFF")


screen blackOut():
    add Image("blackSCREEN.png")

screen whiteOut():
    add Image("whiteSCREEN.png")

screen dread():
    add Image("dreadSCREEN.png")

screen redOut():
    add Image("redSCREEN.png")

screen blank():
    add Image("blankFrame.png")

screen bloody():
    add Image("bloodScreen.png")

screen stareScreen():
    add Image("stare1.png") alpha 0.9

screen languageselect():
    vbox:
        xalign 0.5 yalign 0.5
        textbutton "English" action [ Language(None), SetVariable("_preferences.language", "eng"), Jump("afterLanguage") ]
        textbutton "Português BR" action [ Language("pt_br"), Jump("afterLanguage") ]

# The game starts here.
label splashscreen:

    if _preferences.language == None:
        call screen languageselect

    label afterLanguage:

    #scene black
    #with Pause(1)

    show text "This game is not suitable for children or the easily disturbed.\n\nIt includes depictions of horror elements, human/animal violence and death,\nabuse/abusive relationship(s), disturbing images, loud noises, flashing images/lights and more.\nIndividuals suffering from anxiety, depression or certain fears/phobias may not have a safe experience playing this game.\n\nFor full list of content/trigger warnings go to 'About' section in the game's main menu." with dissolve
    "\ "
    hide text with dissolve
    pause .5
    show text "Please take care of yourself." with dissolve
    "\ "
    hide text with dissolve
    pause 1.75
    return


label start:
    stop music

#label testingNow:
#    menu:
#        "TEST MENU MUSIC":
#            menu:
#                "1-2":
#                    jump prologueEND2
#                "3":
#                    $ persistent.endCounter = 18
#                    return
#                "4":
#                    $ persistent.endCounter = 37
#                    return
#                "5":
#                    $ persistent.ending39Done = True
#                    return
#
#        "TEST GAME":
#            $ persistent.testingNow = True
#            jump chaseTest
#        "Continue to game":
#            $ persistent.testingNow = False
#            jump prologueFIRST

# label chaseTest:
#     menu:
#         "See end image":
#             jump hereAgain
#         "Test chase?":
#             jump finalShowdownChase
#         "Test prologue?":
#             jump prologue_start
#         "Test Maze?":
#             jump mazeStart
#         "Test endgame start?":
#             $ persistent.questionCounter = 0
#             $ persistent.question1 = 0
#             $ persistent.question2 = 0
#             $ persistent.question3 = 0
#             $ persistent.question4 = 0
#             $ persistent.question5 = 0
#             jump encounterCat
#         "Keep testing game":
#             jump mainGameStart
#         "Test game with variables/persistence":
#             jump mainGame
#         "See their story1":
#             $persistent.testingNow = True
#             jump theirLove1
#         "See their story2":
#             $persistent.testingNow = True
#             jump theirLove2
#         "See their story3":
#             $persistent.testingNow = True
#             jump theirLove3

label prologueFIRST:
    if persistent.prologue:
        jump mainGame
    else:
        jump prologue_start

label mainGame:
    if persistent.ending39Done:
        jump hereAgain
    if persistent.endCounter == 37 and persistent.story3 == 0 and persistent.ending36Done == True:
        jump theirLove3
    if persistent.ending36Done:
        jump encounterCat
    if persistent.endCounter >= 36:
        "..."
        "You've been enjoying yourself, haven't you?"
        "Yes... {w}{i}I{/i} as well~"
        "..."
        "Still..."
        "All good things must come to an end..."
        "...And I believe you are {b}ready.{/b}"
        scene bg alleyCat2
        with fade_Red
        pause 3
        $ persistent.readyNow = True
        jump mainChoiceMenu
    if persistent.endCounter == 24 and persistent.story2 == 0:
        jump theirLove2
    if persistent.endCounter == 12 and persistent.story1 == 0:
        jump theirLove1
    else:
        jump mainGameStart

label mainGameStart:
    ".."
    "..."
    "You're walking..."
    "Right. Of course."
    "It's the first time in a while that you've felt like going out..."
    "..."
    "And you're..."
    "...actually glad that you did."
    scene bg street2
    with dissolve
    if persistent.story2Scare:
        play music "audio/birdsUnhinged.mp3" volume 0.5
        "weather good today"
        "that good thing"
        "maybe good luck too"
        "yes lucky"
        play sound "audio/heartbeat.mp3" loop
        show static
        with dissolve
        "{w=0.6}lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}{nw}"
        show cinemaStare
        with dissolve
        "lucky lucky lucky lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}lucky {w=0.6}{nw}"
        show screen dread
        with dissolve
        "lucky lucky lucky lucky lucky lucky lucky lucky {w=0.3}lucky {w=0.3}lucky {w=0.3}lucky {w=0.3}lucky {w=0.6}{nw}"
        stop music
        show screen blackOut
        hide static
        hide cinemaStare
        hide screen dread
        scene black
        hide screen blackOut
        show screen catEyesFade
        with fade_Red
        pause 2
        show text "Or maybe it was..." at truecenter
        with dissolve
        "\ "
        hide text
        stop sound
        show text "{w=0.6}f{w=0.6}a{w=0.6}t{w=0.6}e{w=0.6}~{w=0.6}?" at truecenter
        pause 3
        hide text
        hide screen catEyesFade
        scene bg street2
        play sound "audio/birdsNormal.mp3" volume 0.1
        you "!!!" with vpunch
        you "..."
        $persistent.story2Scare = False
    elif persistent.story1Scare:
        play sound "audio/LOOPS/50a_theirThemeLOOP.mp3" volume 0.2 loop
        "The weather is absolutely {i}perfect{/i} today."
        "That's a good sign, right?"
        "Maybe your luck is finally starting to turn around."
        $persistent.story1Scare = False
    else:
        play sound "audio/birdsNormal.mp3" volume 0.1 loop
        "The weather is absolutely {i}perfect{/i} today."
        "That's a good sign, right?"
        "Maybe your luck is finally starting to turn around."

    stop sound fadeout 2.5
    scene bg street1
    with dissolve
    "You tentatively allow yourself to feel excited for the possibilities of where you could go or what you could do..."
    "...Maybe even {i}who{/i} you could meet."
    "You're so deep in thought that you almost miss it."
    play sound "audio/cat_sadLONG.mp3" volume 0.01
    who "{size=-5}{alpha=0.4}Meow...{/alpha}{/size}"
    you "{i}Huh? What was that?{/i}"
    scene bg alley1
    with dissolve
    "Curiosity guiding your steps, you follow the sound to the entrance of a lonely alleyway."
    "The sunlight only {i}just{/i} manages to reach down in between the tall buildings on either side."
    "You timidly enter the alley and walk forward, the loose gravel and scattered debris on the ground softening your steps."
    play sound "audio/cat_sad.mp3" volume 0.05
    who "Meow! Meow!"
    "Finally the sound's source comes into view in the warm, almost ethereal light of the alley..."
    scene black
    with dissolve
    "At the end of the alley..."
    "...in a big cardboard box..."
    ".."
    "..."
    scene bg alleyCat1
    with dissolve
    play music "audio/LOOPS/03catTheme.mp3" loop
    "...is a cat."
    you "Huh. Guess that should've been... obvious..?"
    scene bg downMeow
    with dissolve
    play sound "audio/cat_sadLONG.mp3" volume 0.1
    cat "Meow!"
    scene bg alleyCat1
    "It's an interesting looking cat. Its pretty yellow eyes shine like gold among the dark sea of its black fur."
    scene bg alleyCat2
    with dissolve
    "It puts its front paws up on the edge of the box and looks up at you."
    scene bg upMeow
    with dissolve
    play sound "audio/cat_happy.mp3" volume 0.1
    cat "Meow..."
    scene bg alleyCat2
    you "!!!" with hpunch
    you "{i}S-{w}So..!{/i}"
    you "..."
    you "..?"
    you "You look so..."
    ".."
    "...{i}familiar{/i}."
    "...Right?"
    scene bg upMeow
    with hpunch
    play sound "audio/cat_happy.mp3" volume 0.2
    cat "Meow!"
    scene bg alleyCat2
    "..."
    "Then again, it {i}is{/i} a cat. Not many different ways for a standard black cat to look, after all."
    "..."
    "{i}This{/i} one sure is a cutie, though."
    "Just look..."
    "It's not glaring at you or hissing at you for getting this close like other stray cats have in the past."
    "It's just sitting there patiently..."
    "Waiting for you to do something..."

if not renpy.music.is_playing('music'):
    play music "audio/LOOPS/03catTheme.mp3" loop

label mainChoiceMenu:
    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/03catTheme.mp3" loop
    menu:
        "Take cat home!":
            jump mainChoice2
        "Do not take cat home...":
            jump mainChoice1

label mainChoice1:
    "Sadly, as cute as the cat is..."
    "..."
    $ renpy.music.set_volume(0.0, 0, "music")
    show screen blackOut
    "{size=-10}...you'd {b}never{/b} take this {color=#FF0000}{b}thing{/b}{/color} home with you.{/size}"
    $ renpy.music.set_volume(1.0, 0, "music")
    hide screen blackOut
    ".."
    "..."
    "...you just {i}can't{/i} take it home with you."
    "You're a responsible adult."
    scene bg upBlink
    pause .1
    scene bg alleyCat2
    pause .6
    scene bg upMeow
    play sound "audio/cat_confused.mp3" volume 0.1
    cat "Meow..."
    scene bg alleyCat2
    "Y-You {i}are!{/i}"
    "With rent and bills to pay for! Not to mention you need to buy food to survive too!"
    "There's no way {i}you{/i} could care for a cat long term, right?"
    "You can barely afford this little outing on your day off..."
    scene bg upBlinkMeow
    with hpunch
    play sound "audio/cat_happy.mp3" volume 0.2
    cat "Meow!"
    scene bg alleyCat2
    you "..."
    "What to do..."
    jump inAlley_start

label mainChoice2:
    cat "..."
    you "..."
    scene bg upSad
    with dissolve
    pause .3
    scene bg upSadMeow
    with dissolve
    play sound "audio/cat_sad.mp3" volume 0.1
    cat "Meow..."
    scene bg upSad
    you "..."
    you "Well... Why not?"
    scene bg alleyCat2
    "Right?"
    scene bg upBlinkMeow
    with hpunch
    play sound "audio/cat_happy.mp3" volume 0.1
    cat "Meow!"
    scene bg upBlinkSmile
    pause .3
    scene black
    with dissolve
    "You barely reach out your arms before the cat eagerly leaps into them and climbs up onto your shoulders."
    "It butts its head into your temple nuzzling against it."
    play sound "audio/cat_purr.mp3" volume 0.2
    cat "Purr... Purr... Purr..."
    you "..."
    you "Hehe..."
    "You can't help but smile at the cat's enthusiasm."
    scene bg alley2
    with dissolve
    you "Let's get you out of here, yeah?"
    play sound "audio/cat_purr.mp3" volume 0.1
    cat "Purr..."
    stop music fadeout 2
    scene bg street1
    with dissolve
    "On the way home, you briefly consider getting cat food..."
    ".."
    "..."
    show screen blackOut
    "{size=-5}But that would be a waste of time.{/size}"
    hide screen blackOut
    "..?"
    "You shrug at the odd feeling and move on."
    scene bg aptFront
    with dissolve
    "You live in a modest apartment."
    scene bg aptDoor
    with dissolve
    "One bedroom. One bathroom."
    "One {i}you{/i} living alone in it..."
    scene black
    with dissolve
    "So it feels weird having another living being inside it after so long."
    "Even if it {i}is{/i} just a cat."
    play music "audio/LOOPS/04homeWithYou.mp3" loop
    scene bg aptLivingRoom
    with dissolve
    "After locking the front door and placing the cat on the floor, you wait for it to walk away and explore the new environment."
    "..."
    "But it simply sits and looks up at you expectantly..."
    jump atHome_start


    return
