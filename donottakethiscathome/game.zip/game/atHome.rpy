﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define cat2 = Character("Cat #2")

default catNotFound = 0
default seekLivingRoomDone = 0
default seekKitchenDone = 0
default seekHallwayDone = 0

default hideArmchair = 0
default hideKitchen = 0
default hideHallway = 0
default hideHallCloset = 0
default hideGetOut = 0
default hideBathroom = 0
default hideCouch = 0

default clock = 100


image tvStatic:
    "normalBGs/aptTV_Floor04a.png"
    pause .1
    "normalBGs/aptTV_Floor04b.png"
    pause .1
    "normalBGs/aptTV_Floor04c.png"
    pause .1
    repeat

image tvMonster:
    "normalBGs/aptTV_Floor07a.png"
    pause .1
    "normalBGs/aptTV_Floor07b.png"
    pause .1
    "normalBGs/aptTV_Floor07c.png"
    pause .1
    repeat

image napAlone1:
    "normalBGs/aptNapALONE1a.png"
    pause .1
    "normalBGs/aptNapALONE1b.png"
    pause .1
    "normalBGs/aptNapALONE1c.png"
    pause .1
    repeat

image napAlone4:
    "normalBGs/aptNapALONE4a.png"
    pause .1
    "normalBGs/aptNapALONE4b.png"
    pause .1
    "normalBGs/aptNapALONE4c.png"
    pause .1
    repeat

image pettingEnd:
    "normalBGs/aptPet07a.png"
    pause .1
    "normalBGs/aptPet07b.png"
    pause .1
    "normalBGs/aptPet07c.png"
    pause .1
    repeat

image mysteryFood:
    "normalBGs/aptFeed01a.png"
    pause 6
    "normalBGs/aptFeed01b.png"
    pause .07
    "normalBGs/aptFeed01c.png"
    pause .07
    "normalBGs/aptFeed01d.png"
    pause .07
    "normalBGs/aptFeed01e.png"
    pause .07
    "normalBGs/aptFeed01f.png"
    pause .07
    "normalBGs/aptFeed01g.png"
    pause .07
    repeat

image hiccup:
    "normalBGs/aptFeed02a.png"
    pause .6
    "normalBGs/aptFeed02b.png"
    pause .1
    "normalBGs/aptFeed02c.png"
    pause .1
    "normalBGs/aptFeed02d.png"
    pause .1
    "normalBGs/aptFeed02e.png"
    pause .1
    "normalBGs/aptFeed02f.png"
    pause .1
    "normalBGs/aptFeed02g.png"
    pause .1
    "normalBGs/aptFeed02h.png"
    pause .1
    "normalBGs/aptFeed02i.png"
    pause .1
    "normalBGs/aptFeed02j.png"
    pause .1
    "normalBGs/aptFeed02k.png"
    pause .1
    "normalBGs/aptFeed02l.png"
    pause .1
    repeat

image meatEye:
    "normalBGs/aptFeed11d.png"
    pause .1
    "normalBGs/aptFeed11e.png"
    pause .1
    "normalBGs/aptFeed11f.png"
    pause .1
    "normalBGs/aptFeed11g.png"
    pause .1
    "normalBGs/aptFeed11h.png"
    pause .1
    "normalBGs/aptFeed11i.png"
    pause .1
    "normalBGs/aptFeed11j.png"
    pause .1
    "normalBGs/aptFeed11k.png"
    pause .1
    "normalBGs/aptFeed11l.png"
    pause .1
    "normalBGs/aptFeed11m.png"
    pause .1
    "normalBGs/aptFeed11n.png"
    pause .1
    "normalBGs/aptFeed11o.png"
    pause .1
    repeat

image meatEyeLook:
    "normalBGs/aptFeed12b.png"
    pause .1
    "normalBGs/aptFeed12c.png"
    pause .1
    "normalBGs/aptFeed12d.png"
    pause .1
    "normalBGs/aptFeed12e.png"
    pause .1
    repeat

image yarn5:
    "normalBGs/aptYarn05a.png"
    pause 3
    "normalBGs/aptYarn05b.png"
    pause .15
    "normalBGs/aptYarn05c.png"
    pause .15
    "normalBGs/aptYarn05d.png"
    pause .15
    "normalBGs/aptYarn05e.png"
    pause .15
    "normalBGs/aptYarn05f.png"
    pause 3
    "normalBGs/aptYarn05g.png"
    pause .15
    repeat

image yarn6:
    "normalBGs/aptYarn06a.png"
    pause 2
    "normalBGs/aptYarn06b.png"
    pause .15
    "normalBGs/aptYarn06c.png"
    pause .15
    "normalBGs/aptYarn06d.png"
    pause .15
    "normalBGs/aptYarn06e.png"
    pause .15
    "normalBGs/aptYarn06f.png"
    pause .15
    "normalBGs/aptYarn06g.png"
    pause .15
    "normalBGs/aptYarn06h.png"
    pause .15
    "normalBGs/aptYarn06i.png"
    pause .15
    repeat

image hide5a:
    "normalBGs/aptHide05a.png"
    pause .1
    "normalBGs/aptHide05b.png"
    pause .1
    "normalBGs/aptHide05c.png"
    pause .1
    repeat

image hide5b:
    "normalBGs/aptHide05d.png"
    pause .1
    "normalBGs/aptHide05e.png"
    pause .1
    "normalBGs/aptHide05f.png"
    pause .1
    repeat

image cleanC2:
    "normalBGs/aptCleanC02a.png"
    pause .1
    "normalBGs/aptCleanC02b.png"
    pause .1
    "normalBGs/aptCleanC02c.png"
    pause .1
    "normalBGs/aptCleanC02d.png"
    pause .1
    "normalBGs/aptCleanC02e.png"
    pause .1
    "normalBGs/aptCleanC02f.png"
    pause .1
    repeat

image cleanC3:
    "normalBGs/aptCleanC03a.png"
    pause .1
    "normalBGs/aptCleanC03b.png"
    pause .1
    "normalBGs/aptCleanC03c.png"
    pause .1
    "normalBGs/aptCleanC03d.png"
    pause .1
    "normalBGs/aptCleanC03e.png"
    pause .1
    "normalBGs/aptCleanC03f.png"
    pause .1
    repeat

image cleanC4:
    "normalBGs/aptCleanC04a.png"
    pause .1
    "normalBGs/aptCleanC04b.png"
    pause .1
    "normalBGs/aptCleanC04c.png"
    pause .1
    "normalBGs/aptCleanC04d.png"
    pause .1
    "normalBGs/aptCleanC04e.png"
    pause .1
    "normalBGs/aptCleanC04f.png"
    pause .1
    repeat

image cleanC5:
    "normalBGs/aptCleanC05a.png"
    pause .1
    "normalBGs/aptCleanC05b.png"
    pause .1
    "normalBGs/aptCleanC05c.png"
    pause .1
    "normalBGs/aptCleanC05d.png"
    pause .1
    "normalBGs/aptCleanC05e.png"
    pause .1
    "normalBGs/aptCleanC05f.png"
    pause .1
    repeat


init:
    image bg aptHall = "normalBGs/apt_HALL.png"
    image bg aptHallDark = "normalBGs/apt_hallDARK.png"
    image bg aptKitchen = "normalBGs/apt_KITCHEN.png"
    image bg mess1 = "normalBGs/aptMess01.png"
    image bg mess2 = "normalBGs/aptMess02.png"
    image bg mess3 = "normalBGs/aptMess03.png"
    image bg mess4 = "normalBGs/aptMess04.png"
    image bg mess5 = "normalBGs/aptMess05.png"
    image bg mess6 = "normalBGs/aptMess06.png"
    image bg mess7 = "normalBGs/aptMess07.png"
    image bg mess8 = "normalBGs/aptMess08.png"
    image bg clone1 = "normalBGs/aptClone01.png"
    image bg clone2 = "normalBGs/aptClone02.png"
    image bg clone3 = "normalBGs/aptClone03.png"
    image bg clone4 = "normalBGs/aptClone04.png"
    image bg clone5 = "normalBGs/aptClone05.png"
    image bg clone6 = "normalBGs/aptClone06.png"
    image bg clone7 = "normalBGs/aptClone07.png"
    image bg clone8a = "normalBGs/aptClone08a.png"
    image bg clone8b = "normalBGs/aptClone08b.png"
    image bg wall1 = "normalBGs/aptWall01.png"
    image bg wall2 = "normalBGs/aptWall02.png"
    image bg wall3 = "normalBGs/aptWall03.png"
    image bg wall4 = "normalBGs/aptWall04.png"
    image bg armchair = "normalBGs/aptArmchair.png"
    image bg tvBehind1 = "normalBGs/aptTV_Behind01.png"
    image bg tvBehind2 = "normalBGs/aptTV_Behind02.png"
    image bg tvBehind3 = "normalBGs/aptTV_Behind03.png"
    image bg tvFloor1 = "normalBGs/aptTV_Floor01.png"
    image bg tvFloor2 = "normalBGs/aptTV_Floor02.png"
    image bg tvFloor3 = "normalBGs/aptTV_Floor03.png"
    image bg tvFloor4a = "normalBGs/aptTV_Floor04a.png"
    image bg tvFloor4b = "normalBGs/aptTV_Floor04b.png"
    image bg tvFloor4c = "normalBGs/aptTV_Floor04c.png"
    image bg tvFloor5 = "normalBGs/aptTV_Floor05.png"
    image bg tvFloor6 = "normalBGs/aptTV_Floor06.png"
    image bg tvFloor7a = "normalBGs/aptTV_Floor07a.png"
    image bg tvFloor7b = "normalBGs/aptTV_Floor07b.png"
    image bg tvFloor7c = "normalBGs/aptTV_Floor07c.png"
    image bg cabinet = "normalBGs/apt_bathCabinet.png"
    image bg cabinetDark = "normalBGs/apt_bathCabinetDARK.png"
    image bg cabinetOpen = "normalBGs/apt_bathCabinetOPEN.png"
    image bg aptBath_O = "normalBGs/apt_bathroomOpenLight.png"
    image bg aptBath_C = "normalBGs/apt_bathroomClosedLight.png"
    image bg aptBath_DO = "normalBGs/apt_bathroomOpenDark.png"
    image bg aptBath_DC = "normalBGs/apt_bathroomClosedDark.png"
    image bg tvSit1 = "normalBGs/aptTV_Sit01.png"
    image bg tvSit2 = "normalBGs/aptTV_Sit02.png"
    image bg tvSit3 = "normalBGs/aptTV_Sit03.png"
    image bg tvSit4 = "normalBGs/aptTV_Sit04.png"
    image bg tvSit5 = "normalBGs/aptTV_Sit05.png"
    image bg tvSit6 = "normalBGs/aptTV_Sit06.png"
    image bg tvSitScare1a = "normalBGs/aptTV_SitScare1a.png"
    image bg tvSitScare1b = "normalBGs/aptTV_SitScare1b.png"
    image bg tvSitScare1c = "normalBGs/aptTV_SitScare1c.png"
    image bg tvSitScare1d = "normalBGs/aptTV_SitScare1d.png"
    image bg tvSitScare2a = "normalBGs/aptTV_SitScare2a.png"
    image bg tvSitScare2b = "normalBGs/aptTV_SitScare2b.png"
    image bg tvSitScare2c = "normalBGs/aptTV_SitScare2c.png"
    image bg tvSitScare3a = "normalBGs/aptTV_SitScare3a.png"
    image bg tvSitScare3b = "normalBGs/aptTV_SitScare3b.png"
    image bg tvSitScare3c = "normalBGs/aptTV_SitScare3c.png"
    image bg tvSitScare3d = "normalBGs/aptTV_SitScare3d.png"
    image bg aptBedroom = "normalBGs/apt_BEDROOMDay.png"
    image bg aptBedroomNight = "normalBGs/apt_BEDROOMNight.png"
    image bg aptBedroomDark = "normalBGs/apt_BEDROOMDark.png"
    image bg nap1 = "normalBGs/aptNap01.png"
    image bg nap2 = "normalBGs/aptNap02.png"
    image bg nap3 = "normalBGs/aptNap03.png"
    image bg napAlone2 = "normalBGs/aptNapALONE2.png"
    image bg napAlone3 = "normalBGs/aptNapALONE3.png"
    image bg napTogether1 = "normalBGs/aptNapTOGETHER1.png"
    image bg napTogether2 = "normalBGs/aptNapTOGETHER2.png"
    image bg napTogether3 = "normalBGs/aptNapTOGETHER3.png"
    image bg pet1 = "normalBGs/aptPet01.png"
    image bg pet2 = "normalBGs/aptPet02.png"
    image bg pet3 = "normalBGs/aptPet03.png"
    image bg pet4 = "normalBGs/aptPet04.png"
    image bg pet5 = "normalBGs/aptPet05.png"
    image bg pet6 = "normalBGs/aptPet06.png"
    image bg pet7a = "normalBGs/aptPet07a.png"
    image bg pet7b = "normalBGs/aptPet07b.png"
    image bg pet7c = "normalBGs/aptPet07c.png"
    image bg pet8a = "normalBGs/aptPet08a.png"
    image bg pet8b = "normalBGs/aptPet08b.png"
    image bg pet8c = "normalBGs/aptPet08c.png"
    image bg feed1h = "normalBGs/aptFeed01h.png"
    image bg feed2a = "normalBGs/aptFeed02a.png"
    image bg feed2b = "normalBGs/aptFeed02b.png"
    image bg feed2c = "normalBGs/aptFeed02c.png"
    image bg feed2d = "normalBGs/aptFeed02d.png"
    image bg feed2e = "normalBGs/aptFeed02e.png"
    image bg feed2f = "normalBGs/aptFeed02f.png"
    image bg feed2g = "normalBGs/aptFeed02g.png"
    image bg feed2h = "normalBGs/aptFeed02h.png"
    image bg feed2i = "normalBGs/aptFeed02i.png"
    image bg feed2j = "normalBGs/aptFeed02j.png"
    image bg feed2k = "normalBGs/aptFeed02k.png"
    image bg feed2l = "normalBGs/aptFeed02l.png"
    image bg feed3 = "normalBGs/aptFeed03.png"
    image bg feed4 = "normalBGs/aptFeed04.png"
    image bg feed5 = "normalBGs/aptFeed05.png"
    image bg feed6 = "normalBGs/aptFeed06.png"
    image bg feed7 = "normalBGs/aptFeed07.png"
    image bg feed8 = "normalBGs/aptFeed08.png"
    image bg feed9a = "normalBGs/aptFeed09a.png"
    image bg feed9b = "normalBGs/aptFeed09b.png"
    image bg feed9c = "normalBGs/aptFeed09c.png"
    image bg feed9d = "normalBGs/aptFeed09d.png"
    image bg feed9e = "normalBGs/aptFeed09e.png"
    image bg feed9f = "normalBGs/aptFeed09f.png"
    image bg feed10 = "normalBGs/aptFeed10.png"
    image bg feed11a = "normalBGs/aptFeed11a.png"
    image bg feed11b = "normalBGs/aptFeed11b.png"
    image bg feed11c = "normalBGs/aptFeed11c.png"
    image bg feed12a = "normalBGs/aptFeed12a.png"
    image bg feed12b = "normalBGs/aptFeed12b.png"
    image bg feed12f = "normalBGs/aptFeed12f.png"
    image bg feed13a = "normalBGs/aptFeed13a.png"
    image bg feed13b = "normalBGs/aptFeed13b.png"
    image bg feed14a = "normalBGs/aptFeed14a.png"
    image bg feed14b = "normalBGs/aptFeed14b.png"
    image bg feed14c = "normalBGs/aptFeed14c.png"
    image bg feed14d = "normalBGs/aptFeed14d.png"
    image bg feed14e = "normalBGs/aptFeed14e.png"
    image bg feed15a = "normalBGs/aptFeed15a.png"
    image bg feed15b = "normalBGs/aptFeed15b.png"
    image bg feed16 = "normalBGs/aptFeed16.png"
    image bg feed17a = "normalBGs/aptFeed17a.png"
    image bg feed17b = "normalBGs/aptFeed17b.png"
    image bg yarn1a = "normalBGs/aptYarn01a.png"
    image bg yarn1b = "normalBGs/aptYarn01b.png"
    image bg yarn1c = "normalBGs/aptYarn01c.png"
    image bg yarn2a = "normalBGs/aptYarn02a.png"
    image bg yarn2b = "normalBGs/aptYarn02b.png"
    image bg yarn2c = "normalBGs/aptYarn02c.png"
    image bg yarn2d = "normalBGs/aptYarn02d.png"
    image bg yarn2e = "normalBGs/aptYarn02e.png"
    image bg yarn2f = "normalBGs/aptYarn02f.png"
    image bg yarn2g = "normalBGs/aptYarn02g.png"
    image bg yarn2h = "normalBGs/aptYarn02h.png"
    image bg yarn2i = "normalBGs/aptYarn02i.png"
    image bg yarn3a = "normalBGs/aptYarn03a.png"
    image bg yarn3b = "normalBGs/aptYarn03b.png"
    image bg yarn3c = "normalBGs/aptYarn03c.png"
    image bg yarn4a = "normalBGs/aptYarn04a.png"
    image bg yarn4b = "normalBGs/aptYarn04b.png"
    image bg yarn4c = "normalBGs/aptYarn04c.png"
    image bg yarn7a = "normalBGs/aptYarn07a.png"
    image bg yarn7b = "normalBGs/aptYarn07b.png"
    image bg laser1a = "normalBGs/aptLaser01a.png"
    image bg laser1b = "normalBGs/aptLaser01b.png"
    image bg laser1c = "normalBGs/aptLaser01c.png"
    image bg laser2a = "normalBGs/aptLaser02a.png"
    image bg laser2b = "normalBGs/aptLaser02b.png"
    image bg laser2c = "normalBGs/aptLaser02c.png"
    image bg laser2d = "normalBGs/aptLaser02d.png"
    image bg laser2e = "normalBGs/aptLaser02e.png"
    image bg laser3 = "normalBGs/aptLaser03.png"
    image bg laser4a = "normalBGs/aptLaser04a.png"
    image bg laser4b = "normalBGs/aptLaser04b.png"
    image bg laser5 = "normalBGs/aptLaser05.png"
    image bg laser6a = "normalBGs/aptLaser06a.png"
    image bg laser6b = "normalBGs/aptLaser06b.png"
    image bg laser6c = "normalBGs/aptLaser06c.png"
    image bg laser6d = "normalBGs/aptLaser06d.png"
    image bg laser6e = "normalBGs/aptLaser06e.png"
    image bg hide1a = "normalBGs/aptHide01a.png"
    image bg hide1b = "normalBGs/aptHide01b.png"
    image bg hide1c = "normalBGs/aptHide01c.png"
    image bg hide1d = "normalBGs/aptHide01d.png"
    image bg hide1e = "normalBGs/aptHide01e.png"
    image bg hide2a = "normalBGs/aptHide02a.png"
    image bg hide2b = "normalBGs/aptHide02b.png"
    image bg hide2c = "normalBGs/aptHide02c.png"
    image bg hide2d = "normalBGs/aptHide02d.png"
    image bg hide2e = "normalBGs/aptHide02e.png"
    image bg hide2f = "normalBGs/aptHide02f.png"
    image bg hide2g = "normalBGs/aptHide02g.png"
    image bg hide2h = "normalBGs/aptHide02h.png"
    image bg hide2i = "normalBGs/aptHide02i.png"
    image bg hide3a = "normalBGs/aptHide03a.png"
    image bg hide3b = "normalBGs/aptHide03b.png"
    image bg hide4 = "normalBGs/aptHide04.png"
    image bg hide6a = "normalBGs/aptHide06a.png"
    image bg hide6b = "normalBGs/aptHide06b.png"
    image bg hide6c = "normalBGs/aptHide06c.png"
    image bg hide6d = "normalBGs/aptHide06d.png"
    image bg hide6e = "normalBGs/aptHide06e.png"
    image bg hide7a = "normalBGs/aptHide07a.png"
    image bg hide7b = "normalBGs/aptHide07b.png"
    image bg hide7c = "normalBGs/aptHide07c.png"
    image bg hide7d = "normalBGs/aptHide07d.png"
    image bg hide7e = "normalBGs/aptHide07e.png"
    image bg hide7f = "normalBGs/aptHide07f.png"
    image bg hide7g = "normalBGs/aptHide07g.png"
    image bg hide7h = "normalBGs/aptHide07h.png"
    image bg cleanQ1a = "normalBGs/aptCleanQ01a.png"
    image bg cleanQ1b = "normalBGs/aptCleanQ01b.png"
    image bg cleanQ1c = "normalBGs/aptCleanQ01c.png"
    image bg cleanQ1d = "normalBGs/aptCleanQ01d.png"
    image bg cleanQ2a = "normalBGs/aptCleanQ02a.png"
    image bg cleanQ2b = "normalBGs/aptCleanQ02b.png"
    image bg cleanQ2c = "normalBGs/aptCleanQ02c.png"
    image bg cleanQ2d = "normalBGs/aptCleanQ02d.png"
    image bg cleanQ2e = "normalBGs/aptCleanQ02e.png"
    image bg cleanC1a = "normalBGs/aptCleanC01a.png"
    image bg cleanC1b = "normalBGs/aptCleanC01b.png"
    image bg cleanC1c = "normalBGs/aptCleanC01c.png"
    image bg cleanC1d = "normalBGs/aptCleanC01d.png"
    image bg cleanC1e = "normalBGs/aptCleanC01e.png"
    image bg cleanC6a = "normalBGs/aptCleanC06a.png"
    image bg cleanC6b = "normalBGs/aptCleanC06b.png"

screen cloneScreen1():
    add Image("normalBGs/aptClone08a.png")

screen cloneScreen2():
    add Image("normalBGs/aptClone08b.png")

screen tunaPanel():
    add Image("tuna.png")

screen meatloafPanel():
    add Image("meatloaf.png")

screen mysteryFoodPanel():
    add Image("mysteryFood.png")

screen catEyesFade():
    add Image("chase/catEyes.png") alpha 0.05

screen my_timer():
    text "[clock]" size 72 color "#FFF"
    if clock <= 10:
        text "[clock]" size 72 color "#FF0000"
    if clock >= 1:
        timer 1 repeat True action [
                SetVariable("clock", clock - 1),
                renpy.restart_interaction
            ]
    else:
        timer 1 action [
                Hide("my_timer"),
                Jump("time_out")
            ]

# The game starts here.

label atHome_start:
if not renpy.music.is_playing('music'):
    play music "audio/LOOPS/04homeWithYou.mp3" loop
menu:
    "Do something alone.":
        "Like what?"
        jump homeAloneMenu
    "Do something with cat.":
        "Like what?"
        jump homeTogetherMenu

label homeAloneMenu:
    menu:
        "Clean apartment":
            jump cleanHome
        "Watch a movie":
            jump watchTV
        "Take a nap":
            jump napAlone
        "On second thought...":
            jump atHome_start

label homeTogetherMenu:
    menu:
        "Pet cat":
            jump petCat
        "Feed cat":
            jump feedHome
        "Play with cat":
            jump playHome
        "Clean cat":
            jump cleanCat
        "On second thought...":
            jump atHome_start

label cleanHome:
    "You decide that even if it's your day off, that doesn't mean you should be {i}completely{/i} unproductive."
    "You know you have a guest and all, but you really shouldn't put off your chores."
    "Best to get them done while you're in the mood to do so..."
    "So for now, you get dressed, roll up your sleeves and get to work on cleaning the apartment."
    scene black
    with dissolve
    ".."
    "..."
    "At least..."
    "...you {i}try{/i} to?"
    scene bg aptLivingRoom
    with wiperight
    "You sweep the living room..."
    scene bg aptKitchen
    with wiperight
    "You wipe the kitchen counter..."
    scene bg aptBedroom
    with wiperight
    "You..."
    "Okay you don't make your bed, but who actually does that anyway?"
    scene bg aptLivingRoom
    with wipeleft
    "..."
    "Still..."
    "You notice that no matter how much you clean up..."
    "...you keep finding more messes than when you started."
    you "..."
    "You peek over at the cat."
    scene bg clone1
    with dissolve
    "You suspect that it might be the culprit behind this mystery..."
    "But every time you rush to check on it or catch it in the act..."
    play sound "audio/cat_purr.mp3" volume 0.1
    cat "Purr.. Purr.."
    "...You always find it napping in the living room."
    play sound "audio/cat_purr.mp3" volume 0.1
    cat "Purr.. Purr.."
    you "..."
    scene bg aptLivingRoom
    with dissolve
    "You keep cleaning, but the cat..."
    "...or {i}something{/i}..."
    "...keeps leaving more and more mess in its wake."

    menu:
        "Keep cleaning":
            jump keepCleaning
        "Catch cat in the act":
            jump catchCat

    label keepCleaning:
        stop music fadeout 1.5
        scene black
        with dissolve
        "You keep cleaning, but there’s just more mess..."
        "And more..."
        "..."
        "And {i}more{/i}..."
        "When you finally stop and look around you..."
        ".."
        "..."
        scene bg mess1
        with fade_Red
        "..."
        "...you don’t even recognize your home anymore."
        play music "audio/LOOPS/05neatFreakIN.mp3"
        queue music "audio/LOOPS/05neatFreakLOOP.mp3" loop
        "There’s piles of junk everywhere. Do you even {i}own{/i} this much stuff?"
        "You don’t remember ever buying or receiving most of it."
        "The piles tower over you."
        "You feel claustrophobic."
        "The stench of garbage is overwhelming, despite your hands feeling raw from all the cleaner fluid you've been using."
        "Your eyes still burn from the bleach."
        "You need some air."
        "You need to get out of here."
        play sound "audio/cupBreak.mp3"
        "Crack!" with hpunch
        "You hear a crash and see a teacup you're certain you don't own smashed on the floor."
        scene bg mess2
        with dissolve
        "You look up and see the cat perched on a teetering pile of china and kitchen appliances."
        play sound "audio/cupBreak2.mp3"
        "It carefully nudges another teacup from the pile, sending it careening to the ground..."
        "...but you don't even flinch as it shatters."
        "Instead..."
        you "Heh..."
        "You start to chuckle."
        you "Hehehe!"
        "Suddenly, you're laughing. It's so hilarious..."
        you "HAHAHA!" with hpunch
        "...that tears start running down your face."
        you "I {i}knew{/i} it was you! {i}You{/i} did this, didn't you?"
        "You pick up the largest piece of ceramic from the broken teacups..."
        you "{size=+5}{b}{i}DIDN'T{/i}{/b} YOU?!{/size}" with hpunch
        "...and throw it at the cat."
        play music "audio/LOOPS/05neatFreakOUT.mp3" noloop
        scene bg mess3
        with dissolve
        "The cat dodges by leaping off of the pile."
        scene bg mess6
        with dissolve
        pause .6
        scene bg mess4
        with dissolve
        "The pile... sways."
        scene bg mess6
        with dissolve
        pause .6
        scene bg mess5
        with dissolve
        "It sways..."
        scene bg mess6
        with dissolve
        ".."
        "..."
        "...It's falling."
        scene bg mess7
        with dissolve
        pause .6
        scene bg mess6
        with dissolve
        you "!!"
        "...It's falling towards yo--{w=0.8}{nw}"
        scene bg mess7
        pause .1
        scene bg mess8
        pause .1
        scene black
        show screen bloody
        play sound "audio/punch_MEDIUM.mp3" volume 0.5
        pause .1
        hide screen bloody
        with p_Red
        play sound "audio/crash.mp3" volume 0.7
        "{size=+25}{b}{i}CRASH!!{/i}{/b}{/size}"with vpunch
        ".."
        "..."
        "...You can't move."
        "You're..."
        "You're buried."
        "The pile fell on top of you."
        "Broken shards of fine china and sharp utensils are piercing your skin..."
        "Your {b}organs{/b}..."
        "Your bones feel loose and limp... crushed under the heavy appliances."
        "Warm liquid pools under you."
        "With the last of your strength..."
        "...you listen as the cat pads over to you before laying down and purring sleepily."
        play sound "audio/cat_purr.mp3" volume 0.2
        cat "Purr... Purr..."
        you "..."
        "Yeah..."
        "A nap sounds..."
        "{size=-5}pretty...{/size}"
        "{size=-10}good...{/size}"
        you "..."
        "..."
        "Ending 1: A (Not So) Clean Getaway"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending1Done:
            jump endAtHome
        else:
            $persistent.ending1Done = True
            $persistent.endCounter += 1
            jump endAtHome



    label catchCat:
        "How are you supposed to finish cleaning up if this little imp is making a menace of itself?"
        "No."
        "You {i}know{/i} the cat's the culprit..."
        "You consider locking it up in the bathroom, at least until you clean the rest of the apartment..."
        "...But it just doesn't seem fair when you don't actually have any proof."
        "You need to investigate this further."
        "You need proof."
        "Not just for the sake of your sanity, but more importantly for the sake..."
        "...of {b}{i}cleanliness!{/i}{/b}" with hpunch
        "You start to clean again and peek behind you, catching mere glimpses of a paw here or a tail there..."
        "But as with earlier, when you rush back to the living room, the cat is still sleeping."
        you "{i}Okay, you wanna play, cat?{/i}"
        you "{i}Then let's play{/i}..."
        "This time, you decide to lay a trap – one your feline friend won’t be able to resist."
        scene bg aptKitchen
        with dissolve
        "You tackle the kitchen island counter and give it the {b}{i}works{/i}{/b}."
        "It’s {i}glistening{/i} by the time you’re done."
        "It’s so clean..."
        "...you’d drop kick anyone who even {b}{i}thought{/i}{/b} of eating off of it."
        "The perfect trap for your little cleaning saboteur."
        stop music fadeout 3
        scene bg aptHall
        with dissolve
        "You whistle innocently as you exit the room and hide around the corner of the entryway to the hall."
        "From the angle you're at, you have a perfect view of the cat and the island counter."
        "There’s no way you won’t catch the culprit in the act now."
        "If it really isn’t the cat, maybe you’ll give it a treat as an apology for your suspicions?"
        scene bg aptLivingRoom
        with dissolve
        "But as you deliberate if you should stop by the grocery store to get some fish... the cat starts to..."
        scene bg clone1
        with dissolve
        pause .1
        play sound "audio/gurgle1.mp3" volume 0.2
        scene bg clone2
        with dissolve
        pause .1
        scene bg clone1
        with dissolve
        "...shift?"
        "Its back that was rising and falling evenly moments ago..."
        play sound "audio/gurgle1.mp3" volume 0.4
        scene bg clone2
        with dissolve
        "...is now rippling in small tremors like an agitated wave on a black sea."
        play sound "audio/gurgle2.mp3" volume 0.4
        scene bg clone3
        with dissolve
        "It’s shuddering..."
        play sound "audio/gurgle3.mp3" volume 0.4
        scene bg clone4
        with dissolve
        "It’s bubbling..."
        play sound "audio/gurgle4.mp3" volume 0.4
        scene bg clone5
        with dissolve
        "It’s bulging..."
        play sound "audio/gurgle5.mp3" volume 0.4
        scene bg clone6
        with dissolve
        "It’s {b}{i}bulging--{/i}{/b}{w=0.3}{nw}"
        stop sound
        play sound "audio/bubblePop.mp3" volume 0.2
        queue sound "audio/squelchLOOP.mp3"
        scene bg clone7
        with vpunch
        stop sound
        "{b}{size=+15}POP!{/size}{/b}" with vpunch
        you "..?"
        you "..?!" with hpunch
        you "{i}What... the {b}hell{/b}..?{/i}"
        "You gape in disbelief as {b}another cat{/b} bursts out of the still, {i}still{/i}, sleeping feline you’d taken home with you."
        scene bg aptLivingRoom
        with dissolve
        you "..."
        "You're..."
        "You're {i}fairly{/i} certain that's not how cats give birth."
        "But more importantly..."
        scene bg aptKitchen
        with dissolve
        "You watch cat #2 shake itself off before leaping up onto the counter..."
        "...rolling around on top of it and leaving fur and grime in its wake."
        you "{i}Hm. Probably should've given it a bath earlier{/i}..."
        "You feel like your mind is lagging behind the reality of the discovery you've just made..."
        "...but you don't seem capable of thinking beyond smaller observations."
        "For example..."
        scene black
        with dissolve
        "Though the hows and whys of what you’re witnessing elude you..."
        "...the more pertinent question that strikes you is that if the original cat is still sleeping..."
        "...and the cloned cat is busy making yet {i}another{/i} mess..."
        ".."
        "..."
        "{size=-8}...then where are all the {b}other{/b} clones?{/size}"
        show screen cloneScreen1
        play sound "audio/violinSting_HIGH.mp3" volume 0.5
        pause .41
        show screen cloneScreen2
        play sound "audio/violinSting.mp3" volume 0.4
        pause .3
        hide screen cloneScreen1
        you "!!!" with vpunch
        "Suddenly, the two cats look directly at you in perfect unison."
        cat "..."
        cat2 "..."
        you "..."
        "Their eyes pin you to the spot with their intensity..."
        "..."
        "But..."
        "You realize with the familiar, sinking feeling of being watched from behind..."
        "...that they're not the {i}only{/i} ones looking at you."
        "You slowly turn around..."
        you "!!" with vpunch
        scene bg aptHall
        play music "audio/LOOPS/06tinyPawsIN.mp3"
        queue music "audio/LOOPS/06tinyPawsLOOP.mp3" loop
        hide screen cloneScreen2
        with dissolve
        pause .8
        scene bg wall1
        with dissolve
        pause .6
        scene bg wall2
        with dissolve
        pause .6
        scene bg wall3
        with dissolve
        pause .8
        scene bg wall4
        with dissolve
        "Packed in the hall behind you, from the floor to the ceiling..."
        "...is a living, breathing, {i}writhing{/i} wall of cats..."
        "...of {i}{b}clones{/b}{/i}..."
        "...all piled on top of each other."
        "The glowing, golden eyes of every cat in the undulating wall of pure black fur..."
        "Every single eye..."
        "...is trained on you."
        you "..."
        "Out of fear and a sheer, desperate need to distance yourself from this blight on reality and order..."
        "...you take a single step back."
        show screen blackOut
        with dissolve
        scene black
        ".."
        "..."
        hide screen blackOut
        "...And in response."
        "The wall just..."
        "...{b}breaks{/b}."
        play sound "audio/humanImpact.mp3" volume 0.4
        scene black
        pause .2
        show screen bloody
        play sound "audio/cut.mp3" volume 0.5
        queue sound "audio/gooeySquish.mp3" volume 0.2
        pause .1
        hide screen bloody
        with p_Red
        with vpunch
        "...the cats all stampeding over you."
        scene black
        show screen bloody
        play sound "audio/cut.mp3" volume 0.5
        queue sound "audio/gooeySquish.mp3" volume 0.2
        pause .1
        hide screen bloody
        with p_Red
        with vpunch
        "It'd be kind of..."
        "...cute?"
        scene black
        show screen bloody
        play sound "audio/cut.mp3" volume 0.5
        queue sound "audio/gooeySquish.mp3" volume 0.2
        pause .1
        hide screen bloody
        with p_Red
        with vpunch
        "...If their soft paws weren't hiding claws as sharp as knives."
        scene black
        show screen bloody
        play sound "audio/cut.mp3" volume 0.5
        queue sound "audio/gooeySquish.mp3" volume 0.2
        pause .1
        hide screen bloody
        with p_Red
        with vpunch
        "You try to protect yourself... {w}but there's just too many of them."
        scene black
        show screen bloody
        play sound "audio/cut.mp3" volume 0.5
        queue sound "audio/gooeySquish.mp3" volume 0.2
        pause .1
        hide screen bloody
        with p_Red
        with vpunch
        play music "audio/LOOPS/06tinyPawsOUT.mp3" noloop
        "Blood leaks steadily from your scratches.."
        "You feel dizzy..."
        "With what little strength you have..."
        "...you turn your head and watch as the cats tear through carpet and upholstery..."
        "...knock over vases and dishes and lamps..."
        "...claw at the walls..."
        "It’s going to take forever to clean this up, you think."
        "Maybe you’ll tackle it all again later..."
        "...right after you..."
        "{size=-5}...take a short..{/size}"
        "{size=-8}...nap...{/size}"
        you "..."
        "With an annoyed sigh..."
        "..."
        "...you breathe your last breath."
        "..."
        "Ending 2: Double Trouble"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending2Done:
            jump endAtHome
        else:
            $persistent.ending2Done = True
            $persistent.endCounter += 1
            jump endAtHome



label watchTV:
    "You're not tired enough for a nap, but you're too lazy to get started on any of your chores."
    "So you decide to watch a movie."
    "You get dressed in your favorite pajamas, make some popcorn with an obscene amount of butter and head over to your armchair..."
    scene bg armchair
    with dissolve
    "...only to discover that the cat is already napping in it."
    "You frown a little in thought."
    "Your couch isn't at the best angle for optimal TV viewing pleasure and you don't feel like pushing it around and having to put it back later."
    "The only options you have left are to sit on the floor..."
    "...or move the cat and reclaim your throne."

    menu:
        "Sit on the floor.":
            jump sitOnFloor

        "Reclaim your throne.":
            jump sitInChair

    label sitOnFloor:
        "You decide to sit on the floor. The cat is a guest after all and you pride yourself on being a good host if nothing else."
        "Well... At least you would if you'd ever had any guests over before."
        "You grab a blanket and some pillows and make a comfy nest in front of the chair."
        stop music fadeout 2
        scene bg tvFloor1
        with dissolve
        pause .6
        scene bg tvFloor2
        with dissolve
        "You pop in a random movie from your collection and can tell instantly that it's one of your favorite horror films."
        "You've seen it a few times already, but it never fails to get your blood pumping."
        "A few minutes in and you’re already invested, getting reacquainted with the story and characters."
        "The scares won't come until later, but..."
        show screen blackOut
        with dissolve
        "...for some reason you feel like something is watching you from behind."
        scene bg tvBehind1
        "You know it's probably nothing, but you feel compelled to check anyway."
        "You peek over your shoulder..."
        hide screen blackOut
        pause .03
        scene bg tvBehind2
        play sound "audio/glitch.mp3" volume 0.7
        pause .03
        scene bg tvBehind3
        you "{size=+5}GAH!{/size}" with vpunch
        "...only to jump out of your skin, jostling a few pieces of popcorn out of the bowl in your lap."
        "The cat is awake and looking right at you."
        cat "..."
        you "*SIGH*"
        "You take a calming breath, recovering from your heart nearly lurching out of your chest and immediately feel foolish."
        "It was just the cat, of course. It was so quiet you’d forgotten it was right behind you..."
        "...even though it’s the whole reason you’re sitting on the floor in the first place."
        scene bg tvFloor2
        with dissolve
        "You shakily pick up the remote, intending to rewind some of the parts you missed."
        "However as soon as you press the rewind button..."
        play sound "audio/click.mp3" volume 0.2
        show screen blackOut
        ".."
        "..."
        scene bg tvFloor3
        hide screen blackOut
        with dissolve
        "...the TV shuts off."
        you "..?"
        "You blink, confused."
        "Nothing else turned off. The kitchen’s dimmed light was still on..."
        "The digital clock was still glowing... and..."
        "...the movie player was still rewinding..."
        "The power clearly didn't go out... So why...?"
        "You feel a chill run down your spine as you catch the cat’s reflection in the dark TV screen."
        "It's still..."
        "...looking at you?"
        you "{i}Cats stare, silly. It's kind of their thing...{/i}"
        "...right?"
        "And you’re a new addition in its life. Of course it’s going to study you closely to see if you're trustworthy."
        "As you mentally reassure yourself, you turn the TV back on."
        play sound "audio/tvStaticLOUD.mp3" volume 0.02 loop
        show tvStatic
        ".."
        "..?"
        "What?"
        "The TV's on, but... the movie isn't what's playing on screen."
        "It's..."
        scene bg tvFloor5
        play sound "audio/click.mp3" volume 0.07
        hide tvStatic
        "!!"
        "It's you..?"
        "You watch yourself frown onscreen as you feel your brow furrow in tandem."
        "It’s like footage of you in real time, like you’re being recorded..."
        "You feel the familiar sensation of your mind focusing on small details to avoid the bigger picture of your current situation."
        "Avoiding the questions of how this is happening... of who or what is doing this..."
        "...and why."
        scene bg tvFloor6
        with dissolve
        "Suddenly, your mirrored self smiles and waves at you. All on its own."
        "You don’t wave back, too stunned to move."
        "..."
        "The {b}you{/b} on the screen doesn’t seem to mind though."
        scene black
        with dissolve
        "It then stands up..."
        "It walks out of frame..."
        "..."
        "And-"
        you "{b}{i}AAHHH!!{/i}{/b}" with vpunch
        "A terrified yell rips out of your mouth before you can think to stifle it."
        "On screen... in the chair..."
        "...is the cat."
        "..."
        "But it’s... {b}wrong{/b}."
        play sound "audio/tvStatic.mp3" fadein 2 loop
        show tvMonster
        with dissolve
        play music "audio/LOOPS/07screenTimeLOOP.mp3" loop
        "It’s become a large swollen mass of black fur..."
        "Its twitching pulse arrhythmical with its slow, almost methodical breaths."
        "Its mouth is a yawning entrance to a black abyss, framed by a set of teeth that look very, {i}very{/i} {b}sharp{/b}."
        "Glowing eyes bulge all over its body..."
        ".."
        "..."
        stop sound
        show screen blackOut
        hide tvMonster
        "{size=-5}It’s... still {b}looking{/b} at you...{/size}"
        "It doesn’t even acknowledge your onscreen persona as they walk back into frame and pet {b}it{/b} almost lovingly."
        "Then..."
        "The {b}you{/b} inside the TV touches one of the \"cat's\" fangs..."
        hide screen blackOut
        play sound "audio/cut.mp3" volume 0.3
        scene bg tvFloor1
        with p_Red
        you "!!" with vpunch
        "You flinch at a sudden, sharp pain in your palm."
        "You look down and sure enough..."
        "...your hand is bleeding."
        "You’re not particularly afraid of blood but..."
        play sound "audio/heartbeat.mp3" volume 0.5 loop
        "...for some reason the sight of it leaking out of you sends another chill down your back."
        "A thought... clear and {i}terrible{/i} flashes across your mind..."
        "It’s not {i}just{/i} the mutated cat {b}in{/b} the TV that’s watching you..."
        "{size=-5}...is it?{/size}"
        "{size=-10}Don't look behind you... Don't look behind you... Don't look behind you... Don't look behind you... Don't look behind you... {/size}"
        show text "Don't look behind you..." at truecenter
        with dissolve
        pause 1
        hide text
        with dissolve
        play music "audio/LOOPS/07screenTimeOUT.mp3" noloop
        "You watch helplessly as your onscreen self smiles and nods at you, almost {i}encouragingly{/i}..."
        "They stand in front of the cat’s gaping jaws..."
        "They look into the dark depths..."
        "...and as you’re torn between the horrifying realization of what’s about to happen..."
        "...and the gripping wonder of what they see looking back at them from that deep, deep darkness..."
        ".."
        "..."
        "...they jump {i}in{/i}."
        play sound "audio/swishMEDIUM.mp3" volume 0.2
        show screen blackOut
        ".."
        "..."
        "Darkness is a sudden presence all around you."
        "Pressing in, holding you down..."
        "...and yet you somehow also feel.. weightless."
        "You can’t tell if you’re falling but it doesn’t feel like you're laying down or standing either."
        "You feel warm..."
        "You feel cold..."
        "You feel everything..."
        "You feel nothing..."
        "..."
        "You feel {b}nothing.{/b}"
        "..."
        "Ending 3: Silent Film"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending3Done:
            jump endAtHome
        else:
            $persistent.ending3Done = True
            $persistent.endCounter += 1
            jump endAtHome



    label sitInChair:
        "You square your shoulders."
        you "Sorry, kitty. But that's my spot."
        scene bg aptLivingRoom
        with dissolve
        "You pick up the cat and place it on the floor."
        play sound "audio/cat_angryQUICK.mp3" volume 0.3
        cat "Mreow!!" with hpunch
        "It's clearly upset with you. When you try to pet it as an apology, it dodges your hand and scampers away."
        "You shrug and put on a random movie before nestling into your chair."
        stop music fadeout 2
        scene bg tvSit1
        with dissolve
        "It's some horror film that you love to heckle from beginning to end."
        "Nothing but an endless string of pointless jumpscares."
        "Did the writers not know the meaning of the word \"subtle\"?"
        play sound "audio/crash.mp3" volume 0.02
        "{size=+15}{b}CRASH!{/b}{/size}" with vpunch
        you "!!"
        you "What was that?! Was that the bathroom..?"
        "The cat must've gotten into the medicine cabinet or knocked something over."
        "Calming your thundering heart with a deep breath, you pause the movie and get up to investigate."
        scene bg aptHall
        with dissolve
        play sound "audio/cat_angryQUICK.mp3" volume 0.4
        cat "Meow!" with hpunch
        you "Whoa!" with vpunch
        "The cat dashes between your legs from the hall."
        you "Fleeing the scene only makes you look guiltier, you know..."
        "You're even more reluctant to see the damage now. You just want to relax and watch your bad horror movie..."
        scene bg aptBath_O
        with dissolve
        "You go into the bathroom and turn on the light."
        "Just as you thought, all the stuff in your medicine cabinet is scattered on the tiles."
        "You sigh. At least none of it looks broken or damaged."
        "You crouch down to pick everything up."
        scene bg aptBath_C
        play sound "audio/doorClose.mp3" volume 0.15
        "{size=-8}click...{/size}"
        you "..?"
        "Did the door just... close? Did you bump it when you crouched down or..?"
        "..."
        "W-Well... At least the cat can't come in and make more of a mess this way-"
        scene bg aptBath_DC
        play sound "audio/click.mp3" volume 0.3
        pause .2
        play sound "audio/click.mp3" volume 0.3
        scene bg aptBath_C
        "..?"
        "The lights?"
        "Didn't you just replace the bulbs? They weren't faulty, were they?"
        "You never remember to hold on to your receipts for situations like these."
        "You doubt you'll be able to get your money back..."
        scene bg aptBath_DC
        play sound "audio/click.mp3" volume 0.3
        pause .2
        play sound "audio/click.mp3" volume 0.3
        scene bg aptBath_C
        "..."
        you "..."
        "You stand up."
        scene bg cabinet
        with dissolve
        "You shake out the pain in your knees from crouching and open your medicine cabinet."
        scene bg cabinetOpen
        with dissolve
        "Carefully, you place everything back where they belong, making sure nothing is missing."
        scene bg cabinet
        with dissolve
        "You close the cabinet door--{w=0.60}{nw}"
        scene bg tvSitScare1a
        play sound "audio/jumpscareQUICK.mp3" volume 0.2
        pause .1
        scene bg tvSitScare1b
        pause .1
        scene bg tvSitScare1c
        pause .1
        scene bg tvSitScare1d
        pause .1
        scene black
        you "{size=+30}AAAAAHHH!!{/size}" with vpunch
        "You jump back, slamming against the wall, covering your mouth."
        "You look back up at the mirror on the medicine cabinet door to see..."
        ".."
        "..."
        scene bg cabinetDark
        with dissolve
        "...nothing."
        "Nothing?"
        play music "audio/LOOPS/08justBreatheLOOP.mp3" loop
        you "What... What the hell..? Something... Something was..."
        "You know you saw something just now."
        "You {i}know{/i} you did."
        "Right?"

        menu:
            "You saw something.":
                jump movieBathroomJumpscare1
            "You {i}definitely{/i} saw something":
                jump movieBathroomJumpscare1

        label movieBathroomJumpscare1:
            "Yeah, definitely. You're not sticking around for--{w=0.4}{nw}"
            $ renpy.music.set_volume(0.0, 0, "music")
            scene bg tvSitScare2a
            play sound "audio/jumpscareQUICK.mp3" volume 0.5
            pause .1
            scene bg tvSitScare2b
            pause .1
            scene bg tvSitScare2c
            pause .1
            scene black
            $ renpy.music.set_volume(1.0, 0, "music")
            you "{size=+35}{b}AAAAAAAAHHHHH!!{/b}{/size}" with hpunch
            "You rush out of the bathroom and slam the door behind you without looking."

        scene bg aptHall
        with wipeleft
        "You enter the hall and-"
        scene bg aptHallDark
        play sound "audio/click.mp3" volume 0.3
        pause .2
        play sound "audio/click.mp3" volume 0.3
        scene bg aptHall
        pause .2
        scene bg aptHallDark
        with dissolve
        you "No..."
        scene bg tvSit2
        with dissolve
        pause .7
        scene bg tvSit3
        with dissolve
        pause .7
        scene bg tvSit4
        with dissolve
        pause .7
        scene bg tvSit5
        with dissolve
        pause .15
        scene bg tvSitScare3a
        play sound "audio/jumpscareQUICK.mp3" volume 0.4
        pause .1
        scene bg tvSitScare3b
        pause .1
        scene bg tvSitScare3c
        pause .1
        scene bg tvSitScare3d
        play sound "audio/violinSting_HIGH.mp3" volume 0.7
        pause .1
        scene black
        you "No no no no no!!" with hpunch
        "You shield yourself with your arms and..."
        ".."
        "..."
        "...nothing."
        "Nothing. Again."
        "You peek through your fingers and see..."
        stop music fadeout 2
        pause 1
        scene bg aptHall
        with dissolve
        "...just your usual hallway."
        "You..."
        play sound "audio/heartbeat.mp3" volume 0.5
        scene bg aptHall
        with p_Red
        stop sound
        "You don't feel very good."
        "..."
        "You need to sit down."
        scene bg tvFloor1
        with dissolve
        "You carefully make your way back to the dark living room..."
        "...trying not to overwhelm your senses anymore than you already have."
        "Maybe you should watch something a little more lighthearted..."
        "...or just lie down instead?"
        "You don't know."
        "It's a little hard to think..."
        "You just... need to sit {b}down.{/b}"
        "Stumbling forward, you reach your chair..."
        "{color=#FF0000}But-{/color}"
        scene black
        with p_Red
        play sound "audio/violinSting.mp3" volume 0.8
        you "{size=+15}!!!!!{/size}" with vpunch
        pause 1
        scene bg tvSit6
        with dissolve
        ".."
        "..."
        "It's nothing."
        "It's nothing at all."
        "Just the cat... sitting back in your chair again. Looking up at you curiously."
        play sound "audio/cat_confused.mp3" volume 0.3
        cat "Meow?"
        scene black
        with dissolve
        ".."
        play sound "audio/heartbeat.mp3" volume 0.5 loop
        scene black
        with p_Red
        ".."
        "..."
        "...but it's enough."
        "Your heart lurched so harshly out of a mixture of fear and anticipation..."
        stop sound
        "...that it completely gives out."
        "Your eyes roll up into your skull."
        "You feel yourself falling back."
        play sound "audio/humanImpact.mp3" volume 0.4
        show screen catEyesFade
        with p_Red
        with vpunch
        ".."
        "..."
        "...You're dead before you even hit the ground."
        "..."
        "Ending 4--{w=0.3}{nw}"
        hide screen catEyesFade
        play sound "audio/tvStaticLOUD.mp3" volume 0.4
        scene bg tvSitScare1a
        pause .1
        scene bg tvSitScare3a
        pause .1
        scene bg tvSitScare2b
        pause .1
        scene bg tvSitScare3d
        pause .1
        scene bg tvSitScare1c
        pause .1
        scene bg tvSitScare1d
        pause .1
        play sound "audio/violinSting_HIGH.mp3" volume 0.6
        scene bg tvSitScare2c
        pause .1
        scene black
        "..."
        "Ending 4: Real \"Subtle\""
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending4Done:
            jump endAtHome
        else:
            $persistent.ending4Done = True
            $persistent.endCounter += 1
            jump endAtHome


label napAlone:
    "You're a little tired from the events of the day."
    "Making life-changing choices like committing to the responsibility of caring for another living creature..."
    "...really wears you out."
    "You could definitely use a nap."
    scene bg aptHall
    with dissolve
    "You head to your room and get dressed in your pajamas, before you decide to grab a glass of water from the kitchen."
    scene bg aptBedroom
    with dissolve
    "You head back to your bedroom, ready for a much-needed nap..."
    play sound "audio/cat_happyLONG.mp3" volume 0.3
    cat "Meow!" with hpunch
    you "Whoa!" with vpunch
    "...only for the cat to race past you through the open door and jump on the middle of the bed."
    scene bg nap1
    with dissolve
    "It takes its time kneading at the sheets before settling down and closing its eyes."
    play sound "audio/cat_purr.mp3" volume 0.5
    cat "Purr... Purr... Purr..."
    you "..."
    you "{i}Well, that was fast...{/i}"
    "You frown thoughtfully."
    "Now that your mind's on it, you find yourself {i}really{/i} craving a nap in your own bed."
    "There's no way you're settling for sleeping on the couch. {i}Certainly{/i} not the armchair..."
    "Which means you should..."

    label napMenu:
    menu:
        "Move the cat.":
            jump napMoveCat
        "Sleep next to cat":
            jump napTogether
        "Do something else":
            you "..."
            "Maybe you can try napping {i}later...{/i}"
            "You decide to do something else with your time."
            scene bg aptLivingRoom
            with wipeleft
            jump homeAloneMenu

    label napMoveCat:
        "You tentatively nudge the cat in an attempt to make it move on its own."
        ".."
        "..."
        "It doesn't budge in the slightest."

        menu:
            "Move the cat?"
            "Keep trying. This is {i}your{/i} bed.":
                jump napMoveCat2
            "On second thought...":
                jump napMenu

        label napMoveCat2:
            "You push a little more firmly this time."
            $ renpy.music.set_volume(0.0, 0, "music")
            scene bg nap2
            with dissolve
            play sound "audio/cat_angryQUICK.mp3" volume 0.3
            cat "Mreow..."
            you "..."
            "The cat sounds annoyed with you..."

        menu:
            "Move the cat?"
            "Again. You WILL sleep in your own bed.":
                jump napMoveCat3
            "I don't know. It sounds mad...":
                cat "..."
                pause .3
                scene bg nap1
                with dissolve
                $ renpy.music.set_volume(1.0, 0, "music")
                jump napMenu

        label napMoveCat3:
            scene bg nap3
            with dissolve
            "The cat opens one yellow eye and slides it up to look at you."
            play sound "audio/cat_angry.mp3" volume 0.3
            cat "{b}Mreowww...{/b}"
            you "..!" with vpunch
            "Is its voice a little... deeper? Than before?"
            "..."

        menu:
            "{size=-5}Move the cat?{/size}"
            "Move. The. Cat.":
                stop music
                $ renpy.music.set_volume(1.0, 0, "music")
                jump napMoveCat4
            "Seriously last chance. You {i}really{/i} want to do this?":
                cat "..."
                pause 1
                scene bg nap1
                with dissolve
                $ renpy.music.set_volume(1.0, 0, "music")
                jump napMenu

        label napMoveCat4:
            "You move forward. {w}Ready to shove the cat with all your might--{w=1.5}{nw}"
            play sound "audio/humanImpact.mp3" volume 0.5
            queue sound "audio/crash.mp3" #volume 0.3
            scene bg aptBedroomDark
            with p_Red
            "{size=+25}CRASH!{/size}" with vpunch
            you "{size=+10}GAH!{/size}" with hpunch
            play music "audio/LOOPS/09letSleepingCatsLieIN.mp3"
            queue music "audio/LOOPS/09letSleepingCatsLieLOOP.mp3" loop
            "You're thrown back by some invisible force and crash into the dresser, before falling to the ground."
            you "Unhh..."
            "Wind knocked out of you, you look up in a daze..."
            you "!!!" with vpunch
            "You..."
            "You don't quite comprehend what it is you're seeing."
            "A strong, swirling wind has picked up, throwing items all over the place..."
            "...as if a miniature hurricane had just taken form in your room."
            "And right there in the center of it all..."
            show napAlone1
            with dissolve
            "...is the cat."
            "Hovering in the air above the bed..."
            "Its eyes open, glowing like molten lava..."
            play sound "audio/catStray.mp3"
            cat "Mreowww..."
            play sound "audio/catStray.mp3"
            cat "{size=+5}Mreowww...{/size}" with vpunch
            show screen whiteOut
            with dissolve
            show napAlone4
            play sound "audio/cat_angry.mp3"
            cat "{size=+10}{b}M r e o w w w...!{/b}{/size}" with vpunch
            hide napAlone1
            hide screen whiteOut
            with dissolve
            you "!!"
            "You watch as a vortex rips open in the center of your bed..."
            "...and panic as the swirling wind turns into a {i}vaccuum.{/i}"
            "{b}Dragging{/b} you towards the bed..."
            play sound "audio/cut.mp3" volume 0.7
            show napAlone4
            with p_Red
            you "Ghh!" with hpunch
            "Your nails catch and {b}{i}tear{/i}{/b} as you desperately try to cling to the carpet... {w}the floor boards..."
            "...any and {i}every{/i} piece of furniture within your reach..."
            "...bloody fingers slipping clumsily on every surface..."
            ".."
            "..."
            "...but there's nothing you can do."
            play music "audio/LOOPS/09letSleepingCatsLieOUT.mp3" noloop
            "As you touch the vortex... your body starts to..."
            "...{i}disintegrate.{/i}"
            "Tiny particles of your body separating and floating into nothing..."
            show screen blackOut
            with dissolve
            hide napAlone4
            "The last thing you see is the cat landing nimbly on the bed and kneading at your sheets..."
            "...before it curls up and falls back asleep."
            play sound "audio/cat_purr.mp3" volume 0.4
            cat "Purr..."
            "..."
            "Ending 5: Do Nyaa-t Disturb"
            # if persistent.testingNow:
            #     jump endAtHome
            if persistent.ending5Done:
                jump endAtHome
            else:
                $persistent.ending5Done = True
                $persistent.endCounter += 1
                jump endAtHome


    label napTogether:
        "You shrug. What's the harm in sharing the bed, right?"
        "You both have had a long day, after all."
        stop music fadeout 3
        "You try to carefully avoid jostling the cat as you lay down, but it immediately scoots over and curls up against you anyway."
        play sound "audio/cat_purr.mp3" volume 0.3
        cat "Purr... Purr... Purr..."
        "You smile."
        show screen blackOut
        with dissolve
        you "Sweet dreams..."
        ".."
        "..."
        "..?"
        scene bg aptBedroomNight
        hide screen blackOut
        with dissolve
        you "Mmph..?"
        "You feel like you slept for a long time."
        "..?"
        "You feel a warm weight on your back..."
        "But you don't see the-{w=0.6}{nw}"
        play sound "audio/cat_purr.mp3" volume 0.3
        cat "Purr... Purr... Purrr..."
        "...Oh. Mystery solved, then."
        "You feel... comfortable..?"
        "You consider getting up..."
        play sound "audio/tvStatic.mp3" volume 0.5 fadein 4 loop
        "...but as soon as the thought enters your head, your mind fills with static and a deep sense of..."
        "...disapproval?"
        you "..."
        stop sound fadeout 3
        show screen blackOut
        with dissolve
        you "{i}Not yet, then? Okay...{/i}"
        "The cat, jostled by your attempts at movement, kneads painfully at your back before settling down again and falling back asleep."
        "You fall back into slumber too."
        ".."
        "..."
        scene bg aptBedroomDark
        hide screen blackOut
        with dissolve
        pause .6
        "..."
        "It's night."
        "You want to get up."
        play sound "audio/cut.mp3" volume 0.3
        show screen blank
        with p_Red
        you "Nnnh!" with vpunch
        "Claws dig into your back like a warning."
        hide screen blank
        you "..."
        show screen blackOut
        with dissolve
        "...Tomorrow then, right?"
        play sound "audio/cat_purr.mp3" volume 0.3
        cat "Purr... Purr..."
        you "..."
        ".."
        play sound "audio/birdsNormal.mp3" volume 0.03 fadein 4
        "..."
        scene bg aptBedroom
        hide screen blackOut
        with dissolve
        "...It's morning. You'll be late for work..."
        "...but the cat doesn't budge."
        "You don't even try to get up this time."
        show screen blackOut
        with dissolve
        stop sound fadeout 3
        "You just close your eyes and drift off again."
        ".."
        "..."
        scene bg aptBedroom
        play music "audio/LOOPS/10aLittleNapIN.mp3"
        queue music "audio/LOOPS/10aLittleNapLOOP.mp3" loop
        hide screen blackOut
        with dissolve
        "It's..."
        "..."
        "It's the next day..."
        "..."
        "...since the last {b}several{/b} days..."
        "...Or has it been weeks?"
        "..."
        "{size=-8}Or longer...?{/size}"
        "..."
        "You're not quite sure."
        play sound "audio/stomachGrowl.mp3" volume 0.3
        you "..."
        "You're hungry."
        "You don’t know how long you’ve been lying down."
        "You feel sore on your back, but also on your stomach, your arms, your face..."
        "Everywhere..."
        "You can't remember your last meal... {w}The last time you drank anything..."
        "You've been sleeping all this time..."
        "...but you feel {b}exhausted{/b}. More tired than you think you've ever felt in your life."
        "It feels like a giant hand is {i}pressing{/i} you into the bed."
        "You can't remember the last time you even considered moving..."
        show screen blackOut
        with dissolve
        "But somehow you know..."
        "{size=-8}...that you need to go back to sleep {b}anyway{/b}.{/size}"
        "Everything will be fine if you just go back to sleep."
        play music "audio/LOOPS/10aLittleNapOUT.mp3" noloop
        ".."
        "..."
        "..?" with vpunch
        "You think you're hallucinating when the cat finally stirs..."
        play sound "audio/cat_trilling.mp3" volume 0.3
        cat "Meow..."
        "It stretches languidly before hopping off your back."
        "You hear its feet padding through your still open bedroom door, its steps fading down the hall."
        ".."
        "..."
        "You don't open your eyes."
        "You don't {i}move.{/i}"
        "..."
        "You’re afraid you don’t remember {b}how.{/b}"
        "You’re afraid that the static will return if you try..."
        "..."
        "But you eventually {i}do{/i} try."
        scene bg aptBedroom
        hide screen blackOut
        with fade_Red
        "You try to prop yourself up on your arm."
        "It’s thinner than you’ve ever seen it..."
        "Thinner than you think should be {i}possible-{/i}"
        play sound "audio/punch_HIGH.mp3" volume 0.1
        show screen blank
        with p_Red
        "{size=+10}CRACK!{/size}" with vpunch
        hide screen blank
        you "..."
        "The arm snaps under the weight of your body and crumbles to dust on the bedsheets."
        "..."
        "It doesn’t hurt in the slightest..."
        "As if even your nerves have dried up and become as useless as..."
        "...well, as useless as you feel in {i}general.{/i}"
        "{size=-8}Just how {b}long{/b} have you been laying in bed..?{/size}"
        "..."
        "You don't have much time to think about it."
        "Your failed attempt at sitting up sends you tumbling over the side of the bed like a rag doll..."
        play sound "audio/punch_HIGH.mp3" volume 0.3
        "{size=+5}CRACK!{/size}" with vpunch
        play sound "audio/humanImpact.mp3" volume 0.7
        "{size=+10}CRACK!{/size}" with vpunch
        play sound "audio/punch_MEDIUM.mp3" volume 0.7
        "{size=+25}CRACK!{/size}" with vpunch
        "But you think you’re probably closer to being a {i}ceramic{/i} doll..."
        "...as your body shatters {i}instantly{/i} upon impact with the floor."
        scene bg napTogether1
        with dissolve
        "Your head rolls towards the door..."
        "...letting you watch as the rest of your strewn body parts crack..."
        "...and {i}crumble{/i}..."
        "...and turn to broken {b}ruin{/b} as your consciousness begins to fade."
        scene bg napTogether2
        with dissolve
        pause 1
        scene bg napTogether3
        with dissolve
        "The cat strolls into view then... poking and prodding at the remains of your brittle limbs."
        "\"Bad kitty.\" {w}You try to say..."
        "..."
        "But you think your jaw might've snapped off earlier as well."
        "Almost as if sensing your attention, the cat walks over to you..."
        "Well... your {i}head{/i} at least..."
        "...and you watch with your final conscious seconds as it lays down, curling its body around you."
        scene black
        with dissolve
        play sound "audio/cat_purr.mp3" volume 0.4
        cat "Purr... Purr..."
        ".."
        "..."
        "It feels warm."
        "..."
        "Well."
        "..."
        "{size=-8}Maybe another nap couldn't hurt...{/size}"
        ".."
        "..."
        "Ending 6: Just A Cat Nap"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending6Done:
            jump endAtHome
        else:
            $persistent.ending6Done = True
            $persistent.endCounter += 1
            jump endAtHome


label petCat:
    "It's not everyday you have access to a cute fluffy animal."
    "What else is there to do but pet it to your heart's content?"
    "You sit on the floor in your living room and click your tongue to call the cat over."
    play sound "audio/cat_trilling.mp3" volume 0.3
    cat "Mrrp!!" with hpunch
    scene bg pet1
    with dissolve
    "The cat dashes over to you, immediately climbing into your lap."
    you "Poor thing~ You just want some attention, don't you?"
    play sound "audio/cat_happyLONG.mp3" volume 0.3
    cat "Meow!"
    you "Hehe, alright, alright!"
    "You carefully pet the cat. {w}A rub behind an ear. {w}A scratch under the chin. {w}A smooth sweep along the back."
    play sound "audio/cat_purr.mp3" volume 0.4
    cat "Purr... Purr... Purr..."
    you "Heh, good?"
    play sound "audio/cat_trilling.mp3" volume 0.15
    cat "Purr..."
    "You keep petting the cat in your lap, enjoying this bonding time together..."
    stop music fadeout 3
    scene bg pet2
    with dissolve
    "...but the cat starts to get restless after a while."

    menu:
        "Keep petting":
            jump keepPetting
        "Let's do something else...":
            scene bg aptLivingRoom
            with wipeleft
            play music "audio/LOOPS/04homeWithYou.mp3" loop
            jump homeTogetherMenu

    label keepPetting:
        play music "audio/LOOPS/11irritationIN.mp3"
        queue music "audio/LOOPS/11irritationLOOP.mp3" loop
        "..."
        "You're not quite ready to stop."
        "You feel so {i}calm{/i}... The repetitive action soothing your usually overworking mind..."
        ".."
        "..."
        "You keep petting."
        scene bg pet3
        with dissolve
        pause .08
        play sound "audio/cat_angryQUICK.mp3" volume 0.25
        cat "Mreow..."
        "The cat leans away from your next head pat."
        "It's trying to get out of your lap."

    menu:
        "Keep petting...":
            jump keepPetting2
        "That's enough. Let's do something else.":
            scene bg aptLivingRoom
            with wipeleft
            play music "audio/LOOPS/04homeWithYou.mp3" loop
            jump homeTogetherMenu

    label keepPetting2:
        play sound "audio/gooeySquish.mp3" volume 0.3
        scene bg pet3
        with p_Red
        with vpunch
        "When you scratch under the cat's chin, it bites at your fingers."
        "You might be bleeding, but really it barely hurts."
        "More of a warning than anything."
        scene bg pet4
        with dissolve
        pause .05
        play sound "audio/cat_angryQUICK.mp3" volume 0.4
        cat "Mreow!" with hpunch
        "The cat struggles in your hold."
        "It's watching you closely."
        you "..."

    menu:
        "...{i}Keep{/i} petting.":
            jump keepPetting3
        "{b}Seriously...{/b} Let's do something else.":
            scene bg aptLivingRoom
            with wipeleft
            play music "audio/LOOPS/04homeWithYou.mp3" loop
            jump homeTogetherMenu

    label keepPetting3:
        ".."
        "..."
        "You keep petting the cat-"
        play sound "audio/cat_angry.mp3" volume 0.8
        cat "{b}{size=+5}MREOW!{/size}{/b}" with hpunch
        scene bg pet5
        play sound "audio/gooeySquish.mp3" volume 0.6
        "{size=+15}{b}CHOMP!{/b}{/size}" with vpunch
        you "!!"
        play music "audio/LOOPS/11irritationOUT.mp3" noloop
        play sound "audio/squelchLOOP.mp3"
        scene bg pet6
        pause .2
        stop sound
        show screen blackOut
        scene black
        hide screen blackOut
        show screen bloody
        pause .1
        show screen redOut
        with p_Red
        pause .2
        hide screen bloody
        hide screen redOut
        with dissolve
        "..."
        "..!"
        "The cat..."
        "...bites {b}off{/b} your finger."
        you "..."
        "It hurts..."
        scene black
        with p_Red
        "You're {i}definitely{/i} bleeding now..."
        "But..."
        "..."
        "...for some reason..."
        "..."
        "{size=-8}...you just can't {b}stop.{/b}{/size}"
        "You don't know what it is..."
        "Its fur is so much {b}{i}softer{/i}{/b} than you realized..."
        "You’d think that it would be shining in the faint light of your living room, but..."
        "...it's as if the darkness of the cat’s black coat is {i}sucking{/i} in all the illumination around it..."
        "...rendering it completely {i}null.{/i}"
        "You're drawn to it. {w}Like you're somehow holding a deep dark {b}abyss{/b} right in your lap."
        play sound "audio/cat_purr.mp3" volume 0.3
        cat "Purr... Purrr.."
        "It seems calmer now, munching on your severed finger."
        "The stump between your thumb and middle finger is leaking..."
        "..."
        "...but you keep petting."
        "You fret that your blood will ruin its fur, but the cat no longer seems to mind."
        ".."
        "..."
        scene bg tvFloor1
        with dissolve
        "Time passes. {w}It's dark out now."
        "Soft as the fur is, your palm has started to feel raw and damp under the constant friction from your petting."
        "..."
        "{size=-7}You think faintly that maybe you’ve had enough.{/size}"
        scene black
        with dissolve
        "You start to lift your hand from the cat..."
        "...when in a flash--{w=0.5}{nw}"
        play sound "audio/swishQUICK_low.mp3" volume 0.4
        show slash
        scene bg redScreen
        with flash
        play sound "audio/punch_MEDIUM.mp3" volume 0.6
        show screen bloody
        with hpunch
        pause 1
        show screen blackOut
        hide screen bloody
        with dissolve
        you "!!!" with vpunch
        ".."
        "..."
        play music "audio/heartbeat.mp3" loop
        show pettingEnd
        hide screen blackOut
        with fade_Red
        ".."
        "..."
        "...your entire {b}hand{/b} is separated from your wrist."
        "It flops onto your lap beside the cat."
        "The cat's claws on its front right paw glisten with crimson liquid."
        "You don’t feel it for a moment but your body tenses..."
        "...anticipating the pain as you blankly watch the cat lick at the bloody palm of your severed hand."
        play sound "audio/cat_happy.mp3" volume 0.15
        cat "Meow!"
        you "H-hah..! It... hurts..."
        "It really, {i}really{/i} hurts.."
        "Then... {w}the cat looks up at you and you... {w}feel compelled..."
        "..."
        stop music
        show screen blackOut
        "{size=-8}...to keep {b}petting.{/b}{/size}"
        "You’re reluctant... but you’re also afraid of what will happen if you don’t heed the call."
        "What will you lose {i}next{/i} if you try to resist again?"
        "..."
        "You were hurt for your insistent petting earlier..."
        "...yet now you’ve been hurt for trying to stop?"
        "...It defies all logic, but that’s what scares you."
        "There’s no reasoning with such fickle whims..."
        scene bg tvFloor1
        hide screen blackOut
        with dissolve
        "You feebly try to raise your {b}{i}uninjured{/i}{/b} hand to pet the cat..."
        "...but it stiffens, golden eyes glinting dangerously."
        ".."
        "..."
        "Well."
        "..."
        "{size=-10}Alright then.{/size}"
        "You raise your bleeding stump and resume your petting to the best of your ability."
        play sound "audio/cat_purr.mp3" volume 0.4
        cat "Purr... Purr... Purrr..."
        you "..."
        "You pet..."
        scene black
        show screen bloody
        play sound "audio/cut.mp3" volume 0.3
        queue sound "audio/gooeySquish.mp3" volume 0.2
        pause .1
        hide screen bloody
        with p_Red
        "...and you bleed."
        "You pet..."
        scene black
        show screen bloody
        play sound "audio/cut.mp3" volume 0.3
        queue sound "audio/gooeySquish.mp3" volume 0.2
        pause .1
        hide screen bloody
        with p_Red
        "...and you bleed."
        "You pet..."
        scene black
        show screen bloody
        play sound "audio/cut.mp3" volume 0.3
        queue sound "audio/gooeySquish.mp3" volume 0.2
        pause .1
        hide screen bloody
        with p_Red
        "...and you bleed."
        "You pet and..."
        "..."
        "...you..."
        you "..."
        "..."
        "Ending 7: Personal Boundaries"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending7Done:
            jump endAtHome
        else:
            $persistent.ending7Done = True
            $persistent.endCounter += 1
            jump endAtHome



label feedHome:
    "The cat looks hungry so you decide to feed it."
    "You’re regretting not stopping for food earlier as you don’t have much left. Grocery shopping day is tomorrow after all..."
    scene bg aptKitchen
    with dissolve
    "You head to the kitchen and click your tongue, ensuring the cat follows after you."
    "It leaps nimbly onto the kitchen counter and watches as you search for meal options."
    you "Hmm, let's see..."
    "You find some things you expect:"
    show screen tunaPanel
    with dissolve
    "A can of tuna in the pantry..."
    show screen meatloafPanel
    with dissolve
    "Some leftover meatloaf in the fridge..."
    show screen mysteryFoodPanel
    with dissolve
    $ renpy.music.set_volume(0.0, 0, "music")
    "And..."
    "..?"
    you "Huh? What's {i}that{/i}..?"
    show screen blackOut
    with dissolve
    hide screen tunaPanel
    hide screen meatloafPanel
    hide screen mysteryFoodPanel
    pause .5
    show mysteryFood
    hide screen blackOut
    with dissolve
    "You realize there's a tightly sealed tupperware on the bottom shelf of the fridge."
    ".."
    "..."
    "You {b}don't{/b} recognize it."
    "A foul odor is leaking from the container..."
    "Whatever's inside {i}can’t{/i} be safe for human consumption..."
    play sound "audio/cat_happyLONG.mp3" volume 0.2
    cat "Meow! Meoww!"
    you "Uhh..."
    "..."
    "...but the {i}cat{/i} seems excited about it. Practically {i}salivating{/i} over it..."
    you "..."
    show screen blackOut
    with dissolve
    hide mysteryFood
    scene bg feed1h
    hide screen blackOut
    with dissolve
    $ renpy.music.set_volume(1.0, 0, "music")
    "Still, {i}you're{/i} the caretaker here."
    "{i}You're{/i} the one who needs to decide what's best to feed a hungry cat."
    "So you'll feed it..."

    label feedHomeMenu:

    menu:
        "Tuna":
            stop music fadeout 3
            jump feedTuna
        "Meatloaf":
            stop music fadeout 3
            jump feedMeatloaf
        "Mystery food":
            stop music fadeout 3
            jump feedMysteryFood
        "Actually, let's eat later.":
            you "Eh, not too hungry right now..."
            "You decide to hold off on food and do something else."
            scene bg aptLivingRoom
            with wipeleft
            jump homeTogetherMenu

    label feedTuna:
        scene bg aptKitchen
        with dissolve
        you "Cats like fish, right?"
        "Shrugging, you take out the tuna for the cat and the meatloaf for yourself."
        "You put the frankly {i}ominous{/i} container back in the fridge."
        "The cat looks a little disappointed."
        "Tough."
        "You'll need to dispose of that weird... {b}{i}whatever-it-is{/i}{/b} later."
        "You open the tuna and spoon it onto a small saucer. You put the saucer on the kitchen counter next to the cat."
        "You don't think you should be encouraging it to eat up there..."
        "...but you figure it'll make up for electing not to feed it the toxic goop it wanted."
        play sound "audio/cat_confused.mp3" volume 0.2
        cat "Meow?"
        "The cat looks like it finds the tuna..."
        "...acceptable."
        "You'll take it."
        you "Eat up, kitty."
        play sound "audio/cat_sad.mp3" volume 0.2
        cat "Meow..."
        "As the cat digs into its meal, you go about heating up the meatloaf in the microwave."
        "While setting the time, you hear-"
        play sound "audio/cat_hiccup.mp3" volume 0.2
        cat "{size=-7}*hiccup*...{/size}"
        you "Hm?"
        "You turn and see that the plate is completely empty."
        you "Whoa, that was quick... You need to pace yourself-"
        play sound "audio/cat_hiccup.mp3" volume 0.4
        cat "*hiccup*..." with hpunch
        play sound "audio/cat_hiccup.mp3" volume 0.4
        cat "*hiccup*... *hiccup*..." with hpunch
        play sound "audio/cat_hiccup.mp3" volume 0.6
        cat "{size=+5}*HICCUP*{/size}" with hpunch
        you "!?"
        you "What the..?"
        show hiccup
        with dissolve
        "You watch, baffled, as the cat continues to hiccup, causing..."
        "...little bubbles to float out of its mouth..?"
        ".."
        "..."
        "Okay."
        "That's okay."
        "You can... You can process this. It's not {i}completely{/i} out of the realm of what's possible, right?"
        "..."
        "Right."
        "Best not to think too hard about it."
        scene bg feed3
        with dissolve
        play music "audio/LOOPS/12floatingPoisonIN.mp3"
        queue music "audio/LOOPS/12floatingPoisonLOOP.mp3" loop
        "Soon enough, the room is full of the floating bubbles."
        play sound "audio/cat_hiccup.mp3" volume 0.15
        cat "h.. h... {size=-5}*hiccup*{/size}..."
        "The cat releases a final, tiny bubble before yawning and laying down right there on the counter."
        play sound "audio/cat_purr.mp3" volume 0.2
        cat "Purr... Purr... Purr..."
        you "Well... Glad you enjoyed it..."
        "The bubbles haven't left the room or popped. They seem to be pretty resilient..."
        "..?"
        "Wait... What..?"
        you "What's that..?"
        "As one of the bubbles floats closer to you..."
        scene bg feed4
        with dissolve
        "...you see that there's actually something inside it."
        "A tiny... {i}furry{/i}..."
        "..?"
        "...fish?"
        you "..."
        you "This is just getting weirder and weirder..."
        "Still..."
        "You can't help but marvel at the impossible wonder in front of you..."
        scene bg feed5
        with dissolve
        "You lift a hand..."
        "..."
        scene bg feed6
        with dissolve
        "You extend a finger towards a bubble..."
        "...Carefully press it against the surface-"
        play sound "audio/bubblePop.mp3" volume 0.4
        scene bg feed7
        pause .2
        play sound "audio/gooeySquish.mp3" volume 0.02
        scene bg feed8
        pause .1
        scene black
        pause .05
        scene black
        with p_Red
        you "!!!" with vpunch
        "The little fish inside lashes out, viciously sinking tiny fangs into your finger."
        "It doesn't really hurt that much at first but then..."
        scene black
        with p_Red
        pause .3
        scene black
        with p_Red
        you "AHH! O-Ow! What..?" with vpunch
        "Pain starts to climb from your finger to the rest of your hand..."
        "Past your wrist..."
        "Could it be... some kind of {b}venom{/b}..?"
        "You fling your arm around in an attempt to dislodge the fish, but..."
        play sound "audio/bubblePop.mp3" volume 0.4
        scene bg feed9a
        with p_Red
        with hpunch
        pause .2
        play sound "audio/bubblePop.mp3" volume 0.4
        scene bg feed9b
        with p_Red
        with hpunch
        pause .2
        play sound "audio/bubblePop.mp3" volume 0.4
        scene bg feed9c
        with p_Red
        with hpunch
        you "!!!" with vpunch
        you "{size=+15}{b}{i}GAH!{/i}{/b}{/size}" with hpunch
        "...you accidentally knock your arm into several of the bubbles floating around."
        "More tiny, ravenous fish latch onto your flesh..."
        play sound "audio/bubblePop.mp3" volume 0.4
        pause .2
        play sound "audio/bubblePop.mp3" volume 0.4
        pause .2
        play sound "audio/bubblePop.mp3" volume 0.4
        "You stumble back out of pain and a sudden bout of dizziness, only to bump into more bubbles..."
        "...more fish digging their teeth into your back."
        play music "audio/LOOPS/12floatingPoisonOUT.mp3" noloop
        you "Ghh..! Uhnn..."
        "It hurts..."
        "You're getting dizzy..."
        "You've got to... get out..."
        "You deliriously try to stumble out of the kitchen..."
        scene bg feed9d
        pause .15
        scene bg feed9e
        pause .15
        scene bg feed9f
        pause .15
        scene black
        "...but the entire room is {i}filled{/i} with the deadly bubbles."
        "By the time you collapse to the ground, you're absolutely covered in tiny, angry, {b}biting{/b} fish..."
        "Your legs... {w}Your torso... {w}Your arms... {w}Your {i}face{/i}..."
        ".."
        "..."
        "...The pain is {b}unbearable.{/b}"
        "You can feel it in your skin and your teeth and your eyes and your hair and..."
        "...and it's so {i}consuming{/i} you can't even feel yourself convulsing."
        "...Or crying."
        "You don't black out."
        "Your eyes are still rolling up into your skull when you gasp out your last breath."
        ".."
        "..."
        "Ending 8: Fish Out of Water"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending8Done:
            jump endAtHome
        else:
            $persistent.ending8Done = True
            $persistent.endCounter += 1
            jump endAtHome


    label feedMeatloaf:
        scene bg aptKitchen
        with dissolve
        "You get the feeling the cat won't be too impressed with anything that comes out of a can."
        "And you're {i}not{/i} about to feed it whatever the heck that toxic-looking sludge is..."
        "So it's settled..."
        "A tuna sandwich for you and leftover meatloaf for your feline guest."
        "You ignore the cat's disappointed meows as you put the weird container back in the fridge to dispose of later."
        "You warm up the meatloaf in the microwave."
        ".."
        "..."
        play sound "audio/microwave.mp3" volume 0.4
        "{size=+5}{i}BEEP! BEEP! BEEP! BEEP!{/i}{/size}" with hpunch
        "You place the now warm meatloaf on a saucer next to the cat on the counter."
        "You don't think you should be encouraging it to eat up there..."
        "...but you figure it'll make up for electing not to feed it the toxic goop it wanted."
        play sound "audio/cat_confused.mp3" volume 0.3
        cat "Meow?"
        "The cat looks like it finds the meatloaf..."
        "...interesting."
        "Works for you."
        you "Eat up, kitty."
        play sound "audio/cat_sad.mp3" volume 0.3
        cat "Meow..."
        "As the cat digs into its meal, you go about searching for some bread for your tuna sandwich."
        "You're so distracted by your search that you only just barely hear-"
        play sound "audio/splat.mp3" volume 0.2
        "{size=-10}*splat*{/size}"
        you "Hm?"
        scene bg feed10
        with dissolve
        "You turn around and see that the meatloaf has only one, {i}maybe{/i} two bites taken out of it..."
        "But more alarmingly..."
        "There seems to be a red trail of..."
        "..."
        "...{i}something{/i}"
        "...leading away from where the cat had been sitting..."
        "...and off the edge of the counter towards the living room."
        you "{i}Is...{/i}"
        you "{i}{size=-5}Is that blood..?{/size}{/i}"
        play sound "audio/squelchLOOP.mp3" volume 0.3
        pause .3
        stop sound fadeout 1.5
        who "*gurgle*... *gurgle*... *grk*... Uhhnn..."
        you "!!" with vpunch
        "You jump at the strange sound coming from around the corner."
        "Further into your apartment."
        "..."
        "You... attempt to steel your nerves."
        scene bg aptLivingRoom
        with dissolve
        "Taking a breath, you walk around the counter to head into the living room-"
        play sound "audio/splat.mp3"
        scene bg aptLivingRoom
        with p_Red
        "*Splat*..."
        you "..?"
        you "!!!" with vpunch
        "You stepped in something warm and wet..."
        "...and {color=#FF0000}red.{/color}"
        "You resist the urge to vomit and step away from the trail of..."
        "Of..."
        "..."
        "You follow the trail into the living room and see that it leads into the hall."
        play sound "audio/squelchLOOP.mp3" volume 0.6
        pause .2
        stop sound fadeout 1.5
        who "{size=+5}*gurgle*... *grk*... *kurrgh*... Uhhhgh...{/size}"
        you "..."
        "It's getting louder."
        "It's {i}definitely{/i} in the hall."
        play sound "audio/heartbeat.mp3" volume 0.7 fadein 8 loop
        scene black
        with dissolve
        ".."
        "..."
        "You feel like you can hear your heartbeat."
        "..."
        "You hope whatever is in the hall {i}can't{/i}."
        "Your body shakes as you feel yourself step forward."
        "..."
        "...And forward."
        "..."
        "...And forward."
        "..."
        "...And {i}{b}forward.{/b}{/i}"
        you "..."
        "You peek..."
        "around the corner..."
        ".."
        "..."
        "..?"
        stop sound fadeout 2.5
        scene bg aptHall
        with dissolve
        "Nothing."
        "There's nothing there."
        you "What..?"
        "You walk further into the hall and see that the trail leads all the way down the end of it."
        "But there's nothing there..."
        "..."
        "You don't... quite feel relief. But at least-"
        play sound "audio/splat.mp3" volume 0.1
        scene bg aptHall
        with p_Red
        "{size=-10}*plop*{/size}"
        you "!!"
        "You feel something wet and warm drip onto your cheek."
        "Something... {i}very{/i} warm..."
        "You swipe your shaking hand across it and pull it back to see your fingers covered... in {color=#FF0000}something-{/color}"
        play sound "audio/squelchLOOP.mp3" volume 0.9
        scene bg feed11a
        with dissolve
        stop sound fadeout 1.5
        who "{size=+15}*gurgle*... *gurgle*...{/size}"
        play sound "audio/squelchLOOP.mp3" volume 0.95
        scene bg feed11b
        with dissolve
        stop sound fadeout 1.5
        pause .6
        play sound "audio/beastRoar.mp3" volume 0.5
        who "{size=+25}MREooUuhgh!!{/size}" with hpunch
        scene bg feed11c
        with dissolve
        you "..."
        "You look up."
        "And see what can only be described as..."
        "...{b}meat{/b}."
        play music "audio/LOOPS/13madeOfMeatIN.mp3"
        queue music "audio/LOOPS/13madeOfMeatLOOP.mp3" loop
        show meatEye
        with dissolve
        "The entire ceiling of the hallway is covered in a thick, undulating, writhing layer of pulsing {b}meat{/b}..."
        "...at its center is a single glowing eyeball, frantically rolling around in every direction..."
        ".."
        "..."
        scene bg feed12a
        hide meatEye
        pause .1
        scene bg feed12b
        pause .05
        show meatEyeLook
        "...until it lands squarely on you."
        you "{size=-8}Ah... ah..!{/size}"
        "You try to take a step back, desperate to escape the hallway..."
        "To escape this {b}thing{/b}..."
        "But-"
        play sound "audio/swishMEDIUM.mp3" volume 0.4
        scene bg feed12f
        play sound "audio/punch_LOW.mp3" volume 0.7
        hide meatEyeLook
        with hpunch
        you "!!!"
        "Before you can even scream, meaty tendrils shoot out and grab you."
        you "{size=+15}NNNOOO!!{/size}" with hpunch
        you "{size=+25}{i}LET ME GO!!{/i}{/size}" with hpunch
        scene black
        with dissolve
        "They pull you up."
        "And up..."
        scene bg feed13a
        with dissolve
        "...into a pair of slowly opening jaws."
        scene bg feed13b
        with dissolve
        "...And then-"
        scene black
        stop music
        show screen bloody
        play sound "audio/punch_MEDIUM.mp3" volume 0.6
        pause .1
        hide screen bloody
        with p_Red
        "{b}{size=+30}CHOMP!!{/size}{/b}" with vpunch
        ".."
        "..."
        "Ending 9: Leftovers"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending9Done:
            jump endAtHome
        else:
            $persistent.ending9Done = True
            $persistent.endCounter += 1
            jump endAtHome



    label feedMysteryFood:
        scene bg feed14a
        with dissolve
        you "..."
        you "{i}Is this really a good idea?{/i}"
        play sound "audio/cat_happy.mp3" volume 0.4
        cat "Meow! Meowww!" with hpunch
        you "..."
        you "Ugh... Fine, I guess if this is what you want..?"
        "You open the container and..."
        play sound "audio/squelchLOOP.mp3" volume 0.25
        scene bg feed14c
        pause .1
        scene bg feed14b
        pause .1
        stop sound fadeout 1
        scene bg feed14c
        with dissolve
        you "UGH! Hrk..!" with hpunch
        "You just barely manage to keep from throwing up."
        "But just {b}barely.{/b}"
        "The stench is {b}{i}overwhelming.{/i}{/b}"
        you "*cough*! *gulp*..."
        play sound "audio/cat_happyLONG.mp3" volume 0.4
        cat "Meow!" with hpunch
        you "Yeah, yeah... G-Give me a minute..."
        you "..."
        "You hazard a look at the contents of the container but..."
        scene bg feed14d
        with dissolve
        "..?"
        "You honestly can't understand what you're supposed to be {i}looking{/i} at."
        "Everything is just... {w}{b}mashed{/b} together."
        "What exactly \"everything\" consists of is a mystery you're {i}more{/i} than happy to keep unsolved."
        scene bg feed14e
        with dissolve
        "Different shapes... {w}Different sizes... {w}Different {i}textures{/i}..."
        "..."
        "Not the color though..."
        "{i}All{/i} of it is the same color..."
        "The most {b}unfortunate{/b} looking shade of gray you've ever seen..."
        "...tinted with a nauseatingly {i}wet{/i} {b}green{/b} film over the top..."
        scene bg aptKitchen
        with dissolve
        you "Hrk..."
        you "Am... Am I supposed to {i}warm{/i} it up or..?"
        "You don't really know how to serve it."
        "Any utensil or plate that touches it is getting thrown out {i}immediately.{/i}"
        "{b}No{/b} exceptions."
        "Your hands are going to be scrubbed with soap and hot water to within an inch of their lives after this..."
        "You decide against putting this crap in your microwave."
        "You doubt it would taste or smell any better warm."
        "Not wanting to hold it anymore, you shake your head and practically toss the container next to the cat on the counter."
        play sound "audio/cat_happy.mp3" volume 0.4
        cat "{size=+5}MEOW!!{/size}" with hpunch
        "The cat enthusiastically dives for the toxic looking sludge, sniffing it as if savoring the scent."
        "You turn to the fridge and close it."
        "..."
        "You've lost your appetite."
        "You're about to head to the bathroom to wash your hands for the next hour or so when-"
        play sound "audio/cat_eating.mp3" volume 0.4
        pause .2
        stop sound fadeout 0.5
        cat "*munch*!"
        play sound "audio/crunch.mp3" volume 0.3
        "{size=-5}*crunch*!{/size}" with vpunch
        scene bg aptKitchen
        show screen bloody
        play sound "audio/gooeySquish.mp3" volume 0.1
        pause .1
        hide screen bloody
        with p_Red
        you "!!!" with vpunch
        you "OW!!" with hpunch
        "A sharp pain on your foot causes you to stumble."
        "You catch yourself on the kitchen sink and look down to see that the tip of your sock is..."
        scene bg feed15a
        with dissolve
        "{color=#FF0000}...red.{/color}"
        "..?!"
        "And the red is still slowly spreading to the rest of your sock."
        "Are you {b}{i}bleeding?{/i}{/b}"
        "You quickly reach down and pull off your sock to see the damage."
        "..."
        you "!!!" with hpunch
        scene bg feed15b
        with dissolve
        play music "audio/LOOPS/14missingIN.mp3"
        queue music "audio/LOOPS/14missingLOOP.mp3" loop
        "..."
        "Your middle toe is..."
        "...{b}gone.{/b}"
        "It's just {i}gone{/i}... {w}Just a stump is left in its place... {w}steadily leaking blood onto the floor."
        scene bg aptKitchen
        with dissolve
        you "Ah... Ah..."
        "You clumsily step back as if it would help you get away from what you were seeing. The blood trail simply follows your movements."
        "9-1-1..."
        "..."
        "You have to... call 9-1-1..."
        you "P-Phone... Where's the-"
        scene bg aptKitchen
        show screen bloody
        play sound "audio/squelchLOOP.mp3"
        pause .2
        stop sound fadeout 0.5
        hide screen bloody
        with p_Red
        you "{b}!!!{/b}" with vpunch
        you "*COUGH!* *COUGH!* {b}*COUGH!*{/b}" with vpunch
        ".."
        "..."
        you "*gurgle* W... Wahs..."
        "Your..."
        "Your {i}tongue{/i} is...!"
        you "Wahs... {w}ahbehh...nnn?!"
        you "{i}What's happening to me..?!{/i}"
        play sound "audio/cat_eating.mp3" volume 0.4
        cat "*munch*... *munch*... *munch*..."
        "..."
        scene bg feed16
        with dissolve
        "You slowly look over to find the cat still eating."
        "Completely unbothered by your suffering."
        cat "*munch*... *munch*... *munch*..."
        "Not bothering to try and stop the blood from dribbling out of your mouth..."
        "...you keep watching in a daze as the cat happily chews at a gross piece of..."
        "..?"
        "Wait..."
        "That's..."
        "You look more closely at the mystery food in the cat's jaws."
        "It looks vaguely familiar..."
        "It... {w}looks... {w}like..."
        "{size=-10}...a tongue?{/size}"
        you "Ah..."
        cat "*munch*... *gulp*..."
        play sound "audio/cat_happyLONG.mp3" volume 0.4
        cat "Meowww!" with hpunch
        "Before you can even think to do anything to stop it, the cat dives into the container again..."
        "...and bites into a piece that looks kind of like a--{w=1.5}{nw}"
        scene bg feed17a
        play sound "audio/squelchLOOP.mp3" volume 0.7
        pause .2
        show screen bloody
        pause .1
        stop sound fadeout 0.5
        hide screen bloody
        with p_Red
        you "{size=+10}AAHHH!!{/size}" with vpunch
        you "GHH..!!" with vpunch
        "You collapse to the floor, clutching your torso."
        "You writhe around on the blood-streaked tiles, crying..."
        "Something... {w}Something {i}inside{/i} you just..."
        show screen bloody
        play sound "audio/splat.mp3" volume 0.7
        pause .1
        hide screen bloody
        with dissolve
        you "Blurgh!!" with vpunch
        "Blood pours out from deep within you..."
        "Whatever that was... {w}felt important..."
        "..."
        "...and now it's probably gone too."
        "..."
        "It hurts..."
        scene bg feed17b
        with p_Red
        "It hurts so {i}much...{/i}"
        you "S... Staaub... Puh... eese..."
        "You weakly try to reach up to the cat on the counter above you..."
        "Your vision blurs. From the effort... From the pain... From your tears... From-"
        scene black
        stop music
        play sound "audio/cut.mp3" volume 0.5
        show screen bloody
        pause .1
        play sound "audio/splat.mp3" volume 0.7
        hide screen bloody
        with p_Red
        stop sound
        you "UUHHgh!!" with vpunch
        "..."
        "!!!"
        you "Uhhnn..."
        ".."
        "..."
        "Your eyes..."
        "Your {b}{i}eyes{/i}{/b}..!"
        "..."
        "You fall limply back to the floor."
        "You're leaking blood all over... {w}{i}from{/i} all over..."
        "Your foot... Your mouth... Your insides... Your eyesockets..."
        "..."
        "You can feel your {i}life{/i} fading away too..."
        "..."
        "That's fine..."
        "If it means not feeling the pain of losing another part of you, then..."
        ".."
        "..."
        "Hopefully the cat will take its time eating your eyeballs..."
        "...and give {i}you{/i} time... {w}{alpha=0.5}to just...{/alpha} {w}{alpha=0.3}just...{/alpha}"
        you "..."
        ".."
        "..."
        "Ending 10: \"You are what you eat...\""
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending10Done:
            jump endAtHome
        else:
            $persistent.ending10Done = True
            $persistent.endCounter += 1
            jump endAtHome


label playHome:
    play sound "audio/cat_confused.mp3" volume 0.4
    cat "Meowww?"
    "Poor thing was probably bored stiff sitting in that old box all day..."
    "Just watching crowds of people walking by them..."
    "{i}Ignoring{/i} them..."
    "..."
    "You can't just leave them alone as soon you're home!"
    "A little interspecies socializing won't kill you, right?"
    play sound "audio/cat_sad.mp3" volume 0.3
    cat "Meow..."
    you "Aww... You just want some attention, don't you? You wanna play, huh?"
    play sound "audio/cat_happy.mp3" volume 0.4
    cat "Meow!" with hpunch
    you "Hehe, okay then!"
    "What to play though?"

    if not renpy.music.is_playing('music'):
        play music "audio/LOOPS/04homeWithYou.mp3" loop

    label playHomeMenu:
        menu:
            "Let's play with the cat!"
            "Look for some yarn?":
                jump playYarn
            "I think my laser pointer still works...":
                jump playLaser
            "Hide and seek: A classic!":
                jump playHideSeek
            "On second thought...":
                jump homeTogetherMenu

    label playYarn:
        "If every movie and cartoon involving cats that you've watched since childhood is to be believed..."
        "...then you can deduce with almost {i}absolute{/i} certainty..."
        "...that cats freaking {b}love{/b} yarn."
        "..."
        "...Probably."
        scene bg aptHall
        with dissolve
        pause .6
        scene bg yarn1a
        with dissolve
        pause .6
        scene bg yarn1b
        with dissolve
        pause .6
        scene bg yarn1c
        with dissolve
        "You unearth some from an old box in the hallway closet that's filled with knick-knacks from various abandoned hobbies."
        "You consider just handing the ball of bright red yarn over to the cat and supervising from the side..."
        "...but that would defeat the idea of playing {i}together{/i}, wouldn't it?"
        "You cut off a decent length of string from the ball of yarn and go back to the living room."
        scene bg aptLivingRoom
        with wiperight
        pause .6
        scene bg yarn2a
        with dissolve
        "The cat is resting on the floor."
        "It's not asleep, but when it looks up as you enter the living room, you feel like it could doze off right then and there."
        "You'll fix that~"
        "You smirk a little, confident with your surprise..."
        scene bg yarn2b
        with dissolve
        pause .3
        scene bg yarn2c
        with dissolve
        "...and let the piece of yarn dangle just above the floor, pinched between your thumb and index finger."
        $ renpy.music.set_volume(0.0, 0, "music")
        scene bg yarn2d
        pause .1
        scene bg yarn2e
        pause .1
        scene bg yarn2f
        cat "..."
        you "..!"
        cat "..."
        scene bg yarn2g
        with dissolve
        "The sudden shift in the cat's demeanor makes your heart start to beat a little faster."
        "Its posture has barely changed at all."
        "Just a subtle shift of the head and ears..."
        "A slight tension in the shoulders..."
        "A sharpness in the gaze as it locks onto the yarn dangling an inch above the floor."
        "The cat could still pass as being almost... relaxed."
        "Calm."
        play sound "audio/heartbeat.mp3" volume 0.4 fadein 9 loop
        scene bg yarn2h
        with dissolve
        "And yet the air is thick with its eagerness to lunge forward..."
        scene bg yarn2i
        with dissolve
        "...waiting for the right moment to strike."
        you "..."
        "You feel like you've just witnessed the awakening of the perfect predator."
        "You're... almost afraid of what will happen once you make the first move..."
        cat "..."
        you "..."
        "...But it {i}will{/i} be {i}you{/i} who makes the first move."
        scene black
        with dissolve
        "You take a deep breath..."
        cat "..."
        "Relax your shoulders..."
        cat "..."
        "And..."
        "..."
        stop sound
        scene bg yarn3a
        play sound "audio/wiggle.mp3"
        pause .1
        scene bg yarn3b
        pause .1
        scene bg yarn3a
        pause .1
        scene bg yarn3c
        pause .1
        scene bg yarn3a
        pause .1
        scene bg yarn3b
        pause .1
        scene bg yarn3a
        pause .1
        scene bg yarn3c
        pause .1
        stop sound
        scene bg aptLivingRoom
        play sound "audio/cat_happy.mp3" volume 0.4
        cat "{b}MEOW!!{/b}" with hpunch
        you "Yoink~!"
        $ renpy.music.set_volume(1.0, 0, "music")
        "The cat had lunged the instant you wiggled the yarn."
        "But you're faster."
        "It completely misses as you flick your wrist, making the yarn recoil out of its reach like a terrified snake."
        "Having overshot the landing in its eagerness, the cat stumbles and looks around as if shocked at its failed attack."
        "You generously click your tongue to help reorient it. The cat whips its head around at the sound."
        "You're slightly taken aback at the intensity of its stare on the yarn."
        "But you persist."
        "You wiggle the yarn again, encouragingly... {w}and yes, maybe a {i}little{/i} tauntingly."
        "This time, the cat anticipates the yarn's upward dodge and leaps up to swipe at it..."
        "But you're already one step ahead, puppeting the yarn to dance gracefully out of reach once more."
        play sound "audio/cat_angryQUICK.mp3" volume 0.4
        cat "Mreow!" with hpunch
        you "Hehe, come on. You can do it~"
        "It's a little condescending, but you can't seem to help it."
        "For some reason, it feels a little good knocking the feline down a peg or two."
        play sound "audio/cat_angry.mp3" volume 0.4
        cat "Mreow! Mreow!"
        "At least it seems to be enjoying itself?"
        "You {i}hope{/i} anyway..."
        "..."
        "You keep going."
        scene bg yarn4a
        play sound "audio/cat_angryQUICK.mp3" volume 0.4
        cat "Mreow!{w=0.7}{nw}" with vpunch
        scene bg yarn4b
        play sound "audio/cat_angry.mp3" volume 0.4
        cat "{size=+5}Mreow!!{/size}{w=0.7}{nw}" with vpunch
        scene bg yarn4c
        play sound "audio/cat_angryQUICK.mp3" volume 0.5
        cat "{size=+10}Mreow!!!{/size}{w=0.7}{nw}" with vpunch
        "The cat's movements have gotten more... aggressive."
        "It must be getting frustrated."
        "You could {i}swear{/i} it nearly took a shot at your eye that last time, it had jumped so high and erratically..."
        "You've been keeping the yarn in constant motion, afraid to slow down."
        "Your wrist is starting to get tired..."
        "The cat doesn't seem to be losing any energy though."
        "It's like..."
        "...it's getting faster and faster."
        play sound "audio/cat_angryQUICK.mp3" volume 0.4
        cat "{b}Mreow!{/b}" with vpunch
        "*Flick*"
        play sound "audio/cat_angry.mp3" volume 0.4
        cat "{size=+5}{b}Mreow!{/b}{/size}" with vpunch
        "*Flick*"
        play sound "audio/cat_angryQUICK.mp3" volume 0.5
        cat "{size=+10}{b}Mreow!{/b}{/size}" with vpunch
        "*Flick*-"
        play sound "audio/cut.mp3" volume 0.5
        scene bg aptLivingRoom
        with p_Red
        you "Nhh!"
        "Your wrist finally cramps sharply..."
        "...making you lose control of the yarn's motion as the tip of it brushes lightly against your stomach-"
        stop music
        scene black
        play sound "audio/swishQUICK_low.mp3" volume 0.4
        show slash
        pause .1
        pause .15
        show yarn5
        with p_Red
        play sound "audio/punch_MEDIUM.mp3" volume 0.6
        show screen bloody
        "{size=+25}{i}SLASH!!!{/i}{/size}" with hpunch
        hide screen bloody
        with dissolve
        play music "audio/LOOPS/15redStringIN.mp3"
        queue music "audio/LOOPS/15redStringLOOP.mp3" loop
        you "..!!! GHH!!" with vpunch
        "Pain rips low across your torso..."
        "...{i}into{/i} your torso."
        play sound "audio/splat.mp3" volume 0.8
        show screen bloody
        with p_Red
        stop sound fadeout 0.5
        you "B-Blurgh!" with vpunch
        "Blood pours out of your mouth..."
        hide screen bloody
        with dissolve
        "In a daze, you look down and see red blooming slowly along the bottom of your shirt... around the tears in the fabric..."
        you "*cough* *cough*-"
        play sound "audio/squelchLOOP.mp3" volume 0.6 fadein 1
        scene black
        with p_Red
        pause .2
        stop sound fadeout 0.5
        play sound "audio/splat.mp3"
        "{size=+10}{b}PLOP!{/b}{/size}" with vpunch
        you "!!!"
        you "A-Ah..!"
        show yarn6
        with dissolve
        "You watch as long thick ropes of..."
        "{i}...something...{/i}"
        "...pour out from under your shirt into a bloody heap on the floor at your feet."
        "A single red streaked rope still hangs from you... {w}{i}connecting{/i} you to all that... {b}mess{/b}."
        "Are... {w}Are those your...?"
        "You crumble to the ground and topple over onto your side."
        "Your vision has gone blurry..."
        play music "audio/LOOPS/15redStringOUT.mp3" noloop
        "But..."
        scene bg yarn7a
        with dissolve
        pause .6
        scene bg yarn7b
        with fade_Red
        "...you can just make out the shape of something small and a deep, inky black as it walks over and inspects your..."
        "{size=-10}Oh god, they're your {i}intestines{/i}...{/size}"
        "...before it starts to giddily roll around in the mass of your bloody insides next to you."
        play sound "audio/cat_happyLONG.mp3" volume 0.4
        cat "Meow! Meow!"
        scene black
        with fade_Red
        "Darkness falls over you..."
        play sound "audio/cat_trilling.mp3" volume 0.4
        cat "Meow!"
        you "..."
        "The cat... {w}sounds happy."
        "Nonsensically you wonder where the yarn has gone but... {w}there's really no need to worry about it."
        "The cat seems content with the next best thing."
        "..."
        "Ending 11: At The End of Your Rope"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending11Done:
            jump endAtHome
        else:
            $persistent.ending11Done = True
            $persistent.endCounter += 1
            jump endAtHome



    label playLaser:
        "Cats are curious creatures by nature..."
        "They're also natural hunters... Sort of."
        "Why not pass the time by letting the cat hunt after something it'll never quite understand?"
        "..."
        "That sounds a little mean when you think of it like that..."
        "But it's not like the cat will know anyway."
        "\"Ignorance is bliss\", or so they say."
        "So you dig out your old laser pointer from your long gone dreaded days of group presentations in school."
        "You flip it on and see that even after all this time, the batteries still work."
        "You get a little kick out of aiming it at a mirror hanging in the living room, so it reflects off the glass..."
        "...Making a little red dot appear on your knee."
        play sound "audio/cat_confused.mp3" volume 0.35
        cat "...Meow?"
        "The cat cautiously walks over, stopping every few steps to cast a look of suspicion at you."
        "When it finally reaches you, it lightly presses a paw to your knee..."
        "...like it's trying to catch the dot of red light as casually as possible."
        you "Hm!" with vpunch
        "You manage to hold back a chuckle. Not that it really matters."
        "The cat isn't paying attention to you at all, entirely focused on the light now resting on top of its paw."
        you "Hehe~"
        "You move the light a little higher above your knee."
        "The cat reacts immediately, trying to pin the light down..."
        "...but in the next second, you've already moved it to the floor."
        scene bg laser1a
        with dissolve
        "The cat jerkily follows, attempting a more energetic pounce when you shift the red dot..."
        "Over here..."
        scene bg laser1b
        with dissolve
        "Over there..."
        scene bg laser1c
        with dissolve
        "And over there..."
        scene bg laser2a
        with dissolve
        "By the couch..."
        scene bg laser2b
        pause .15
        scene bg laser2c
        pause .15
        scene bg laser2d
        pause .18
        scene bg laser2e
        pause .15
        "{i}On{/i} the couch..."
        scene bg aptLivingRoom
        with dissolve
        play sound "audio/cat_angryQUICK.mp3" volume 0.4
        cat "Mreow! Mreow!!" with hpunch
        you "Hehehe!"
        "The cat might be ignoring you, but you're certainly enjoying yourself."
        "It's been a while since you've laughed this much."
        "..."
        "You're laughing {i}so{/i} much in fact..."
        "...that you accidentally shift the red dot onto a lamp beside the couch."
        play sound "audio/cat_angry.mp3" volume 0.4
        cat "{size=+10}Mreow!{/size}" with hpunch
        "In its haste to get the light, the cat leaps onto the lamp, sending them both to the ground."
        stop music
        pause .01
        play sound "audio/crash.mp3" volume 0.4
        "{size=+20}CRASH!!{/size}" with vpunch
        you "*Gasp* Oh my gosh!"
        scene bg laser3
        with dissolve
        "The cat is sitting in the middle of the former lamp's broken shards..."
        "...back hunched, its head whipping around back and forth as if in a panic."
        "You quickly turn off the laser pointer and rush over."
        you "I'm so sorry! A-Are you okay? Are you hurt?"
        "You reach down to pick up the cat and check it for any injuries when-"
        play sound "audio/cat_angryQUICK.mp3" volume 0.65
        cat "{size=+5}MREOWR!!{/size}" with vpunch
        play sound "audio/swishQUICK.mp3" volume 0.3
        scene bg aptLivingRoom
        with p_Red
        play sound "audio/gooeySquish.mp3" volume 0.25
        "{size=+20}{i}SLASH!{/i}{/size}" with hpunch
        you "OW! Hey!"
        "The cat swipes at you, claws extended."
        "It backs up and twitches away, making frantic half turns in various directions as if looking for something..."
        "...or {i}waiting{/i} for something to appear."
        you "Ow, geez... That really hurt, you know..."
        "You hold the hand with the scratch close to your chest."
        "It's bleeding, but it's not too big. You're more annoyed than anything but..."
        play sound "audio/cat_angryQUICK.mp3" volume 0.3
        cat "Mreowr!{w=0.75}{nw}" with hpunch
        play sound "audio/cat_angryQUICK.mp3" volume 0.5
        cat "Mreowr! Mreowr!{w=1}{nw}" with hpunch
        "...immediately your annoyance starts to bleed into concern."
        play sound "audio/cat_angry.mp3" volume 0.65
        cat "{i}MREOWR!{/i}" with vpunch
        "You watch in shock as the cat starts to run around tearing at the carpet, the sofa, your armchair..."
        "You want to stop it, but you're afraid of getting in the middle of its rampage."
        "You consider calling a vet for advice on how to calm it down, but for some reason..."
        "..."
        show screen blackOut
        "{size=-10}...you feel like that wouldn't be a good idea.{/size}"
        hide screen blackOut
        "..."
        you "What happened to you...? Is it...?"
        you "..!" with vpunch
        "An idea comes to you. Or rather, a realization?"
        "You grasp the laser pointer, aiming it safely away towards the floor in the middle of the living room..."
        "Thinking... {w}{i}hoping{/i}... {w}that the cat would calm down if it found what it was looking for..."
        "...you turn on the laser pointer."
        cat "!!!" with hpunch
        scene black
        with dissolve
        ".."
        "..."
        "The cat's reaction is {b}immediate.{/b}"
        play music "audio/LOOPS/16laserFocusedIN.mp3"
        queue music "audio/LOOPS/16laserFocusedLOOP.mp3" loop
        play sound "audio/cat_angry.mp3" volume 0.4
        cat "Mreowr!" with hpunch
        play sound "audio/cat_angry.mp3" volume 0.5
        cat "{size=+15}MREOWR!! {/size}" with hpunch
        play sound "audio/beastRoar.mp3" volume 0.8
        cat "{size=+25}{b}MROARRRR!!!{/b}{/size}" with hpunch
        you "!!!"
        "..."
        "{size=-8}...You screwed up.{/size}"
        scene bg tvFloor1
        with dissolve
        "In the span of mere seconds, you watch as the cat spies the red dot from its perch on the shredded armchair..."
        scene bg laser4a
        with dissolve
        "...leaps high into the air..."
        scene bg laser4b
        with dissolve
        "...{i}{b}changes{/b}{/i} in the air..."
        play sound "audio/humanImpact.mp3"
        scene bg p9
        with vpunch
        play sound "audio/crash.mp3" volume 0.8
        "{size=+35}{b}CRASH!!{/b}{/size}{w=0.2}{nw}" with hpunch
        "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch
        you "!!!"
        hide screen blank
        "...and slams down upon the dot on the floor, with a weight and force that {i}shakes{/i} the whole apartment."
        "Maybe even the whole building."
        "You wonder dazedly how none of the other tenants have rushed over to complain about the noise..."
        "Yet as you stare at the sight in front of you..."
        scene bg laser5
        with dissolve
        play sound "audio/beastGrowl.mp3"
        "The cat has somehow {i}grown{/i} in size..."
        "...eyes bulging and glowing... {w}tail thrashing... {w}teeth enlarged, bared and covered alarmingly in a bubbling froth..."
        scene bg p9
        with dissolve
        "Its giant claws rip and shred through the carpet, through the floor tiles and even {b}below{/b} them..."
        "...ravenously trying to get at the red dot."
        "Your hands are shaking."
        "You don't know what to do. You feel trapped. You have to get away."
        "...Get {i}it{/i} away from you."
        you "!!"
        "You slowly back up towards the door."
        "The light moves with you."
        cat "{size=+10}!!!{/size}" with hpunch
        you "!!!"
        "Instinctively you flick the light away, this way and that, the cat stampeding after it..."
        play sound "audio/crash.mp3"
        "{size=+30}{b}CRASH!!{/b}{/size}" with vpunch
        you "{i}So fast...{/i}"
        "...smashing through the TV ...breaking the couch in the half..."
        play sound "audio/crashBig.mp3"
        "{size=+30}{b}CRASH!!{/b}{/size}{w=0.2}{nw}" with vpunch
        play sound "audio/crashBigger.mp3"
        "{size=+30}{b}CRASH!! CRASH!!{/b}{/size}" with vpunch
        you "{i}Too fast...{/i}"
        "...bulldozing through the wall into the hallway."
        play sound "audio/crashHuge.mp3"
        "{size=+35}{b}CRASH!!{/b}{/size}" with vpunch
        you "!!"
        "A chance!"
        "You turn, intending to bolt out of the door and never come back..."
        "...but in your haste, you {b}forget{/b} something."
        "You forget {i}several{/i} somethings."
        "You forget the laser pointer, gripped like a lifeline in your hand..."
        cat "!!!"
        "You forget the mirror, still miraculously hanging on the wall next to the hallway..."
        "...the laser reflecting off of it..."
        "...putting a small, glowing red dot..."
        "..."
        "...on the back of your head..."
        cat "..."
        play music "audio/LOOPS/16laserFocusedOUT.mp3" noloop
        scene black
        with dissolve
        "And as you reach the door..."
        play sound "audio/beastGrowl.mp3"
        cat "{b}*GROWL*{/b}"
        "..."
        "...you forget that it's locked."
        scene bg p9
        with dissolve
        pause .5
        scene bg laser6a
        with dissolve
        pause .2
        scene bg laser6b
        with dissolve
        pause 1
        play sound "audio/swishMEDIUM.mp3" volume 0.1
        scene bg laser6c
        pause .05
        scene bg laser6d
        pause .05
        scene bg laser6e
        pause .02
        scene black
        play sound "audio/swishMEDIUM.mp3" volume 0.5
        show slash
        pause .1
        scene black
        play sound "audio/punch_LOW.mp3" volume 0.8
        show screen bloody
        with p_Red
        with vpunch
        pause .5
        hide screen bloody
        with dissolve
        ".."
        "..."
        "You don't even have the chance to turn around before the cat lunges all the way across the room at you."
        scene black
        play sound "audio/swishQUICK_low.mp3" volume 0.5
        show slash
        pause .1
        scene bg redScreen
        with p_Red
        play sound "audio/punch_MEDIUM.mp3" volume 0.8
        show screen bloody
        with vpunch
        pause .2
        hide screen bloody
        pause .1
        scene black
        with dissolve
        pause .3
        play sound "audio/swishQUICK_low.mp3" volume 0.5
        show slash
        pause .1
        scene bg redScreen
        with p_Red
        play sound "audio/punch_LOW.mp3" volume 0.8
        show screen bloody
        with vpunch
        pause .2
        hide screen bloody
        pause .1
        scene black
        with dissolve
        pause .3
        play sound "audio/swishQUICK_low.mp3" volume 0.5
        show slash
        pause .1
        scene bg redScreen
        with p_Red
        play sound "audio/punch_MEDIUM.mp3" volume 0.8
        show screen bloody
        with vpunch
        pause .2
        hide screen bloody
        with dissolve
        scene black
        with dissolve
        pause .5
        you "..."
        "You're torn to shreds before you can even blink."
        "..."
        "Ending 12: Targeted"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending12Done:
            jump endAtHome
        else:
            $persistent.ending12Done = True
            $persistent.endCounter += 1
            jump endAtHome



    label playHideSeek:
        you "What about hide and seek..?"
        play sound "audio/cat_confused.mp3" volume 0.3
        cat "Meow?"
        you "..."
        cat "..."
        "You're... not quite sure how this is going to work."
        "Can a cat even understand the concept of a {i}game...{/i} {w}let alone one with rules like hide and seek?"
        you "Hmm... Here, just..."
        "You pick up the cat and turn them away from you before hiding behind the armchair."
        scene bg hide1a
        with dissolve
        "You're almost certain the cat must've turned and looked while you were hiding... {w}out of confusion at least, if nothing else..."
        scene bg hide1b
        pause .1
        scene bg hide1c
        pause .1
        scene bg hide1d
        pause .1
        scene bg hide1e
        play sound "audio/cat_confused.mp3" volume 0.3
        cat "Meow?"
        "Regardless, a few moments later, the cat cautiously peeks around the armchair at you, eyes curious."
        scene bg aptLivingRoom
        with dissolve
        "You smile and scoop it up, holding it out in front of you."
        you "You found me! You win!!"
        play sound "audio/cat_happy.mp3" volume 0.4
        cat "Meow! Meow!" with hpunch
        "The cat looks confused, but pleased at your praise."
        "This time, you put it on the armchair so it can't see your hiding spot as easily."
        scene bg aptKitchen
        with wiperight
        "You dash over to the kitchen, hiding behind the counter."
        "It takes a little longer this time for the cat to find you."
        "This time, when it does, it startles you by hopping down into your lap from the countertop above."
        you "Whoa!" with vpunch
        play sound "audio/cat_happyLONG.mp3" volume 0.3
        cat "Meow! Meoww!" with hpunch
        you "You found me again!"
        play sound "audio/cat_happy.mp3" volume 0.3
        cat "Meoww!"
        you "Hehe, okay okay, you win!"
        "You reward it with little scratches behind the ear and under the chin when it leans into your touch."
        play sound "audio/cat_purr.mp3" volume 0.3
        cat "Purr.. Purr.."
        you "Hehe~ Okay, why don't you give it a try?"
        play sound "audio/cat_confused.mp3" volume 0.3
        cat "Meow?"
        scene bg aptLivingRoom
        with dissolve
        "You go and stand in the middle of the living room..."
        scene bg hide2a
        with dissolve
        "...the cat following you."
        scene bg hide2b
        pause .15
        scene bg hide2c
        pause .15
        scene bg hide2d
        pause .15
        scene bg hide2e
        pause .3
        scene black
        with dissolve
        "You make a show of covering your eyes and turning around."
        you "Okay~"
        you "5... 4... 3... 2... 1... Go!"
        scene bg hide2e
        with dissolve
        pause .15
        scene bg hide2f
        pause .15
        scene bg hide2g
        pause .15
        scene bg hide2h
        pause .15
        scene bg hide2i
        pause .6
        "You turn around and see that the cat is gone."
        scene bg aptLivingRoom
        with dissolve
        you "Huh, you sure catch on quick..."
        "There aren't that many places available in your apartment for someone your size to hide..."
        "...but without the opposable thumbs needed to open the closed doors in the hall, the cat will have its limits too."
        "Fair game."
        you "Okay, now where to look~"

        if not renpy.music.is_playing('music'):
            play music "audio/LOOPS/04homeWithYou.mp3" loop

        label seekingCatMenu:

        if catNotFound == 3:
            jump seekingDone

        menu:
            "Living Room" if seekLivingRoomDone < 1:
                jump seekLivingRoom
            "Kitchen" if seekKitchenDone < 1:
                jump seekKitchen
            "Hallway" if seekHallwayDone < 1:
                jump seekHallway

        label seekLivingRoom:
            "You look behind the couch and the armchair... {w}Then under the coffee table..."
            "..."
            "Nothing. The living room is pretty sparse when it comes to furniture, after all."
            $ catNotFound += 1
            $ seekLivingRoomDone += 1
            jump seekingCatMenu


        label seekKitchen:
            scene bg aptKitchen
            with dissolve
            "You peek around the counter... {w}Grab a chair and check on top of the fridge..."
            "You even open the cupboards along the floor, just in case the cat managed to squeeze inside..."
            "..."
            "Nothing. You decide that's for the best."
            "The kitchen is for making food, not playing games."
            scene bg aptLivingRoom
            with dissolve
            $ catNotFound += 1
            $ seekKitchenDone += 1
            jump seekingCatMenu


        label seekHallway:
            scene bg aptHall
            with dissolve
            "You peek around the corner into the hall..."
            "..."
            "..."
            "Nothing. You're not sure what you were expecting."
            "With all the doors closed..."
            "There's nowhere in the hall for the cat to hide."
            scene bg aptLivingRoom
            with dissolve
            $ catNotFound += 1
            $ seekHallwayDone += 1
            jump seekingCatMenu


        label seekingDone:
            stop music fadeout 5
            "You couldn't find the cat anywhere..."
            "You start to get a little worried when you hear a soft sound coming from... the hall..?"
            scene bg aptHall
            with wipeleft
            "You head to the hall and listen again."
            ".."
            "..."
            play sound "audio/scratchDoor.mp3" volume 0.15
            "{size=-5}*scratch* *scratch*{/size}"
            "That sounded like it was coming from... your bedroom... but..."
            "You walk down the hall to your room and gingerly open the door-"
            play sound "audio/cat_trilling.mp3" volume 0.3
            cat "Meow!" with hpunch
            you "Gah!" with vpunch
            "The cat trots out and runs around your legs, and meowing insistently."
            play sound "audio/cat_angryQUICK.mp3" volume 0.3
            cat "Meow! Meow!"
            "It looks... {w}disappointed somehow? {w}Perhaps in your apparently subpar seeking skills..."
            "But..."
            "You lift the cat into your arms and look at your bedroom door."
            you "How did you... get in my room?"
            play sound "audio/cat_happy.mp3" volume 0.3
            cat "Meow!"
            you "..."
            "You... {w}You {i}know{/i} the door was closed."
            "{size=-5}Right..?{/size}"
            "The cat wiggles out of your hold and runs out of the hall."
            you "..."
            scene bg aptLivingRoom
            with dissolve
            pause .6
            scene bg hide3a
            with dissolve
            "You follow to see it sitting in the middle of the living room."
            play sound "audio/cat_angryQUICK.mp3" volume 0.25
            cat "Meow!"
            scene bg hide3b
            with dissolve
            "Upon seeing you, the cat promptly turns around."
            "Guess it wants to take its turn seeking?"
            "You're about to indulge it by hiding around the counter again when-"
            play sound "audio/click.mp3" volume 0.3
            scene black
            you "!!"
            "The lights... Did the power go out?"
            you "Darn it..."
            scene bg p9
            with dissolve
            "As you wait for your eyes to adjust to the darkness..."
            scene bg hide4
            with dissolve
            pause .6
            "...you notice that the cat hasn't moved an inch."
            "Was it scared?"
            you "Hey, are you-"
            play sound "audio/heartbeat.mp3" volume 0.6 loop
            "*Badum* *Badum* *Badum*"
            "..?"
            "What?"
            "For some reason..."
            "...your heart starts beating faster."
            "You..."
            play music "audio/tvStatic.mp3" loop
            show hide5a
            with dissolve
            "You consider going to over to the cat..."
            "But when you do..."
            show hide5b
            with fade_Red
            "...the thought makes you feel..."
            play music "audio/glitch.mp3" volume 0.5 noloop
            scene bg p9
            with hpunch
            you ".."
            you "..."
            "...You feel like your life is in danger."
            ".."
            "..."
            "You need to hide."
            stop sound
            "{b}Now.{/b}"
            play music "audio/LOOPS/17iSeeYouIN.mp3"
            queue music "audio/LOOPS/17iSeeYouLOOP.mp3" loop

            label hidingHomeMenu:
                if not renpy.music.is_playing('music'):
                    play music "audio/LOOPS/17iSeeYouIN.mp3"
                    queue music "audio/LOOPS/17iSeeYouLOOP.mp3" loop

            show screen my_timer
            with dissolve

            menu:
                    "Hide behind the armchair." if hideArmchair < 1:
                        jump hidingArmchair
                    "Hide behind kitchen counter." if hideKitchen < 1:
                        jump hidingKitchen
                    "Hide in the hall." if hideHallway < 1:
                        jump hidingHall
                    "Hide in the hallway closet." if hideHallCloset < 1:
                        jump hidingHallCloset
                    "Hide in the bathroom." if hideBathroom < 1:
                        jump hidingBathroom
                    "Hide in your bedroom...":
                        jump hidingBedroom
                    "Get out of the apartment." if hideGetOut < 1:
                        jump hidingGetOut
                    "Sit on the couch." if hideCouch < 1:
                        jump hidingSitOnCouch

            label time_out:
                stop music
                show screen blackOut
                play sound "audio/punch_LOW.mp3" volume 0.7
                show screen bloody
                with p_Red
                scene black
                hide screen blackOut
                hide screen bloody
                with dissolve
                pause .6
                show screen catEyesFade
                with dissolve
                "..."
                show text "{alpha=0.2}How disappointing...{/alpha}" at truecenter
                with dissolve
                pause 2
                hide text
                with dissolve
                pause .6
                hide screen catEyesFade
                with fade_Red
                "You failed."
                "..."
                "Try again?"

                menu:
                    "Yes":
                        $ clock = 100
                        $ hideArmchair = 0
                        $ hideKitchen = 0
                        $ hideHallway = 0
                        $ hideHallCloset = 0
                        $ hideGetOut = 0
                        $ hideBathroom = 0
                        $ hideCouch = 0
                        scene bg p9
                        jump hidingHomeMenu
                    "No":
                        jump endAtHome


            label hidingArmchair:
                "No, that's too close. It would find you immediately."
                $ hideArmchair += 1
                jump hidingHomeMenu

            label hidingKitchen:
                "You've hidden there before and it found you almost instantly. That won't work."
                $ hideKitchen += 1
                jump hidingHomeMenu

            label hidingHall:
                "Just... In the hall?"
                "{size=-5}{b}There's nowhere to {i}hide{/i} in the hall.{/b}{/size}"
                $ hideHallway += 1
                jump hidingHomeMenu

            label hidingHallCloset:
                scene bg aptHallDark
                with wipeleft
                pause .6
                scene black
                with wipeleft
                "You quietly slip into the hallway closet..."
                "..."
                you "!!!" with hpunch
                "The door won't close because a heavy box is now blocking it after you squeezed inside."
                "If you try to move it further, the cat might hear it."
                "That is, if it hasn't heard you already."
                "This won't work. You need to hide somewhere else."
                "Hurry!"
                scene bg p9
                with dissolve
                $ hideHallCloset += 1
                jump hidingHomeMenu

            label hidingBathroom:
                scene bg aptHallDark
                with wipeleft
                "You quietly rush to the bathroom and-"
                play sound "audio/doorLocked.mp3" volume 0.7
                "*clink!* *clink!* *clink!*" with hpunch
                you "{i}What?! Why is the door {b}locked?!{/b}{/i}"
                "You freeze upon realizing how much noise you just made jostling the doorknob and hold your breath."
                "Listening..."
                you "..."
                "The silence coming from the living room feels heavier than before. More restless."
                "Even if some miracle opened the door now, it would know exactly where you were. No good."
                scene bg p9
                with dissolve
                $ hideBathroom += 1
                jump hidingHomeMenu

            label hidingBedroom:
                scene bg aptHallDark
                with wipeleft
                pause .6
                scene bg aptBedroomDark
                with wipeleft
                "You quietly rush into the bedroom, carefully closing the door behind you."
                "The only place to hide in your bedroom is your closet."

                menu:
                    "Hide in the closet.":
                        jump hideAndSeekEnd
                    "Risk another hiding spot.":
                        scene bg p9
                        with dissolve
                        jump hidingHomeMenu

                label hideAndSeekEnd:

                    hide screen my_timer
                    with dissolve

                    play sound "audio/slidingDoorClose.mp3" volume 0.7
                    pause .3
                    scene bg hide7a
                    pause .15
                    scene bg hide7b
                    pause .15
                    scene bg hide7c
                    pause .15
                    scene black
                    play music "audio/LOOPS/17iSeeYouOUT.mp3" noloop
                    "You lock the door as quietly as you can before lunging into the closet and sliding the door shut."
                    "As soon as you've secured yourself inside the closet..."
                    "...there's a sudden shift throughout the entire apartment."
                    "As if something can sense that you're as ready as you'll ever be..."
                    "As if it can sense..."
                    "...that you're ready to be hunted."
                    "A horrible chill runs down your spine as you realize that's what this game has become."
                    "This isn't a simple game of hide and seek anymore."
                    "This is being {i}hunted{/i} by a predator... as prey."
                    "It..."
                    "{size=-10}It never really mattered where you chose to hide, did it?{/size}"
                    play sound "audio/doorBang1.mp3"
                    "{size=+15}*BAM!!*{/size}" with hpunch
                    you "!!!" with vpunch
                    "As if in answer to your question, you hear a loud slam on the bedroom door."
                    "You {i}just{/i} manage to hold back from making a startled noise at the sound."
                    play sound "audio/doorBang2.mp3"
                    "{size=+20}*BAM!! BAM!!*{/size}" with hpunch
                    play music "audio/heartbeat.mp3" loop
                    "Your heart rate kicks up again, making it feel hard to breathe quietly. Hard to breathe in general..."
                    play sound "audio/doorBang3.mp3"
                    "{size=+25}*BAM!! BAM!! BAM!!*{/size}" with hpunch
                    "Tears fill your eyes as you cover your panting mouth with your shaking hands."
                    "It knows."
                    "It {i}{b}knows{/b}{/i}."
                    "Crying with your hands over your mouth, trying to smother the choked sounds leaking out of you..."
                    "...you slide down the wall at the back of your closet into a heap on the floor."
                    play sound "audio/doorBang4.mp3"
                    "{size=+30}*BAM!! BAM!! BAM!! BAM!! BAM!! BAM!! BAM!!*{/size}" with vpunch
                    play sound "audio/breakDoorLOUD.mp3"
                    "{size=+35}{i}{b}*CRACK!! CRASH!!*{/b}{/i}{/size}" with hpunch
                    "You flinch harshly at the sound of the door being ripped off its hinges... {w}followed by a loud crash against the wall on the other side of the room..."
                    "Like the door had been {b}blown{/b} away..."
                    ".."
                    "..."
                    "The silence that follows... is almost too much to bear."
                    "You... You can't..."
                    you "{size=-8}*sob*{/size}" with vpunch
                    "A single sob escapes through your nose."
                    "..."
                    "You squeeze your eyes shut in defeat at how loud it sounds in the quiet of the room."
                    "Not much point in hiding it anymore anyway, is there?"
                    "You instinctively put whatever energy you have left into listening for footsteps.."
                    "...even as you emotionally shut down."
                    "But you hear nothing."
                    "...Nothing."
                    "... {w}...Nothing."
                    "Then..."
                    "..."
                    play sound "audio/slidingDoorOpen.mp3" volume 0.2
                    "{size=-10}*Shhhheeee*{/size}"
                    you "!!!"
                    "Something..."
                    "...slides open the closet door."
                    scene black
                    with dissolve
                    "You've curled in on yourself."
                    "Knees up... {w}Back curved forward... {w}Head down... {w}Mouth covered... {w}Eyes shut tight, so tight it hurts."
                    "You don't want to look."
                    "You don't want to {i}{b}look{/b}{/i}."
                    "But that's what it's waiting for."
                    "It won't end you without this final act of cruelty."
                    "Of making you {b}look{/b} at it before it takes your life."
                    "So... {i}so{/i} cruel."
                    "You just want this to be over..."
                    "So..."
                    ".."
                    "..."
                    stop music
                    "...you open your eyes."
                    scene bg hide7c
                    with dissolve
                    pause .6
                    scene bg hide7d
                    with dissolve
                    pause .1
                    scene bg hide7e
                    with dissolve
                    pause .1
                    scene bg hide7f
                    with dissolve
                    pause .1
                    scene bg hide7g
                    with dissolve
                    pause 2
                    scene bg hide7h
                    with fade_Red
                    pause .15
                    "You see... {w}{i}something...{/i} {w}glaring in at you from the darkness beyond the closet door."
                    "It looks..."
                    "..."
                    "...disappointed."
                    scene black
                    with dissolve
                    "In the moment before you draw your last breath, you almost consider apologizing for being such unworthy prey."
                    "Guess your hiding skills were just as subpar as your seeking skills."
                    ".."
                    "..."
                    "Ending 13: Disappointing Prey"
                    # if persistent.testingNow:
                    #     jump endAtHome
                    if persistent.ending13Done:
                        jump endAtHome
                    else:
                        $persistent.ending13Done = True
                        $persistent.endCounter += 1
                        jump endAtHome


            label hidingGetOut:
                scene black
                with dissolve
                "You're halfway to the front door when-{w=0.75}{nw}"
                scene bg hide6a
                pause .1
                play sound "audio/glitch.mp3" volume 0.6
                scene bg hide6b
                pause .1
                scene bg hide6c
                pause .1
                scene bg hide6d
                pause .1
                play sound "audio/jumpscareQUICK.mp3" volume 0.6
                scene bg hide6e
                pause .1
                scene black
                you "!!!" with vpunch
                "You look at the door and see several more locks over it than you {i}know{/i} you have."
                "You peek over at the cat. It's not looking at you but..."
                "...You feel a wave of disappointment practically pouring from it into you."
                "It feels almost..."
                "...like a warning."
                you "..."
                "You back away from the door and the feeling slowly subsides, letting you breathe again."
                "There's no getting out then."
                "You need to hide."
                scene bg p9
                with dissolve
                $ hideGetOut += 1
                jump hidingHomeMenu

            label hidingSitOnCouch:
                "..."
                "Are you joking?"
                "You get the feeling the cat won't appreciate your lack of effort, and anyway..."
                "{size=-8}...like {b}hell{/b} are you getting any closer to it.{/size}"
                "Stop messing around and find a place to hide."
                $ hideCouch += 1
                jump hidingHomeMenu



label cleanCat:
    "Upon giving it a second look..."
    "...you realize that the cat isn't exactly clean."
    "Not surprising since up until you brought it home, it's been sitting in a dirty, old box..."
    "...in an alley full of scattered garbage... {w}for who knows how long..."
    "You've heard that cats can keep themselves clean..."
    "...but maybe this is one of those times that a little human help couldn't hurt?"
    scene black
    with wipeleft
    pause .6
    scene bg aptBath_O
    with dissolve
    "You head into the bathroom and set things up, trying to remember how to wash a cat."
    "You're definitely no expert but you think the best way to get a cat clean would be..."

    menu:
        "Quickly":
            jump cleanQuick
        "Carefully":
            jump cleanCareful

    label cleanQuick:
        "Cats don't like water, you think..."
        "So a quick wash would be the way to go, right?"
        "You decide to do everything at once, filling the tub deep with soapy, bubbly warm water."
        "A quick dunk here, a short scrubbing there, then rinse and dry."
        "The cat won't even know what hit it before everything's over."
        "You open the door and click your tongue, beckoning the cat inside."
        "It quickly scampers in, curious of the newly available setting."
        play sound "audio/doorClose.mp3" volume 0.15
        scene bg aptBath_C
        with dissolve
        "You close the door so it won't be able to run out and make a mess of the apartment..."
        "Steeling yourself, you roll up your sleeves."
        scene bg cleanQ1a
        with dissolve
        "You lift up the cat and carry it over to the tub."
        "Your plan's already compromised as the cat starts to struggle in your hold."
        "You probably should've held it so it couldn't see the water?"
        play sound "audio/swishQUICK.mp3" volume 0.15
        queue sound "audio/gooeySquish.mp3" volume 0.2
        scene bg aptBath_C
        with p_Red
        you "Ow! Ow, hey!"
        "It scratches at your arms. {w}You knew it wouldn't be happy about the water..."
        "...but you didn't think it'd be {i}this{/i} irate."
        "Still, as mad as it will be at you for a little while... {w}you know this is for the best."
        play sound "audio/swishQUICK.mp3" volume 0.3
        queue sound "audio/gooeySquish.mp3" volume 0.3
        scene bg cleanQ1a
        with p_Red
        with vpunch
        "A deep scratch to your bicep startles you..."
        scene bg cleanQ1b
        with dissolve
        stop music
        "...making you drop the cat into the tub."
        scene bg cleanQ1c
        pause .1
        scene bg cleanQ1d
        pause .15
        play sound "audio/cat_angry.mp3" volume 0.6
        cat "{size=+10}MREAWWRRR!!!{/size}" with hpunch
        play sound "audio/splash.mp3" volume 0.2
        "{size=+20}{b}SPLASH!!{/b}{/size}" with vpunch
        you "!! Shoot! Kitty?!"
        "..."
        scene bg cleanQ2a
        with dissolve
        "The cat doesn't reemerge hissing and yowling like you thought it would."
        you "!!!"
        "You rush over and dunk your arms beneath the soapy surface, searching for the cat."
        "What if it bumped its head and blacked out?! It would drown!"
        ".."
        "..."
        "But you don't find the cat."
        "Instead..."
        play music "audio/LOOPS/18soapyDepthsIN.mp3"
        queue music "audio/LOOPS/18soapyDepthsLOOP.mp3" loop
        scene bg cleanQ2b
        with dissolve
        you "..?! What the..?"
        "...you watch as the water starts to darken."
        "At first, you think it's just dirt from the cat and feel a little vindicated about your decision, but..."
        scene bg cleanQ2c
        with dissolve
        pause .2
        scene bg cleanQ2d
        with dissolve
        "...the water darkens further and further..."
        scene bg cleanQ2e
        with dissolve
        "...until it looks like you've filled your tub with {i}black ink{/i}, rather than water."
        "Even the soap bubbles are a transculent obsidian now..."
        you "This is..."
        "Something's... not right."
        "But as soon as you have this thought-"
        "!!!" with vpunch
        you "W-Whoa!"
        ".."
        "..."
        "You just..."
        "You just felt something tugging you from under the water."
        "You try to pull away... but your arm won't budge."
        "Whatever it is, it pulls you closer toward the water."
        "You try to use your free hand to release the drain plug..."
        "...but when you dunk your other arm in the water without thinking..."
        "...it's grabbed {i}too.{/i}"
        "Both hands restrained, you can't get any leverage to force yourself free."
        you "H-HEL-"
        stop music
        play sound "audio/splash.mp3" volume 0.5
        scene black
        "{size=+30}{b}{i}SPLASH!!{/i}{/b}{/size}" with vpunch
        play music "audio/LOOPS/18soapyDepthsOUT.mp3" fadein 0.5 noloop
        ".."
        "..."
        "You're dragged into the murky waters of the tub."
        "You're dragged down..."
        "And down..."
        "And down further still..."
        "Much farther than it should be possible for your bathtub..."
        "You..."
        "You can't breathe."
        "You think you can't see either but..."
        "...as you draw your final breath..."
        show screen catEyesFade
        with dissolve
        pause .5
        "...you think you see what has been pulling you down."
        "Something resting deep, deep down below..."
        "Something waiting..."
        "..."
        "...for {i}you.{/i}"
        hide screen catEyesFade
        with dissolve
        "..."
        "Ending 14: Bath Hater"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending14Done:
            jump endAtHome
        else:
            $persistent.ending14Done = True
            $persistent.endCounter += 1
            jump endAtHome


    label cleanCareful:
        "You think careful is the way to go."
        "Cats aren't always fond of water, so you doubt it'll be a fan of an excessive amount of it."
        "So you pick the cat up and place it gently in the sink, before turning on the water."
        play sound "audio/cat_angryQUICK.mp3" volume 0.3
        cat "Meow!" with hpunch
        "The cat is startled but ultimately..."
        "...doesn't try to run away!"
        "Nice."
        play sound "audio/sink.mp3"
        scene bg cleanC1a
        with dissolve
        pause .6
        scene bg cleanC1b
        with dissolve
        pause .6
        scene bg cleanC1c
        with dissolve
        pause .6
        "You lather your hands with some soap and carefully give the cat a thorough half-scrub, half-massage."
        stop sound fadeout 5
        "After a few minutes, you rinse the cat completely and gather it up in a blanket, drying it."
        "Then you take a brush and carefully run it through the cat's fur."
        play sound "audio/cat_purr.mp3" volume 0.4
        cat "Purr... Purr... Purrr..."
        "The cat seems like it's in heaven as you brush it."
        "Some hairs are sticking to you, but you don't... mind..."
        stop music fadeout 4
        "..?"
        scene bg cleanC1d
        with dissolve
        "In fact..."
        scene bg cleanC1e
        with dissolve
        "...quite a {i}lot{/i} of fur is sticking on you."
        play music "audio/LOOPS/19furryFriendIN.mp3"
        queue music "audio/LOOPS/19furryFriendLOOP.mp3" loop
        "You try to brush it away but it won’t come off."
        "Guess you're up next for a bath yourself..."
        play sound "audio/cat_happyLONG.mp3" volume 0.3
        cat "Meow..."
        you "..."
        show screen dread
        with dissolve
        "You try to ignore the fur and finish with the cat quickly, but more hair keeps sticking to you."
        "Your hands, your arms.."
        "Before you realize it, they’re covered in fur that won’t come off."
        "It’s thick enough that you try to just yank it off but-"
        show screen blackOut
        hide screen dread
        with p_Red
        you "Ow! What..?"
        "Pain lances through the spot you tugged at."
        you "!!!" with vpunch
        "Upon closer inspection... {w}you see that the hair is..."
        "...{i}growing{/i}..."
        "..."
        "{size=-5}{b}...growing {i}out{/i} of you.{/b}{/size}"
        you "Ah... Ah..!"
        scene bg aptBath_DC
        hide screen blackOut
        with dissolve
        "You can actually {b}feel{/b} it now."
        show cleanC2
        with dissolve
        "Fur {i}growing{/i} out of your back, your neck..."
        show cleanC3
        with dissolve
        "your face..."
        show cleanC4
        with dissolve
        "your eyes..."
        show cleanC5
        with dissolve
        "your tongue..."
        scene bg aptBath_DC
        with dissolve
        "It's even growing inside your {i}throat-{/i}"
        scene bg aptBath_DC
        with p_Red
        you "*Gasp!* *Cough!* *Cough!*" with vpunch
        scene bg cleanC6a
        with dissolve
        pause .6
        scene bg cleanC6b
        with dissolve
        pause .6
        scene black
        with p_Red
        play music "audio/LOOPS/19furryFriendOUT.mp3" noloop
        ".."
        "..."
        "As you collapse and start to choke on the thickening fur in your esophagus..."
        "...the cat leans up to lap at the fur growing on your forehead..."
        "...grooming your hair as thoroughly as you did for it earlier."
        play sound "audio/cat_purr.mp3" volume 0.4
        cat "Purr... Purrr..."
        "You think it’d be sweet... {w}if you weren’t currently losing air."
        "Still."
        "Feels nice at least... {w}to be looked after and cared for in some way."
        "Even if it's just for a little while longer."
        "The cat’s careful grooming is the last thing you feel..."
        "..."
        "...before you’re no longer able to breath."
        "..."
        "Ending 15: Self-Care Buddies"
        # if persistent.testingNow:
        #     jump endAtHome
        if persistent.ending15Done:
            jump endAtHome
        else:
            $persistent.ending15Done = True
            $persistent.endCounter += 1
            jump endAtHome


label endAtHome:
    # $ persistent.testingNow = False


    return
